# Versión: limpieza de editores + micrófono + VSRadio

## Eliminado por redundancia

- VSAudio Simple: panel inferior de proyecto/exportación y pie informativo.
- VSMix: panel duplicado de transporte y pie informativo. El mezclador se conserva.

## Grabación

- Simple: grabación/stop, consentimiento antes de reemplazar archivo, visualización de tiempo y carga al editor.
- Mix: grabación/stop, visualización de tiempo, nueva pista Micrófono posicionada en el cursor inicial.

## VSRadio

- Nueva área de estación local con biblioteca, cola, Auto DJ, Deck A/B, crossfader, control de micrófono y grabación del programa.
- Guardar/reabrir proyectos `.vsradio` incluyendo fuentes, exportación de programación `.json`.
- Envío del WAV generado por Simple y de la mezcla WAV de Mix a la cola de VSRadio.

## Sin cambios

- Home cinematográfico y sus estilos.
- VSPack y base Blockbench; se mantiene su proceso de compilación única.
- Repositorio GitHub y plugin Folia.

## Pendiente

- Emisión real hacia Minecraft, conexión con Plasmo Voice/VSEngine, permisos y autenticación del servidor.
- Prueba con micrófono físico y dispositivos múltiples en CachyOS.
