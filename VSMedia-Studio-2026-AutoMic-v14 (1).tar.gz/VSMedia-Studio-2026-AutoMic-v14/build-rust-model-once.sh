#!/usr/bin/env bash
# Compila únicamente el núcleo geométrico opcional de VSMedia mediante wasm-pack.
# Mantiene la misma salida que scripts/build-all.sh para evitar builds divergentes.
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
MODEL="$ROOT/modules/vspack/vs-model-studio"
if ! command -v cargo >/dev/null 2>&1 || ! command -v rustup >/dev/null 2>&1; then
  echo '[VSMedia] Necesitás Rustup y Cargo para compilar el núcleo geométrico.' >&2
  exit 1
fi
if ! command -v wasm-pack >/dev/null 2>&1; then
  echo '[VSMedia] Instalando wasm-pack (una única vez)...'
  cargo install wasm-pack --locked
fi
rustup target add wasm32-unknown-unknown
cd "$MODEL/crates/vs_model_core"
# Importante: --out-dir es de wasm-pack; --features es de Cargo.
wasm-pack build --release --target web --out-dir ../../wasm -- --features wasm
[[ -s "$MODEL/wasm/vs_model_core.js" && -s "$MODEL/wasm/vs_model_core_bg.wasm" ]] || {
  echo '[VSMedia] wasm-pack no generó los dos archivos esperados.' >&2
  exit 1
}
printf '// Generado por build-rust-model-once.sh.\nexport const RUST_MODEL_WASM_READY = true;\n' > "$MODEL/embed/wasm-capability.js"
echo '[VSMedia] Rust geométrico compilado correctamente.'
