#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
printf '%s\n' '[VSMedia] Sintaxis + pruebas de regresión (Workspace v3)'
bash verify-ux-research.sh
printf '%s\n' '[VSMedia] Workspace v3 verificado.'
