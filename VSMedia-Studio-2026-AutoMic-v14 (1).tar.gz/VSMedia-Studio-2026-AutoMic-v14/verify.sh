#!/usr/bin/env sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
for file in assets/js/core.js assets/js/zip.js assets/js/simple.js assets/js/mix.js assets/js/vspack.js; do
  if command -v node >/dev/null 2>&1; then node --check "$file"; fi
done
test -f modules/vspack/vs-model-studio/js/main.ts
grep -Fq "entryPoints: ['./js/main.ts']" modules/vspack/vs-model-studio/build.js
if command -v node >/dev/null 2>&1; then
  node --check modules/vspack/assets/model-native.mjs
  node --check modules/vspack/assets/app.js
  node --check modules/vspack/vs-model-studio/embed/bridge.js
  node --check modules/vspack/vs-model-studio/embed/component.js
  node --test modules/vspack/vs-model-studio/tests/*.test.mjs
  node modules/vspack/test-compositor.mjs
  node modules/vspack/test-viewport.mjs
fi
if [ ! -s modules/vspack/vs-model-studio/dist/bundle.js ]; then
  printf '%s\n' 'AVISO: falta el bundle real de Blockbench. Copiá dist/bundle.js de tu compilación previa.' >&2
fi
test -f assets/css/simple.css
test -f assets/css/audio-pro.css
echo 'OK: estructura, fuente completa de Blockbench y sintaxis (si Node.js está disponible).'
