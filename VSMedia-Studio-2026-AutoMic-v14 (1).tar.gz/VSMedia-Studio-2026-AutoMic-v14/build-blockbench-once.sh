#!/usr/bin/env sh
# ONE-TIME packaging step only. NOT run by VSMedia on startup.
set -eu
cd "$(dirname "$0")/modules/vspack/vs-model-studio"
if [ -s dist/bundle.js ]; then
  node scripts/patch-embedded-bundle.mjs
  echo 'El bundle de Blockbench ya existe y sus parches de integración están aplicados.'
  exit 0
fi
if ! command -v npm >/dev/null 2>&1; then
  echo 'Falta npm en el equipo de BUILD, no en el equipo del usuario final.' >&2; exit 1
fi
npm ci --no-audit --no-fund
npm run build-web
test -s dist/bundle.js
node scripts/patch-embedded-bundle.mjs
# Installed Node dependencies are build-only: the deployed VSMedia runs with static dist files.
rm -rf node_modules
printf '%s\n' 'Bundle creado una sola vez; al distribuir VSMedia conservar dist/bundle.js.'
