# VS Model Studio — reparación de integración (9/11/2026)

Se revisó el **editor original Blockbench 5.2.2** que VSPack incluye en `modules/vspack/vs-model-studio`.

## Problemas encontrados

1. El integrador anterior (`assets/model-native.mjs`) recortaba el HTML de Blockbench, lo insertaba en el DOM de VSPack y cambiaba temporalmente el elemento `<base>`. Así los estilos globales, Vue, los recursos relativos, los paneles y la escena Three.js podían interferir entre editores.
2. La importación desde el pack usaba siempre el codec `.bbmodel`, incluso para `assets/.../models/*.json`.
3. La exportación no distinguía el JSON de Minecraft del proyecto editable `.bbmodel`.
4. El editor estaba separado visualmente del espacio disponible: varias barras de navegación reducían el área útil y podía quedarse una pantalla sin indicación al faltar `dist/bundle.js`.
5. El guardado iniciado desde un proyecto nuevo intentaba leer el nombre en `window.Project` del VSPack anfitrión, donde Blockbench nunca había inicializado ese objeto.

## Correcciones

- El editor **no se reconstruye**. Se monta el *documento original completo* de Blockbench como componente local `<vs-model-studio>` (iframe interno de mismo origen, no una web externa). La instancia original controla Vue, Three.js, sus menús y sus rutas. El contenedor le envía acciones mediante el puente `postMessage`, con validación de ventana y origen.
- La vista toma el espacio completo en VSPack: se ocultan sus menús externos redundantes únicamente mientras se edita un modelo. El panel de Blockbench sigue siendo el original.
- La barra estrecha de VSPack permite **Volver**, **Guardar en pack** y **Exportar archivo**, sin duplicar las herramientas de modelado de Blockbench.
- Importar/exportar `.bbmodel` conserva el codec original y las texturas embebidas. Modelos Java `.json` usan el codec original `java_block` tanto en apertura como en exportación.
- Guardar en pack escribe los bytes reales a IndexedDB de VSPack; en un modelo nuevo propone un nombre obtenido del proyecto del editor, no de variables globales de la web principal.
- `Ctrl+S` / `Cmd+S` en modo integrado solicita guardar en el pack. La navegación interna y el cierre advierten cuando se detectan cambios no guardados. Se distingue la exportación local del guardado al pack.
- Si falta el archivo compilado, aparece un mensaje comprensible en lugar de una pantalla vacía.

## Requisito del bundle

El ZIP entregado anteriormente **no** incluía el archivo compilado de Blockbench. El usuario informó una compilación exitosa (npm: `dist/bundle.js 4.2mb`), pero ese archivo **no estaba adjunto** a esta conversación.

Copiar desde la carpeta donde compilaste:

`modules/vspack/vs-model-studio/dist/bundle.js`

hacia esa misma ruta de esta entrega. **No ejecutar npm durante el arranque**. Si querés regenerarlo en una máquina de desarrollo una vez: `./build-blockbench-once.sh`; esto sí requiere dependencias npm para el build. Los demás módulos no las necesitan.

## Comprobaciones efectuadas

- `node --check` de adaptador, puente, componente y VSPack: correctos.
- `node --test` del puente y componente: 9 pruebas aprobadas, incluyendo origen, apertura `.bbmodel`, JSON Java, guardado y Ctrl+S.
- `node test-compositor.mjs` y `node test-viewport.mjs`: correctos.
- No se pudo probar el **Blockbench real compilado** en Chromium en este entorno: falta el bundle generado en el equipo del usuario, y el navegador de pruebas bloquea localhost. Se requiere validar modelo 3D, UVs y texturas en CachyOS con ese bundle.

No se modificaron el Home, Simple, VSMix, VSRadio ni sus estilos y códigos. No se modificó GitHub.
