/* Shared "Guardar en Resource Pack" action for all VSMedia audio editors. */
(()=>{'use strict';
let working=false;
const safeName=value=>String(value||'sonido').replace(/\.[a-z0-9]{2,5}$/i,'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9_.-]+/g,'_').replace(/^_+|_+$/g,'').slice(0,64)||'sonido';
function ask(source){return new Promise(resolve=>{
 const overlay=document.createElement('div');overlay.className='vs-pack-audio-overlay';overlay.id='vs-pack-audio-overlay';
 const packs=window.VSPackApp?.state()?.packs||[];
 const options=packs.map(p=>`<option value="${p.id}">${window.VS.escape(p.name)}</option>`).join('');
 overlay.innerHTML=`<form class="vs-pack-audio-dialog" role="dialog" aria-modal="true" aria-label="Guardar audio en Resource Pack"><header><h2>Guardar en Resource Pack</h2><button type="button" data-cancel aria-label="Cerrar">✕</button></header><p>VSMedia convierte el sonido a OGG/Vorbis en tu navegador y lo agrega a VS Pack junto con su evento de Minecraft.</p><label>Pack de destino<select name="packId"><option value="">${packs.length?'Pack activo / predeterminado':'Crear pack VSMedia Sonidos'}</option>${options}</select></label><label>Namespace<input name="namespace" pattern="[a-z0-9_.-]{1,40}" value="virgoland" required maxlength="40"></label><label>ID del sonido<input name="eventName" pattern="[a-z0-9_.\/-]+" value="${safeName(source)}" required maxlength="120"></label><label class="vs-pack-audio-check"><input type="checkbox" name="stream"> Música larga / streaming</label><output id="vs-pack-save-status" role="status"></output><footer><button type="button" data-cancel>Cancelar</button><button type="submit">Guardar en VS Pack</button></footer></form>`;
 document.body.append(overlay);
 const close=value=>{overlay.remove();resolve(value);};
 overlay.addEventListener('click',e=>{if(e.target===overlay||e.target.closest('[data-cancel]'))close(null);});
 overlay.querySelector('form').addEventListener('submit',e=>{e.preventDefault();const data=new FormData(e.currentTarget);close({packId:data.get('packId')||null,namespace:String(data.get('namespace')),eventName:String(data.get('eventName')),stream:data.has('stream')});});
 });}
async function save(file,{name,stream=false}={}){
 if(working)throw Error('Ya hay una exportación de audio en curso.');
 if(!(file instanceof Blob)||!file.size)throw Error('No hay audio para guardar.');
 if(!window.VSCodecs||!window.VSPackApp)throw Error('VS Pack o el codificador todavía no están disponibles.');
 const choice=await ask(name||file.name||'sonido');if(!choice)return null;
 working=true;
 try{
  window.VS.toast('Codificando OGG/Vorbis localmente…');
  const preset=stream||choice.stream?'mc-music':'mc-sfx';
  const result=await window.VSCodecs.convert(file,preset);
  const record=await window.VSPackApp.importSound({...choice,blob:result,stream:stream||choice.stream});
  window.VS.toast(`Guardado en ${record.packName}: ${record.eventId}`);
  return record;
 }finally{working=false;}
}
window.VSResourceAudio={save,safeName,_test:{safeName}};
})();
