/* VSMedia Auto Voice v14 — lightweight local adaptive gain and soft expander.
   Uses WebRTC capture filters when present. This is NOT AI/Krisp denoising.
   No server calls, no microphone data storage, no high-latency FFT models. */
(()=>{'use strict';
const clamp=(v,lo,hi)=>Math.min(hi,Math.max(lo,Number.isFinite(Number(v))?Number(v):lo));
function create({browserAgc=false}={}){
 let noiseDb=-68,gainDb=0,history=[],voice=false,lastVoice=-1e9,lastUpdate=-1e9,steps=0;
 function reset(){noiseDb=-68;gainDb=0;history=[];voice=false;lastVoice=-1e9;lastUpdate=-1e9;steps=0;}
 function step({inputDb=-96,outputDb=-96,peak=0,now=0}={}){
  const raw=clamp(inputDb,-96,0),out=clamp(outputDb,-96,0),pk=clamp(peak,0,1);
  const time=clamp(now,0,Number.MAX_SAFE_INTEGER);
  history.push(raw);
  if(history.length>90)history.shift();
  const sorted=history.slice().sort((a,b)=>a-b);
  // The lower fifth of the recent microphone envelope approximates room noise.
  // Cap the upper end conservatively so sustained speech is not learned as noise.
  const floorCandidate=Math.min(-46,sorted[Math.floor((sorted.length-1)*.2)]??-68);
  const smoothing=floorCandidate<noiseDb?.16:.015;
  noiseDb=clamp(noiseDb+(floorCandidate-noiseDb)*smoothing,-90,-46);
  const openAt=clamp(noiseDb+10,-68,-34);
  const recent=history.slice(-16),spread=recent.length>7?Math.max(...recent)-Math.min(...recent):0;
  const dynamics=spread>5 && raw>noiseDb+4 && raw>-64;
  const speaking=raw>openAt+(voice?-4:1) || dynamics;
  if(speaking){voice=true;lastVoice=time;}
  else if(time-lastVoice>400)voice=false;
  const fresh=steps<10;
  const gateFactor=fresh||voice?1:.45; // keep quiet syllables; never a hard binary gate
  if(voice && !fresh && time-lastUpdate>=90 && out>-65){
   // Only adapt while speaking. No 'gain hunting' or noise pumping in silence.
   // WebRTC AGC already adjusts hardware/stream gain on supported browsers.
   const desired=-23;
   const error=desired-out;
   let delta=clamp(error*.035,-.9,.24);
   if(pk>.90 || out>-8)delta=Math.min(delta,-.75);
   gainDb=clamp(gainDb+delta,-10,browserAgc?3:12);
   lastUpdate=time;
  }
  steps++;
  return {voice:voice||time-lastVoice<380,gainDb,noiseDb,gateDb:openAt,gateFactor,
          clipping:pk>.985,level:raw,webRtcAgc:browserAgc,calibrating:steps<15};
 }
 return {step,reset,get state(){return {noiseDb,gainDb,voice,steps,browserAgc};}};
}
window.VSAutoVoice=Object.freeze({create,clamp});
})();
