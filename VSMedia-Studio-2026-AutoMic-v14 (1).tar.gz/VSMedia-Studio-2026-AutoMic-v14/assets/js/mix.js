/* VSMix: self-contained multipista Web Audio editor (VSMedia 2026). */
(()=>{'use strict';
const {escape:E,$, $$,toast,download,filename,humanBytes,menu,initMenus,dialog,text}=window.VS||{};
// window.VS is assigned before DOMContentLoaded; use it only inside functions.
const colors=['#e8c6aa','#8fbeae','#d8bd7a','#c7979a','#9db18c','#a9b6c5','#c5a28c'];
const menus=[
 {label:'Archivo',actions:[{label:'Importar audios…',action:'import'},{label:'Abrir proyecto .vsmedia…',action:'openproject'},{label:'Guardar proyecto con archivos…',action:'saveproject'},{label:'Recuperar última sesión local…',action:'recover'},{label:'Borrar copia de recuperación…',action:'clearrecovery'},{label:'Exportar mezcla WAV…',action:'export'},{label:'Guardar mezcla en Resource Pack…',action:'savepack'},{label:'Exportar WebM/Opus para Chrome…',action:'exportwebm'},{label:'Enviar mezcla a VSRadio',action:'toradio'},{label:'Nuevo proyecto',action:'new'}]},
 {label:'Editar',actions:[{label:'Deshacer',action:'undo'},{label:'Rehacer',action:'redo'},{label:'Dividir clip en cursor (S)',action:'split'},{label:'Eliminar clip seleccionado (Supr)',action:'deleteclip'},{label:'Duplicar clip (D)',action:'duplicateclip'},{label:'Normalizar clip',action:'normalizeclip'},{label:'Mover clip al cursor',action:'movetocursor'},{label:'Desplazar clip -50 ms (Alt+←)',action:'nudgeleft'},{label:'Desplazar clip +50 ms (Alt+→)',action:'nudgeright'},{label:'Nueva pista vacía',action:'newtrack'},{label:'Duplicar pista completa',action:'duplicatetrack'},{label:'Mover pista hacia arriba',action:'trackup'},{label:'Mover pista hacia abajo',action:'trackdown'},{label:'Insertar silencio (pista vacía)',action:'newtrack'},{label:'Ajustar zoom a clips',action:'zoomfit'}]},
 {label:'Efectos',actions:[{label:'Activar/desactivar EQ de pista',action:'togglefx'},{label:'Restablecer EQ de pista',action:'resetfx'},{label:'Mostrar/ocultar consola',action:'togglemixer'},{label:'Fade in 0.5 s al clip',action:'fadein'},{label:'Fade out 0.5 s al clip',action:'fadeout'}]},
 {label:'Grabar',actions:[{label:'Iniciar grabación de micrófono',action:'record'},{label:'Detener grabación',action:'stoprecord'}]},
 {label:'Reproducción',actions:[{label:'Reproducir/Pausar (espacio)',action:'play'},{label:'Detener',action:'stop'},{label:'Volver al inicio',action:'rewind'},{label:'Marcar entrada del bucle (I)',action:'loopin'},{label:'Marcar salida del bucle (O)',action:'loopout'},{label:'Borrar región de bucle',action:'clearloop'},{label:'Crear marcador en cursor (K)',action:'addmarker'},{label:'Marcador anterior',action:'prevmarker'},{label:'Marcador siguiente',action:'nextmarker'},{label:'Activar/desactivar bucle (L)',action:'loop'}]},
 {label:'Ver',actions:[{label:'Acercar timeline',action:'zoomin'},{label:'Alejar timeline',action:'zoomout'},{label:'Ajustar clips a ventana',action:'zoomfit'},{label:'Restaurar zoom',action:'zoomreset'},{label:'Borrar marcadores',action:'clearmarkers'}]},
 {label:'Ayuda',actions:[{label:'Atajos y formatos',action:'help'}]}
];
const uid=()=>globalThis.crypto?.randomUUID?.()||'id-'+Math.random().toString(36).slice(2);
const S={assets:new Map(),tracks:[],selected:null,trackSelected:null,playhead:0,zoom:1,loop:false,playing:false,sources:[],audioCtx:null,startAt:0,raf:0,record:null,history:[],redo:[],search:'',tab:'mixer',snap:true,multi:false,rendering:false,renderCancel:false,recoveryTimer:0,recoveryWarned:false,markers:[],masterGain:.9,liveGraph:null,mixerCollapsed:false,loopRegion:{start:null,end:null},follow:true};
let root=null,renderTimer=0,layoutFrame=0;
const byId=id=>S.tracks.find(t=>t.id===id);
const locateClip=id=>{for(const t of S.tracks){const c=t.clips.find(x=>x.id===id);if(c)return {t,c};}return null;};
const duration=()=>Math.max(8,...S.tracks.flatMap(t=>t.clips.map(c=>c.start+c.length+2)),...S.markers.map(m=>m.at+2),0);
const pxps=()=>{const view=window.VS?.$("#timeline-view");const available=Math.max(260,(view?.clientWidth||960)-164);return Math.max(.0001,available/Math.max(1,duration()))*S.zoom;};
const timelineWidth=()=>Math.max(260,Math.ceil(duration()*pxps()));
// Escala 1-2-5: evita etiquetas encimadas cuando se amplía o reduce el timeline.
function rulerStep(pp){const minSpacing=85;const desired=minSpacing/Math.max(.0001,pp);const order=[1,2,5];const exponent=Math.floor(Math.log10(Math.max(.001,desired)));for(let n=exponent;n<=6;n++)for(const m of order){const step=m*10**n;if(step>=desired)return step;}return 3600;}
function rulerHtml(width,pp){const step=rulerStep(pp),count=Math.min(400,Math.ceil(width/(pp*step))+1);return Array.from({length:count},(_,i)=>{const seconds=i*step;return `<span class="ruler-tick" style="left:${seconds*pp}px">${fmt(seconds)}</span>`;}).join('');}
function loopBounds(region=S.loopRegion){const {start,end}=region;return Number.isFinite(start)&&Number.isFinite(end)&&start>=0&&end>start+.04?{start,end}:null;}
function regionDisplay(){const region=loopBounds(),out=window.VS?.$('#mix-loop-label');if(out)out.textContent=region?`A ${fmt(region.start)}.${String(Math.floor(region.start*10)%10)} · B ${fmt(region.end)}.${String(Math.floor(region.end*10)%10)}`:'A/B sin definir';const btn=window.VS?.$('#mix-loop-toggle');if(btn){btn.setAttribute('aria-pressed',String(!!S.loop));btn.classList.toggle('active',!!S.loop);}}
function markLoop(side){const at=Math.min(duration(),Math.max(0,getCursor()));saveUndo();if(side==='start'){S.loopRegion.start=at;if(S.loopRegion.end!==null&&S.loopRegion.end<=at+.04)S.loopRegion.end=null;}
 else{S.loopRegion.end=at;if(S.loopRegion.start!==null&&S.loopRegion.start>=at-.04)S.loopRegion.start=null;}
 renderTimeline();regionDisplay();}
function toggleFollow(){S.follow=!S.follow;const btn=window.VS?.$('#mix-follow-toggle');if(btn){btn.setAttribute('aria-pressed',String(S.follow));btn.classList.toggle('active',S.follow);}try{localStorage.setItem('vsmedia-follow-mix-v4',S.follow?'1':'0');}catch{}toast(S.follow?'Seguimiento del cursor activado.':'Seguimiento desactivado: podés navegar libremente.');}
function followHead(){if(!S.follow||!S.playing)return;const view=window.VS?.$('#timeline-view');if(!view||view.clientWidth<=0)return;const x=144+getCursor()*pxps(),left=view.scrollLeft,w=view.clientWidth;if(x>left+w*.88||x<left+144){view.scrollLeft=Math.max(0,x-w*.34);}}

/** Keep the time under the cursor fixed when the timeline is zoomed. */
function zoomTimeline(nextZoom,clientX=null){
 const view=window.VS.$('#timeline-view');
 if(!view)return;
 const rect=view.getBoundingClientRect(),anchor=clientX??(rect.left+rect.width/2);
 const oldPx=pxps(),point=anchor-rect.left;
 const sourceTime=Math.max(0,(view.scrollLeft+point-144)/Math.max(.0001,oldPx));
 S.zoom=Math.min(512,Math.max(.25,nextZoom));
 const slider=window.VS.$('#zoom-control');if(slider)slider.value=String(Math.log2(S.zoom));
 renderTimeline();
 view.dataset.lastPx=String(pxps());
 view.scrollLeft=Math.max(0,sourceTime*pxps()+144-point);
}
const fmt=s=>{s=Math.max(0,s||0);return `${String(Math.floor(s/60)).padStart(2,'0')}:${String(Math.floor(s%60)).padStart(2,'0')}`;};
const status=message=>{const el=window.VS.$('#mix-status');if(el)el.textContent=message;};
function ensureContext(){if(!S.audioCtx)S.audioCtx=new (window.AudioContext||window.webkitAudioContext)({latencyHint:'interactive'});if(S.audioCtx.state==='suspended')S.audioCtx.resume();return S.audioCtx;}
function saveUndo(){scheduleRecovery();S.history.push(JSON.stringify({tracks:S.tracks,selected:S.selected,trackSelected:S.trackSelected,markers:S.markers,masterGain:S.masterGain,loopRegion:S.loopRegion}));if(S.history.length>60)S.history.shift();S.redo.length=0;}
function historyRestore(src,dst){if(!src.length)return;stop();dst.push(JSON.stringify({tracks:S.tracks,selected:S.selected,trackSelected:S.trackSelected,markers:S.markers,masterGain:S.masterGain,loopRegion:S.loopRegion}));if(dst.length>60)dst.shift();const v=JSON.parse(src.pop());S.tracks=v.tracks;S.selected=v.selected;S.trackSelected=v.trackSelected;S.markers=v.markers||[];S.loopRegion=v.loopRegion||{start:null,end:null};S.masterGain=Number.isFinite(v.masterGain)?v.masterGain:.9;renderAll();}
function newTrack(name='Nueva pista',color){const track={id:uid(),name,color:color||colors[S.tracks.length%colors.length],gain:1,pan:0,mute:false,solo:false,fx:false,hp:20,lp:18000,low:0,mid:0,high:0,comp:false,threshold:-18,ratio:3,send:0,clips:[]};S.tracks.push(track);return track;}
function addClip(track,asset,start=0){const c={id:uid(),assetId:asset.id,start:Math.max(0,start),offset:0,length:Math.max(.05,asset.buffer.duration),gain:1,fadeIn:0,fadeOut:0};track.clips.push(c);return c;}
async function loadFile(file,addToTrack=true){const accepted=/\.(wav|mp3|ogg|flac|m4a|opus|webm|aac)$/i.test(file.name)||file.type.startsWith('audio/');if(!accepted)throw Error('Formato de audio no compatible: '+file.name);if(file.size>75*1048576)throw Error('Audio demasiado grande (máx. 75 MiB): '+file.name);
 const ctx=ensureContext(),bytes=new Uint8Array(await file.arrayBuffer());let buffer;try{buffer=await ctx.decodeAudioData(bytes.buffer.slice(0));}catch{throw Error('No se pudo decodificar '+file.name+' en este navegador.');}
 if(!Number.isFinite(buffer.duration)||buffer.duration>5400)throw Error('Duración máxima por archivo: 90 minutos.');
 const a={id:uid(),name:file.name,type:file.type||'application/octet-stream',bytes,buffer};S.assets.set(a.id,a);
 if(addToTrack){saveUndo();const t=newTrack(file.name.replace(/\.[^/.]+$/,''));S.selected=addClip(t,a).id;S.trackSelected=t.id;}return a;
}
async function importAudio(files){if(!files?.length)return;let ok=0,errors=[];status('Importando y decodificando audio…');for(const file of files){try{await loadFile(file);ok++;}catch(e){errors.push(e.message);}}renderAll();const msg=`${ok} audio(s) importado(s)${errors.length?' · '+errors[0]:''}`;status(msg);toast(msg,!!errors.length);}
function rootHtml(){return `<div class="audio-root"><header class="work-header"><button class="work-back" data-a="home">← Inicio</button><span class="work-brand"><span class="v">▽</span> VSMEDIA</span><span class="work-section">VSMIX · EDICIÓN MULTIPISTA</span><button class="work-tool" data-a="simple">VSAudio Simple</button><button class="work-tool" data-a="radio">VSRadio ↗</button><div class="work-fill"></div><span class="work-mini" id="mix-recovery-status">Sin copia local</span><button class="work-tool soft" id="mix-recovery-btn" data-a="recover" hidden title="Restaurar sesión tras un cierre inesperado">↶ Recuperar</button><button class="work-tool soft" data-a="saveproject">Guardar proyecto</button><button class="work-tool" data-a="exportwebm" title="WebM/Opus liviano para Chrome / Chromium">↓ WebM</button><button class="work-tool primary" data-a="export">↓ Exportar WAV</button><button class="work-tool" data-a="savepack" title="Mezcla en OGG/Vorbis para Minecraft">⇣ Resource Pack</button></header>
 ${window.VS.menu(menus)}
 <div class="audio-tools"><div class="transport-actions"><button class="transport-btn" data-a="rewind" title="Inicio">⏮</button><button class="transport-btn play" data-a="play" id="play-button" title="Reproducir/Pausar">▶</button><button class="transport-btn" data-a="stop" title="Detener">■</button><button class="transport-btn mix-loop-toggle" id="mix-loop-toggle" data-a="loop" aria-pressed="false" title="Bucle entre A y B · tecla L">⟲</button><button class="transport-btn mic-record" data-a="record" id="record-button" title="Grabar micrófono" aria-label="Grabar o detener micrófono">● <span>Grabar</span></button>${window.VSMic.controls()}<span class="mic-time" id="mix-record-timer" hidden>REC 00:00</span></div><div class="time-display" id="audio-clock">00:00</div><span class="muted tiny">/</span><span class="tiny" id="audio-total">00:00</span><div class="work-fill"></div><button class="work-tool mix-follow-toggle active" id="mix-follow-toggle" data-a="follow" aria-pressed="true" title="Seguir el cursor al reproducir">⌖ Seguir</button><output class="mix-export-progress" id="mix-render-progress" role="status" hidden></output><button class="work-tool mix-cancel-export" data-a="cancelrender" id="mix-cancel-export" hidden>✕ Cancelar exportación</button><button class="work-tool" data-a="zoomout" title="Alejar timeline">−</button><label>ZOOM <input type="range" min="-2" max="9" step="0.05" value="0" id="zoom-control"></label><button class="work-tool" data-a="zoomin" title="Acercar timeline">＋</button><label><input type="checkbox" id="snap-control" checked> Snap</label><button class="work-tool" data-a="zoomfit" title="Ajustar toda la mezcla a ventana">⤢ Ajustar</button><button class="work-tool" data-a="newtrack">＋ Pista</button><button class="work-tool" data-a="import">＋ Importar audio</button></div>
 <div class="work-titlebar"><div><h1>VSMix <span class="editor-title-accent">Studio</span></h1><small>Sesión multipista · Edición no destructiva · Mezcla local</small></div><div class="work-fill"></div><span class="chip" id="track-count">0 pistas</span><span class="chip" id="asset-count">0 audios</span><span class="mix-status-indicator" id="mix-status" aria-live="polite">Listo</span></div>
 <div class="audio-layout"><section class="pane audio-library"><div class="pane-caption"><span>BIBLIOTECA</span><span class="count">ARCHIVOS</span></div><div class="audio-lib-tools"><input type="search" placeholder="Buscar audio…" id="audio-search"><button class="panel-btn primary" data-a="import" title="Importar">＋</button></div><div class="audio-lib-list pane-body" id="audio-assets"></div><div class="audio-lib-hint">Arrastrá audio al timeline o pulsá ＋ para crear una pista automáticamente. Los archivos no salen de tu equipo.</div></section>
 <section class="pane audio-center"><div class="pane-caption"><span>PRINCIPAL</span><span class="count">TIMELINE</span></div><div class="timeline-top"><span class="tiny mix-loop-controls"><b>EDICIÓN</b> · S = dividir <button class="tiny-btn" data-a="loopin" title="Entrada del bucle: I">[ A</button><button class="tiny-btn" data-a="loopout" title="Salida del bucle: O">B ]</button><span id="mix-loop-label" aria-live="polite">A/B sin definir</span></span><div class="right"><button class="tiny-btn" data-a="split" title="Dividir en cursor">✂ Dividir</button><button class="tiny-btn" data-a="duplicateclip">⧉ Duplicar</button><button class="tiny-btn" data-a="normalizeclip">◭ Normalizar</button><button class="tiny-btn" data-a="deleteclip" title="Eliminar clip">✕ Clip</button><button class="tiny-btn" data-a="zoomfit" title="Ajustar zoom">⤢</button></div></div><div class="timeline-frame"><div class="timeline-view scrollbar" id="timeline-view"><div class="timeline-inner" id="timeline-inner"></div></div></div></section>
 <aside class="pane audio-inspector"><div class="pane-caption"><span>INSPECTOR</span><span class="count">EFECTOS</span></div><div class="inspector-tabs"><button data-inspect="clip" class="active">Clip</button><button data-inspect="fx">Efectos / EQ</button></div><div class="inspector-body pane-body" id="audio-inspector-body"></div></aside>
 <section class="pane audio-bottom"><div class="pane-caption"><span>MEZCLADOR · CONSOLA</span><div class="mix-console-head"><label>MASTER <input type="range" id="mix-master-gain" min="0" max="1.5" step="0.01" value=".9" aria-label="Master general"></label><output id="mix-master-output">−0.9 dB</output><button class="tiny-btn" data-a="togglemixer" title="Mostrar u ocultar consola">▤</button></div></div><div id="audio-bottom-content" class="mixer-list"></div></section></div></div>`;}
function getCursor(){if(S.playing&&S.audioCtx)return Math.max(0,S.audioCtx.currentTime-S.startAt);return S.playhead;}
function halt(){for(const src of S.sources){try{src.stop()}catch{}}S.sources=[];S.playing=false;cancelAnimationFrame(S.raf);S.liveGraph?.dispose();S.liveGraph=null;const b=window.VS.$('#play-button');if(b)b.textContent='▶';}
function stop(){halt();S.playhead=0;updateClock();}
function pause(){S.playhead=getCursor();halt();updateClock();}
function seek(sec){let play=S.playing;halt();S.playhead=Math.max(0,Math.min(sec,duration()));if(play)playAudio();else updateClock();}
// Grafo por pista: EQ de tres bandas, compresor, paneo, send de eco y limitador master.
// El mismo grafo se utiliza para escuchar y para exportar con OfflineAudioContext.
function createMixerGraph(ctx,live=false){
 const nodes=[],make=(method,...args)=>{const node=ctx[method](...args);nodes.push(node);return node;};
 const master=make('createGain'),limiter=make('createDynamicsCompressor');
 limiter.threshold.value=-1;limiter.knee.value=0;limiter.ratio.value=18;limiter.attack.value=.003;limiter.release.value=.09;
 master.gain.value=S.masterGain;master.connect(limiter).connect(ctx.destination);
 const echo=make('createDelay',1),feedback=make('createGain'),wet=make('createGain');
 echo.delayTime.value=.24;feedback.gain.value=.26;wet.gain.value=.25;
 echo.connect(feedback).connect(echo);echo.connect(wet).connect(master);
 const buses=new Map();
 for(const t of S.tracks){
   const input=make('createGain'),hp=make('createBiquadFilter'),low=make('createBiquadFilter'),mid=make('createBiquadFilter'),high=make('createBiquadFilter'),lp=make('createBiquadFilter');
   hp.type='highpass';lp.type='lowpass';
   low.type='lowshelf';low.frequency.value=160;
   mid.type='peaking';mid.frequency.value=1300;mid.Q.value=.9;
   high.type='highshelf';high.frequency.value=6200;
   const comp=make('createDynamicsCompressor'),pan=make('createStereoPanner'),vol=make('createGain'),send=make('createGain');
   input.connect(hp).connect(low).connect(mid).connect(high).connect(lp).connect(comp).connect(pan).connect(vol);
   vol.connect(master);vol.connect(send).connect(echo);
   const strip={input,hp,low,mid,high,lp,comp,pan,vol,send};buses.set(t.id,strip);
   updateStrip(ctx,strip,t);
 }
 const graph={master,limiter,buses,dispose(){for(const n of nodes){try{n.disconnect();}catch{}}}};
 if(live)S.liveGraph=graph;
 return graph;
}
function updateStrip(ctx,b,t){
 const set=(param,value)=>{if(!Number.isFinite(value))return;param.setTargetAtTime(value,ctx.currentTime,.018);};
 const silent=t.mute||S.tracks.some(x=>x.solo)&&!t.solo;
 set(b.vol.gain,silent?0:Math.max(0,Math.min(2,Number(t.gain)||0)));
 set(b.pan.pan,Math.max(-1,Math.min(1,Number(t.pan)||0)));
 set(b.hp.frequency,t.fx?t.hp:20);set(b.lp.frequency,t.fx?t.lp:20000);
 set(b.low.gain,Number(t.low)||0);set(b.mid.gain,Number(t.mid)||0);set(b.high.gain,Number(t.high)||0);
 set(b.comp.threshold,t.comp?(Number.isFinite(Number(t.threshold))?Number(t.threshold):-18):0);
 set(b.comp.ratio,t.comp?(Number(t.ratio)||3):1);
 set(b.send.gain,Math.max(0,Math.min(.6,Number(t.send)||0)));
}
function updateLiveTrack(t){const graph=S.liveGraph;if(graph&&S.audioCtx){const b=graph.buses.get(t.id);if(b)updateStrip(S.audioCtx,b,t);}}
function routeBuffer(ctx,buffer,c,t,startWhen,position,buses,sourceList=S.sources){
 // The audible segment starts at max(playhead, clip start). Never schedule beyond
 // the visible trimmed clip: offset is a position in the source, NOT its duration.
 const from=Math.max(position,c.start),elapsed=from-c.start,off=c.offset+elapsed;
 const len=Math.min(c.length-elapsed,buffer.duration-off);
 if(!Number.isFinite(len)||len<=.0001)return;
 const source=ctx.createBufferSource(),gain=ctx.createGain();source.buffer=buffer;
 source.connect(gain).connect(buses.get(t.id).input);
 const envelope=p=>{const relative=p-c.start;let a=1;if(c.fadeIn>0)a=Math.min(a,Math.max(0,relative/c.fadeIn));if(c.fadeOut>0)a=Math.min(a,Math.max(0,(c.length-relative)/c.fadeOut));return Math.max(0,a)*c.gain;};
 const when=startWhen+(from-position),finish=when+len;
 gain.gain.setValueAtTime(envelope(from),when);
 if(c.fadeIn>0){const x=c.start+c.fadeIn;if(x>from&&x<from+len)gain.gain.linearRampToValueAtTime(envelope(x),startWhen+(x-position));}
 if(c.fadeOut>0){const x=c.start+c.length-c.fadeOut;if(x>from&&x<from+len)gain.gain.setValueAtTime(envelope(x),startWhen+(x-position));}
 if(c.fadeOut>0)gain.gain.linearRampToValueAtTime(0,finish);
 source.start(when,off,len);sourceList.push(source);
}
function schedule(ctx,at,offset,live=false,sourceList=S.sources){
 const graph=createMixerGraph(ctx,live);
 for(const t of S.tracks)for(const c of t.clips){if(c.start+c.length<=offset)continue;const a=S.assets.get(c.assetId);if(a)routeBuffer(ctx,a.buffer,c,t,at,offset,graph.buses,sourceList);}
 return graph;
}
function playAudio(){if(S.playing){pause();return;}if(!S.tracks.some(t=>t.clips.length)){toast('Importá un audio antes de reproducir.',true);return;}
 const ctx=ensureContext();const region=loopBounds();if(S.loop&&region&&(S.playhead<region.start||S.playhead>=region.end))S.playhead=region.start;else if(S.playhead>=duration())S.playhead=0;S.playing=true;S.startAt=ctx.currentTime-S.playhead;const at=ctx.currentTime+.04;S.startAt+=.04;try{schedule(ctx,at,S.playhead,true);}catch(e){halt();toast(e.message,true);return;}
 window.VS.$('#play-button').textContent='Ⅱ';tick();}
function tick(){if(!S.playing)return;const pos=getCursor(),region=loopBounds();if(S.loop&&region&&pos>=region.end){seek(region.start);return;}if(pos>=duration()) {if(S.loop){seek(region?.start||0);return;}pause();return;}updateClock();followHead();S.raf=requestAnimationFrame(tick);}
function updateMeters(pos){
 const channelBoxes=window.VS?.$$('[data-meter-id]')||[];
 for(const box of channelBoxes){const t=byId(box.dataset.meterId);if(!t||!S.playing||t.mute||(S.tracks.some(x=>x.solo)&&!t.solo)){box.style.width='0%';continue;}let peak=0;
 for(const c of t.clips){const a=S.assets.get(c.assetId);if(!a||pos<c.start||pos>c.start+c.length)continue;const rate=a.buffer.sampleRate,at=Math.floor((c.offset+pos-c.start)*rate),ar=a.buffer.getChannelData(0);
 const span=Math.min(1024,Math.max(0,ar.length-at));for(let i=0;i<span;i+=16){peak=Math.max(peak,Math.abs(ar[at+i]||0)*c.gain*t.gain);}}
 box.style.width=Math.min(100,peak*100)+'%';box.classList.toggle('meter-clipping',peak>.98);
 }
}
function updateClock(){const p=getCursor();updateMeters(p);const label=window.VS.$('#audio-clock');if(label)label.textContent=fmt(p);const ph=window.VS.$('#audio-playhead');if(ph)ph.style.left=(144+p*pxps())+'px';}
function mixRecordingIndicator(){const button=window.VS.$('#record-button'),badge=window.VS.$('#mix-record-timer');if(!button||!badge)return;
 const on=!!S.record;button.classList.toggle('recording',on);button.querySelector('span').textContent=on?'Detener':'Grabar';badge.hidden=!on;
 if(on){const elapsed=Math.max(0,(Date.now()-S.record.began)/1000);badge.textContent='REC '+fmt(elapsed);}}
async function recordToggle(stopOnly=false){
 if(S.record){const r=S.record;S.record=null;clearInterval(r.timer);mixRecordingIndicator();if(r.recorder.state!=='inactive')r.recorder.stop();status('Procesando grabación del micrófono…');return;}
 if(stopOnly)return;
 if(!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder){toast('Necesitás localhost o HTTPS y un navegador con MediaRecorder para grabar.',true);return;}
 try{
   const startAt=getCursor();const session=await window.VSMic.open();const stream=session.stream;
   let rec;try{rec=new MediaRecorder(stream);}catch(e){session.stop();throw e;}
   const chunks=[];rec.ondataavailable=e=>{if(e.data?.size)chunks.push(e.data);};rec.onerror=e=>toast('Error del micrófono: '+(e.error?.message||'no se pudo grabar'),true);
   rec.onstop=async()=>{try{if(!chunks.length)throw Error('No hay audio grabado.');const blob=new Blob(chunks,{type:rec.mimeType||'audio/webm'}),ext=blob.type.includes('ogg')?'ogg':blob.type.includes('mp4')?'m4a':'webm';
     const file=new File([blob],`Microfono-${Date.now()}.${ext}`,{type:blob.type});
     const before=new Set(S.assets.keys());await loadFile(file,false);
     const asset=[...S.assets.values()].find(a=>!before.has(a.id));if(!asset)throw Error('No se pudo agregar el audio.');
     saveUndo();const track=newTrack('Micrófono', '#ec9daa');const clip=addClip(track,asset,startAt);S.trackSelected=track.id;S.selected=clip.id;
     refreshAudio();renderAll();toast('Micrófono agregado como pista independiente en '+fmt(startAt)+'.');status('Grabación incorporada al timeline.');
   }catch(e){toast('No se pudo importar la grabación: '+e.message,true);}finally{session.stop();}};
   rec.start(300);S.record={stream,session,recorder:rec,began:Date.now(),timer:null};S.record.timer=setInterval(mixRecordingIndicator,400);mixRecordingIndicator();
   status('Grabando micrófono · nuevo clip desde '+fmt(startAt));
 }catch(e){toast('No se pudo iniciar la grabación: '+e.message,true);}}
function exportFeedback(progress,part,count){const out=root?.querySelector('#mix-render-progress');if(out){out.hidden=false;out.textContent=`Renderizando ${Math.round(progress*100)}% · bloque ${part}/${count}`;}status(`Exportando mezcla: ${Math.round(progress*100)}% · ${part}/${count} bloques`);}
async function renderAudio(target='download'){
 if(S.rendering)return;
 if(!S.tracks.some(t=>t.clips.length))return toast('No hay pistas para exportar.',true);
 let length=0;for(const t of S.tracks)for(const c of t.clips)length=Math.max(length,c.start+c.length);
 if(length<=0)return;
 const spec=window.VSMixExport.plan(length);
 const MAX_BROWSER=512*1048576,MAX_CODEC=384*1048576;
 if(target==='pack'&&spec.bytes>128*1048576)return toast('Para guardar en VS Pack, exportá una mezcla de hasta 128 MiB en WAV y menos de 30 minutos.',true);
   if(target==='webm'&&spec.bytes>MAX_CODEC)return toast('Esta mezcla supera el límite del conversor local (384 MiB de WAV). Exportá WAV por partes o acortá la sesión.',true);
 if(target==='radio'&&spec.bytes>75*1048576)return toast('Para VSRadio, convertí la mezcla larga a Opus antes de incorporarla.',true);
 let sink=null;
 if(target==='download'&&spec.bytes>240*1048576&&typeof window.showSaveFilePicker==='function'){
  try{const file=await window.showSaveFilePicker({suggestedName:'VSMix-mezcla-'+Date.now()+'.wav',types:[{description:'Audio WAV',accept:{'audio/wav':['.wav']}}]});sink=await file.createWritable();}
  catch(e){if(e?.name==='AbortError')return;console.warn('[VSMix] Guardado directo no disponible:',e);}
 }
 if(!sink&&spec.bytes>MAX_BROWSER)return toast('El WAV supera 512 MiB. En Chrome podés guardarlo por bloques; en Firefox dividí la sesión para evitar agotar la memoria.',true);
 if(!sink&&spec.bytes>160*1048576){const yes=await dialog('Exportación grande',`<p>La mezcla durará ${Math.ceil(length/60)} min y ocupará aproximadamente ${(spec.bytes/1048576).toFixed(0)} MiB en WAV.</p><p>El renderizado se hará en bloques de 30 segundos. No cierres esta pestaña; podés cancelar durante el proceso.</p>`,[{label:'Continuar',value:true,primary:true},{label:'Cancelar'}]);if(!yes)return;}
 S.rendering=true;S.renderCancel=false;
 const cancel=root?.querySelector('#mix-cancel-export');if(cancel)cancel.hidden=false;
 status('Preparando exportación por bloques…');
 try{
  const result=await window.VSMixExport.render({duration:length,rate:44100,blockSeconds:30,prerollSeconds:2.4,
   Context:window.OfflineAudioContext||window.webkitOfflineAudioContext,
   schedule:(ctx,offset)=>schedule(ctx,0,offset,false,[]),cancelled:()=>S.renderCancel,onProgress:exportFeedback,sink});
  if(cancel)cancel.hidden=true;
  if(sink){await sink.close();sink=null;toast('WAV guardado directamente en disco.');status('Exportación completada.');}
  else if(target==='webm'){status('Comprimiendo mezcla WebM/Opus con FFmpeg local…');const converted=await window.VSCodecs.convert(result.blob,'webm-radio-96');download(converted,'VSMedia-mezcla-'+Date.now()+'.webm');toast('WebM/Opus exportado correctamente.');status('Audio comprimido y exportado.');}
  else if(target==='pack'){await window.VSResourceAudio.save(result.blob,{name:'VSMix-mezcla',stream:length>40});status('Mezcla enviada a VS Pack.');}
  else if(target==='radio'){await window.VSRadioApp.importFile(new File([result.blob],'VSMix-programa-'+Date.now()+'.wav',{type:'audio/wav'}));window.VS.navigate('radio');toast('Mezcla enviada a VSRadio.');status('Audio enviado a VSRadio.');}
  else{download(result.blob,'VSMedia-mezcla-'+Date.now()+'.wav');toast('WAV exportado por bloques, sin truncar la sesión.');status('Exportación terminada.');}
 }catch(e){if(sink){try{await sink.abort();}catch{}}if(S.renderCancel)toast('Exportación cancelada, sin modificar el proyecto.');else toast('No se pudo exportar: '+e.message,true);status(S.renderCancel?'Exportación cancelada.':'La exportación falló.');}
 finally{S.rendering=false;S.renderCancel=false;if(cancel)cancel.hidden=true;const out=root?.querySelector('#mix-render-progress');if(out)out.hidden=true;}
}
function encodeWav(buffer){const channels=2,frames=buffer.length,bytes=frames*4+44;const raw=new ArrayBuffer(bytes),dv=new DataView(raw);let p=0;const str=x=>{for(let i=0;i<x.length;i++)dv.setUint8(p++,x.charCodeAt(i));};const w16=n=>{dv.setUint16(p,n,true);p+=2;};const w32=n=>{dv.setUint32(p,n,true);p+=4;};str('RIFF');w32(bytes-8);str('WAVE');str('fmt ');w32(16);w16(1);w16(2);w32(buffer.sampleRate);w32(buffer.sampleRate*4);w16(4);w16(16);str('data');w32(frames*4);const L=buffer.getChannelData(0),R=buffer.getChannelData(1);for(let i=0;i<frames;i++){dv.setInt16(p,Math.max(-32768,Math.min(32767,Math.round(L[i]*32767))),true);p+=2;dv.setInt16(p,Math.max(-32768,Math.min(32767,Math.round(R[i]*32767))),true);p+=2;}return new Blob([raw],{type:'audio/wav'});}
function recoveryManifest(){return {format:'vsmedia-studio',schema:1,tracks:S.tracks,markers:S.markers,masterGain:S.masterGain,loopRegion:S.loopRegion,assets:[...S.assets.values()].map(a=>({id:a.id,name:a.name,type:a.type,file:`audio/${a.id}.bin`}))};}
function showRecoveryInfo(info){const btn=root?.querySelector('#mix-recovery-btn'),indicator=root?.querySelector('#mix-recovery-status');if(btn)btn.hidden=!info;if(indicator)indicator.textContent=info?'Copia local '+new Date(info.savedAt).toLocaleTimeString('es-AR',{hour:'2-digit',minute:'2-digit'}):'Sin copia local';}
function scheduleRecovery(){if(!S.assets.size||!window.VSMixRecovery)return;clearTimeout(S.recoveryTimer);S.recoveryTimer=setTimeout(()=>{void flushRecovery();},2600);}
async function flushRecovery(){clearTimeout(S.recoveryTimer);S.recoveryTimer=0;if(!S.assets.size||!window.VSMixRecovery)return;
 try{const info=await window.VSMixRecovery.save(recoveryManifest(),[...S.assets.values()].map(a=>({id:a.id,name:a.name,type:a.type,bytes:a.bytes})));showRecoveryInfo(info);S.recoveryWarned=false;}
 catch(e){console.warn('[VSMix] No se pudo crear copia local:',e);if(!S.recoveryWarned){S.recoveryWarned=true;toast('No se pudo guardar la recuperación automática. Exportá el proyecto manualmente.',true);}}}
async function recoverSession(){const backup=await window.VSMixRecovery?.restore?.();if(!backup)return toast('No existe una sesión recuperable.',true);
 const yes=await dialog('Recuperar sesión de VSMix',`<p>Copia guardada el ${new Date(backup.savedAt).toLocaleString('es-AR')} · ${backup.model.tracks?.length||0} pistas · ${backup.assets.length} archivos.</p><p>Esto reemplazará el montaje abierto. Guardá el proyecto actual si necesitás conservarlo.</p>`,[{label:'Recuperar sesión',value:true,primary:true},{label:'Cancelar'}]);
 if(!yes)return;
 const files=new Map([['project.json',new TextEncoder().encode(JSON.stringify(backup.model))]]);
 for(const a of backup.assets)files.set(`audio/${a.id}.bin`,a.bytes);
 await openProject(new File([window.VSZip.write(files)],'VSMix-Recuperacion.vsmedia',{type:'application/zip'}));
}
async function clearRecovery(){const yes=await dialog('Eliminar recuperación local','<p>¿Borrar la copia automática de VSMix? No afecta al proyecto que está abierto ni a los archivos exportados.</p>',[{label:'Borrar copia',value:true,primary:true},{label:'Cancelar'}]);if(!yes)return;clearTimeout(S.recoveryTimer);S.recoveryTimer=0;await window.VSMixRecovery?.clear?.();showRecoveryInfo(null);toast('Copia de recuperación eliminada.');}
async function saveProject(){if(!S.assets.size){toast('Importá audio para crear un proyecto.');return;}try{const manifest=recoveryManifest();const files=new Map([['project.json',text(JSON.stringify(manifest,null,2))]]);for(const a of S.assets.values())files.set(`audio/${a.id}.bin`,a.bytes);download(window.VSZip.write(files),'VSMedia-proyecto-'+Date.now()+'.vsmedia');toast('Proyecto completo guardado con audio incluido.');}catch(e){toast('No se pudo guardar el proyecto: '+e.message,true);}}
async function openProject(file){let files;try{files=await window.VSZip.read(file,{maxCompressed:450*1048576,maxTotal:900*1048576,maxItem:80*1048576,maxFiles:400});}catch(e){toast('Proyecto inválido: '+e.message,true);return;}
 const raw=files.get('project.json');if(!raw){toast('No existe project.json en ese proyecto.',true);return;}let obj;try{obj=JSON.parse(new TextDecoder().decode(raw));}catch(e){toast('Manifiesto JSON incorrecto.',true);return;}
 if(obj?.format!=='vsmedia-studio'||obj.schema!==1||!Array.isArray(obj.assets)||!Array.isArray(obj.tracks)||obj.tracks.length>64||obj.assets.length>500){toast('Proyecto no compatible.',true);return;}
 const ctx=ensureContext(),nextAssets=new Map();try{for(const a of obj.assets){if(!/^[\w-]+$/.test(a.id)||typeof a.name!=='string'||a.name.length>250)throw Error('Referencia de audio inválida');const bytes=files.get(a.file);if(!bytes)throw Error('Falta el audio '+a.name);const buffer=await ctx.decodeAudioData(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength));nextAssets.set(a.id,{...a,bytes,buffer});}
 for(const t of obj.tracks){if(!Array.isArray(t.clips)||t.clips.length>800)throw Error('Demasiados clips');for(const c of t.clips){if(!nextAssets.has(c.assetId)||!Number.isFinite(c.start)||!Number.isFinite(c.length)||c.length<=0||c.start<0)throw Error('Clip inválido')}}
 halt();S.assets=nextAssets;S.tracks=obj.tracks.map(t=>({...{gain:1,pan:0,mute:false,solo:false,fx:false,hp:20,lp:18000,low:0,mid:0,high:0,comp:false,threshold:-18,ratio:3,send:0},...t}));S.masterGain=Number.isFinite(obj.masterGain)?Math.min(1.5,Math.max(0,obj.masterGain)):.9;S.markers=Array.isArray(obj.markers)?obj.markers.slice(0,200).filter(m=>Number.isFinite(m.at)&&m.at>=0&&m.at<5400&&typeof m.name==='string').map(m=>({at:m.at,name:m.name.slice(0,70)})):[];const reg=obj.loopRegion||{};S.loopRegion={start:Number.isFinite(reg.start)&&reg.start>=0&&reg.start<=5400?reg.start:null,end:Number.isFinite(reg.end)&&reg.end>=0&&reg.end<=5400?reg.end:null};S.selected=null;S.trackSelected=null;S.playhead=0;S.history=[];S.redo=[];renderAll();scheduleRecovery();toast('Proyecto restaurado con '+obj.tracks.length+' pistas.');status('Proyecto cargado correctamente.');
 }catch(e){toast('No se pudo abrir proyecto: '+e.message,true);}}
function renderAssets(){const zone=window.VS.$('#audio-assets');if(!zone)return;let list=[...S.assets.values()].filter(a=>a.name.toLowerCase().includes(S.search.toLowerCase()));zone.innerHTML=list.length?list.map(a=>`<button class="lib-item" draggable="true" data-asset="${a.id}" title="Agregar a una nueva pista o arrastrar al timeline"><span class="disc">◉</span><span class="lib-name"><strong>${window.VS.escape(a.name)}</strong><small>${fmt(a.buffer.duration)} · ${humanBytes(a.bytes.byteLength)}</small></span><span class="lib-add">＋</span></button>`).join(''):`<div class="empty">Sin audios todavía.<br>Importá WAV, MP3, OGG o WebM.</div>`;
 $$('[data-asset]',zone).forEach(b=>{b.onclick=()=>{saveUndo();const a=S.assets.get(b.dataset.asset),t=newTrack(a.name.replace(/\.[^/.]+$/,''));S.selected=addClip(t,a,S.playhead).id;S.trackSelected=t.id;renderAll();};b.ondragstart=e=>e.dataTransfer.setData('text/vsmedia-audio',b.dataset.asset);});window.VS.$('#asset-count').textContent=`${S.assets.size} ${S.assets.size===1?'audio':'audios'}`;
}
function renderTimeline(){const frame=window.VS.$('#timeline-inner');if(!frame)return;const width=timelineWidth(),p=pxps();frame.style.width=(width+144)+'px';frame.innerHTML=`<div class="ruler-row"><div class="ruler-label">PISTAS</div><div class="ruler-content" id="audio-ruler" style="width:${width}px">${rulerHtml(width,p)}${S.markers.map((m,i)=>`<button class="mix-marker" data-marker="${i}" style="left:${m.at*p}px" title="${window.VS.escape(m.name)} · ${fmt(m.at)}">◆</button>`).join('')}</div></div>${loopBounds()?`<div class="mix-loop-band" style="left:${144+loopBounds().start*p}px;width:${(loopBounds().end-loopBounds().start)*p}px" aria-hidden="true"></div>`:''}`+S.tracks.map(t=>`<div class="track-row" data-track="${t.id}"><div class="track-meta"><input class="track-name" value="${window.VS.escape(t.name)}" data-track-name="${t.id}" aria-label="Nombre de pista"><div class="track-buttons"><span class="track-color-dot" style="background:${t.color}"></span><button class="tiny-btn ${t.mute?'active':''}" data-mute="${t.id}" title="Silenciar">M</button><button class="tiny-btn ${t.solo?'active':''}" data-solo="${t.id}" title="Solo">S</button><button class="tiny-btn" data-track-move="up:${t.id}" title="Subir pista">↑</button><button class="tiny-btn" data-track-move="down:${t.id}" title="Bajar pista">↓</button><button class="tiny-btn del" data-drop-track="${t.id}" title="Eliminar pista">✕</button></div><input class="track-gain" type="range" min="0" max="2" step="0.01" value="${t.gain}" data-track-gain="${t.id}" aria-label="Volumen de pista"></div><div class="track-lane" data-lane="${t.id}" style="width:${width}px">${t.clips.map(c=>{const a=S.assets.get(c.assetId);return `<div class="wave-clip ${S.selected===c.id?'selected':''}" data-clip="${c.id}" tabindex="0" role="button" aria-label="Clip ${window.VS.escape(a?.name||'audio')}; clic derecho para editar" style="left:${c.start*p}px;width:${Math.max(5,c.length*p)}px;--clip-color:${t.color}" title="${window.VS.escape(a?.name||'Clip')}"><span class="clip-label">${window.VS.escape(a?.name||'Clip')} <i>${fmt(c.length)}</i></span><canvas aria-hidden="true"></canvas><span class="clip-handle start" data-handle="start"></span><span class="clip-handle end" data-handle="end"></span></div>`;}).join('')}</div></div>`).join('')+(!S.tracks.length?'<div class="track-placeholder"><div class="mix-empty-visual">≋</div><strong>Tu timeline está vacío</strong><span>Importá audio o creá una pista para empezar a mezclar.</span><button class="work-tool primary" data-a="import">＋ Importar primer archivo</button></div>':'')+`<div class="audio-playhead" id="audio-playhead" style="left:${144+S.playhead*p}px"></div>`;
 regionDisplay();window.VS.$('#track-count').textContent=`${S.tracks.length} ${S.tracks.length===1?'pista':'pistas'}`;window.VS.$('#audio-total').textContent=fmt(duration());
 $$('[data-track-name]',frame).forEach(input=>input.onchange=()=>{const t=byId(input.dataset.trackName);if(t){saveUndo();t.name=input.value.trim().slice(0,80)||'Pista';renderAll();}});
 $$('[data-track-move]',frame).forEach(b=>b.onclick=()=>{S.trackSelected=b.dataset.trackMove.slice(b.dataset.trackMove.indexOf(':')+1);moveTrack(b.dataset.trackMove.startsWith('up:')?-1:1);});
 $$('[data-mute]',frame).forEach(b=>b.onclick=()=>{saveUndo();const t=byId(b.dataset.mute);t.mute=!t.mute;refreshAudio();renderAll();});
 $$('[data-solo]',frame).forEach(b=>b.onclick=()=>{saveUndo();const t=byId(b.dataset.solo);t.solo=!t.solo;refreshAudio();renderAll();});
 $$('[data-drop-track]',frame).forEach(b=>b.onclick=()=>{saveUndo();S.tracks=S.tracks.filter(t=>t.id!==b.dataset.dropTrack);if(!locateClip(S.selected))S.selected=null;refreshAudio();renderAll();});
 $$('[data-track-gain]',frame).forEach(b=>b.onchange=()=>{saveUndo();const t=byId(b.dataset.trackGain);t.gain=Number(b.value);refreshAudio();renderAll();});
 window.VS.$('#audio-ruler').querySelectorAll('[data-marker]').forEach(b=>b.onclick=e=>{e.stopPropagation();seek(S.markers[Number(b.dataset.marker)].at);});
 window.VS.$('#audio-ruler').onclick=e=>{const box=e.currentTarget.getBoundingClientRect();seek((e.clientX-box.left)/p);};
 $$('[data-lane]',frame).forEach(lane=>{lane.onclick=e=>{if(e.target!==lane)return;S.trackSelected=lane.dataset.lane;S.selected=null;const at=(e.clientX-lane.getBoundingClientRect().left)/p;seek(at);renderInspector();};lane.ondragover=e=>{e.preventDefault();lane.classList.add('drag-over')};lane.ondragleave=()=>lane.classList.remove('drag-over');lane.ondrop=e=>{e.preventDefault();lane.classList.remove('drag-over');const id=e.dataTransfer.getData('text/vsmedia-audio');const a=S.assets.get(id);if(a){saveUndo();const t=byId(lane.dataset.lane);S.selected=addClip(t,a,(e.clientX-lane.getBoundingClientRect().left)/p).id;renderAll();}else if(e.dataTransfer.files?.length)importAudio([...e.dataTransfer.files]);};});
 $$('[data-clip]',frame).forEach(div=>{const id=div.dataset.clip;div.onpointerdown=e=>{if(e.button!==0)return;e.stopPropagation();const loc=locateClip(id);if(!loc)return;S.selected=id;S.trackSelected=loc.t.id;saveUndo();const startX=e.clientX,old={...loc.c},kind=e.target.dataset.handle||'move';div.setPointerCapture(e.pointerId);let moved=false;
 const mv=ev=>{const delta=(ev.clientX-startX)/p;if(Math.abs(delta)<.01)return;moved=true;const a=S.assets.get(loc.c.assetId);if(!a)return;const snap=sec=>{if(!S.snap)return sec;const quarters=Math.round(sec*4)/4,edges=[0,...S.markers.map(m=>m.at),...S.tracks.flatMap(t=>t.clips.filter(c=>c.id!==id).flatMap(c=>[c.start,c.start+c.length]))];const magnetic=window.VSAudioAnalysis?.snapToEdge(sec,edges,.12)??sec;return magnetic!==sec?magnetic:quarters;};
 if(kind==='move'){loc.c.start=Math.max(0,snap(old.start+delta));}
 else if(kind==='start'){const change=Math.min(old.length-.1,Math.max(-old.offset,snap(delta)));loc.c.start=Math.max(0,old.start+change);loc.c.offset=old.offset+change;loc.c.length=old.length-change;}
 else {loc.c.length=Math.max(.1,Math.min(a.buffer.duration-old.offset,snap(old.length+delta)));}
 div.style.left=loc.c.start*p+'px';div.style.width=Math.max(5,loc.c.length*p)+'px';};
 const up=()=>{div.removeEventListener('pointermove',mv);div.removeEventListener('pointerup',up);div.removeEventListener('pointercancel',up);if(!moved)S.history.pop();renderAll();};
 div.addEventListener('pointermove',mv);div.addEventListener('pointerup',up);div.addEventListener('pointercancel',up);
 };});
 requestAnimationFrame(drawWaves);updateClock();}
function drawWaves(){const cvs=window.VS.$$('#timeline-inner .wave-clip');for(const el of cvs){const loc=locateClip(el.dataset.clip);if(!loc)continue;const a=S.assets.get(loc.c.assetId);if(!a)continue;const canvas=el.querySelector('canvas'),w=Math.min(4096,Math.max(10,Math.round(canvas.getBoundingClientRect().width*devicePixelRatio))),h=Math.max(70,Math.round(canvas.getBoundingClientRect().height*devicePixelRatio));if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;}const ctx=canvas.getContext('2d');ctx.clearRect(0,0,w,h);ctx.fillStyle=loc.t.color;const sRate=a.buffer.sampleRate,peaks=window.VSPeaks.forBuffer(a.buffer);for(let x=0;x<w;x++){const from=(loc.c.offset+x*loc.c.length/w)*sRate,to=(loc.c.offset+(x+1)*loc.c.length/w)*sRate;let lo=0,hi=0;for(const ch of peaks){const [a,b]=ch.range(from,Math.max(from+1,to));lo=Math.min(lo,a);hi=Math.max(hi,b);}const height=Math.max(2,Math.max(Math.abs(lo),Math.abs(hi))*(h*.78));ctx.fillRect(x,h/2-height/2,1,height);}}}
function responseCurve(t){const coords=[];for(let i=0;i<=120;i++){const f=20*Math.pow(1000,i/120);const hp=t.fx?Math.max(20,t.hp):20,lp=t.fx?Math.min(20000,t.lp):20000;
 const h=f/Math.sqrt(f*f+hp*hp)*lp/Math.sqrt(lp*lp+f*f);const db=Math.max(-30,20*Math.log10(Math.max(.001,h)));coords.push(`${(i/120*280).toFixed(1)},${(66-(db+30)*1.55).toFixed(1)}`);}
 return `<svg viewBox="0 0 280 80" preserveAspectRatio="none"><path d="M ${coords.join(' L ')}" /></svg>`;
}
function renderInspector(){const body=window.VS.$('#audio-inspector-body');if(!body)return;const tab=window.VS.$('.inspector-tabs button.active')?.dataset.inspect||'clip',selected=locateClip(S.selected),t=byId(S.trackSelected)||selected?.t;
 if(tab==='clip'){if(!selected){body.innerHTML='<div class="empty">Seleccioná un clip del timeline.<br>Acá vas a encontrar cortes, ganancias y fades.</div>';return;}
 const c=selected.c,a=S.assets.get(c.assetId);body.innerHTML=`<h3>${window.VS.escape(a?.name||'Clip')}</h3><div class="inspector-section"><p class="kicker">PROPIEDADES DEL CLIP</p>${[['start','Posición','s'],['offset','Inicio fuente','s'],['length','Duración','s'],['gain','Ganancia','×'],['fadeIn','Fade in','s'],['fadeOut','Fade out','s']].map(([key,title,unit])=>`<div class="field-row"><label>${title}</label><input type="number" step="0.05" min="0" max="5400" value="${c[key]}" data-clip-field="${key}" aria-label="${title}"><output>${unit}</output></div>`).join('')}</div><p class="inspector-foot" style="margin-top:18px">Los cambios son no destructivos. Los audios originales no se sobrescriben.</p>`;
 $$('[data-clip-field]',body).forEach(el=>el.onchange=()=>{let v=Number(el.value);if(!Number.isFinite(v))return;const obj=locateClip(S.selected);if(!obj)return;const a=S.assets.get(obj.c.assetId);saveUndo();const key=el.dataset.clipField;
 if(key==='start')v=Math.max(0,Math.min(5400,v));if(key==='offset')v=Math.max(0,Math.min(a.buffer.duration-.05,v));if(key==='length')v=Math.max(.05,Math.min(a.buffer.duration-obj.c.offset,v));if(key==='gain')v=Math.max(0,Math.min(3,v));if(key.startsWith('fade'))v=Math.max(0,Math.min(obj.c.length,v));obj.c[key]=v;if(obj.c.offset+obj.c.length>a.buffer.duration)obj.c.length=Math.max(.05,a.buffer.duration-obj.c.offset);renderAll();});
 }else{if(!t){body.innerHTML='<div class="empty">Seleccioná una pista para editar su EQ y panorama.</div>';return;}
 body.innerHTML=`<h3>${window.VS.escape(t.name)}</h3><div class="inspector-section"><p class="kicker">CURVA DE RESPUESTA REAL</p><div class="inspector-wave">${responseCurve(t)}</div><div class="field-row"><label>Activar EQ</label><input type="checkbox" data-fx="fx" ${t.fx?'checked':''}></div><div class="field-row"><label>Pasa-altos</label><input type="range" min="20" max="8000" step="10" value="${t.hp}" data-fx="hp"><output>${t.hp} Hz</output></div><div class="field-row"><label>Pasa-bajos</label><input type="range" min="1000" max="20000" step="100" value="${t.lp}" data-fx="lp"><output>${t.lp} Hz</output></div></div><div class="inspector-section"><p class="kicker">PISTA · ESPACIALIDAD</p><div class="field-row"><label>Paneo L / R</label><input type="range" min="-1" max="1" step="0.01" value="${t.pan}" data-fx="pan"><output>${Math.round(t.pan*100)}%</output></div><div class="field-row"><label>Volumen</label><input type="range" min="0" max="2" step="0.01" value="${t.gain}" data-fx="gain"><output>${Math.round(t.gain*100)}%</output></div></div><button class="panel-btn" data-a="resetfx">Restablecer efectos</button>`;
 $$('[data-fx]',body).forEach(el=>{el.oninput=()=>{const k=el.dataset.fx,v=k==='fx'?el.checked:Number(el.value);const track=byId(S.trackSelected);if(track){track[k]=v;if(k==='hp'||k==='lp'||k==='fx'){const graph=body.querySelector('.inspector-wave');if(graph)graph.innerHTML=responseCurve(track);}el.nextElementSibling&&(el.nextElementSibling.textContent=k==='pan'?`${Math.round(v*100)}%`:k==='gain'?`${Math.round(v*100)}%`:`${v} Hz`);}};el.onchange=()=>{refreshAudio();};});
 }}
function renderBottom(){
 const box=window.VS.$('#audio-bottom-content');if(!box)return;box.className='mixer-list';
 box.innerHTML=S.tracks.length?S.tracks.map(t=>`<div class="mixer-channel mixer-strip" data-mixer="${t.id}" style="--meter:${t.color}">
 <div class="mixer-strip-head"><span class="track-color-dot" style="background:${t.color}"></span><strong title="${window.VS.escape(t.name)}">${window.VS.escape(t.name)}</strong><button class="tiny-btn" data-mixer-inspect="${t.id}" title="Seleccionar efectos">⚙</button></div>
 <div class="channel-meter"><span data-meter-id="${t.id}" style="width:0%"></span></div>
 <div class="strip-switches"><button class="tiny-btn ${t.mute?'active':''}" data-mute="${t.id}">MUTE</button><button class="tiny-btn ${t.solo?'active':''}" data-solo="${t.id}">SOLO</button><label class="strip-comp"><input type="checkbox" data-mixer-param="comp" data-mixer-id="${t.id}" ${t.comp?'checked':''}> COMP</label></div>
 <label class="strip-control">VOL <input type="range" min="0" max="2" step=".01" value="${t.gain}" data-mixer-param="gain" data-mixer-id="${t.id}"><output>${t.gain===0?'−∞':(20*Math.log10(t.gain)).toFixed(1)} dB</output></label>
 <label class="strip-control">PAN <input type="range" min="-1" max="1" step=".01" value="${t.pan||0}" data-mixer-param="pan" data-mixer-id="${t.id}"><output>${Math.round((t.pan||0)*100)}%</output></label>
 <div class="strip-eq" aria-label="Ecualización de tres bandas">
 ${[['low','LOW'],['mid','MID'],['high','HIGH']].map(([k,label])=>`<label>${label}<input type="range" min="-12" max="12" value="${t[k]||0}" step=".5" data-mixer-param="${k}" data-mixer-id="${t.id}"><output>${t[k]||0} dB</output></label>`).join('')}</div>
 <label class="strip-control">ECHO <input type="range" min="0" max="0.6" step=".01" value="${t.send||0}" data-mixer-param="send" data-mixer-id="${t.id}"><output>${Math.round((t.send||0)*100)}%</output></label>
 <label class="strip-control">UMBRAL <input type="range" min="-40" max="0" step="1" value="${t.threshold??-18}" data-mixer-param="threshold" data-mixer-id="${t.id}"><output>${t.threshold??-18} dB</output></label>
 </div>`).join(''):'<div class="empty" style="width:100%">La consola muestra canales cuando importás audio.</div>';
 for(const b of box.querySelectorAll('[data-mixer-param]')){
   // Capturar historial ANTES de modificar la pista; una entrada por gesto.
   let captured=false;const checkpoint=()=>{if(!captured){saveUndo();captured=true;}};
   b.addEventListener('pointerdown',checkpoint);b.addEventListener('focus',checkpoint);
   b.addEventListener('input',()=>{
     const t=byId(b.dataset.mixerId);if(!t)return;checkpoint();const key=b.dataset.mixerParam;
     t[key]=b.type==='checkbox'?b.checked:Number(b.value);updateLiveTrack(t);
     const out=b.nextElementSibling;if(out?.tagName==='OUTPUT')out.textContent=key==='gain'?(t.gain===0?'−∞':(20*Math.log10(t.gain)).toFixed(1))+' dB':key==='pan'?Math.round(t.pan*100)+'%':key==='send'?Math.round(t.send*100)+'%':key==='threshold'?t.threshold+' dB':t[key]+' dB';
   });
   b.addEventListener('change',()=>{captured=false;renderInspector();});b.addEventListener('blur',()=>{captured=false;});
 }
 $$('[data-mixer-inspect]',box).forEach(b=>b.onclick=()=>{S.trackSelected=b.dataset.mixerInspect;S.selected=null;const tab=window.VS.$('[data-inspect="fx"]');tab?.click();renderInspector();});
 $$('[data-mute]',box).forEach(b=>b.onclick=()=>{saveUndo();const t=byId(b.dataset.mute);t.mute=!t.mute;for(const t0 of S.tracks)updateLiveTrack(t0);renderBottom();});
 $$('[data-solo]',box).forEach(b=>b.onclick=()=>{saveUndo();const t=byId(b.dataset.solo);t.solo=!t.solo;for(const t0 of S.tracks)updateLiveTrack(t0);renderBottom();});
 const master=window.VS.$('#mix-master-gain');if(master){master.value=String(S.masterGain);window.VS.$('#mix-master-output').textContent=S.masterGain===0?'−∞':(20*Math.log10(S.masterGain)).toFixed(1)+' dB';}
}
function renderAll(){if(!root)return;renderAssets();renderTimeline();renderInspector();renderBottom();scheduleRecovery();const view=root.querySelector('#timeline-view');if(view)view.dataset.lastPx=String(pxps());}
function refreshLayout(){
 if(!root||root.hidden||layoutFrame)return;
 layoutFrame=requestAnimationFrame(()=>{
  layoutFrame=0;if(!root||root.hidden)return;
  // Preserve horizontal scroll position in seconds on resize.
  const view=root.querySelector('#timeline-view');if(!view)return;
  const previousPx=Number(view.dataset.lastPx||pxps());
  const previousScroll=view.scrollLeft;
  const seconds=Math.max(0,(previousScroll-144)/Math.max(1,previousPx));
  const newPx=pxps();view.dataset.lastPx=String(newPx);
  renderTimeline();
  // 0..144px is the non-time ruler/track header: don't introduce a phantom scroll.
  view.scrollLeft=previousScroll<=144?previousScroll:Math.max(0,144+seconds*newPx);
 });
}
function refreshAudio(){if(S.playing){const p=getCursor();halt();S.playhead=p;playAudio();}}
function splitClip(){const sel=locateClip(S.selected),pos=getCursor();if(!sel||pos<=sel.c.start+.03||pos>=sel.c.start+sel.c.length-.03){toast('Situá el cursor dentro del clip seleccionado para dividirlo.',true);return;}saveUndo();const old=sel.c,n={...old,id:uid(),start:pos,offset:old.offset+(pos-old.start),length:old.length-(pos-old.start)};old.length=pos-old.start;sel.t.clips.push(n);S.selected=n.id;renderAll();}
function deleteClip(){const obj=locateClip(S.selected);if(!obj)return;saveUndo();obj.t.clips=obj.t.clips.filter(c=>c.id!==S.selected);S.selected=null;refreshAudio();renderAll();}
function duplicateClip(){const obj=locateClip(S.selected);if(!obj)return toast('Seleccioná un clip.',true);saveUndo();const c={...obj.c,id:uid(),start:obj.c.start+obj.c.length};obj.t.clips.push(c);S.selected=c.id;refreshAudio();renderAll();toast('Clip duplicado.');}
function nudgeSelected(direction,coarse=false){const obj=locateClip(S.selected);if(!obj)return toast('Seleccioná un clip para desplazarlo.',true);
 saveUndo();obj.c.start=Math.max(0,Math.round((obj.c.start+direction*(coarse?.5:.05))*1000)/1000);refreshAudio();renderTimeline();renderInspector();scheduleRecovery();}
function moveToCursor(){const obj=locateClip(S.selected);if(!obj)return toast('Seleccioná un clip.',true);saveUndo();obj.c.start=Math.max(0,getCursor());refreshAudio();renderAll();}
function fadeSelected(key){const obj=locateClip(S.selected);if(!obj)return toast('Seleccioná un clip.',true);saveUndo();obj.c[key]=Math.min(0.5,obj.c.length/2);refreshAudio();renderAll();}
function duplicateTrack(){const track=byId(S.trackSelected)||locateClip(S.selected)?.t;if(!track)return toast('Seleccioná una pista para duplicarla.',true);
 if(S.tracks.length>=64)return toast('Máximo de 64 pistas.',true);
 saveUndo();const index=S.tracks.indexOf(track),copy={...track,id:uid(),name:track.name+' copia',clips:track.clips.map(c=>({...c,id:uid()}))};S.tracks.splice(index+1,0,copy);S.trackSelected=copy.id;S.selected=copy.clips[0]?.id||null;renderAll();toast('Pista duplicada con sus clips y ajustes.');}
function moveTrack(direction){const track=byId(S.trackSelected)||locateClip(S.selected)?.t;if(!track)return toast('Seleccioná una pista.',true);const i=S.tracks.indexOf(track),to=i+direction;if(to<0||to>=S.tracks.length)return;
 saveUndo();S.tracks.splice(to,0,S.tracks.splice(i,1)[0]);renderAll();}
function addMarker(){const at=Math.max(0,getCursor());if(S.markers.length>=200)return toast('Máximo de 200 marcadores.',true);
 const name=prompt('Nombre del marcador:',`Marca ${S.markers.length+1}`);if(name===null)return;
 saveUndo();S.markers.push({at,name:name.trim().slice(0,70)||`Marca ${S.markers.length+1}`});S.markers.sort((a,b)=>a.at-b.at);renderTimeline();}
function nextMarker(direction){const at=getCursor(),sorted=S.markers.slice().sort((a,b)=>a.at-b.at);
 const candidates=sorted.filter(m=>direction>0?m.at>at+.005:m.at<at-.005);const m=direction>0?candidates[0]:candidates.at(-1);if(m)seek(m.at);else toast('No hay otro marcador en esa dirección.');}
function normalizeClip(){const obj=locateClip(S.selected);if(!obj)return toast('Seleccioná un clip.',true);const asset=S.assets.get(obj.c.assetId);if(!asset)return;const lo=Math.max(0,Math.floor(obj.c.offset*asset.buffer.sampleRate)),hi=Math.min(asset.buffer.length,Math.ceil((obj.c.offset+obj.c.length)*asset.buffer.sampleRate));let peak=0;for(const ch of window.VSPeaks.forBuffer(asset.buffer)){const [a,b]=ch.range(lo,hi);peak=Math.max(peak,Math.abs(a),Math.abs(b));}if(peak<.00001)return toast('No hay señal para normalizar.',true);saveUndo();obj.c.gain=Math.min(4,.98/peak);refreshAudio();renderAll();toast('Pico normalizado sin modificar el archivo.');}
async function newProject(){const yes=await dialog('Nuevo proyecto','<p>Se vaciará el proyecto abierto. Descargá un archivo .vsmedia antes si querés conservarlo.</p>',[{label:'Vaciar editor',value:true,primary:true},{label:'Cancelar'}]);if(!yes)return;halt();S.assets.clear();S.tracks=[];S.markers=[];S.loopRegion={start:null,end:null};S.masterGain=.9;S.selected=null;S.trackSelected=null;S.playhead=0;S.history=[];S.redo=[];clearTimeout(S.recoveryTimer);S.recoveryTimer=0;try{await window.VSMixRecovery?.clear?.();}catch(e){console.warn('[VSMix] No se pudo limpiar la recuperación:',e);}showRecoveryInfo(null);renderAll();}
async function action(a){try{switch(a){case'home':window.VS.navigate('home');break;case'simple':window.VS.navigate('simple');break;case'radio':window.VS.navigate('radio');break;case'import':window.VS.$('#audio-file-input').click();break;case'saveproject':await saveProject();break;case'recover':await recoverSession();break;case'clearrecovery':await clearRecovery();break;case'cancelrender':S.renderCancel=true;status('Cancelando al terminar el bloque actual…');break;case'openproject':window.VS.$('#audio-project-input').click();break;case'export':await renderAudio();break;case'exportwebm':await renderAudio('webm');break;case'savepack':await renderAudio('pack');break;case'toradio':await renderAudio('radio');break;case'new':await newProject();break;case'newtrack':saveUndo();S.trackSelected=newTrack().id;renderAll();break;case'duplicatetrack':duplicateTrack();break;case'trackup':moveTrack(-1);break;case'trackdown':moveTrack(1);break;case'addmarker':addMarker();break;case'nextmarker':nextMarker(1);break;case'prevmarker':nextMarker(-1);break;case'clearmarkers':if(S.markers.length&&confirm('Eliminar todos los marcadores?')){saveUndo();S.markers=[];renderTimeline();}break;case'undo':historyRestore(S.history,S.redo);break;case'redo':historyRestore(S.redo,S.history);break;case'play':playAudio();break;case'stop':stop();break;case'rewind':seek(0);break;case'record':await recordToggle();break;case'stoprecord':await recordToggle(true);break;case'loop':S.loop=!S.loop;regionDisplay();toast(S.loop?'Bucle activado':'Bucle desactivado');break;case'loopin':markLoop('start');break;case'loopout':markLoop('end');break;case'clearloop':saveUndo();S.loopRegion={start:null,end:null};renderTimeline();break;case'follow':toggleFollow();break;case'zoomin':zoomTimeline(S.zoom*1.35);break;case'zoomout':zoomTimeline(S.zoom/1.35);break;case'zoomreset':zoomTimeline(1);break;case'togglemixer':S.mixerCollapsed=!S.mixerCollapsed;window.VS.$('.audio-layout')?.classList.toggle('mixer-collapsed',S.mixerCollapsed);break;case'zoomfit':S.zoom=1;window.VS.$('#zoom-control').value='0';renderTimeline();window.VS.$('#timeline-view').scrollLeft=0;break;case'split':splitClip();break;case'deleteclip':deleteClip();break;case'duplicateclip':duplicateClip();break;case'normalizeclip':normalizeClip();break;case'movetocursor':moveToCursor();break;case'nudgeleft':nudgeSelected(-1);break;case'nudgeright':nudgeSelected(1);break;case'fadein':fadeSelected('fadeIn');break;case'fadeout':fadeSelected('fadeOut');break;case'togglefx':{const t=byId(S.trackSelected);if(t){t.fx=!t.fx;renderInspector();refreshAudio();}}break;case'resetfx':{const t=byId(S.trackSelected);if(t){t.fx=false;t.hp=20;t.lp=18000;t.pan=0;renderInspector();refreshAudio();}}break;case'help':await dialog('VSMix · Guía','<p>Importá audio y arrastrá clips entre pistas. Seleccioná un clip y editá posición, duración, volumen y fades desde el Inspector.</p><p><b>Atajos:</b> Espacio = play/pausa; S = dividir; Supr = eliminar; Ctrl+Z/Y = deshacer/rehacer; ←/→ = ±100 ms; Shift+flecha = ±1 s; Inicio/Fin = extremos.</p><p>La consola permite volumen, pan, EQ LOW/MID/HIGH, COMP, envío ECHO y master. Arrastrá con botón central o Shift+rueda para desplazar el timeline. Ctrl/Alt+rueda ajusta zoom. Teclas I/O fijan A/B; L activa el bucle; «⌖ Seguir» acompaña el cursor y se puede desactivar.</p><p>Alt+←/→ desplaza el clip seleccionado 50 ms (Shift+Alt: 500 ms). El zoom es logarítmico y «Ajustar» encuadra toda la sesión. La exportación larga se hace en bloques y podés recuperarla después de un cierre inesperado.</p><p>Conservá también un archivo .vsmedia externo como copia de seguridad.</p>');break;}}
 catch(e){console.error(e);toast(e.message,true);}}
function init(element){root=element;try{S.follow=localStorage.getItem('vsmedia-follow-mix-v4')!=='0';}catch{}root.innerHTML=rootHtml();
 // Menú contextual del clip, accesible por click derecho o Shift+F10.
 const clipMenu=document.createElement('div');clipMenu.id='mix-clip-context';clipMenu.className='vs-clip-context';clipMenu.setAttribute('role','menu');clipMenu.hidden=true;
 clipMenu.innerHTML='<strong>EDICIÓN DEL CLIP</strong><button data-a="split" role="menuitem">✂ Dividir (S)</button><button data-a="duplicateclip" role="menuitem">⧉ Duplicar (D)</button><button data-a="normalizeclip" role="menuitem">◭ Normalizar</button><button data-a="fadein" role="menuitem">↗ Fundido de entrada</button><button data-a="fadeout" role="menuitem">↘ Fundido de salida</button><button data-a="deleteclip" role="menuitem">✕ Eliminar (Supr)</button>';
 root.append(clipMenu);
 function hideClipMenu(){clipMenu.hidden=true;}
 function showClipMenu(id,x,y){const loc=locateClip(id);if(!loc)return;S.selected=id;S.trackSelected=loc.t.id;renderTimeline();renderInspector();clipMenu.hidden=false;
   // Mantenerlo dentro de la ventana aun en pantallas pequeñas.
   const w=224,h=270;clipMenu.style.left=Math.max(8,Math.min(x,window.innerWidth-w-8))+'px';clipMenu.style.top=Math.max(8,Math.min(y,window.innerHeight-h-8))+'px';
   clipMenu.querySelector('button')?.focus({preventScroll:true});}
 root.addEventListener('contextmenu',e=>{const clip=e.target.closest('.wave-clip[data-clip]');if(!clip)return;e.preventDefault();showClipMenu(clip.dataset.clip,e.clientX,e.clientY);});
 root.addEventListener('keydown',e=>{if(e.key==='Escape'&&!clipMenu.hidden){e.preventDefault();e.stopPropagation();hideClipMenu();}if((e.key==='F10'&&e.shiftKey)&&document.activeElement?.closest?.('.wave-clip[data-clip]')){e.preventDefault();const r=document.activeElement.getBoundingClientRect();showClipMenu(document.activeElement.dataset.clip,r.left+24,r.top+20);}});
 clipMenu.addEventListener('click',hideClipMenu);
 document.addEventListener('pointerdown',e=>{if(!clipMenu.hidden&&!clipMenu.contains(e.target))hideClipMenu();});
 const f=root.querySelector('#mix-follow-toggle');if(f){f.setAttribute('aria-pressed',String(S.follow));f.classList.toggle('active',S.follow);}window.VS.initMenus(root,action);root.addEventListener('input',scheduleRecovery);root.addEventListener('change',scheduleRecovery);root.addEventListener('pointerup',scheduleRecovery);void window.VSMixRecovery?.info?.().then(showRecoveryInfo).catch(e=>console.warn('[VSMix] Recuperación no disponible:',e.message));root.addEventListener('click',e=>{const a=e.target.closest('[data-a]');if(a){action(a.dataset.a);return;}const inTab=e.target.closest('[data-inspect]');if(inTab){window.VS.$$('.inspector-tabs button').forEach(b=>b.classList.toggle('active',b===inTab));renderInspector();}});
 window.VS.$('#mix-master-gain').oninput=e=>{S.masterGain=Number(e.target.value);S.liveGraph?.master.gain.setTargetAtTime(S.masterGain,S.audioCtx.currentTime,.02);window.VS.$('#mix-master-output').textContent=S.masterGain===0?'−∞':(20*Math.log10(S.masterGain)).toFixed(1)+' dB';};
 window.VS.$('#audio-search').oninput=e=>{S.search=e.target.value;renderAssets();};window.VS.$('#zoom-control').oninput=e=>zoomTimeline(2**Number(e.target.value));window.VS.$('#snap-control').onchange=e=>S.snap=e.target.checked;
 window.VS.$('#audio-file-input').onchange=async e=>{const files=[...e.target.files];e.target.value='';await importAudio(files);};
 window.VS.$('#audio-project-input').onchange=async e=>{const f=e.target.files[0];e.target.value='';if(f)await openProject(f);};
 root.querySelector('#timeline-view')?.addEventListener('wheel',e=>{
   const view=e.currentTarget;
   if(e.ctrlKey||e.altKey){e.preventDefault();zoomTimeline(S.zoom*(e.deltaY<0?1.25:1/1.25),e.clientX);return;}
   if(e.shiftKey){e.preventDefault();view.scrollLeft+=e.deltaY+e.deltaX;}
 },{passive:false});
 let pan=null;root.querySelector('#timeline-view')?.addEventListener('pointerdown',e=>{
   if(e.button!==1&&!((e.button===0)&&e.shiftKey&&e.target.closest('.timeline-view')))return;
   if(e.target.closest('input,button'))return;
   e.preventDefault();const view=e.currentTarget;pan={x:e.clientX,y:e.clientY,left:view.scrollLeft,top:view.scrollTop,id:e.pointerId};view.setPointerCapture(e.pointerId);
 });
 root.querySelector('#timeline-view')?.addEventListener('pointermove',e=>{if(!pan||pan.id!==e.pointerId)return;const view=e.currentTarget;view.scrollLeft=pan.left+pan.x-e.clientX;view.scrollTop=pan.top+pan.y-e.clientY;});
 for(const evt of ['pointerup','pointercancel'])root.querySelector('#timeline-view')?.addEventListener(evt,()=>{pan=null;});root.addEventListener('dragover',e=>{if(e.dataTransfer.types.includes('Files'))e.preventDefault();});root.addEventListener('drop',e=>{if(e.dataTransfer.files.length&&!e.target.closest('[data-lane]')){e.preventDefault();importAudio([...e.dataTransfer.files]);}});
 document.addEventListener('keydown',e=>{if(root.hidden||e.defaultPrevented||e.target.closest('input,textarea,select,[contenteditable],.vs-command-layer,.dialog-layer,.menu-popover,.vs-view-menu')||document.querySelector('.vs-command-layer:not([hidden]),.dialog-layer:not([hidden])'))return;if(e.altKey&&(e.key==='ArrowRight'||e.key==='ArrowLeft')){e.preventDefault();nudgeSelected(e.key==='ArrowRight'?1:-1,e.shiftKey);return;}if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();seek(getCursor()+(e.key==='ArrowRight'?1:-1)*(e.shiftKey?1:0.1));return;}if(e.key==='Home'||e.key==='End'){e.preventDefault();seek(e.key==='Home'?0:duration());return;}if(e.code==='Space'){e.preventDefault();action('play');}else if(e.key.toLowerCase()==='i'&&!e.ctrlKey){e.preventDefault();action('loopin');}else if(e.key.toLowerCase()==='o'&&!e.ctrlKey){e.preventDefault();action('loopout');}else if(e.key.toLowerCase()==='l'&&!e.ctrlKey){e.preventDefault();action('loop');}else if(e.key.toLowerCase()==='k'&&!e.ctrlKey){e.preventDefault();action('addmarker');}else if(e.key.toLowerCase()==='s'&&!e.ctrlKey){e.preventDefault();action('split');}else if(e.key==='Delete'){action('deleteclip');}else if(e.key==='Backspace'){e.preventDefault();action('deleteclip');}else if(e.key.toLowerCase()==='d'&&!e.ctrlKey){e.preventDefault();action('duplicateclip');}else if(e.ctrlKey&&e.key.toLowerCase()==='z'){e.preventDefault();action('undo');}else if(e.ctrlKey&&e.key.toLowerCase()==='y'){e.preventDefault();action('redo');}});
 renderAll();
 if(typeof ResizeObserver==='function'){
  let lastW=0;const resize=new ResizeObserver(entries=>{const w=Math.round(entries[0]?.contentRect.width||0);if(w>0&&w!==lastW){lastW=w;refreshLayout();}});
  resize.observe(root.querySelector('#timeline-view'));
 }
 window.addEventListener('resize',refreshLayout,{passive:true});document.addEventListener('visibilitychange',()=>{if(document.hidden&&S.assets.size)void flushRecovery();});
}
window.VSMixApp={init,openProject,refreshLayout,pauseOutput:()=>{if(S.playing)pause();},leave:()=>{if(S.playing)pause();if(S.record)recordToggle(true);void flushRecovery();},enter:()=>{updateClock();refreshLayout();},importFile:async(file)=>{await importAudio([file]);},inspect:()=>({tracks:S.tracks.length,assets:S.assets.size}),_test:{encodeWav,fmt,routeBuffer,rulerStep,rulerHtml,loopBounds,markLoop,followHead}};
})();
