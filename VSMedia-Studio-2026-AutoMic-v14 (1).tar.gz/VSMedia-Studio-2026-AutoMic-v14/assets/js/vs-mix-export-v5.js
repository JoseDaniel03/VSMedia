/* VSMedia v5 — PCM16 WAV renderer by bounded OfflineAudioContext segments.
   Pre-roll reconstructs compressor/EQ/delay state without writing pre-roll twice.
   No audio is uploaded to a third-party service. */
(()=>{'use strict';
const DEFAULT_RATE=44100;
const PCM_CHANNELS=2;
const MAX_WAV_FRAMES=Math.floor((0xffffffff-36)/4);
function plan(seconds, rate=DEFAULT_RATE, blockSeconds=30, prerollSeconds=2.4){
 if(!Number.isFinite(seconds)||seconds<=0||!Number.isInteger(rate)||rate<8000||rate>192000)throw Error('Duración o frecuencia de muestreo inválida.');
 const total=Math.ceil(seconds*rate),block=Math.max(1,Math.floor(blockSeconds*rate)),pre=Math.max(0,Math.floor(prerollSeconds*rate));
 if(total>MAX_WAV_FRAMES)throw Error('La mezcla supera el límite RIFF/WAV de 4 GiB. Dividí la sesión.');
 const regions=[];
 for(let first=0;first<total;first+=block){const frames=Math.min(total-first,block),before=Math.min(first,pre);regions.push({start:first,frames,preroll:before,renderFrames:before+frames,offsetSeconds:(first-before)/rate});}
 return {rate,total,bytes:total*PCM_CHANNELS*2+44,regions};
}
function header(rate,frames){const bytes=frames*4+44;if(bytes>0xffffffff)throw Error('WAV demasiado grande.');const b=new ArrayBuffer(44),v=new DataView(b);let p=0;
 const str=s=>{for(let i=0;i<s.length;i++)v.setUint8(p++,s.charCodeAt(i));};
 const u16=n=>{v.setUint16(p,n,true);p+=2;},u32=n=>{v.setUint32(p,n,true);p+=4;};
 str('RIFF');u32(bytes-8);str('WAVE');str('fmt ');u32(16);u16(1);u16(2);u32(rate);u32(rate*4);u16(4);u16(16);str('data');u32(frames*4);return new Uint8Array(b);
}
function pcmSegment(buffer,preroll,frames){if(buffer.numberOfChannels<2||buffer.length<preroll+frames)throw Error('El motor no renderizó los canales solicitados.');
 const L=buffer.getChannelData(0),R=buffer.getChannelData(1),pcm=new Uint8Array(frames*4),view=new DataView(pcm.buffer);
 for(let i=0;i<frames;i++){const a=preroll+i,v=Math.max(-1,Math.min(1,L[a]||0)),w=Math.max(-1,Math.min(1,R[a]||0));view.setInt16(i*4,v<0?Math.round(v*32768):Math.round(v*32767),true);view.setInt16(i*4+2,w<0?Math.round(w*32768):Math.round(w*32767),true);}
 return pcm;
}
async function render({duration,rate=DEFAULT_RATE,blockSeconds=30,prerollSeconds=2.4,schedule,Context=globalThis.OfflineAudioContext,onProgress=()=>{},cancelled=()=>false,sink=null,yieldUI=()=>new Promise(resolve=>setTimeout(resolve,0))}){
 if(typeof schedule!=='function'||typeof Context!=='function')throw Error('Motor de renderizado no disponible.');
 const spec=plan(duration,rate,blockSeconds,prerollSeconds);
 const pieces=sink?null:[header(rate,spec.total)];
 if(sink)await sink.write(header(rate,spec.total));
 for(let i=0;i<spec.regions.length;i++){
  if(cancelled())throw Error('Exportación cancelada.');
  const region=spec.regions[i];const ctx=new Context(2,region.renderFrames,rate);
  await schedule(ctx,region.offsetSeconds);
  const buffer=await ctx.startRendering();
  if(cancelled())throw Error('Exportación cancelada.');
  const pcm=pcmSegment(buffer,region.preroll,region.frames);
  if(sink)await sink.write(pcm);else pieces.push(pcm);
  onProgress((region.start+region.frames)/spec.total,i+1,spec.regions.length);
  if(i<spec.regions.length-1)await yieldUI();
 }
 return {blob:sink?null:new Blob(pieces,{type:'audio/wav'}),bytes:spec.bytes,frames:spec.total,rate};
}
const api={plan,header,pcmSegment,render,MAX_WAV_FRAMES};
if(typeof window!=='undefined')window.VSMixExport=api;
if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
