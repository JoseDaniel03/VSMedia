/* VSMedia Workspace v3: widths, presets, keyboard-accessible splitters.
   Keeps every editor's own DOM and audio engine; no external dependencies. */
(()=>{'use strict';
const CONFIG={simple:{grid:'.simple-grid',left:'.simple-library',right:'.simple-inspector',width:[174,224]},mix:{grid:'.audio-layout',left:'.audio-library',right:'.audio-inspector',width:[180,228]},radio:{grid:'.radio-grid',left:'.radio-library',right:'.radio-queue',width:[178,220]}};
const KEY='vsmedia-workspace-widths-v3';
const DEFAULTS=Object.fromEntries(Object.entries(CONFIG).map(([id,c])=>[id,{left:c.width[0],right:c.width[1]}]));
let state=JSON.parse(JSON.stringify(DEFAULTS));
try{const cached=JSON.parse(localStorage.getItem(KEY)||'null');for(const id of Object.keys(CONFIG))for(const side of ['left','right']){const v=cached?.[id]?.[side];if(Number.isFinite(v)&&v>=125&&v<=450)state[id][side]=v;}}catch{}
const persist=()=>{try{localStorage.setItem(KEY,JSON.stringify(state));}catch{}};
const activePage=id=>{const page=document.getElementById(id);return page&&!page.hidden?page:null;};
const clamp=(n,lo,hi)=>Math.max(lo,Math.min(hi,n));
const minCenter=360;
function constraints(id,side){const cfg=CONFIG[id],grid=document.querySelector('#'+id+' '+cfg.grid);if(!grid)return {min:125,max:350};const total=grid.getBoundingClientRect().width;const opposite=state[id][side==='left'?'right':'left'];return {min:130,max:Math.max(130,Math.min(400,total-minCenter-opposite-26))};}
function apply(id,notify=true){const page=document.getElementById(id),cfg=CONFIG[id];if(!page||!cfg)return;
 page.style.setProperty('--vs-lib-size',state[id].left+'px');page.style.setProperty('--vs-ins-size',state[id].right+'px');
 for(const handle of page.querySelectorAll('.vs-resizer')){const side=handle.dataset.side,value=state[id][side];handle.setAttribute('aria-valuenow',String(value));handle.setAttribute('aria-valuetext',value+' píxeles');}
 if(notify)window.dispatchEvent(new Event('resize'));
}
function set(id,side,value){const bounds=constraints(id,side);state[id][side]=Math.round(clamp(Number(value)||bounds.min,bounds.min,bounds.max));apply(id);persist();}
function reset(id){state[id]={left:CONFIG[id].width[0],right:CONFIG[id].width[1]};apply(id);persist();}
function install(id){const page=document.getElementById(id),cfg=CONFIG[id],grid=page?.querySelector(cfg.grid);if(!page||!grid||grid.querySelector('.vs-resizer'))return;
 for(const side of ['left','right']){
   const splitter=document.createElement('div');splitter.className='vs-resizer vs-resizer-'+side;splitter.dataset.side=side;
   splitter.tabIndex=0;splitter.setAttribute('role','separator');splitter.setAttribute('aria-orientation','vertical');splitter.setAttribute('aria-label',side==='left'?'Ajustar ancho de biblioteca':'Ajustar ancho de inspector');splitter.setAttribute('aria-valuemin','130');splitter.setAttribute('aria-valuemax','400');splitter.title='Arrastrá o usá ← → para cambiar el ancho · doble clic para restaurar';
   grid.appendChild(splitter);
   let start=null;
   splitter.addEventListener('pointerdown',e=>{if(e.button!==0||!activePage(id))return;e.preventDefault();start={pointer:e.pointerId,x:e.clientX,size:state[id][side]};splitter.setPointerCapture(e.pointerId);page.classList.add('vs-resizing');});
   splitter.addEventListener('pointermove',e=>{if(!start||start.pointer!==e.pointerId)return;const delta=(e.clientX-start.x)*(side==='left'?1:-1);set(id,side,start.size+delta);});
   const finish=()=>{start=null;page.classList.remove('vs-resizing');};
   splitter.addEventListener('pointerup',finish);splitter.addEventListener('pointercancel',finish);
   splitter.addEventListener('dblclick',()=>reset(id));
   splitter.addEventListener('keydown',e=>{const direction=e.key==='ArrowRight'?1:e.key==='ArrowLeft'?-1:0;if(direction){e.preventDefault();set(id,side,state[id][side]+direction*(e.shiftKey?30:10)*(side==='left'?1:-1));}else if(e.key==='Home'){e.preventDefault();reset(id);}});
 }
 apply(id,false);
 const menu=page.querySelector('.vs-view-menu');if(menu&&!menu.querySelector('[data-vs-preset]')){
  const section=document.createElement('div');section.className='vs-view-subheading';section.textContent='DISTRIBUCIÓN RÁPIDA';menu.append(section);
  const choices=[['balanced','Equilibrada'],['editor','Solo editor + consola'],['mixing',id==='radio'?'Mesa DJ':'Mesa de mezcla'],['reset','Restaurar anchos']];
  for(const [preset,name] of choices){const button=document.createElement('button');button.type='button';button.dataset.vsPreset=preset;button.textContent=name;menu.append(button);button.addEventListener('click',()=>selectPreset(id,preset));}
 }
}
function selectPreset(id,preset){if(preset==='reset'){reset(id);return;}
 const page=document.getElementById(id);if(!page)return;
 const wanted=preset==='balanced'?{library:true,inspector:true,focus:false}:preset==='editor'?{library:false,inspector:false,focus:false}:preset==='mixing'?{library:false,inspector:true,focus:false}:null;
 if(!wanted)return;
 const settings=window.VSEditorUI?.inspect?.()?.panels?.[id]||{};
 for(const [key,value] of Object.entries(wanted))if((settings[key]!==false&&key!=='focus'?!!settings[key]:!!settings[key])!==value){const button=page.querySelector('.vs-view-menu [data-layout="'+key+'"]');button?.click();}
 apply(id);
}
function init(){for(const id of Object.keys(CONFIG))install(id);
 window.addEventListener('resize',()=>{for(const id of Object.keys(CONFIG))if(activePage(id))apply(id,false);},{passive:true});
}
window.VSWorkspaceV3={init,apply,reset,selectPreset,inspect:()=>JSON.parse(JSON.stringify(state)),_test:{constraints,clamp}};
window.addEventListener('DOMContentLoaded',()=>setTimeout(init,0));
})();
