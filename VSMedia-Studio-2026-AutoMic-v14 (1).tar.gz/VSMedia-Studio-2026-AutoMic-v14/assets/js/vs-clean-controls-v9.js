/* VSMedia v9 — Depuración visual incremental sobre la UI v8.
   No modifica DSP, formatos, reproducción ni el contenido de los proyectos.
   Reutiliza nodos y listeners originales: evita clones de acciones. */
(()=>{'use strict';
const pages=['simple','mix','radio'];
let initialized=false;
function nativeMenu(page,label){return [...page.querySelectorAll('.work-menubar .menu-wrap')]
 .find(item=>item.querySelector('.menu-trigger')?.textContent.trim()===label);}
function mergeHeaderControls(page){
 const ver=nativeMenu(page,'Ver');
 const panelHost=page.querySelector('.work-header .vs-view-controls');
 if(panelHost && (ver || page.id==='radio')){
   const popup=ver?.querySelector('.menu-popover') || page.querySelector('.vs-compact-dropdown[data-kind="navigate"] .vs-compact-dropdown-list');
   // Mover la instancia REAL, no duplicar el panel: conserva preferencias,
   // listeners, distribución y presets inyectados por VSWorkspaceV3.
   panelHost.classList.add('vs-v9-panels-in-ver');
   const trigger=panelHost.querySelector('.vs-view-trigger');
   trigger.textContent='▥ Paneles y distribución';
   trigger.title='Biblioteca, inspector, modo enfoque y diseño de pistas';
   if(ver){trigger.setAttribute('role','menuitem');trigger.setAttribute('tabindex','-1');}
   popup.append(panelHost);
 }
 const tools=page.querySelector('.vs-compact-dropdown[data-kind="navigate"] .vs-compact-dropdown-list');
 const command=page.querySelector('.work-header .vs-command-trigger');
 if(tools&&command){
   command.textContent='⌕ Buscar comandos · Ctrl+K';
   command.title='Abrir la búsqueda de comandos (Ctrl+K)';
   command.classList.add('vs-v9-command-item');
   tools.append(command); // mueve el botón original conservando su evento click
 }
}
function tidyTimeline(){
 const mix=document.getElementById('mix');if(!mix)return;
 // Un slider, Ajustar y los comandos Ver permiten controlar zoom;
 // los botones ± de la barra eran un segundo control de lo mismo.
 mix.querySelector('.audio-tools [data-a="zoomout"]')?.remove();
 mix.querySelector('.audio-tools [data-a="zoomin"]')?.remove();
 const region=mix.querySelector('.mix-loop-controls');
 if(region){
   const label=region.querySelector('b');if(label)label.textContent='CLIPS';
   const text=[...region.childNodes].find(n=>n.nodeType===Node.TEXT_NODE && n.textContent.includes('dividir'));
   if(text)text.textContent=' · Clic derecho: editar · S: dividir ';
 }
 mix.querySelector('.timeline-top .right .vs-clip-hint')?.remove();
 // Los controles de región aparecen al activar un bucle, no de forma permanente.
 const loop=mix.querySelector('#mix-loop-toggle');
 const range=mix.querySelector('#mix-loop-label');
 const syncLoop=()=>{
   const defined=range?.textContent?.startsWith('A ')||false;
   const enabled=loop?.getAttribute('aria-pressed')==='true';
   mix.classList.toggle('vs-v9-loop-editing',enabled||defined);
 };
 if(loop)new MutationObserver(syncLoop).observe(loop,{attributes:true,attributeFilter:['aria-pressed']});
 if(range)new MutationObserver(syncLoop).observe(range,{subtree:true,childList:true,characterData:true});
 syncLoop();
 // Un solo indicador de sesión. Se conservan los nodos originales para que el
 // renderizador siga escribiendo sin cambiar su lógica.
 const tracks=mix.querySelector('#track-count'),assets=mix.querySelector('#asset-count');
 if(tracks&&assets){
   const summary=document.createElement('span');summary.className='chip vs-v9-session-summary';
   summary.id='mix-session-summary';summary.setAttribute('role','status');
   tracks.before(summary);tracks.classList.add('vs-v9-underlying-count');assets.classList.add('vs-v9-underlying-count');
   const sync=()=>{summary.textContent=`${tracks.textContent.trim()} · ${assets.textContent.trim()}`;};
   new MutationObserver(sync).observe(tracks,{subtree:true,childList:true,characterData:true});
   new MutationObserver(sync).observe(assets,{subtree:true,childList:true,characterData:true});
   sync();
 }
 // El mezclador conserva MUTE/SOLO/Gain completos; la pista solo los muestra
 // cuando se contrae la consola, para no exhibir dos juegos simultáneos.
 const mixer=mix.querySelector('.audio-layout');
 if(mixer){
   const btn=mix.querySelector('.audio-bottom [data-a="togglemixer"]');
   const update=()=>{
     btn?.setAttribute('aria-expanded',String(!mixer.classList.contains('mixer-collapsed')));
     if(btn)btn.title=mixer.classList.contains('mixer-collapsed')?'Expandir mezclador':'Contraer mezclador';
   };
   new MutationObserver(update).observe(mixer,{attributes:true,attributeFilter:['class']});update();
 }
}
function init(){if(initialized)return;initialized=true;
 for(const id of pages){const page=document.getElementById(id);if(page)mergeHeaderControls(page);}
 tidyTimeline();
}
window.VSCleanControlsV9={init};
})();
