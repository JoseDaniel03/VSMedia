/* VS Media · command search. Native DOM operations, no dependencies or server. */
(()=>{'use strict';
const modules=[['home','Inicio','Home / espacio creativo'],['simple','VSAudio Simple','Una pista y grabación'],['mix','VSMix','Timeline y mezclador'],['radio','VSRadio','Estación y DJ'],['voice','VS Voice Studio','Locución y micrófono'],['soundboard','VS Soundboard','Bancos de sonidos'],['vspack','VSPack','Texturas y modelos']];
const normalize=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
let layer,field,list,status,opener,options=[],active=0,isOpen=false;
function current(){return modules.map(m=>m[0]).find(id=>!document.getElementById(id)?.hidden)||'home';}
function build(){const page=document.getElementById(current());const rows=modules.map(([id,label,detail])=>({key:'go-'+id,label:'Abrir '+label,detail,group:'Ir a',run:()=>window.VS.navigate(id)}));
 if(page&&page.id!=='home'){
  page.querySelectorAll('.work-menubar .menu-wrap').forEach(w=>{
   const menu=w.querySelector('[data-menu]')?.dataset.menu||'Acciones';
   w.querySelectorAll('.menu-popover [data-action]').forEach(b=>{
    rows.push({key:'act-'+menu+'-'+b.dataset.action,label:b.textContent.trim(),detail:menu+' · '+page.id.toUpperCase(),group:'Acciones del editor',run:()=>b.click()});
   });
  });
  const quick=page.querySelector('.vs-view-trigger');if(quick)rows.push({key:'view',label:'Personalizar espacio de trabajo',detail:'Biblioteca, inspector, enfoque y densidad',group:'Vista',run:()=>quick.click()});
  const open=page.querySelector('[data-simple="import"], [data-mix="import"], [data-radio="import"]');
  if(open&&!rows.some(x=>x.label.toLowerCase().includes('abrir audio')))rows.push({key:'open-audio',label:'Importar audio',detail:'Abrir archivo local',group:'Archivo',run:()=>open.click()});
 }
 rows.push({key:'help',label:'Atajos de teclado y ayuda',detail:'Comandos, menús y navegación',group:'Ayuda',run:()=>showHelp()});
 return rows;
}
function matchOptions(query){const q=normalize(query).trim(),terms=q.split(/\s+/).filter(Boolean);
 return build().filter(x=>terms.every(t=>normalize(x.label+' '+x.detail+' '+x.group).includes(t))).slice(0,35);
}
function render(){options=matchOptions(field.value);active=Math.min(active,Math.max(0,options.length-1));list.replaceChildren();
 if(!options.length){const empty=document.createElement('p');empty.className='vs-command-empty';empty.textContent='No hay resultados. Probá con “mezclador”, “guardar” o “radio”.';list.append(empty);}
 let section='';options.forEach((item,i)=>{
  if(item.group!==section){section=item.group;const group=document.createElement('p');group.className='vs-command-group';group.textContent=section;list.append(group);}
  const button=document.createElement('button');button.type='button';button.className='vs-command-item';button.dataset.index=i;button.id='vs-command-item-'+i;button.setAttribute('role','option');button.setAttribute('aria-selected',String(i===active));
  const name=document.createElement('span');name.className='vs-command-label';name.textContent=item.label;
  const detail=document.createElement('small');detail.textContent=item.detail;
  button.append(name,detail);button.addEventListener('pointermove',()=>{if(active!==i){active=i;sync();}});
  button.addEventListener('click',()=>execute(i));list.append(button);
 });sync(false);status.textContent=options.length+' resultados · ↑ ↓ para navegar · Enter para ejecutar · Esc para cerrar';
}
function sync(scroll=true){list.querySelectorAll('[role=option]').forEach(b=>b.setAttribute('aria-selected',String(Number(b.dataset.index)===active)));const button=list.querySelector('[data-index="'+active+'"]');if(button){field.setAttribute('aria-activedescendant',button.id);if(scroll)button.scrollIntoView({block:'nearest'});}else field.removeAttribute('aria-activedescendant');}
function open(initial=''){if(!layer)return;opener=document.activeElement;isOpen=true;layer.hidden=false;for(const menu of document.querySelectorAll('.menu-popover,.vs-view-menu'))menu.hidden=true;for(const trigger of document.querySelectorAll('.menu-trigger,.vs-view-trigger'))trigger.setAttribute('aria-expanded','false');field.value=initial;active=0;render();field.focus({preventScroll:true});}
function close(){if(!layer||!isOpen)return;isOpen=false;layer.hidden=true;field.value='';opener?.focus?.({preventScroll:true});}
function execute(index){const selected=options[index];if(!selected)return;close();try{selected.run();if(selected.key.startsWith('go-')){const target=selected.key.slice(3);const page=document.getElementById(target);const button=target==='home'?document.getElementById('open-drawer'):page?.querySelector('.work-back,.bs-back,[data-radio=home],[data-simple=home]');button?.focus?.({preventScroll:true});}}catch(err){window.VS?.toast?.('No se pudo ejecutar: '+err.message,true);}}
function showHelp(){window.VS.dialog('Atajos de VSMedia',`<div class="vs-help-content"><p><strong>Ctrl / Cmd + K</strong> · Buscar acciones y módulos</p><p><strong>?</strong> · Abrir esta ayuda</p><p><strong>Tab / Shift + Tab</strong> · Ir al siguiente control</p><p><strong>↑ / ↓</strong> · Navegar en menús y búsqueda</p><p><strong>Esc</strong> · Cerrar menús y ventanas</p><p><strong>Espacio</strong> · Reproducir o pausar en los editores de audio</p><p><strong>Shift + rueda</strong> · Desplazamiento horizontal del timeline</p><p><strong>Ctrl / Alt + rueda</strong> · Zoom del timeline de VSMix</p><small>Las teclas no interrumpen la escritura de guiones ni los campos de texto.</small></div>`,[{label:'Cerrar',primary:true}]);}
function init(){if(layer)return;layer=document.createElement('div');layer.className='vs-command-layer';layer.hidden=true;layer.innerHTML=`<div class="vs-command-scrim"></div><section class="vs-command-dialog" role="dialog" aria-modal="true" aria-labelledby="vs-command-title"><header><span id="vs-command-title">BUSCAR ACCIONES</span><button type="button" class="vs-command-close" aria-label="Cerrar búsqueda" title="Cerrar (Esc)">✕</button></header><input id="vs-command-input" type="text" role="combobox" aria-controls="vs-command-options" aria-autocomplete="list" aria-expanded="true" autocomplete="off" spellcheck="false" placeholder="Abrir editor, guardar, exportar, efectos…"><div id="vs-command-options" class="vs-command-options" role="listbox"></div><footer id="vs-command-status" role="status"></footer></section>`;
 document.body.append(layer);field=layer.querySelector('#vs-command-input');list=layer.querySelector('#vs-command-options');status=layer.querySelector('#vs-command-status');
 layer.querySelector('.vs-command-scrim').addEventListener('click',close);layer.querySelector('.vs-command-close').addEventListener('click',close);field.addEventListener('input',()=>{active=0;render();});
 layer.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();close();}else if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();active=(active+(e.key==='ArrowDown'?1:-1)+Math.max(options.length,1))%Math.max(options.length,1);sync();}else if(e.key==='Enter'){e.preventDefault();execute(active);}else if(e.key==='Tab'){e.preventDefault();field.focus();}},true);
 document.addEventListener('keydown',e=>{const editable=!!e.target.closest?.('input,textarea,select,[contenteditable="true"]');if((e.ctrlKey||e.metaKey)&&(e.key.toLowerCase()==='k'||(e.shiftKey&&e.key.toLowerCase()==='p'))){e.preventDefault();if(isOpen)close();else open();}
 else if(!isOpen&&!editable&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&e.key==='?'){e.preventDefault();showHelp();}},true);
}
function attachButtons(){ // Modules are rendered after DOMContentLoaded by core.js.
 for(const id of ['simple','mix','radio','voice','soundboard']){
  const header=document.querySelector('#'+id+' .work-header, #'+id+' .bs-header');if(!header||header.querySelector('.vs-command-trigger'))continue;
  const button=document.createElement('button');button.type='button';button.className='vs-command-trigger';button.setAttribute('aria-label','Buscar comandos (Ctrl+K)');button.title='Buscar comandos (Ctrl+K)';button.textContent='⌕  Comandos';button.addEventListener('click',()=>open());const view=header.querySelector('.vs-view-controls');if(view)view.after(button);else header.append(button);
 }
}
window.VSQuickActions={init,open,close,matchOptions,refreshButtons:attachButtons,isOpen:()=>isOpen,_test:{normalize}};
window.addEventListener('DOMContentLoaded',()=>window.VSQuickActions.init());
})();
