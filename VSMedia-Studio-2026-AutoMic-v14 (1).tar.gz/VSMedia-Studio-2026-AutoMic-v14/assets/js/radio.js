/* VSRadio station: original local browser implementation. No simulated Minecraft streaming. */
(()=>{'use strict';
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>window.VS.escape(s),fmt=t=>{t=Math.max(0,Math.floor(t||0));return `${String(Math.floor(t/60)).padStart(2,'0')}:${String(t%60).padStart(2,'0')}`;};
const uid=()=>crypto.randomUUID?.()||`clip-${Date.now()}-${Math.random().toString(36).slice(2)}`;
let PROGRAM=null;
const S={root:null,ctx:null,master:null,destination:null,micNode:null,micStream:null,recorder:null,chunks:[],recStarted:0,clockTimer:null,library:[],queue:[],auto:true,station:'Mi estación',show:'Programa principal',xfade:-1,volume:.85,dj:{enabled:true,fade:6,transition:null,duck:true},decks:{A:{fileId:null,src:null,gain:null,playing:false,offset:0,started:0,volume:1,bass:0,treble:0},B:{fileId:null,src:null,gain:null,playing:false,offset:0,started:0,volume:1,bass:0,treble:0}}};
const asset=id=>S.library.find(x=>x.id===id),duration=a=>a?.buffer?.duration||0;
function initAudio(){if(S.ctx)return S.ctx;const ctx=new (window.AudioContext||window.webkitAudioContext)({latencyHint:'interactive'});S.ctx=ctx;S.master=ctx.createGain();S.master.gain.value=S.volume;S.destination=ctx.createMediaStreamDestination();S.master.connect(ctx.destination);S.master.connect(S.destination);for(const d of Object.values(S.decks)){
  d.gain=ctx.createGain();d.low=ctx.createBiquadFilter();d.high=ctx.createBiquadFilter();d.trim=ctx.createGain();
  d.low.type='lowshelf';d.low.frequency.value=200;d.high.type='highshelf';d.high.frequency.value=4500;d.analyser=ctx.createAnalyser();d.analyser.fftSize=512;d.levelData=new Float32Array(512);
  d.gain.connect(d.low).connect(d.high).connect(d.analyser).connect(d.trim).connect(S.master);
 }applyCrossfade();applyDeckTone();return ctx;}
function applyDeckTone(){if(!S.ctx)return;for(const d of Object.values(S.decks)){
 d.low.gain.setTargetAtTime(d.bass,S.ctx.currentTime,.02);
 d.high.gain.setTargetAtTime(d.treble,S.ctx.currentTime,.02);
 d.trim.gain.setTargetAtTime(d.volume, S.ctx.currentTime,.04);
 }updateDucking();}
/** Voice-based sidechain: duck only when speech is audible, not when mic is merely armed. */
function updateDucking(){
 if(!S.ctx)return;
 const speechFromMic=!!S.micSession?.isSpeaking?.();
 let recordedVoice=false;
 for(const d of Object.values(S.decks)){
  if(!d.playing||!d.voice||!d.analyser)continue;
  d.analyser.getFloatTimeDomainData(d.levelData);
  let power=0;for(const v of d.levelData)power+=v*v;
  if(20*Math.log10(Math.max(1e-6,Math.sqrt(power/d.levelData.length))) > -43)recordedVoice=true;
 }
 const speaking=(speechFromMic||recordedVoice||PROGRAM?.isVoicePlaying?.())&&S.dj.duck;
 for(const d of Object.values(S.decks)){
  const ownVoice=d.playing&&d.voice;
  const destination=d.volume*(speaking&&!ownVoice?.23:1);
  d.trim.gain.setTargetAtTime(destination,S.ctx.currentTime,speaking?.065:.33);
 }
 const badge=S.root?.querySelector('#radio-dj-duck-status');
 if(badge)badge.textContent=speaking?'VOZ ACTIVA · MÚSICA −13 dB':'MÚSICA NORMAL';
}
function crossfadeGains(v){const pos=Math.max(-1,Math.min(1,Number(v)));return {A:Math.cos((pos+1)*Math.PI/4),B:Math.sin((pos+1)*Math.PI/4)};}
function applyCrossfade(){const {A:a,B:b}=crossfadeGains(S.xfade);const ctx=S.ctx;if(ctx){S.decks.A.gain.gain.setTargetAtTime(a,ctx.currentTime,.012);S.decks.B.gain.gain.setTargetAtTime(b,ctx.currentTime,.012);S.master.gain.setTargetAtTime(S.volume,ctx.currentTime,.012);} }
function timeFor(d){return !d.playing||!S.ctx?d.offset:Math.max(0,d.offset+S.ctx.currentTime-d.started);}
function stopDeck(letter,reset=false){const d=S.decks[letter];if(d.src){const src=d.src;d.src=null;try{src.onended=null;src.stop()}catch{}src.disconnect();}d.offset=reset?0:Math.min(timeFor(d),duration(asset(d.fileId)));d.playing=false;}
function loadDeck(letter,id){const d=S.decks[letter];if(!asset(id))return;stopDeck(letter,true);d.fileId=id;d.voice=!!asset(id)?.voice;d.offset=0;const index=S.queue.indexOf(id);if(index>=0)S.queue.splice(index,1);drawDeck(letter);renderDecks();renderLibrary();}
async function playDeck(letter){const d=S.decks[letter];if(!d.fileId){if(!S.library.length){window.VS.toast('Importá un audio a la biblioteca de VSRadio.');return;}loadDeck(letter,S.library[0].id);}const a=asset(d.fileId);if(!a)return;if(d.playing){stopDeck(letter);renderDecks();return;}const ctx=initAudio();await ctx.resume();if(d.offset>=a.buffer.duration-.01)d.offset=0;const source=ctx.createBufferSource();source.buffer=a.buffer;source.connect(d.gain);d.src=source;d.started=ctx.currentTime;d.playing=true;source.onended=()=>{if(d.src!==source)return;d.src=null;d.playing=false;d.offset=0;renderDecks();if(S.auto&&S.queue.length&&!S.dj.transition)next();};source.start(0,d.offset);renderDecks();}
function next(){
 const id=S.queue.shift();if(!id){window.VS.toast('La cola de reproducción está vacía.');return;}
 const current=Object.entries(S.decks).find(([_,d])=>d.playing)?.[0];
 const target=current?(current==='A'?'B':'A'):'A';
 if(current&&S.dj.enabled){S.queue.unshift(id);if(beginDJTransition(current))return;S.queue.shift();}
 if(current)stopDeck(current);S.dj.transition=null;
 loadDeck(target,id);S.xfade=target==='A'?-1:1;updateDJUI();applyCrossfade();
 playDeck(target).catch(err=>window.VS.toast(err.message,true));renderLibrary();
}
// Crossfade DJ de potencia constante: entrada anticipada antes del final de la canción.
function beginDJTransition(from){
 if(!S.dj.enabled||S.dj.transition||!S.queue.length)return false;
 const to=from==='A'?'B':'A',id=S.queue.shift();if(!asset(id))return false;
 loadDeck(to,id);S.xfade=from==='A'?-1:1;applyCrossfade();
 const remaining=duration(asset(S.decks[from].fileId))-timeFor(S.decks[from]);
 const fade=Math.min(S.dj.fade,Math.max(.5,remaining));
 S.dj.transition={from,to,started:null,duration:fade};
 playDeck(to).then(()=>{if(S.dj.transition?.to===to)S.dj.transition.started=performance.now();}).catch(e=>{S.dj.transition=null;window.VS.toast('DJ: '+e.message,true);});
 renderLibrary();updateDJUI();return true;
}
function tickDJ(){
 const transition=S.dj.transition;
 if(transition){
   if(transition.started===null)return;
   if(!S.decks[transition.to].playing){S.dj.transition=null;return;}
   const p=Math.min(1,(performance.now()-transition.started)/(transition.duration*1000));
   S.xfade=transition.from==='A'?-1+2*p:1-2*p;applyCrossfade();
   const f=$('#radio-cross',S.root);if(f)f.value=S.xfade;
   if(p>=1){stopDeck(transition.from,true);S.dj.transition=null;renderDecks();updateDJUI();}
   return;
 }
 if(!S.auto||!S.dj.enabled||!S.queue.length)return;
 for(const l of ['A','B']){const d=S.decks[l],a=asset(d.fileId);if(!d.playing||!a||S.decks[l==='A'?'B':'A'].playing)continue;
   const remaining=a.buffer.duration-timeFor(d);
   if(remaining>0&&remaining<=S.dj.fade){beginDJTransition(l);break;}
 }
}
function updateDJUI(){if(!S.root)return;const info=$('#radio-dj-status',S.root);if(info)info.textContent=S.dj.transition?'MEZCLANDO '+S.dj.transition.from+' → '+S.dj.transition.to:S.dj.enabled?'AUTO CROSSFADE ACTIVADO':'CROSSFADE MANUAL';}

function previous(){const d=S.decks.A;if(!d.fileId)return;stopDeck('A',true);playDeck('A').catch(err=>window.VS.toast(err.message,true));}
async function importFiles(files){if(!files.length)return;const ctx=initAudio();let ok=0;for(const f of files){try{if(!/\.(wav|mp3|ogg|m4a|opus|flac|webm|aac)$/i.test(f.name)&&!f.type.startsWith('audio/'))throw Error('Formato no compatible');if(f.size>100*1048576)throw Error('Máximo 100 MiB por audio');const raw=await f.arrayBuffer();const buf=await ctx.decodeAudioData(raw.slice(0));const a={id:uid(),name:f.name,buffer:buf,size:f.size,mime:f.type||'application/octet-stream',raw:new Uint8Array(raw)};S.library.push(a);S.queue.push(a.id);ok++;}catch(e){window.VS.toast(`${f.name}: ${e.message}`,true);}}renderLibrary();renderDecks();PROGRAM?.draw();window.VS.toast(`${ok} audio(s) incorporado(s) a la estación.`,!ok);}
function drawWave(letter){const d=S.decks[letter],a=asset(d.fileId),canvas=$(`#radio-wave-${letter}`,S.root);if(!canvas)return;const w=Math.max(150,canvas.clientWidth),h=Math.max(44,canvas.clientHeight);canvas.width=Math.round(w*devicePixelRatio);canvas.height=Math.round(h*devicePixelRatio);const g=canvas.getContext('2d');g.scale(devicePixelRatio,devicePixelRatio);g.fillStyle='#212322';g.fillRect(0,0,w,h);g.strokeStyle='#5c5148';g.beginPath();g.moveTo(0,h/2);g.lineTo(w,h/2);g.stroke();if(!a)return;const channels=window.VSPeaks.forBuffer(a.buffer);g.strokeStyle=letter==='A'?'#e8c6aa':'#8fbeae';for(let x=0;x<w;x++){const start=Math.floor(x*a.buffer.length/w),end=Math.max(start+1,Math.ceil((x+1)*a.buffer.length/w));let peak=0;for(const ch of channels){const [lo,hi]=ch.range(start,end);peak=Math.max(peak,Math.abs(lo),Math.abs(hi));}const bar=Math.max(1,peak*h*.44);g.beginPath();g.moveTo(x,h/2-bar);g.lineTo(x,h/2+bar);g.stroke();}}
function drawDeck(letter){drawWave(letter);const d=S.decks[letter],a=asset(d.fileId);const wrap=$(`[data-radio-deck="${letter}"]`,S.root);if(!wrap)return;$('.radio-deck-title',wrap).textContent=a?a.name:'Sin audio cargado';$('.radio-deck-duration',wrap).textContent=fmt(duration(a));$('.radio-deck-play',wrap).textContent=d.playing?'Ⅱ Pausar':'▶ Reproducir';const range=$('.radio-deck-seek',wrap);range.max=Math.max(.1,duration(a));range.value=Math.min(timeFor(d),Number(range.max));$('.radio-deck-clock',wrap).textContent=fmt(timeFor(d));}
function renderDecks(){for(const letter of ['A','B'])drawDeck(letter);$('#radio-live-status',S.root).textContent=Object.values(S.decks).some(d=>d.playing)?'REPRODUCCIÓN LOCAL':'ESTACIÓN EN ESPERA';}
function renderLibrary(){if(!S.root)return;$('#radio-lib-count',S.root).textContent=`${S.library.length} archivos`;$('#radio-queue-count',S.root).textContent=`${S.queue.length} pendientes`;
 const lib=$('#radio-library',S.root);lib.innerHTML=S.library.length?S.library.map(a=>`<div class="radio-audio-item"><div><strong title="${esc(a.name)}">${esc(a.name)}</strong><small>${fmt(a.buffer.duration)} · ${(a.size/1048576).toFixed(1)} MiB</small></div><div class="radio-item-buttons"><button data-radio="loadA" data-id="${a.id}" title="Cargar en reproductor A">A</button><button data-radio="loadB" data-id="${a.id}" title="Cargar en reproductor B">B</button><button data-radio="enqueue" data-id="${a.id}" title="Añadir a cola">＋</button><button data-radio="voiceasset" data-id="${a.id}" title="Marcar como locución para reducción automática de música" aria-pressed="${!!a.voice}">${a.voice?'🎙 Voz':'Voz'}</button><button data-radio="packasset" data-id="${a.id}" title="Guardar sonido en Resource Pack">⇣ Pack</button></div></div>`).join(''):'<div class="radio-empty">Importá archivos para preparar tu estación.</div>';
 const queue=$('#radio-queue',S.root);queue.innerHTML=S.queue.length?S.queue.map((id,i)=>{const a=asset(id);return `<div class="radio-queue-item"><span class="radio-num">${String(i+1).padStart(2,'0')}</span><div><strong>${esc(a?.name||'Archivo retirado')}</strong><small>${fmt(duration(a))}</small></div><div class="radio-item-buttons"><button data-radio="up" data-index="${i}" aria-label="Subir">↑</button><button data-radio="down" data-index="${i}" aria-label="Bajar">↓</button><button data-radio="remove" data-index="${i}" aria-label="Quitar">×</button></div></div>`}).join(''):'<div class="radio-empty">La cola está vacía. Añadí canciones, cortinas o separadores.</div>';
 $('#radio-autodj',S.root).checked=S.auto;}
function setupMicUI(){const b=$('#radio-mic',S.root),label=$('#radio-mic-status',S.root);b.classList.toggle('recording',!!S.micStream);b.textContent=S.micStream?'■ Apagar micrófono':'● Activar micrófono';label.textContent=S.micStream?'MIC ABIERTO · USAR AURICULARES':'MIC CERRADO';}
async function toggleMic(){if(S.micStream){S.micNode?.disconnect();S.micNode=null;S.micSession?.stop();S.micSession=null;S.micStream=null;applyDeckTone();setupMicUI();return;}if(!navigator.mediaDevices?.getUserMedia){window.VS.toast('La captura requiere localhost o HTTPS y permiso del navegador.',true);return;}try{const ctx=initAudio();await ctx.resume();const session=await window.VSMic.open({context:ctx,record:false});const stream=session.rawStream;S.micStream=stream;S.micSession=session;S.micNode=session.output;const gain=ctx.createGain();gain.gain.value=Number($('#radio-mic-volume',S.root).value);S.micNode.connect(gain).connect(S.master);S.micGain=gain;applyDeckTone();stream.getAudioTracks().forEach(t=>t.onended=()=>{if(S.micStream===stream)toggleMic()});setupMicUI();window.VS.toast('Micrófono abierto. Utilizá auriculares para evitar acoples.');}catch(e){window.VS.toast('Micrófono: '+e.message,true);}}
function recordingUI(){const btn=$('#radio-record',S.root),status=$('#radio-record-state',S.root);if(!btn||!status)return;btn.classList.toggle('recording',!!S.recorder);btn.textContent=S.recorder?'■ Detener y guardar programa':'● Grabar programa';status.textContent=S.recorder?`Grabando · ${fmt((Date.now()-S.recStarted)/1000)}`:'No se está grabando';}
async function toggleRecording(){if(S.recorder){const r=S.recorder;S.recorder=null;clearInterval(S.recordTimer);recordingUI();if(r.state!=='inactive')r.stop();return;}if(!window.MediaRecorder)return window.VS.toast('Este navegador no admite MediaRecorder.',true);try{const ctx=initAudio();await ctx.resume();let mime=['audio/webm;codecs=opus','audio/ogg;codecs=opus','audio/webm',''].find(m=>!m||MediaRecorder.isTypeSupported(m));const rec=new MediaRecorder(S.destination.stream,mime?{mimeType:mime}:undefined);const chunks=[];rec.ondataavailable=e=>{if(e.data?.size)chunks.push(e.data);};rec.onstop=async()=>{if(!chunks.length){window.VS.toast('No se recibió audio del programa.',true);return;}const b=new Blob(chunks,{type:rec.mimeType||'audio/webm'});const ext=b.type.includes('ogg')?'ogg':'webm';const name=`${window.VS.filename(S.station)}-programa-${Date.now()}.${ext}`;S.lastRecordedFile=new File([b],name,{type:b.type});window.VS.download(b,name);try{void window.VSMediaLibrary?.addFile(new File([b],name,{type:b.type}),'radio');}catch(e){console.warn('Biblioteca de radio:',e);}if(b.size>100*1048576){window.VS.toast('Grabación descargada; supera el límite de 100 MiB para cargarla en la biblioteca.');return;}try{const raw=new Uint8Array(await b.arrayBuffer());const buffer=await initAudio().decodeAudioData(raw.buffer.slice(0));S.library.push({id:uid(),name,buffer,size:b.size,mime:b.type,raw});renderLibrary();PROGRAM?.draw();window.VS.toast('Programa grabado, descargado y agregado a la biblioteca para futuras sesiones.');}catch(e){window.VS.toast('Grabación descargada. Importala a la biblioteca para programarla.');}};rec.start(1000);S.recorder=rec;S.recStarted=Date.now();S.recordTimer=setInterval(recordingUI,500);recordingUI();}catch(e){window.VS.toast('Grabación del programa: '+e.message,true);}}
async function saveStation(){
 const total=S.library.reduce((x,a)=>x+(a.raw?.length||0),0);if(total>300*1048576){window.VS.toast('La estación excede 300 MiB. Exportá una versión más pequeña.',true);return;}
 const manifest={format:'vsradio-station',schema:1,station:S.station,show:S.show,auto:S.auto,volume:S.volume,queue:S.queue,radioPlanner:PROGRAM?.state()||null,dj:{enabled:S.dj.enabled,fade:S.dj.fade,duck:S.dj.duck,eq:Object.fromEntries(['A','B'].map(l=>[l,{volume:S.decks[l].volume,bass:S.decks[l].bass,treble:S.decks[l].treble}]))},
   decks:{A:S.decks.A.fileId,B:S.decks.B.fileId},sources:S.library.map(a=>({id:a.id,name:a.name,mime:a.mime,path:`audio/${a.id}.bin`,voice:!!a.voice}))};
 const files=new Map([['station.json',new TextEncoder().encode(JSON.stringify(manifest,null,2))]]);
 for(const a of S.library)files.set(`audio/${a.id}.bin`,a.raw);
 try{window.VS.download(window.VSZip.write(files),`${window.VS.filename(S.station)}.vsradio`);window.VS.toast('Estación guardada con programación y archivos.');}
 catch(e){window.VS.toast('No se pudo guardar estación: '+e.message,true);}
}
async function openStation(file){
 if(S.recorder||S.micStream){window.VS.toast('Detené el micrófono y la grabación antes de abrir una estación.',true);return;}
 const files=await window.VSZip.read(file,{maxCompressed:310*1048576,maxTotal:340*1048576,maxItem:101*1048576,maxFiles:300});
 const raw=files.get('station.json');if(!raw)throw Error('Archivo sin station.json');
 const m=JSON.parse(new TextDecoder().decode(raw));if(m.format!=='vsradio-station'||m.schema!==1||!Array.isArray(m.sources)||m.sources.length>120)throw Error('Formato .vsradio inválido.');
 const ctx=initAudio(),newLibrary=[];let size=0;
 for(const a of m.sources){if(!a||typeof a.id!=='string'||!/^[a-zA-Z0-9-]{1,100}$/.test(a.id)||typeof a.path!=='string'||a.path!==`audio/${a.id}.bin`)throw Error('Referencia de audio inválida.');
  const bytes=files.get(a.path);if(!bytes)throw Error('Falta el audio '+a.name);size+=bytes.length;if(size>300*1048576)throw Error('Estación excede 300 MiB');
  const pcm=await ctx.decodeAudioData(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength));
  newLibrary.push({id:a.id,name:String(a.name||'Audio').slice(0,160),mime:String(a.mime||'audio/wav'),size:bytes.byteLength,raw:bytes,buffer:pcm,voice:!!a.voice});
 }
 for(const l of ['A','B'])stopDeck(l,true);
 S.library=newLibrary;const ids=new Set(newLibrary.map(a=>a.id));S.queue=(Array.isArray(m.queue)?m.queue:[]).filter(id=>ids.has(id)).slice(0,300);
 S.station=String(m.station||'Mi estación').slice(0,70);S.show=String(m.show||'Programa principal').slice(0,70);S.auto=m.auto!==false;S.volume=Number.isFinite(Number(m.volume))?Math.min(1,Math.max(0,Number(m.volume))):.85;
 if(m.dj&&typeof m.dj==='object'){S.dj.enabled=m.dj.enabled!==false;S.dj.duck=m.dj.duck!==false;S.dj.fade=Math.min(20,Math.max(1,Number(m.dj.fade)||6));for(const l of ['A','B']){const values=m.dj.eq?.[l]||{};for(const key of ['volume','bass','treble'])if(Number.isFinite(Number(values[key])))S.decks[l][key]=Math.max(key==='volume'?0:-12,Math.min(key==='volume'?1.5:12,Number(values[key])));}}
 $('#radio-station-name',S.root).value=S.station;$('#radio-show-name',S.root).value=S.show;$('#radio-master',S.root).value=S.volume;$('#radio-dj-auto',S.root).checked=S.dj.enabled;$('#radio-dj-duck',S.root).checked=S.dj.duck;$('#radio-dj-fade',S.root).value=S.dj.fade;$('#radio-dj-fade-output',S.root).textContent=S.dj.fade+' s';for(const input of S.root.querySelectorAll('[data-radio-eq]')){const [deck,key]=input.dataset.radioEq.split(':');input.value=S.decks[deck][key];}applyDeckTone();updateDJUI();
 for(const l of ['A','B'])S.decks[l].fileId=ids.has(m.decks?.[l])?m.decks[l]:null;
 applyCrossfade();persist();if(m.radioPlanner)PROGRAM?.restore(m.radioPlanner);else PROGRAM?.draw();renderLibrary();renderDecks();window.VS.toast('Estación y guiones recuperados con sus archivos de audio.');
}
function exportSchedule(){const data={format:'vsradio-station',schema:1,station:S.station,show:S.show,queuedFiles:S.queue.map(id=>asset(id)?.name).filter(Boolean),radioPlanner:PROGRAM?.state()||null,date:new Date().toISOString(),note:'Las fuentes de audio no se incluyen. Se vuelven a importar para reproducir.'};window.VS.download(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),`${window.VS.filename(S.station)}-programacion.json`);}
function persist(){try{localStorage.setItem('vsradio-station-v1',JSON.stringify({name:S.station,show:S.show,volume:S.volume,auto:S.auto,djEnabled:S.dj.enabled,djFade:S.dj.fade,djDuck:S.dj.duck}));}catch{}}
function rootHtml(){return `<div class="radio-root"><header class="work-header radio-header"><button class="work-back" data-radio="home">← Inicio</button><span class="work-brand"><span class="v">▽</span> VSMEDIA</span><span class="work-section">VSRADIO · ESTACIÓN</span><button class="work-tool" data-radio="simple">VSAudio</button><button class="work-tool" data-radio="mix">VSMix</button><div class="work-fill"></div><button class="work-tool" data-radio="openstation">Abrir estación</button><button class="work-tool" data-radio="savestation">Guardar estación</button><button class="work-tool" data-radio="planner" id="rp-open">▦ Programación</button><button class="work-tool" data-radio="console" id="rp-console">🎚 Consola A/B</button><button class="work-tool" data-radio="schedule">↓ Guion JSON</button><button class="work-tool primary" data-radio="import">＋ Importar audio</button></header>
 <div class="radio-title"><div><p class="radio-eyebrow">RADIODIFUSIÓN · ESTUDIO LOCAL</p><h1>VSRadio <em>Station</em></h1><p>Programá sesiones con música, playlists, separadores y locuciones; reproducilas solo cuando quieras.</p></div><div class="radio-local-badge"><strong id="radio-live-status">ESTACIÓN EN ESPERA</strong><span>Monitor local · no conectado a Minecraft</span></div></div>
 <section class="radio-meta"><label>ESTACIÓN<input id="radio-station-name" placeholder="Nombre de la estación" maxlength="70"></label><label>PROGRAMA<input id="radio-show-name" placeholder="Nombre del programa" maxlength="70"></label><label class="radio-auto">AUTO DJ <input type="checkbox" id="radio-autodj" checked></label><button class="radio-btn" data-radio="next">▶ Siguiente en cola</button><button class="radio-btn" data-radio="prev">↶ Reiniciar A</button></section>
 <main class="radio-grid"><section class="radio-panel radio-library"><div class="radio-panel-head"><strong>BIBLIOTECA</strong><small id="radio-lib-count">0 archivos</small></div><div id="radio-library" class="radio-list"></div><div class="radio-panel-foot">A / B cargan al reproductor · ＋ añade a la cola</div></section>
 <section class="radio-center"><div class="radio-decks">${['A','B'].map(l=>`<section class="radio-deck" data-radio-deck="${l}"><div class="radio-deck-head"><span class="radio-deck-letter">DECK ${l}</span><span class="radio-deck-duration">00:00</span></div><strong class="radio-deck-title">Sin audio cargado</strong><canvas id="radio-wave-${l}" class="radio-wave" aria-label="Forma de onda deck ${l}"></canvas><div class="radio-deck-controls"><button class="radio-btn radio-deck-play" data-radio="play${l}">▶ Reproducir</button><button class="radio-btn" data-radio="stop${l}">■</button><span class="radio-deck-clock">00:00</span></div><input type="range" class="radio-deck-seek" data-radio-seek="${l}" min="0" max="0.1" step="0.1" value="0" aria-label="Buscar en deck ${l}"><div class="radio-deck-eq"><label>VOL <input data-radio-eq="${l}:volume" type="range" min="0" max="1.5" value="1" step=".01"></label><label>BAJOS <input data-radio-eq="${l}:bass" type="range" min="-12" max="12" value="0" step="1"></label><label>AGUDOS <input data-radio-eq="${l}:treble" type="range" min="-12" max="12" value="0" step="1"></label></div></section>`).join('')}</div><section class="radio-crosspanel"><div class="radio-cross-head"><b>MESA DJ · CROSSFADER</b><span id="radio-dj-status">AUTO CROSSFADE ACTIVADO</span></div><div class="radio-dj-controls"><label><input type="checkbox" id="radio-dj-auto" checked> Fundido automático</label><label><input type="checkbox" id="radio-dj-duck" checked> Música más baja al hablar</label><span id="radio-dj-duck-status" class="radio-duck-status" aria-live="off">MÚSICA NORMAL</span><label>Fundido <input type="range" id="radio-dj-fade" min="1" max="20" value="6" step="1"><output id="radio-dj-fade-output">6 s</output></label><button class="radio-btn" data-radio="djnext">♫ Mezclar siguiente</button></div><input id="radio-cross" type="range" min="-1" max="1" step="0.01" value="-1" aria-label="Crossfader A y B"><div class="radio-cross-controls"><label>MASTER <input id="radio-master" type="range" min="0" max="1" step=".01" value=".85"></label><span>A · B mezclados en tiempo real</span></div></section>
 <section class="radio-broadcast"><div><b>CONTROL DE MICRÓFONO</b><p id="radio-mic-status">MIC CERRADO</p><label>Micrófono <input id="radio-mic-volume" type="range" min="0" max="1.5" step=".05" value="1"></label>${window.VSMic.controls()}<button class="radio-btn radio-record" id="radio-mic" data-radio="mic">● Activar micrófono</button></div><div><b>GRABADORA DEL PROGRAMA</b><p id="radio-record-state">No se está grabando</p><button class="radio-btn radio-record" id="radio-record" data-radio="record">● Grabar programa</button><button class="radio-btn" data-radio="savepackrecord" title="Convertir la última grabación a sonido Minecraft">⇣ Guardar programa en VS Pack</button><small>Guarda WebM/Opus u OGG, según navegador.</small></div></section></section>
 <aside class="radio-panel radio-queue"><div class="radio-panel-head"><strong>PROGRAMACIÓN</strong><small id="radio-queue-count">0 pendientes</small></div><div id="radio-queue" class="radio-list"></div><div class="radio-panel-foot">Ordená con ↑ ↓. Auto DJ alterna los decks A/B y mezcla las canciones con fundido automático.</div></aside></main><section id="radio-program-pane" class="radio-program" aria-label="Programación de la radio"></section>
 <div class="radio-caveat"><span>EMISIÓN LOCAL</span> No transmite a un servidor Minecraft: la integración con el plugin y Plasmo Voice requiere un adaptador de backend.</div></div>`;}
async function action(code,dataset={}){try{if(code==='home'||code==='simple'||code==='mix')return window.VS.navigate(code);if(code==='import')return $('#radio-file-input').click();if(code==='openstation')return $('#radio-project-input').click();if(code==='savestation')return saveStation();if(code==='loadA'||code==='loadB')return loadDeck(code.slice(-1),dataset.id);if(code==='enqueue'){if(asset(dataset.id))S.queue.push(dataset.id);renderLibrary();return;}
 if(code==='voiceasset'){const a=asset(dataset.id);if(a){a.voice=!a.voice;for(const d of Object.values(S.decks))if(d.fileId===a.id)d.voice=a.voice;renderLibrary();}return;}
 if(code==='packasset'){const a=asset(dataset.id);if(a)await window.VSResourceAudio.save(new File([a.raw],a.name,{type:a.mime}),{name:a.name});return;}if(code==='up'||code==='down'||code==='remove'){const i=Number(dataset.index);if(!Number.isInteger(i)||i<0||i>=S.queue.length)return;const j=code==='up'?Math.max(0,i-1):Math.min(S.queue.length-1,i+1);if(code==='remove')S.queue.splice(i,1);else [S.queue[i],S.queue[j]]=[S.queue[j],S.queue[i]];renderLibrary();return;}if(code==='playA'||code==='playB')return playDeck(code.slice(-1));if(code==='stopA'||code==='stopB'){stopDeck(code.slice(-1),true);renderDecks();return;}if(code==='djnext'){const now=Object.entries(S.decks).find(([_,d])=>d.playing)?.[0];if(now){if(!beginDJTransition(now))window.VS.toast('No hay siguiente canción en cola.');}else next();return;}if(code==='next')return next();if(code==='prev')return previous();if(code==='mic')return toggleMic();if(code==='record')return toggleRecording();if(code==='savepackrecord'){if(!S.lastRecordedFile)return window.VS.toast('Primero grabá un programa de radio.',true);return window.VSResourceAudio.save(S.lastRecordedFile,{name:S.lastRecordedFile.name,stream:true});}if(code==='schedule')return exportSchedule();}catch(e){console.error(e);window.VS.toast(e.message||String(e),true);}}
function frame(){if(!S.root||S.root.hidden||document.hidden)return;updateDucking();tickDJ();for(const l of ['A','B']){const d=S.decks[l],a=asset(d.fileId),wrap=$(`[data-radio-deck="${l}"]`,S.root);if(!wrap)continue;$('.radio-deck-clock',wrap).textContent=fmt(timeFor(d));const seek=$('.radio-deck-seek',wrap);if(seek&&!seek.matches(':active'))seek.value=Math.min(duration(a),timeFor(d));}}
function init(root){S.root=root;try{const x=JSON.parse(localStorage.getItem('vsradio-station-v1')||'null');if(x){S.station=String(x.name||S.station).slice(0,70);S.show=String(x.show||S.show).slice(0,70);if(Number.isFinite(Number(x.volume)))S.volume=Math.min(1,Math.max(0,Number(x.volume)));S.auto=x.auto!==false;S.dj.enabled=x.djEnabled!==false;S.dj.duck=x.djDuck!==false;S.dj.fade=Math.max(1,Math.min(20,Number(x.djFade)||6));}}catch{}
 root.innerHTML=rootHtml();$('#radio-station-name',root).value=S.station;$('#radio-show-name',root).value=S.show;$('#radio-master',root).value=S.volume;$('#radio-autodj',root).checked=S.auto;$('#radio-dj-auto',root).checked=S.dj.enabled;$('#radio-dj-duck',root).checked=S.dj.duck;$('#radio-dj-fade',root).value=S.dj.fade;$('#radio-dj-fade-output',root).textContent=S.dj.fade+' s';
 root.addEventListener('click',e=>{const b=e.target.closest('[data-radio]');if(b)action(b.dataset.radio,b.dataset);});
 $('#radio-file-input').onchange=async e=>{const fs=[...e.target.files];e.target.value='';await importFiles(fs);};
 $('#radio-project-input').onchange=async e=>{const f=e.target.files?.[0];e.target.value='';if(f)try{await openStation(f);}catch(err){window.VS.toast('No se pudo abrir estación: '+err.message,true);}};
 for(const l of ['A','B'])$(`[data-radio-seek="${l}"]`,root).onchange=e=>{const d=S.decks[l],playing=d.playing;stopDeck(l,true);d.offset=Number(e.target.value);if(playing)playDeck(l);else renderDecks();};
 $('#radio-cross',root).oninput=e=>{S.dj.transition=null;S.xfade=Number(e.target.value);applyCrossfade();updateDJUI();};
 $('#radio-dj-auto',root).onchange=e=>{S.dj.enabled=e.target.checked;S.dj.transition=null;persist();updateDJUI();};
 $('#radio-dj-duck',root).onchange=e=>{S.dj.duck=e.target.checked;applyDeckTone();persist();};
 for(const e of root.querySelectorAll('[data-radio-eq]'))e.oninput=()=>{const [deck,key]=e.dataset.radioEq.split(':');S.decks[deck][key]=Number(e.value);applyDeckTone();};
 $('#radio-dj-fade',root).oninput=e=>{S.dj.fade=Number(e.target.value);$('#radio-dj-fade-output',root).textContent=S.dj.fade+' s';persist();};
 $('#radio-master',root).oninput=e=>{S.volume=Number(e.target.value);applyCrossfade();persist();};
 $('#radio-mic-volume',root).oninput=e=>{if(S.micGain&&S.ctx)S.micGain.gain.setTargetAtTime(Number(e.target.value),S.ctx.currentTime,.02);};
 $('#radio-station-name',root).onchange=e=>{S.station=e.target.value.trim()||'Mi estación';persist();};
 $('#radio-show-name',root).onchange=e=>{S.show=e.target.value.trim()||'Programa principal';persist();};
 $('#radio-autodj',root).onchange=e=>{S.auto=e.target.checked;persist();};
 renderLibrary();renderDecks();updateDJUI();PROGRAM=window.VSRadioProgramFactory?.({root,library:()=>S.library,initAudio,master:()=>S.master,stopDecks:()=>{stopDeck('A',true);stopDeck('B',true);renderDecks();}})||null;PROGRAM?.mount();S.clockTimer=setInterval(frame,100);
}
function pauseOutput(){S.dj.transition=null;PROGRAM?.stop?.();for(const l of ['A','B']){if(S.decks[l].playing)stopDeck(l);}if(S.micStream)toggleMic();if(S.recorder)toggleRecording();renderDecks();updateDJUI();}
function leave(){PROGRAM?.close();S.dj.transition=null;for(const l of ['A','B'])stopDeck(l);if(S.micStream)toggleMic();if(S.recorder)toggleRecording();renderDecks();}
let deckResizeFrame=0;
function refreshLayout(){if(!S.root||S.root.hidden||deckResizeFrame)return;
 deckResizeFrame=requestAnimationFrame(()=>{deckResizeFrame=0;if(S.root&&!S.root.hidden){for(const id of ['A','B'])drawWave(id);PROGRAM?.draw?.();}});
}
if(typeof window.addEventListener==='function')window.addEventListener('resize',refreshLayout,{passive:true});
window.VSRadioApp={init,pauseOutput,refreshLayout,openProject:openStation,enter:()=>{renderLibrary();renderDecks();PROGRAM?.draw();},leave,importFile:async f=>importFiles([f]),inspect:()=>({assets:S.library.length,queue:S.queue.length,station:S.station,mic:!!S.micStream,recording:!!S.recorder,planner:PROGRAM?.getState()}),_test:{crossfadeGains}};
})();
