/* New offline ZIP32 reader/writer for VSMedia. Uses browser standard streams; no dependencies. */
(()=>{'use strict';
const enc=new TextEncoder(),dec=new TextDecoder();
const table=new Uint32Array(256);for(let i=0;i<256;i++){let c=i;for(let j=0;j<8;j++)c=(c&1)?(0xEDB88320^(c>>>1)):(c>>>1);table[i]=c>>>0;}
const crc32=bytes=>{let c=0xFFFFFFFF;for(let i=0;i<bytes.length;i++)c=table[(c^bytes[i])&255]^(c>>>8);return (c^0xFFFFFFFF)>>>0;};
const safePath=p=>typeof p==='string'&&p.length>0&&p.length<=450&&!p.includes('\\')&&!p.startsWith('/')&&!p.includes('\0')&&!p.split('/').some(x=>x==='..'||x==='.')&&!/^[A-Za-z]:/.test(p);
const u16=(dv,o)=>dv.getUint16(o,true),u32=(dv,o)=>dv.getUint32(o,true);
async function inflate(data){if(!('DecompressionStream'in window))throw Error('Tu navegador no puede descomprimir ZIP; probá Chromium actualizado.');let stream;try{stream=new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw'));return new Uint8Array(await new Response(stream).arrayBuffer());}catch(e){throw Error('No se pudo descomprimir una entrada ZIP: '+e.message);}}
async function read(input,limits={}){
  const maxCompressed=limits.maxCompressed||96*1024*1024,maxTotal=limits.maxTotal||300*1024*1024,maxFiles=limits.maxFiles||14000,maxItem=limits.maxItem||64*1024*1024;
  const buffer=input instanceof ArrayBuffer?input:await input.arrayBuffer();if(buffer.byteLength>maxCompressed)throw Error('ZIP demasiado grande (máximo '+Math.floor(maxCompressed/1048576)+' MiB).');
  const dv=new DataView(buffer),bytes=new Uint8Array(buffer);let eocd=-1;
  for(let i=buffer.byteLength-22;i>=Math.max(0,buffer.byteLength-65557);i--){if(u32(dv,i)===0x06054b50){eocd=i;break;}}
  if(eocd<0)throw Error('No se encontró el directorio ZIP.');
  if(u16(dv,eocd+4)!==0||u16(dv,eocd+6)!==0)throw Error('ZIP dividido en varios volúmenes no compatible.');
  const count=u16(dv,eocd+10),cdSize=u32(dv,eocd+12),cdStart=u32(dv,eocd+16);
  if(count>maxFiles||count===0xffff||cdStart===0xffffffff)throw Error('ZIP64 o demasiados archivos: formato no admitido.');
  if(cdStart+cdSize>buffer.byteLength)throw Error('Directorio ZIP fuera del archivo.');
  let cursor=cdStart,total=0;const files=new Map();
  for(let i=0;i<count;i++){
    if(cursor+46>buffer.byteLength||u32(dv,cursor)!==0x02014b50)throw Error('Encabezado ZIP dañado.');
    const flags=u16(dv,cursor+8),method=u16(dv,cursor+10),crc=u32(dv,cursor+16),compressed=u32(dv,cursor+20),original=u32(dv,cursor+24);
    const nameLen=u16(dv,cursor+28),extra=u16(dv,cursor+30),comment=u16(dv,cursor+32),local=u32(dv,cursor+42);
    if(cursor+46+nameLen+extra+comment>buffer.byteLength)throw Error('Ruta ZIP truncada.');
    const name=dec.decode(bytes.subarray(cursor+46,cursor+46+nameLen));cursor+=46+nameLen+extra+comment;
    if(name.endsWith('/'))continue;
    if(!safePath(name))throw Error('Ruta peligrosa o inválida en ZIP.');
    if(files.has(name))throw Error('Entrada duplicada en ZIP: '+name);
    if(flags&1)throw Error('ZIP cifrado no compatible.');
    if(method!==0&&method!==8)throw Error('ZIP con compresión '+method+' no compatible.');
    if(original>maxItem||total+original>maxTotal|| (compressed>0&&original/compressed>500))throw Error('ZIP excede los límites de seguridad.');
    if(local+30>buffer.byteLength||u32(dv,local)!==0x04034b50)throw Error('Entrada local ZIP dañada.');
    const begin=local+30+u16(dv,local+26)+u16(dv,local+28);if(begin+compressed>buffer.byteLength)throw Error('Datos ZIP truncados.');
    const payload=bytes.slice(begin,begin+compressed);
    const raw=method===0?payload:await inflate(payload);
    if(raw.byteLength!==original||crc32(raw)!==crc)throw Error('El contenido del ZIP no coincide con su checksum: '+name);
    files.set(name,raw);total+=original;
  }
  return files;
}
function write(source){
  const files=source instanceof Map?[...source]:Object.entries(source),parts=[],centrals=[];
  let offset=0,total=0;
  const add=p=>{parts.push(p);offset+=p.length;};
  for(const [path,data] of files){
    if(!safePath(path))throw Error('Ruta ZIP inválida: '+path);
    const bytes=data instanceof Uint8Array?data:new Uint8Array(data);
    if(bytes.length>0xffffffff)throw Error('El archivo supera el límite ZIP32.');
    const filename=enc.encode(path);if(filename.length>65535)throw Error('Ruta ZIP demasiado larga.');
    const crc=crc32(bytes),size=bytes.length;
    const local=new Uint8Array(30+filename.length),ldv=new DataView(local.buffer);
    ldv.setUint32(0,0x04034b50,true);ldv.setUint16(4,20,true);ldv.setUint16(6,0x0800,true);
    ldv.setUint16(8,0,true);ldv.setUint32(14,crc,true);ldv.setUint32(18,size,true);ldv.setUint32(22,size,true);
    ldv.setUint16(26,filename.length,true);local.set(filename,30);
    const start=offset;add(local);add(bytes);
    const center=new Uint8Array(46+filename.length),dv=new DataView(center.buffer);
    dv.setUint32(0,0x02014b50,true);dv.setUint16(4,20,true);dv.setUint16(6,20,true);dv.setUint16(8,0x0800,true);
    dv.setUint16(10,0,true);dv.setUint32(16,crc,true);dv.setUint32(20,size,true);dv.setUint32(24,size,true);
    dv.setUint16(28,filename.length,true);dv.setUint32(42,start,true);center.set(filename,46);centrals.push(center);total+=size;
    if(total>500*1024*1024)throw Error('Exportación demasiado grande (500 MiB).');
  }
  if(files.length>65534)throw Error('Demasiados archivos para ZIP32.');
  const cdStart=offset;for(const c of centrals)add(c);const cdSize=offset-cdStart;
  const end=new Uint8Array(22),edv=new DataView(end.buffer);edv.setUint32(0,0x06054b50,true);
  edv.setUint16(8,files.length,true);edv.setUint16(10,files.length,true);edv.setUint32(12,cdSize,true);edv.setUint32(16,cdStart,true);add(end);
  return new Blob(parts,{type:'application/zip'});
}
window.VSZip={read,write,crc32,safePath};
})();
