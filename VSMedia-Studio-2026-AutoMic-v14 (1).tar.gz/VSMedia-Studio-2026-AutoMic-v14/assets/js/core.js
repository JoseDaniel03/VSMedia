/* VSMedia shell. New implementation; no frameworks, no installation. */
(()=>{'use strict';
const $=(s,root=document)=>root.querySelector(s), $$=(s,root=document)=>[...root.querySelectorAll(s)];
const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const filename=s=>String(s||'VSMedia').replace(/[^a-zA-Z0-9_.-]+/g,'-').slice(0,80);
const humanBytes=n=>n<1024?`${n} B`:n<1048576?`${(n/1024).toFixed(1)} KiB`:`${(n/1048576).toFixed(1)} MiB`;
const text=(s)=>new TextEncoder().encode(s);
const download=(blob,name)=>{const href=URL.createObjectURL(blob),a=document.createElement('a');a.href=href;a.download=name;a.style.display='none';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(href),15000);};
let toastTimer;
const toast=(message,error=false)=>{const t=$('#toast');t.textContent=message;t.classList.toggle('error',error);t.classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove('visible'),4400);};
// Modal accesible: foco contenido, Escape para cancelar y restauración de foco.
function dialog(title,body,actions=[{label:'Cerrar'}]){return new Promise(resolve=>{
 const layer=$('#dialog-layer'),from=document.activeElement;layer.hidden=false;
 layer.innerHTML=`<div class="dialog" role="dialog" aria-modal="true" aria-label="${escape(title)}"><h2>${escape(title)}</h2><div class="dialog-content">${body}</div><div class="dialog-actions">${actions.map((a,i)=>`<button type="button" class="work-tool ${a.primary?'primary':''}" data-choice="${i}">${escape(a.label)}</button>`).join('')}</div></div>`;
 const finish=value=>{layer.removeEventListener('keydown',key);layer.hidden=true;layer.replaceChildren();from?.focus?.({preventScroll:true});resolve(value);};
 const key=e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();finish(null);return;}if(e.key!=='Tab')return;const items=$$('button,[href],input,select,textarea,[tabindex]:not([tabindex="-1"])',layer).filter(x=>!x.disabled);if(!items.length)return;
  const index=items.indexOf(document.activeElement);if(e.shiftKey&&index<=0){e.preventDefault();items.at(-1).focus();}else if(!e.shiftKey&&index===items.length-1){e.preventDefault();items[0].focus();}};
 layer.addEventListener('keydown',key);
 $$('[data-choice]',layer).forEach(button=>button.addEventListener('click',()=>finish(actions[Number(button.dataset.choice)].value??null)));
 const first=$('.dialog-actions .primary',layer)||$('.dialog-actions button',layer);first?.focus({preventScroll:true});
 });}
// Menús de editor accesibles por teclado. Los eventos se enlazan a cada instancia,
// sin modificar el menú nativo de Blockbench.
let menuCounter=0;
function menu(buttons){return `<div class="work-menubar" aria-label="Menús del editor">${buttons.map(it=>{
 const id=`vs-editor-menu-${++menuCounter}`;
 return `<div class="menu-wrap"><button type="button" class="menu-trigger" aria-haspopup="menu" aria-expanded="false" aria-controls="${id}" data-menu="${escape(it.label)}">${escape(it.label)}</button><div class="menu-popover" id="${id}" role="menu" aria-label="${escape(it.label)}" hidden>${it.actions.map(a=>`<button type="button" role="menuitem" tabindex="-1" data-action="${escape(a.action)}">${escape(a.label)}</button>`).join('')}</div></div>`;
 }).join('')}</div>`;}
function initMenus(root,onAction){
 const triggers=$$('[data-menu]',root),popovers=$$('.menu-popover',root);
 const close=(restoreFocus=false)=>{const active=triggers.find(b=>b.getAttribute('aria-expanded')==='true');for(const pop of popovers)pop.hidden=true;for(const btn of triggers){btn.classList.remove('open');btn.setAttribute('aria-expanded','false');}if(restoreFocus)active?.focus();};
 const open=(btn,focusItem=false,fromEnd=false)=>{close();const pop=btn.nextElementSibling;if(!pop)return;pop.hidden=false;btn.classList.add('open');btn.setAttribute('aria-expanded','true');if(focusItem){const items=$$('[role="menuitem"]:not(:disabled)',pop);(fromEnd?items.at(-1):items[0])?.focus();}};
 triggers.forEach((btn,index)=>{
  btn.addEventListener('click',e=>{e.stopPropagation();btn.getAttribute('aria-expanded')==='true'?close():open(btn);});
  btn.addEventListener('keydown',e=>{if(['ArrowDown','ArrowUp','Enter',' '].includes(e.key)){e.preventDefault();open(btn,true,e.key==='ArrowUp');}
   else if(['ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();triggers[(index+(e.key==='ArrowRight'?1:-1)+triggers.length)%triggers.length].focus();}
   else if(e.key==='Escape'){e.preventDefault();close(true);}});
 });
 for(const [index,pop] of popovers.entries()){
  pop.addEventListener('keydown',e=>{
   const items=$$('[role="menuitem"]:not(:disabled)',pop);if(!items.length)return;
   const current=items.indexOf(document.activeElement);let next=-1;
   if(e.key==='ArrowDown')next=(current+1)%items.length;
   if(e.key==='ArrowUp')next=(current-1+items.length)%items.length;
   if(e.key==='Home')next=0;
   if(e.key==='End')next=items.length-1;
   if(next>=0){e.preventDefault();items[next].focus();return;}
   if(e.key==='Escape'){e.preventDefault();close(true);return;}
   if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();const other=triggers[(index+(e.key==='ArrowRight'?1:-1)+triggers.length)%triggers.length];open(other,true);}
  });
 }
 $$('[role="menuitem"][data-action]',root).forEach(btn=>btn.addEventListener('click',()=>{const action=btn.dataset.action;close();onAction(action);}));
 root.addEventListener('click',e=>{if(!e.target.closest('.menu-wrap'))close();});
 document.addEventListener('pointerdown',e=>{if(!root.hidden&&!root.contains(e.target))close();});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!window.VSQuickActions?.isOpen?.()&&!root.hidden&&triggers.some(b=>b.getAttribute('aria-expanded')==='true')){e.preventDefault();e.stopPropagation();close(true);}},true);
 return {close};
}
const modal={dialog};
const navigate=(target)=>{
  let page=target==='model'?'vspack':target==='projects'?'home':target==='audio'?'simple':target;
  const previous=['home','simple','mix','radio','vspack','voice','soundboard'].find(id=>!$('#'+id).hidden);
  if(previous&&previous!==page){window.VSGuiones?.close?.();if(previous==='simple')window.VSSimpleApp?.leave?.();if(previous==='mix')window.VSMixApp?.leave?.();if(previous==='radio')window.VSRadioApp?.leave?.();if(previous==='voice')window.VSVoiceStudio?.leave?.();if(previous==='soundboard')window.VSSoundboard?.leave?.();}
  if(!['home','simple','mix','radio','vspack','voice','soundboard'].includes(page))page='home';
  ['home','simple','mix','radio','vspack','voice','soundboard'].forEach(id=>$('#'+id).hidden=id!==page);
  if(target==='model'&&window.VSPackApp)window.VSPackApp.show('models');
  if(target==='projects')dialog('Abrir proyecto','<p>Podés recuperar un proyecto de VSAudio desde su archivo .vsmedia o importar un Resource Pack ZIP.</p>',[{label:'Audio Simple',value:'simple'},{label:'VSMix',value:'mix'},{label:'Resource Pack',value:'vspack'},{label:'Cancelar'}]).then(choice=>{if(choice)navigate(choice);});
  history.replaceState(null,'','#'+(target==='model'?'model':page));document.title=`VSMedia · ${page==='home'?'Creative Suite':page==='simple'?'VSAudio Simple':page==='mix'?'VSMix':page==='radio'?'VSRadio':page==='voice'?'VS Voice Studio':page==='soundboard'?'VS Soundboard':'VSPack'}`;
  if(page==='simple')window.VSSimpleApp?.enter();
  if(page==='mix')window.VSMixApp?.enter();
  if(page==='vspack')window.VSPackApp?.enter();
  if(page==='radio')window.VSRadioApp?.enter();
  if(page==='voice')window.VSVoiceStudio?.enter?.();
  window.VSMediaLibrary?.onNavigate(page);
  $('#drawer').hidden=true;$('#scrim').hidden=true;
};
const start=()=>{
  $('#open-drawer').onclick=()=>{$('#drawer').hidden=false;$('#scrim').hidden=false;};
  $('#close-drawer').onclick=$('#scrim').onclick=()=>{$('#drawer').hidden=true;$('#scrim').hidden=true;};
  $$('[data-go]').forEach(el=>el.onclick=()=>navigate(el.dataset.go));
  $('#home-project').onclick=$('#home-new').onclick=()=>dialog('Nuevo proyecto','<p>Elegí dónde querés empezar. El Home permanece separado de las herramientas.</p>',[{label:'Nuevo VSAudio Simple',value:'simple',primary:true},{label:'Nuevo VSMix',value:'mix'},{label:'Resource Pack',value:'vspack'},{label:'Cancelar'}]).then(v=>{if(v)navigate(v);});
  $('#explore-tools').onclick=()=>$('#home-discover').scrollIntoView({behavior:'smooth',block:'center'});
  $('#home-search').onclick=()=>dialog('Buscar herramientas','<p>VSAudio: editor de una pista con recortes, fades, filtros y exportación.<br>VSMix: mezcla multipista, clips y grabación.<br>VSRadio: estación local y grabación de programa.<br>VS Voice Studio: micrófono con filtros y conversión Opus/Vorbis.<br>VS Soundboard: bancos de sonido con exportación para VSMedia.<br>VSPack: importar, combinar y exportar ZIPs de Minecraft.<br>VSModel: inspector geométrico .bbmodel y .json integrado en VSPack.</p>',[{label:'Entendido'}]);
  window.addEventListener('hashchange',()=>navigate(location.hash.replace('#','')||'home'));
  window.VSSimpleApp?.init($('#simple'));
  window.VSMixApp?.init($('#mix'));
  window.VSRadioApp?.init($('#radio'));
  window.VSPackApp?.init($('#vspack'));
  window.VSMic?.init();
  window.VSGuiones?.init();
  window.VSMediaLibrary?.init();
  window.VSVoiceStudio?.init($('#voice'));
  window.VSSoundboard?.init($('#soundboard'));
  window.VSEditorUI?.init();
  window.VSQuickActions?.refreshButtons?.();
  // Los accesos repetidos viven ahora en un único menú de módulos por editor.
  window.VSCompactUI?.init();
  window.VSCleanControlsV9?.init();
  navigate(location.hash.replace('#','')||'home');
  // Pausar TODA reproducción al ocultar/cerrar la pestaña; no reanudar automáticamente.
  const pauseOutputs=()=>{for(const app of [window.VSSimpleApp,window.VSMixApp,window.VSRadioApp,window.VSVoiceStudio,window.VSSoundboard]){try{app?.pauseOutput?.();}catch(err){console.warn('Pausa de audio:',err);}}};
  document.addEventListener('visibilitychange',()=>{if(document.hidden)pauseOutputs();});
  window.addEventListener('pagehide',pauseOutputs);
  window.VSPlayback={pauseAll:pauseOutputs};
};
window.VS={$, $$,escape,filename,humanBytes,text,download,toast,dialog,menu,initMenus,navigate};
window.addEventListener('DOMContentLoaded',start);
})();
