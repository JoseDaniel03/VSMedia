/* VS Media v6. Compactación sin pérdida de acciones ni eventos.
   Los botones originales se MUEVEN: conservan identificadores, listeners y data-action. */
(()=>{'use strict';
const TARGETS=[['simple','≋ VSAudio Simple'],['mix','〽 VSMix'],['radio','◉ VSRadio'],['voice','● VS Voice Studio'],['soundboard','▦ VS Soundboard'],['vspack','▦ VSPack']];
const ids=['simple','mix','radio'];let ready=false;
function menu(title,root,kind='actions'){
 const wrap=document.createElement('details');wrap.className='vs-compact-dropdown';wrap.dataset.kind=kind;
 const summary=document.createElement('summary');summary.textContent=title;summary.title=title+' (Enter o espacio para abrir)';
 const content=document.createElement('div');content.className='vs-compact-dropdown-list';content.setAttribute('role','group');content.setAttribute('aria-label',title);
 wrap.append(summary,content);root.append(wrap);
 wrap.addEventListener('toggle',()=>{if(wrap.open){document.querySelectorAll('.vs-compact-dropdown').forEach(x=>{if(x!==wrap)x.open=false;});}});
 wrap.addEventListener('keydown',e=>{
   const buttons=[...content.querySelectorAll('button,select,input')].filter(x=>!x.disabled);
   if(e.key==='Escape'&&wrap.open){e.preventDefault();e.stopPropagation();wrap.open=false;summary.focus();return;}
   if((e.key==='ArrowDown'||e.key==='ArrowUp')&&wrap.open&&buttons.length){
     const at=buttons.indexOf(document.activeElement);const step=e.key==='ArrowDown'?1:-1;
     if(at!==-1||document.activeElement===summary){e.preventDefault();buttons[(at+step+buttons.length)%buttons.length].focus();}
   }
   if(e.key==='ArrowDown'&&document.activeElement===summary&&!wrap.open){e.preventDefault();wrap.open=true;buttons[0]?.focus();}
 });
 content.addEventListener('click',e=>{if(e.target.closest('button'))wrap.open=false;});
 return {wrap,content};
}
function move(container,selector){const el=document.querySelector(selector);if(!el)return false;container.appendChild(el);return true;}
function nav(page){const header=page.querySelector('.work-header');if(!header)return;
 const old=page.id==='simple'?['[data-simple="mix"]','[data-simple="radio"]']:page.id==='mix'?['[data-a="simple"]','[data-a="radio"]']:['[data-radio="simple"]','[data-radio="mix"]'];
 old.forEach(s=>header.querySelector(s)?.remove());
 const holder=document.createElement('div');holder.className='vs-compact-holder';
 const {wrap,content}=menu('Herramientas',holder,'navigate');
 for(const [id,label] of TARGETS){if(id===page.id)continue;
   const b=document.createElement('button');b.type='button';b.dataset.vsNav=id;b.textContent=label;
   b.addEventListener('click',()=>{wrap.open=false;window.VS.navigate(id);});content.append(b);
 }
 const before=header.querySelector('.work-fill');header.insertBefore(holder,before||null);
}
function toolbarMenu(page,title,selectors){const header=page.querySelector('.work-header');if(!header)return;
 const holder=document.createElement('div');holder.className='vs-compact-holder';const menuObj=menu(title,holder,'files');
 let moved=0;for(const sel of selectors){const el=page.querySelector(sel);if(!el)continue;menuObj.content.append(el);moved++;}
 if(moved){header.insertBefore(holder,header.querySelector('.work-fill')||null);}else holder.remove();
}
function simplifySimple(page){
 // La selección tiene su propio botón de recorte, no necesita otro en la biblioteca.
 page.querySelector('.simple-library .simple-tips [data-simple="crop"]')?.remove();
 // Archivo ya existe en la barra nativa: no crear un segundo menú.
 // La acción WebM vive ahora en Archivo y el proyecto ya tenía Abrir.
 page.querySelector('.work-header [data-simple="open"]')?.remove();
 page.querySelector('.work-header [data-simple="exportwebm"]')?.remove();
 const top=page.querySelector('.simple-tools [data-simple="import"]');
 const side=page.querySelector('.simple-library [data-simple="import"]');
 if(top&&side){
  // Mostrar UNA llamada a la importación según el contexto; en enfoque, la barra siempre queda utilizable.
  const sync=()=>{
   const name=page.querySelector('#simple-file-name')?.textContent?.trim();const hasFile=!!name&&name!=='Ningún audio';
   const libraryHidden=page.classList.contains('vs-hide-library')||page.classList.contains('vs-focus-workspace');
   const topVisible=hasFile||libraryHidden;top.hidden=!topVisible;side.hidden=topVisible;
  };
  const fileName=page.querySelector('#simple-file-name');if(fileName)new MutationObserver(sync).observe(fileName,{characterData:true,subtree:true,childList:true});
  new MutationObserver(sync).observe(page,{attributes:true,attributeFilter:['class']});sync();
 }
}
function simplifyMix(page){
 // Exportar WebM ya está en el menú Archivo original de VSMix.
 page.querySelector('.work-header [data-a="exportwebm"]')?.remove();
 // Dos botones para ajustar zoom ejecutaban exactamente el mismo comando.
 page.querySelector('.timeline-top [data-a="zoomfit"]')?.remove();
 // La biblioteca tenía otro botón "Importar" además de la barra de transporte y el estado vacío.
 const extra=page.querySelector('.audio-lib-tools [data-a="import"]');extra?.remove();
 const hint=page.querySelector('.audio-lib-hint');if(hint)hint.textContent='Importá desde la barra superior o arrastrá un archivo al timeline. Los audios permanecen en tu equipo.';
 // Acciones menos frecuentes se agrupan sin cambiar su comando ni el estado del clip.
 const controls=page.querySelector('.timeline-top .right');
 if(controls){const {wrap,content}=menu('Más del clip',controls,'clip');let n=0;
  for(const action of ['normalizeclip','deleteclip']){const btn=controls.querySelector('[data-a="'+action+'"]');if(btn){content.append(btn);n++;}}
  if(!n)wrap.remove();
 }
}
function simplifyRadio(page){
 toolbarMenu(page,'Archivo',[
  '.work-header [data-radio="openstation"]',
  '.work-header [data-radio="schedule"]'
 ]);
 const queue=page.querySelector('.radio-auto');if(queue){const node=[...queue.childNodes].find(x=>x.nodeType===3);if(node)node.nodeValue='COLA AUTOMÁTICA ';}
 const fade=page.querySelector('#radio-dj-auto')?.closest('label');if(fade){const node=[...fade.childNodes].find(x=>x.nodeType===3);if(node)node.nodeValue=' Transición anticipada';}
}
function libraryTabs(page){
 const side=page.querySelector(page.id==='simple'?'.simple-library':page.id==='mix'?'.audio-library':'.radio-library');
 if(!side||side.querySelector('.vs-library-switch'))return;
 const shared=side.querySelector('.vsl-side-container');
 if(!shared)return;
 const heading=side.querySelector('.pane-caption,.radio-panel-head');
 if(!heading)return;
 const local=document.createElement('div');local.className='vs-library-local';local.setAttribute('role','tabpanel');local.id='vs-lib-local-'+page.id;
 const children=[...side.children].filter(x=>x!==shared&&x!==heading);
 for(const node of children)local.append(node);
 side.append(local);
 shared.classList.add('vs-library-shared');shared.setAttribute('role','tabpanel');shared.id='vs-lib-shared-'+page.id;
 const headingLabel=heading.querySelector('span:first-child,strong:first-child');
 if(headingLabel)headingLabel.textContent=page.id==='simple'?'AUDIO':'BIBLIOTECA';
 const labelCounter=heading.querySelector('.pane-caption .count');
 if(labelCounter)labelCounter.textContent=page.id==='simple'?'1 PISTA':'VS / SESIÓN';
 const insideLabel=shared.querySelector('.vsl-head>span');if(insideLabel)insideLabel.textContent='▤ CARPETAS Y ARCHIVOS';
 const tabs=document.createElement('div');tabs.className='vs-library-switch';tabs.setAttribute('role','tablist');tabs.setAttribute('aria-label','Fuente de archivos');
 const choices=[['shared','Biblioteca VS',shared],['local',page.id==='simple'?'Audio actual':'En sesión',local]];
 for(const [key,label,panel] of choices){
   const b=document.createElement('button');b.type='button';b.setAttribute('role','tab');b.dataset.libTab=key;
   b.id='vs-lib-tab-'+page.id+'-'+key;b.setAttribute('aria-controls',panel.id);b.textContent=label;
   panel.setAttribute('aria-labelledby',b.id);tabs.append(b);
 }
 side.insertBefore(tabs,shared);
 const storage='vsmedia-library-source-v6-'+page.id;
 let selected=page.id==='simple'?'local':'shared';
 try{const saved=localStorage.getItem(storage);if(saved==='shared'||saved==='local')selected=saved;}catch{}
 const activate=(key,focus=false)=>{
   if(key!=='local'&&key!=='shared')return;selected=key;
   for(const [id,_,panel] of choices){panel.hidden=id!==selected;const b=tabs.querySelector('[data-lib-tab="'+id+'"]');b.setAttribute('aria-selected',String(id===selected));b.tabIndex=id===selected?0:-1;if(id===selected&&focus)b.focus();}
   try{localStorage.setItem(storage,key);}catch{}
 };
 tabs.addEventListener('click',e=>{const b=e.target.closest('[data-lib-tab]');if(b)activate(b.dataset.libTab);});
 tabs.addEventListener('keydown',e=>{
   if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;
   e.preventDefault();const next=e.key==='Home'?'shared':e.key==='End'?'local':selected==='shared'?'local':'shared';activate(next,true);
 });
 activate(selected);
}
function simplifyOther(){
 for(const id of ids){const page=document.getElementById(id);const home=page?.querySelector('.vsl-home-button');if(home){home.textContent='▤ Proyectos';home.title='Abrir proyectos recientes y biblioteca inicial de este editor';}}
 const voice=document.getElementById('voice');if(voice){
  const take=voice.querySelector('[data-voice="to-board"]');if(take)take.textContent='→ Enviar toma al Soundboard';
  const converted=voice.querySelector('[data-voice="send-converted"]');if(converted)converted.textContent='→ Enviar conversión';
 }
 const board=document.getElementById('soundboard');if(board){
  const manifest=[...board.querySelectorAll('button')].find(b=>b.textContent.includes('Solo manifiesto JSON'));
  if(manifest){manifest.textContent='↓ Manifiesto JSON (sin audios)';manifest.title='Exporta solamente la configuración, no el banco de sonidos';}
 }
}
/* v8 — remove duplicate *visible* commands. Keep their real handlers in native menus.
   The operations remain available by keyboard, menus, and contextual clip menu. */
function nativeMenu(page,label){return [...page.querySelectorAll('.work-menubar .menu-wrap')].find(w=>w.querySelector('.menu-trigger')?.textContent.trim()===label)?.querySelector('.menu-popover');}
function removeNativeItem(page,label,action){nativeMenu(page,label)?.querySelector(`[data-action="${action}"]`)?.remove();}
function tidyV8(){
 const simple=document.getElementById('simple'),mix=document.getElementById('mix'),radio=document.getElementById('radio');
 if(simple){
   // Guardar/Exportar ya están en Archivo: liberar espacio del encabezado.
   simple.querySelector('.work-header [data-simple="save"]')?.remove();
   simple.querySelector('.work-header [data-simple="export"]')?.remove();
   // El selector de calidad WAV sigue en Archivo; no se pierde ninguna variante.
   const quality=simple.querySelector('.work-header .export-format'),fileMenu=nativeMenu(simple,'Archivo');
   if(quality&&fileMenu){quality.classList.add('vs-export-quality');fileMenu.querySelector('[data-action="export"]')?.after(quality);}
   // Normalización, reversa, fades, etc. ya están en los menús Editar/Efectos.
   const tipBox=simple.querySelector('.simple-tips');
   if(tipBox){
     const onlyUnique=['findsilence','nextsilence','maskdetected'];
     for(const btn of [...tipBox.querySelectorAll('[data-simple]')])if(!onlyUnique.includes(btn.dataset.simple))btn.remove();
     const title=tipBox.querySelector('.kicker');if(title)title.textContent='ANÁLISIS DE SILENCIOS';
     tipBox.classList.add('vs-silence-tools');
   }
   // Los selectores de rango y el acceso Ctrl+A sustituyen estos dos botones permanentes.
   simple.querySelector('.simple-wave-head [data-simple="selectall"]')?.remove();
   simple.querySelector('.simple-wave-head [data-simple="clearselection"]')?.remove();
   // Doble clic y Ctrl+A siguen seleccionando; Escape limpia la selección.
   const waveHeader=simple.querySelector('.simple-wave-head');
   if(waveHeader)waveHeader.title='Doble clic en la onda: seleccionar todo. Ctrl+A: seleccionar todo; Escape: limpiar selección.';
   // Restaurar efectos está en Efectos, no necesita otro botón al final del inspector.
   simple.querySelector('.simple-inspector [data-simple="reseteffects"]')?.remove();
 }
 if(mix){
   mix.querySelector('.work-header [data-a="saveproject"]')?.remove();
   mix.querySelector('.work-header [data-a="export"]')?.remove();
   mix.querySelector('.audio-tools [data-a="import"]')?.remove();
   // El menú Editar/Ver ya tiene estas acciones; el timeline ofrece menú contextual.
   mix.querySelector('.timeline-top .right [data-a="split"]')?.remove();
   mix.querySelector('.timeline-top .right [data-a="duplicateclip"]')?.remove();
   mix.querySelector('.timeline-top .right .vs-compact-dropdown[data-kind="clip"]')?.remove();
   removeNativeItem(mix,'Editar','zoomfit'); // También estaba en Ver.
   const repeated=[...(nativeMenu(mix,'Editar')?.querySelectorAll('[data-action="newtrack"]')||[])];
   repeated.slice(1).forEach(el=>el.remove()); // Nueva pista e "Insertar silencio" hacían lo mismo.
   const editing=mix.querySelector('.timeline-top .right');
   if(editing){editing.innerHTML='<span class="vs-clip-hint" title="Clic derecho en un clip para editarlo. S dividir · D duplicar · Supr eliminar">Clic derecho sobre un clip · S dividir · D duplicar</span>';}
   const tool=mix.querySelector('.audio-lib-hint');if(tool)tool.textContent='Arrastrá audios al timeline o importalos desde Archivo. No se envían a internet.';
 }
 // La biblioteca tenía otro «Inicio» que abría exactamente la misma pantalla
 // que el botón «Proyectos» del encabezado.
 for(const id of ['simple','mix','radio']){
   const page=document.getElementById(id);
   page?.querySelector('.vsl-side-container [data-vsl-start]')?.remove();
   // «Ver» es el menú de zoom; «Paneles» administra el espacio de trabajo.
   const layout=page?.querySelector('.vs-view-trigger');
   if(layout){layout.textContent='▥ Paneles';layout.title='Mostrar u ocultar paneles y cambiar la distribución del editor';}
 }
 if(radio){
   const file=radio.querySelector('.vs-compact-dropdown[data-kind="files"] .vs-compact-dropdown-list');
   if(file){for(const action of ['savestation','import']){const button=radio.querySelector(`.work-header [data-radio="${action}"]`);if(button){button.classList.remove('primary');file.append(button);}}}
 }
}
function closeMenus(event){if(event?.target?.closest?.('.vs-compact-dropdown'))return;document.querySelectorAll('.vs-compact-dropdown[open]').forEach(x=>x.open=false);}
function init(){if(ready)return;ready=true;
 for(const id of ids){const page=document.getElementById(id);if(!page)continue;nav(page);if(id==='simple')simplifySimple(page);if(id==='mix')simplifyMix(page);if(id==='radio')simplifyRadio(page);libraryTabs(page);}
 simplifyOther();tidyV8();
 document.addEventListener('pointerdown',closeMenus);
 document.addEventListener('keydown',e=>{if(e.key==='Escape')closeMenus();},false);
}
window.VSCompactUI={init,close:closeMenus};
})();
