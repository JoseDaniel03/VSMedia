/* VSMix v5 — incremental local crash recovery. Audio bytes are written only
   when a new asset is introduced; edits update the small project manifest.
   Recovery is explicitly user-initiated, never automatically overwrites work. */
(()=>{'use strict';
const DB_NAME='VSMedia-Mix-Recovery-v5',DB_VERSION=1;
let pending=null,known=null,queue=Promise.resolve();
const chain=fn=>{const result=queue.then(fn);queue=result.catch(()=>{});return result;};
function database(){if(pending)return pending;
 pending=new Promise((resolve,reject)=>{if(typeof indexedDB==='undefined')return reject(Error('IndexedDB no disponible'));
  const req=indexedDB.open(DB_NAME,DB_VERSION);
  req.onupgradeneeded=()=>{const db=req.result;db.createObjectStore('meta');db.createObjectStore('assets',{keyPath:'id'});};
  req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error||Error('No se pudo abrir la recuperación'));req.onblocked=()=>reject(Error('Base de recuperación bloqueada'));
 }).catch(err=>{pending=null;throw err;});return pending;
}
function request(req){return new Promise((resolve,reject)=>{req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error||Error('Error de lectura'));});}
function done(tx){return new Promise((resolve,reject)=>{tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error||Error('Error al guardar'));tx.onabort=()=>reject(tx.error||Error('Almacenamiento cancelado'));});}
async function keys(db){if(known)return known;const tx=db.transaction('assets','readonly');const names=await request(tx.objectStore('assets').getAllKeys());known=new Set(names);return known;}
async function saveImpl(model,assets){if(!Array.isArray(assets)||!model||model.format!=='vsmedia-studio')throw Error('Proyecto inválido para recuperar');
 const db=await database(),old=await keys(db),ids=new Set(assets.map(a=>a.id));
 const tx=db.transaction(['meta','assets'],'readwrite'),as=tx.objectStore('assets'),meta=tx.objectStore('meta');
 const complete=done(tx);let modified=0;
 for(const a of assets){if(!old.has(a.id)){as.put({id:a.id,name:a.name,type:a.type,bytes:a.bytes});modified++;}}
 for(const id of old)if(!ids.has(id))as.delete(id);
 const savedAt=Date.now();meta.put({savedAt,model,ids:[...ids]},'active');await complete;
 known=new Set(ids);return {savedAt,assetsWritten:modified,assetsTotal:ids.size};
}
const save=(model,assets)=>chain(()=>saveImpl(model,assets));
async function infoImpl(){const db=await database(),tx=db.transaction('meta','readonly');return await request(tx.objectStore('meta').get('active'))||null;}
const info=()=>chain(infoImpl);
async function restoreImpl(){
 const db=await database();
 const metaTx=db.transaction('meta','readonly');
 const meta=await request(metaTx.objectStore('meta').get('active'));if(!meta)return null;
 const assetsTx=db.transaction('assets','readonly'),as=assetsTx.objectStore('assets');
 const assets=await Promise.all(meta.ids.map(id=>request(as.get(id))));
 for(let i=0;i<assets.length;i++)if(!assets[i]?.bytes)throw Error('La copia de recuperación está incompleta: '+meta.ids[i]);
 return {...meta,assets};
}
const restore=()=>chain(restoreImpl);
async function clearImpl(){const db=await database(),tx=db.transaction(['meta','assets'],'readwrite');const complete=done(tx);tx.objectStore('meta').clear();tx.objectStore('assets').clear();await complete;known=new Set();}
const clear=()=>chain(clearImpl);
const api={save,info,restore,clear};
if(typeof window!=='undefined')window.VSMixRecovery=api;
if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
