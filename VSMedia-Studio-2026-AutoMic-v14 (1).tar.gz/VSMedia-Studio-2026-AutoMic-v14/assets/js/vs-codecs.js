/* VSMedia: los trabajos pesados de audio se realizan en el navegador.
 * MediaRecorder genera WebM/Opus en el cliente; Vorbis/OGG se codifica
 * dentro de un Web Worker (sin FFmpeg en Folia).
 * El plugin Folia jamás recibe el archivo para convertirlo.
 */
(()=>{'use strict';
const presets={
 'voice-32':{label:'NPC · Opus mono · 32 kbps',ext:'opus',codec:'opus',kbps:32},
 'voice-40':{label:'Locución · Opus mono · 40 kbps',ext:'opus',codec:'opus',kbps:40},
 'sfx-48':{label:'Efectos · Opus mono · 48 kbps',ext:'opus',codec:'opus',kbps:48},
 'radio-96':{label:'Radio · Opus estéreo · 96 kbps',ext:'opus',codec:'opus',kbps:96},
 'radio-128':{label:'Música · Opus estéreo · 128 kbps',ext:'opus',codec:'opus',kbps:128},
 'webm-voice-40':{label:'Chrome · Voz WebM/Opus · 40 kbps',ext:'webm',codec:'opus',kbps:40},
 'webm-radio-96':{label:'Chrome · Radio WebM/Opus · 96 kbps',ext:'webm',codec:'opus',kbps:96},
 'webm-music-128':{label:'Chrome · Música WebM/Opus · 128 kbps',ext:'webm',codec:'opus',kbps:128},
 'mc-sfx':{label:'Vanilla · Vorbis mono · Q4',ext:'ogg',codec:'vorbis',kbps:null},
 'mc-music':{label:'Vanilla · Vorbis estéreo · Q5',ext:'ogg',codec:'vorbis',kbps:null}
};
const canEncode=()=>!!(window.MediaRecorder?.isTypeSupported?.('audio/webm;codecs=opus') && (window.AudioContext||window.webkitAudioContext));
const presetOptions=(chosen='voice-32')=>Object.entries(presets).map(([id,p])=>`<option value="${id}" ${id===chosen?'selected':''}>${p.label}</option>`).join('');
let cachedCapabilities=null;
async function capabilities(){
 if(cachedCapabilities)return cachedCapabilities;
 let remote=null;
 try{const response=await fetch('/api/audio/capabilities',{cache:'no-store',signal:AbortSignal.timeout(2500)});if(response.ok)remote=await response.json();}catch{}
 cachedCapabilities={...remote,ok:true,ffmpeg:!!remote?.ffmpeg,browserEncoding:canEncode(),server:remote?.server||'browser',pluginConnected:!!remote?.pluginConnected};
 return cachedCapabilities;
}
async function browserWebm(file,preset,{normalize=false}={}){
 if(!canEncode())throw Error('Este navegador no admite WebM/Opus por MediaRecorder. Usá Chromium actualizado.');
 if(file.size>128*1048576)throw Error('Para evitar falta de memoria, la conversión WebM del navegador admite hasta 128 MiB por archivo.');
 const Context=window.AudioContext||window.webkitAudioContext;
 const ctx=new Context();
 let recorder=null,source=null,finishTimeout=null,timeout=null;
 try{
  const raw=await file.arrayBuffer();
  const buffer=await ctx.decodeAudioData(raw);
  if(buffer.duration>3600)throw Error('Para codificar en tiempo real se admiten hasta 60 minutos por archivo.');
  // Normalización de pico aproximada, limitada para evitar recorte. No equivale
  // a una medición de loudness LUFS; dicha medición requiere un analizador.
  let gainValue=1;
  if(normalize){let peak=0;for(let ch=0;ch<buffer.numberOfChannels;ch++){
    const data=buffer.getChannelData(ch);for(let i=0;i<data.length;i+=64)peak=Math.max(peak,Math.abs(data[i]));
   }if(peak>1e-6)gainValue=Math.min(4,0.90/peak);
  }
  const gain=ctx.createGain();gain.gain.value=gainValue;
  const destination=ctx.createMediaStreamDestination();
  source=ctx.createBufferSource();source.buffer=buffer;source.connect(gain);gain.connect(destination);
  const chunks=[];
  const result=new Promise((resolve,reject)=>{
    recorder=new MediaRecorder(destination.stream,{mimeType:'audio/webm;codecs=opus',audioBitsPerSecond:presets[preset].kbps*1000});
    recorder.ondataavailable=e=>{if(e.data?.size)chunks.push(e.data);};
    recorder.onerror=e=>reject(Error(e.error?.message||'Fallo de MediaRecorder'));
    recorder.onstop=()=>{const blob=new Blob(chunks,{type:'audio/webm'});blob.size?resolve(blob):reject(Error('No se obtuvo audio comprimido'));};
    source.onended=()=>{finishTimeout=setTimeout(()=>{if(recorder.state!=='inactive')recorder.stop();},200);};
    recorder.start(1000);source.start();ctx.resume().catch(reject);
    timeout=setTimeout(()=>reject(Error('Se agotó el tiempo de codificación en el navegador.')),Math.ceil((buffer.duration+12)*1000));
  });
  return await result;
 }finally{
  if(timeout)clearTimeout(timeout);if(finishTimeout)clearTimeout(finishTimeout);
  try{if(recorder?.state!=='inactive')recorder?.stop();}catch{}
  try{source?.stop();}catch{}
  try{await ctx.close();}catch{}
 }
}
/** Minecraft uses real OGG/Vorbis, never rename WebM or Opus to .ogg. */
async function browserVorbis(file,preset,{normalize=false}={}){
 if(file.size>128*1048576)throw Error('El audio supera el límite local de 128 MiB.');
 const ctx=new (window.AudioContext||window.webkitAudioContext)();
 try{
  const decoded=await ctx.decodeAudioData(await file.arrayBuffer());
  if(decoded.duration>30*60)throw Error('Máximo 30 minutos por sonido en el navegador.');
  const channels=Math.min(preset==='mc-sfx'?1:2,decoded.numberOfChannels);
  const samples=[];
  for(let c=0;c<channels;c++){
   const arr=new Float32Array(decoded.length);arr.set(decoded.getChannelData(c));samples.push(arr);
  }
  if(normalize){let peak=0;for(const ch of samples)for(let i=0;i<ch.length;i+=32)peak=Math.max(peak,Math.abs(ch[i]));
   const gain=peak>1e-7?Math.min(4,.92/peak):1;
   for(const ch of samples)for(let i=0;i<ch.length;i++)ch[i]*=gain;
  }
  const quality=preset==='mc-sfx'?4:5;
  if(typeof Worker==='function'){
   return await new Promise((resolve,reject)=>{
    let worker,finished=false;
    const timeout=setTimeout(()=>done(Error('La conversión Vorbis superó el tiempo máximo.')),Math.max(30000,decoded.duration*3000));
    function done(err,bytes){if(finished)return;finished=true;clearTimeout(timeout);worker?.terminate();
      if(err)reject(err);else resolve(new Blob([bytes],{type:'audio/ogg'}));}
    try{worker=new Worker('assets/js/vs-vorbis-worker.js');
     worker.onmessage=e=>e.data?.error?done(Error(e.data.error)):done(null,e.data.bytes);
     worker.onerror=e=>done(Error(e.message||'Fallo en el codificador Vorbis'));
     worker.postMessage({channels:samples,rate:decoded.sampleRate,length:decoded.length,quality},samples.map(s=>s.buffer));
    }catch(error){done(error);}
   });
  }
  if(!window.VSOggVorbis)throw Error('No se pudo cargar el codificador OGG/Vorbis.');
  return window.VSOggVorbis.encodeBuffer({numberOfChannels:channels,length:decoded.length,sampleRate:decoded.sampleRate,duration:decoded.duration,getChannelData:i=>samples[i]},{quality});
 }finally{await ctx.close().catch(()=>{});}
}
async function serverConvert(file,preset,normalize){
 let res;try{res=await fetch(`/api/audio/convert?preset=${encodeURIComponent(preset)}&normalize=${normalize?1:0}`,{method:'POST',headers:{'Content-Type':'application/octet-stream','X-VSMedia-Local':'1'},body:file,signal:AbortSignal.timeout(380000)});}catch(e){throw Error('Conversor opcional no disponible: '+e.message);}
 if(!res.ok){let err;try{err=(await res.json()).error}catch{}throw Error(err||`Error de conversión HTTP ${res.status}`);}
 const blob=await res.blob();if(!blob.size)throw Error('El conversor devolvió un archivo vacío');return new Blob([blob],{type:res.headers.get('Content-Type')||'audio/ogg'});
}
async function convert(file,preset,{normalize=false}={}){
 if(!presets[preset])throw Error('Perfil de conversión inválido');
 if(!file?.size)throw Error('Seleccioná un archivo de audio');
 if(file.size>384*1048576)throw Error('Límite: 384 MiB por archivo');
 // Prioridad absoluta al navegador; no se envía audio al plugin ni a Minecraft.
 if(preset.startsWith('mc-'))return browserVorbis(file,preset,{normalize});
 if(preset.startsWith('webm-')&&canEncode())return browserWebm(file,preset,{normalize});
 const caps=await capabilities();
 if(caps.ffmpeg&&!caps.pluginConnected)return serverConvert(file,preset,normalize);
 throw Error(preset.startsWith('webm-')
  ?'WebM/Opus requiere MediaRecorder en el navegador (Chromium recomendado).'
  :'Esta salida OGG/Opus requiere un encoder WASM adicional. El plugin no convierte audio para proteger el rendimiento de Minecraft. Usá WebM/Opus o convertí en tu PC.');
}
function encodedName(original,preset){const base=String(original||'audio').replace(/\.[^.]+$/,'').replace(/[^\p{L}\p{N}._-]+/gu,'-').slice(0,84)||'audio';return `${base}.${presets[preset]?.ext||'ogg'}`;}
async function sha256(blob){const hash=await crypto.subtle.digest('SHA-256',await blob.arrayBuffer());return Array.from(new Uint8Array(hash),x=>x.toString(16).padStart(2,'0')).join('');}
window.VSCodecs={presets,presetOptions,capabilities,convert,encodedName,sha256};
})();
