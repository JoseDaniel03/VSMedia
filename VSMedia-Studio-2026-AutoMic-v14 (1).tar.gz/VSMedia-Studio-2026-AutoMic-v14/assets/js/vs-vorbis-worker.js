/* CPU-heavy OGG/Vorbis encoding is moved away from the page and Folia server. */
'use strict';
self.window=self;
importScripts('vs-ogg-vorbis.js');
self.onmessage=async event=>{
 try{
  const {channels,rate,length,quality}=event.data||{};
  if(!Array.isArray(channels)||!channels.length||channels.length>2||
     !channels.every(ch=>ch instanceof Float32Array&&ch.length===length)||
     !Number.isInteger(length)||length<1||length>48000*60*30||
     !Number.isFinite(rate)||rate<8000||rate>192000)throw Error('Audio inválido o demasiado largo.');
  const audio={numberOfChannels:channels.length,length,sampleRate:rate,duration:length/rate,
    getChannelData:i=>channels[i]};
  const blob=await self.VSOggVorbis.encodeBuffer(audio,{quality:Number(quality)||5});
  const bytes=await blob.arrayBuffer();
  if(new Uint8Array(bytes,0,4).some((v,i)=>v!==[79,103,103,83][i]))throw Error('OGG inválido');
  self.postMessage({bytes},[bytes]);
 }catch(err){self.postMessage({error:String(err.message||err)});}
};
