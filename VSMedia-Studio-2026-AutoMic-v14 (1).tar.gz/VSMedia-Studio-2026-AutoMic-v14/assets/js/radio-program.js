/* VSRadio Programación: sesiones finitas, listas locales/M3U y reproductor oficial YouTube.
   No extrae audio de YouTube, no simula emisiones Minecraft y no continúa con la pestaña cerrada. */
(() => {'use strict';
const $=(s,r)=>r.querySelector(s), esc=s=>window.VS.escape(String(s??''));
const uid=()=>crypto.randomUUID?.()||`r-${Date.now()}-${Math.random().toString(36).slice(2)}`;
const clamp=(n,a,b)=>Math.max(a,Math.min(b,Number(n)||0));
const pad=n=>String(Math.floor(n)).padStart(2,'0');
const fmt=n=>{n=Math.max(0,Math.round(Number(n)||0));return `${pad(Math.floor(n/3600))}:${pad(Math.floor(n%3600/60))}:${pad(n%60)}`;};
function youtubeRef(input){
 let u;try{u=new URL(String(input).trim());}catch{return null;}
 const host=u.hostname.toLowerCase();if(!['youtube.com','www.youtube.com','m.youtube.com','music.youtube.com','youtu.be','www.youtube-nocookie.com'].includes(host))return null;
 const list=u.searchParams.get('list');
 if(list&&/^[A-Za-z0-9_-]{10,80}$/.test(list))return {kind:'ytplaylist',ref:list,title:'Playlist de YouTube'};
 let vid=host==='youtu.be'?u.pathname.slice(1):u.pathname.startsWith('/shorts/')?u.pathname.split('/')[2]:u.pathname.startsWith('/embed/')?u.pathname.split('/')[2]:u.searchParams.get('v');
 if(vid&&/^[A-Za-z0-9_-]{11}$/.test(vid))return {kind:'ytvideo',ref:vid,title:'Video de YouTube'};
 return null;
}
function cleanEntry(raw){
 if(!raw||typeof raw!=='object')return null;
 const allowed=['local','ytvideo','ytplaylist','silence'];if(!allowed.includes(raw.kind))return null;
 const obj={id:typeof raw.id==='string'&&raw.id.length<90?raw.id:uid(),kind:raw.kind,title:String(raw.title||'Bloque').slice(0,130),role:['canción','locución','separador','programa'].includes(raw.role)?raw.role:'canción',ref:String(raw.ref||'').slice(0,110),localName:String(raw.localName||'').slice(0,150),seconds:clamp(raw.seconds,0,3600),fadeIn:clamp(raw.fadeIn,0,5),fadeOut:clamp(raw.fadeOut,0,5)};
 if(obj.kind==='ytvideo'&&!/^[A-Za-z0-9_-]{11}$/.test(obj.ref))return null;
 if(obj.kind==='ytplaylist'&&!/^[A-Za-z0-9_-]{10,80}$/.test(obj.ref))return null;
 if(obj.kind==='silence')obj.seconds=clamp(obj.seconds||5,1,3600);
 return obj;
}
function parseM3U(text){const lines=text.replace(/^\uFEFF/,'').split(/\r?\n/),items=[];let label='';for(const line of lines){const s=line.trim();if(!s)continue;if(s.startsWith('#EXTINF:')){label=s.slice(s.indexOf(',')+1).trim();continue;}if(s.startsWith('#'))continue;let ref=youtubeRef(s);if(ref)items.push(cleanEntry({...ref,title:label||ref.title}));else if(!/^\w+:\/\//.test(s)){const name=s.replace(/\\/g,'/').split('/').pop();items.push(cleanEntry({kind:'local',ref:'',localName:name,title:label||name}));}label='';if(items.length>=200)break;}return items.filter(Boolean);}
function normalize(data){const out={playlists:[],sessions:[],activePlaylist:null,activeSession:null};if(!data||typeof data!=='object')return out;
 for(const a of (Array.isArray(data.playlists)?data.playlists:[]).slice(0,50)){if(!a||typeof a!=='object')continue;out.playlists.push({id:String(a.id||uid()).slice(0,90),name:String(a.name||'Playlist').slice(0,80),items:(Array.isArray(a.items)?a.items:[]).slice(0,200).map(cleanEntry).filter(Boolean)});}
 for(const a of (Array.isArray(data.sessions)?data.sessions:[]).slice(0,50)){if(!a||typeof a!=='object')continue;out.sessions.push({id:String(a.id||uid()).slice(0,90),name:String(a.name||'Sesión').slice(0,80),date:/^\d{4}-\d\d-\d\d$/.test(a.date)?a.date:'',at:/^([01]\d|2[0-3]):[0-5]\d$/.test(a.at)?a.at:'',items:(Array.isArray(a.items)?a.items:[]).slice(0,250).map(cleanEntry).filter(Boolean)});}
 out.activePlaylist=out.playlists.some(x=>x.id===data.activePlaylist)?data.activePlaylist:out.playlists[0]?.id||null;
 out.activeSession=out.sessions.some(x=>x.id===data.activeSession)?data.activeSession:out.sessions[0]?.id||null;return out;}
function factory(ctx){
 const root=ctx.root,toast=(s,bad=false)=>window.VS.toast(s,bad);
 let model=normalize(null),ui=null,running=false,index=-1,token=0,source=null,timeout=null,yt=null,ytHost=null,lastScheduled='',armed=false,currentType='',startClock=0,watcher=null;
 try{model=normalize(JSON.parse(localStorage.getItem('vsradio-program-v2')||'null'));}catch{}
 if(!model.playlists.length){const p={id:uid(),name:'Música principal',items:[]};model.playlists.push(p);model.activePlaylist=p.id;}
 if(!model.sessions.length){const s={id:uid(),name:'Programa del día',date:'',at:'',items:[]};model.sessions.push(s);model.activeSession=s.id;}
 const playlist=()=>model.playlists.find(p=>p.id===model.activePlaylist);
 const session=()=>model.sessions.find(s=>s.id===model.activeSession);
 const lib=()=>ctx.library();
 const getAsset=item=>lib().find(a=>a.id===item.ref)||lib().find(a=>a.name===item.localName)||lib().find(a=>a.name===item.title);
 function persist(){try{localStorage.setItem('vsradio-program-v2',JSON.stringify(model));}catch{}}
 function state(){return JSON.parse(JSON.stringify(model));}
 function restore(d){stop();model=normalize(d);if(!model.playlists.length){model.playlists.push({id:uid(),name:'Música principal',items:[]});model.activePlaylist=model.playlists[0].id;}if(!model.sessions.length){model.sessions.push({id:uid(),name:'Programa del día',date:'',at:'',items:[]});model.activeSession=model.sessions[0].id;}persist();draw();}
 const opts=(arr,selected)=>arr.map(x=>`<option value="${esc(x.id)}" ${x.id===selected?'selected':''}>${esc(x.name)}</option>`).join('');
 function estimate(item){if(item.kind==='silence')return item.seconds;if(item.kind==='local')return getAsset(item)?.buffer?.duration||null;return null;}
 function itemName(item){return item.kind==='local'&&getAsset(item)?.name||item.title;}
 function renderItems(items,scope){let sec=0,indefinite=false;return items.length?items.map((item,i)=>{const dur=estimate(item),when=indefinite?'—':fmt(sec);if(dur!==null)sec+=dur;else indefinite=true;let sub=item.kind==='local'?getAsset(item)?fmt(dur):'Falta importar el archivo':item.kind==='ytvideo'?'YouTube · video visible':item.kind==='ytplaylist'?'YouTube · lista externa':'Pausa · '+fmt(dur);return `<div class="rp-item ${running&&scope==='session'&&i===index?'playing':''}" data-rp-index="${i}"><span class="rp-item-no">${pad(i+1)}</span><div class="rp-item-main"><b>${esc(itemName(item))}</b><small>${esc(item.role)} · ${esc(sub)}</small></div><span class="rp-item-time" title="Inicio acumulado estimado">${when}</span><div class="rp-item-actions"><button data-rp="up" data-scope="${scope}" data-index="${i}" title="Subir">↑</button><button data-rp="down" data-scope="${scope}" data-index="${i}" title="Bajar">↓</button>${scope==='session'?`<button data-rp="cue" data-index="${i}" title="Reproducir desde aquí">▶</button>`:''}<button data-rp="remove" data-scope="${scope}" data-index="${i}" title="Quitar">×</button></div></div>`;}).join(''):'<div class="rp-empty">Sin bloques. Agregá canciones, locuciones, separadores o una playlist.</div>';}
 function renderPlaylist(){const p=playlist(),el=$('#rp-play-items',root);if(!p||!el)return;el.innerHTML=renderItems(p.items,'playlist');$('#rp-playlists',root).innerHTML=opts(model.playlists,model.activePlaylist);$('#rp-play-count',root).textContent=`${p.items.length} elementos`;}
 function renderSession(){const s=session();if(!s)return;$('#rp-sessions',root).innerHTML=opts(model.sessions,model.activeSession);$('#rp-date',root).value=s.date;$('#rp-at',root).value=s.at;$('#rp-session-count',root).textContent=`${s.items.length} bloques`;
 $('#rp-session-items',root).innerHTML=renderItems(s.items,'session');const seconds=s.items.reduce((n,item)=>n+(estimate(item)||0),0);$('#rp-duration',root).textContent=seconds?`Mínimo ${fmt(seconds)}`:'Duración variable';}
 function renderLibrary(){const select=$('#rp-local',root);if(!select)return;select.innerHTML=lib().length?lib().map(a=>`<option value="${esc(a.id)}">${esc(a.name)}</option>`).join(''):'<option value="">Importá audio en Biblioteca</option>';}
 function renderStatus(){if(!root)return;const s=session();const current=running&&s?.items[index];const status=$('#rp-status',root);if(status)status.textContent=running?`EN SESIÓN · ${index+1}/${s.items.length} · ${itemName(current)}`:armed?'PROGRAMACIÓN ARMADA · pestaña abierta':'FUERA DEL AIRE · SIN SESIÓN';$('#rp-go',root).disabled=running;$('#rp-stop',root).disabled=!running;$('#rp-next',root).disabled=!running;const badge=$('#radio-live-status',root);if(badge&&running)badge.textContent='SESIÓN EN REPRODUCCIÓN LOCAL';}
 function draw(){renderPlaylist();renderSession();renderLibrary();renderStatus();}
 function makeHtml(){return `<div class="rp-top"><div><p class="radio-eyebrow">RADIO POR BLOQUES · TIPO GTA</p><h2>Programación y sesiones</h2><p>El programa empieza cuando lo ordenás y termina al acabar la última pieza. No hay emisión continua.</p></div><div class="rp-status" id="rp-status">FUERA DEL AIRE</div></div>
 <div class="rp-content"><section class="rp-panel rp-playlist-panel"><div class="rp-section-head"><strong>PLAYLISTS</strong><small id="rp-play-count"></small></div><div class="rp-field-row"><select id="rp-playlists" aria-label="Playlist"></select><button class="rp-btn" data-rp="newplaylist" title="Nueva playlist">＋</button><button class="rp-btn" data-rp="cloneplaylist" title="Duplicar playlist">⧉</button><button class="rp-btn" data-rp="delplaylist" title="Eliminar playlist">×</button></div><div class="rp-field-row"><button class="rp-btn" data-rp="shuffleplaylist" title="Orden aleatorio">⤨ Mezclar</button><button class="rp-btn" data-rp="sortplaylist" title="Ordenar por título">A–Z</button><button class="rp-btn" data-rp="dedupeplaylist" title="Eliminar duplicados">≠ Duplicados</button></div><div class="rp-field-row"><select id="rp-local" aria-label="Audio local"></select><select id="rp-role" title="Tipo de contenido"><option value="canción">Canción</option><option value="locución">Locución</option><option value="separador">Separador</option><option value="programa">Programa grabado</option></select></div><button class="rp-btn full" data-rp="addlocal">＋ Añadir audio a playlist</button><div class="rp-field-row"><input id="rp-url" type="url" placeholder="Pegar URL de YouTube (video o playlist)" aria-label="YouTube URL"><button class="rp-btn" data-rp="addyoutube">Añadir</button></div><button class="rp-btn full" data-rp="importm3u">↑ Importar playlist .m3u / .m3u8</button><div class="rp-list" id="rp-play-items"></div><button class="rp-btn full primary" data-rp="addplaylist">→ Añadir playlist completa al programa</button></section>
 <section class="rp-panel rp-session-panel"><div class="rp-section-head"><strong>GUION DE LA SESIÓN</strong><small id="rp-session-count"></small></div><div class="rp-field-row"><select id="rp-sessions" aria-label="Sesión"></select><button class="rp-btn" data-rp="newsession" title="Nueva sesión">＋</button><button class="rp-btn" data-rp="clonesession" title="Duplicar sesión">⧉</button><button class="rp-btn" data-rp="delsession" title="Eliminar sesión">×</button></div><div class="rp-field-row"><label>FECHA <input id="rp-date" type="date" title="Fecha programada (opcional)"></label><label>HORA <input id="rp-at" type="time" title="Hora de inicio (opcional)"></label></div><div class="rp-note">Fechas/horas: activan el programa solo con la página abierta y permisos de reproducción. Sin fecha: sesión manual.</div><div class="rp-field-row"><button class="rp-btn" data-rp="addcurrent">＋ Audio seleccionado</button><button class="rp-btn" data-rp="addsilence">＋ Pausa</button><button class="rp-btn" data-rp="exportplan">↓ Guion JSON</button><button class="rp-btn" data-rp="exporttxt">↓ Escaleta TXT</button></div><div class="rp-list rp-session-items" id="rp-session-items"></div><div class="rp-totals"><span id="rp-duration">Duración variable</span><span>Duración YouTube: externa</span></div><div class="rp-transport"><button id="rp-go" class="rp-btn primary" data-rp="play">▶ Iniciar sesión</button><button id="rp-stop" class="rp-btn" data-rp="stop">■ Detener</button><button id="rp-next" class="rp-btn" data-rp="skip">⏭ Siguiente</button></div><label class="rp-arm"><input id="rp-armed" type="checkbox"> Habilitar inicio programado de sesiones por fecha/hora</label></section>
 <section class="rp-panel rp-player-panel"><div class="rp-section-head"><strong>REPRODUCTOR YOUTUBE</strong><small>Player oficial</small></div><div id="rp-youtube" class="rp-youtube"><p>Al iniciar un bloque de YouTube se mostrará aquí su reproductor oficial. No se descarga ni extrae el audio.</p></div><p class="rp-note">Las playlists de YouTube se reproducen como bloque dentro del player visible. No se mezclan ni se graban con el mixer local y pueden requerir clic en ▶. Para programar canción por canción importá una playlist M3U o agregá videos individualmente.</p><div class="rp-section-head"><strong>FUENTES DEL PROGRAMA</strong></div><p class="rp-note">♫ Archivos locales · <strong>LOC</strong> locuciones pregrabadas · <strong>SEP</strong> separadores · <strong>YT</strong> videos/listas externas · <strong>⏱</strong> pausas. Las grabaciones de Simple/Mix se pueden importar aquí.</p><div class="rp-section-head"><strong>ESTADO</strong></div><p class="rp-note">Una sesión termina y la estación queda en espera. Para transmitir a Minecraft se necesitará el adaptador del plugin. Un navegador cerrado no puede cumplir horarios automáticamente.</p></section></div><input id="rp-m3u" type="file" accept=".m3u,.m3u8,audio/x-mpegurl" hidden></div>`;}
 function setView(isPlan){if(!isPlan&&running&&(currentType==='ytvideo'||currentType==='ytplaylist'))stop();root.classList.toggle('program-mode',isPlan);$('#rp-open',root)?.classList.toggle('rp-selected',isPlan);$('#rp-console',root)?.classList.toggle('rp-selected',!isPlan);}
 function stopSource(){if(source){try{source.onended=null;source.stop();source.disconnect();}catch{}source=null;}if(timeout!==null){clearTimeout(timeout);timeout=null;}if(yt){try{yt.destroy();}catch{}yt=null;}ytHost.innerHTML='<p>Reproductor de YouTube en espera.</p>';}
 function stop(){running=false;index=-1;token++;stopSource();renderStatus();}
 function finish(curr){if(!running||token!==curr)return;run(index+1,curr).catch(e=>{toast(e.message,true);stop();});}
 function loadYouTubeApi(){if(window.YT?.Player)return Promise.resolve();if(window.__vsRadioYTApi)return window.__vsRadioYTApi;window.__vsRadioYTApi=new Promise((resolve,reject)=>{const old=window.onYouTubeIframeAPIReady;const timer=setTimeout(()=>reject(Error('YouTube no respondió. Revisá tu conexión.')),15000);window.onYouTubeIframeAPIReady=()=>{clearTimeout(timer);try{old?.();}catch{}resolve();};const script=document.createElement('script');script.src='https://www.youtube.com/iframe_api';script.onerror=()=>{clearTimeout(timer);reject(Error('No se pudo cargar la API de YouTube.'));};document.head.appendChild(script);});return window.__vsRadioYTApi;}
 async function run(i,curr){if(curr!==token||!running)return;stopSource();const s=session();if(!s||i>=s.items.length){stop();toast('Sesión terminada. La radio quedó fuera del aire.');return;}index=i;const step=s.items[i];currentType=step.kind;renderSession();renderStatus();
 if(step.kind==='silence'){timeout=setTimeout(()=>finish(curr),step.seconds*1000);return;}
 if(step.kind==='local'){const a=getAsset(step);if(!a){toast(`Falta el archivo: ${step.title}`,true);stop();return;}const ac=ctx.initAudio();await ac.resume();if(token!==curr)return;const src=ac.createBufferSource();src.buffer=a.buffer;const gain=ac.createGain();const d=a.buffer.duration,fadeIn=Math.min(d/2,step.fadeIn),fadeOut=Math.min(d/2,step.fadeOut);gain.gain.setValueAtTime(fadeIn?0:1,ac.currentTime);if(fadeIn)gain.gain.linearRampToValueAtTime(1,ac.currentTime+fadeIn);if(fadeOut){gain.gain.setValueAtTime(1,ac.currentTime+d-fadeOut);gain.gain.linearRampToValueAtTime(0,ac.currentTime+d);}src.connect(gain).connect(ctx.master());source=src;src.onended=()=>finish(curr);startClock=performance.now();src.start();return;}
 await loadYouTubeApi();if(token!==curr)return;ytHost.innerHTML='<div id="rp-youtube-player" class="rp-video"></div>';yt=new YT.Player('rp-youtube-player',{height:'216',width:'100%',videoId:step.kind==='ytvideo'?step.ref:undefined,playerVars:{playsinline:1,controls:1,rel:0,origin:location.origin.startsWith('http')?location.origin:undefined,...(step.kind==='ytplaylist'?{listType:'playlist',list:step.ref}:{})},events:{onReady:e=>{if(token!==curr)return;try{e.target.playVideo();}catch{}},onStateChange:e=>{if(token!==curr||!running)return;if(e.data===YT.PlayerState.ENDED){if(step.kind==='ytvideo')finish(curr);else{const list=e.target.getPlaylist()||[];const at=e.target.getPlaylistIndex();if(list.length&&at>=list.length-1)finish(curr);}}},onError:e=>{if(token===curr){toast('YouTube no permite reproducir este contenido (código '+e.data+').',true);stop();}}}});
 }
 function play(from=0){if(running)stop();if(!session()?.items.length){toast('Agregá al menos un bloque al programa.',true);return;}ctx.stopDecks();running=true;token++;setView(true);const curr=token;run(from,curr).catch(e=>{if(token===curr){toast(e.message,true);stop();}});}
 function tick(){if(!root||root.hidden||running||!armed)return;const today=new Date(),day=`${today.getFullYear()}-${pad(today.getMonth()+1)}-${pad(today.getDate())}`,hh=`${pad(today.getHours())}:${pad(today.getMinutes())}`;for(const s of model.sessions){const key=`${s.id}-${day}-${hh}`;if(s.at===hh&&(!s.date||s.date===day)&&s.items.length&&lastScheduled!==key){lastScheduled=key;model.activeSession=s.id;renderSession();play();toast('Inicio horario solicitado. Si el navegador bloquea autoplay, pulsá ▶.');break;}}}
 function addEntry(target,entry){if(!target)return;const cleaned=cleanEntry(entry);if(!cleaned)return;if(target.items.length>=250)return toast('Límite de 250 bloques.',true);target.items.push(cleaned);persist();draw();}
 function handleAction(code,d){const p=playlist(),s=session();const name=()=>prompt('Nombre',code.includes('session')?'Programa nuevo':'Playlist nueva');switch(code){
 case 'console':setView(false);return;
 case 'open':setView(true);renderLibrary();return;
 case 'newplaylist':{const title=name();if(!title?.trim())return;model.playlists.push({id:uid(),name:title.trim().slice(0,80),items:[]});model.activePlaylist=model.playlists.at(-1).id;break;}
 case 'delplaylist':if(model.playlists.length<2)return toast('Debe quedar al menos una playlist.',true);if(!confirm(`Eliminar la playlist «${p.name}»?`))return;model.playlists=model.playlists.filter(x=>x.id!==p.id);model.activePlaylist=model.playlists[0].id;break;
 case 'newsession':{const title=name();if(!title?.trim())return;model.sessions.push({id:uid(),name:title.trim().slice(0,80),date:'',at:'',items:[]});model.activeSession=model.sessions.at(-1).id;break;}
 case 'delsession':if(model.sessions.length<2)return toast('Debe quedar al menos una sesión.',true);if(!confirm(`Eliminar la sesión «${s.name}»?`))return;if(running)stop();model.sessions=model.sessions.filter(x=>x.id!==s.id);model.activeSession=model.sessions[0].id;break;
 case 'cloneplaylist':{
  if(model.playlists.length>=50)return toast('Límite de playlists.',true);
  const copy={id:uid(),name:(p.name+' copia').slice(0,80),items:p.items.map(x=>({...x,id:uid()}))};model.playlists.push(copy);model.activePlaylist=copy.id;break;
 }
 case 'shuffleplaylist':{
  if(p.items.length<2)return;for(let i=p.items.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[p.items[i],p.items[j]]=[p.items[j],p.items[i]];}break;
 }
 case 'sortplaylist':p.items.sort((a,b)=>a.title.localeCompare(b.title,'es',{sensitivity:'base'}));break;
 case 'dedupeplaylist':{
  const seen=new Set();const old=p.items.length;
  p.items=p.items.filter(item=>{const key=item.kind+'|'+(item.ref||item.localName||item.title).toLowerCase();if(seen.has(key))return false;seen.add(key);return true;});
  toast(`${old-p.items.length} elementos duplicados eliminados.`);break;
 }
 case 'clonesession':{
  if(model.sessions.length>=50)return toast('Límite de sesiones.',true);
  if(running)return toast('Detené la sesión antes de duplicarla.',true);
  const copy={...s,id:uid(),name:(s.name+' copia').slice(0,80),date:'',at:'',items:s.items.map(x=>({...x,id:uid()}))};model.sessions.push(copy);model.activeSession=copy.id;break;
 }
 case 'addlocal':case 'addcurrent':{const a=lib().find(x=>x.id===$('#rp-local',root).value);if(!a)return toast('Importá primero un audio.',true);addEntry(code==='addlocal'?p:s,{kind:'local',title:a.name,ref:a.id,localName:a.name,role:$('#rp-role',root).value});return;}
 case 'addyoutube':{const u=$('#rp-url',root).value.trim(),ref=youtubeRef(u);if(!ref)return toast('Pegá un enlace válido de video o playlist de YouTube.',true);const title=prompt('Nombre para identificar este bloque',ref.title);if(title===null)return;addEntry(p,{...ref,title:title.trim()||ref.title});$('#rp-url',root).value='';return;}
 case 'addplaylist':{if(!p.items.length)return toast('La playlist está vacía.',true);if(s.items.length+p.items.length>250)return toast('La sesión supera los 250 bloques.',true);s.items.push(...p.items.map(x=>({...x,id:uid()})));break;}
 case 'addsilence':{const sec=Number(prompt('Segundos de pausa', '5'));if(!Number.isFinite(sec)||sec<=0||sec>3600)return;addEntry(s,{kind:'silence',title:`Pausa ${sec} s`,seconds:sec,role:'separador'});return;}
 case 'up':case 'down':case 'remove':{const target=d.scope==='playlist'?p:s,idx=Number(d.index);if(!target||!Number.isInteger(idx)||idx<0||idx>=target.items.length)return;if(running&&target===s)return toast('Detené la sesión antes de reordenarla.',true);if(code==='remove')target.items.splice(idx,1);else{const j=code==='up'?idx-1:idx+1;if(j<0||j>=target.items.length)return;[target.items[idx],target.items[j]]=[target.items[j],target.items[idx]];}break;}
 case 'cue':return play(Number(d.index));
 case 'play':return play();
 case 'stop':return stop();
 case 'skip':return finish(token);
 case 'importm3u':return $('#rp-m3u',root).click();
 case 'exporttxt':{
  let total=0,unknown=false;
  const lines=[`VSMEDIA / ESC ALETA DE RADIO: ${s.name}`,`Fecha: ${s.date||'sin fecha'} · Horario: ${s.at||'manual'}`,'—'.repeat(54)];
  for(let i=0;i<s.items.length;i++){
    const item=s.items[i],length=estimate(item);
    const at=unknown?'--:--:--':fmt(total);
    lines.push(`${String(i+1).padStart(2,'0')} [${at}] ${item.role.toUpperCase()} · ${itemName(item)} (${length===null?'duración externa':fmt(length)})`);
    if(length===null)unknown=true;else total+=length;
  }
  lines.push('',`Duración local contabilizada: ${fmt(total)}`,'YouTube y enlaces externos pueden requerir inicio manual.');
  window.VS.download(new Blob([lines.join('\n')],{type:'text/plain;charset=utf-8'}),`${window.VS.filename(s.name)}-escaleta.txt`);return;
 }
 case 'exportplan':{const payload={format:'vsradio-program-v2',schema:2,exported:new Date().toISOString(),...state()};window.VS.download(new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}),`${window.VS.filename(s.name)}-guion.json`);return;}
 }persist();draw();}
 function mount(){ui=$('#radio-program-pane',root);ui.innerHTML=makeHtml();ytHost=$('#rp-youtube',root);ui.addEventListener('click',e=>{const b=e.target.closest('[data-rp]');if(b)handleAction(b.dataset.rp,b.dataset);});$('#rp-playlists',root).onchange=e=>{model.activePlaylist=e.target.value;persist();renderPlaylist();};$('#rp-sessions',root).onchange=e=>{if(running)stop();model.activeSession=e.target.value;persist();renderSession();};$('#rp-date',root).onchange=e=>{session().date=e.target.value;persist();};$('#rp-at',root).onchange=e=>{session().at=e.target.value;persist();};$('#rp-armed',root).onchange=e=>{armed=e.target.checked;renderStatus();};$('#rp-m3u',root).onchange=async e=>{const f=e.target.files?.[0];e.target.value='';if(!f)return;if(f.size>1024*1024)return toast('Archivo M3U demasiado grande.',true);const items=parseM3U(await f.text());if(!items.length)return toast('M3U sin entradas compatibles.',true);{const p=playlist();p.items.push(...items.slice(0,Math.max(0,200-p.items.length)));}persist();draw();toast(`${items.length} entradas importadas. Los archivos locales requieren relink por nombre.`);};root.addEventListener('click',e=>{const b=e.target.closest('[data-radio="planner"]');if(b)setView(true);const c=e.target.closest('[data-radio="console"]');if(c)setView(false);});watcher=setInterval(tick,15000);draw();setView(true);}
 function close(){stop();armed=false;$('#rp-armed',root).checked=false;renderStatus();}
 return {mount,draw,stop,close,state,restore,play,isVoicePlaying:()=>{const step=running?session()?.items?.[index]:null;return !!(step&&step.kind==='local'&&step.role==='locución'&&source);},getState:()=>({running,index,armed,session:session()?.name,playlists:model.playlists.length,sessions:model.sessions.length}),youtubeRef,parseM3U};
}
window.VSRadioProgramFactory=factory;
window.VSRadioProgramTools={youtubeRef,parseM3U,normalize};
})();
