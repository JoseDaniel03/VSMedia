/* Deterministic, allocation-bounded analysis for VSAudio and VSMix.
   Uses AudioBuffer-compatible input, so it can be tested without a browser. */
(function(scope){'use strict';
 function detectSilences(buffer,{thresholdDb=-38,minSeconds=.35,hopSeconds=.02,mergeSeconds=.06}={}){
   if(!buffer||!Number.isFinite(buffer.sampleRate)||buffer.sampleRate<=0||!Number.isFinite(buffer.length)||buffer.length<0)throw Error('AudioBuffer inválido');
   if(!Number.isFinite(thresholdDb)||thresholdDb>0||thresholdDb< -100)throw Error('Umbral inválido');
   if(!Number.isFinite(minSeconds)||minSeconds<.05||minSeconds>60)throw Error('Duración mínima inválida');
   const hop=Math.max(1,Math.floor(buffer.sampleRate*hopSeconds));
   const channelCount=Math.min(2,Math.max(1,buffer.numberOfChannels||1));
   const channels=Array.from({length:channelCount},(_,i)=>buffer.getChannelData(i));
   const threshold=Math.pow(10,thresholdDb/10);
   const windows=Math.ceil(buffer.length/hop),runs=[];
   let start=-1;
   for(let n=0;n<windows;n++){
     const a=n*hop,b=Math.min(buffer.length,a+hop),stride=Math.max(1,Math.floor((b-a)/128));
     let energy=0,count=0;
     for(let i=a;i<b;i+=stride)for(const c of channels){const s=c[i]||0;energy+=s*s;count++;}
     const silent=count===0||energy/count<=threshold;
     if(silent){if(start===-1)start=a;}
     else if(start!==-1){runs.push([start/buffer.sampleRate,a/buffer.sampleRate]);start=-1;}
   }
   if(start!==-1)runs.push([start/buffer.sampleRate,buffer.length/buffer.sampleRate]);
   const merged=[];
   for(const [a,b] of runs){const prev=merged.at(-1);if(prev&&a-prev[1]<=mergeSeconds)prev[1]=b;else merged.push([a,b]);}
   return merged.filter(([a,b])=>b-a>=minSeconds).slice(0,200);
 }
 /** RMS and true sample peak, never estimated from the gain slider. */
 function audioStats(buffer,{start=0,end=buffer.duration}={}){
  const sr=buffer.sampleRate,a=Math.max(0,Math.floor(start*sr)),b=Math.min(buffer.length,Math.ceil(end*sr));
  if(!Number.isFinite(a)||!Number.isFinite(b)||b<a)throw Error('Región inválida');
  let power=0,peak=0,count=0;
  for(let c=0;c<buffer.numberOfChannels;c++){
   const ch=buffer.getChannelData(c);
   for(let i=a;i<b;i++){const x=ch[i];power+=x*x;peak=Math.max(peak,Math.abs(x));count++;}
  }
  return {peak,rms:Math.sqrt(power/Math.max(1,count)),samples:count};
 }
 function snapToEdge(time,edges,tolerance=.10){
  if(!Number.isFinite(time)||!Number.isFinite(tolerance)||tolerance<0)return time;
  let closest=time,best=tolerance;
  for(const edge of edges)if(Number.isFinite(edge)){const d=Math.abs(edge-time);if(d<=best){best=d;closest=edge;}}
  return closest;
 }
 scope.VSAudioAnalysis={detectSilences,audioStats,snapToEdge};
 if(typeof module!=='undefined'&&module.exports)module.exports=scope.VSAudioAnalysis;
})(typeof window!=='undefined'?window:globalThis);
