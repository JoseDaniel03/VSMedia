/* VSMedia VSPack panel. Mount large Foundry/Blockbench resources only on first entry. */
(()=>{'use strict';
let host=null, frame=null, ready=false, lastState=null, current='library', manager=null, initialized=false, pending=new Map(), readyListeners=[];
const views=[['library','Biblioteca'],['managers','Gestores'],['editor','Editor'],['composer','Compositor'],['publisher','Exportar']];
const locationFor=()=>`modules/vspack/index.html?embed=1&view=${encodeURIComponent(current)}${manager?'&manager='+encodeURIComponent(manager):''}`;
function html(){return `<div class="pack-top pack-top-compact"><div class="pack-mark">▽ <strong>VSMEDIA</strong> <span> / VSPACK</span></div><div class="pack-top-actions"><span id="pack-runtime-status">Gestión local</span><button id="pack-home" class="panel-btn">⌂ Home</button></div></div><div class="pack-embed"><iframe id="vspack-internal" title="VSPack Foundry — gestor de recursos" src="${locationFor()}" allow="fullscreen" loading="eager"></iframe></div>`;}
function send(type,opts={}){if(!frame?.contentWindow)return;frame.contentWindow.postMessage({source:'vsmedia',type,requestId:'vm-'+Date.now().toString(36),...opts},location.origin);}
function switchView(view,selectedManager=null){
 if(!views.some(([id])=>id===view))return;
 if(!initialized){current=view;manager=selectedManager;return;}
 if(ready)send('NAVIGATE',{view,manager:selectedManager});
 else if(frame){current=view;manager=selectedManager;frame.src=locationFor();}
}
function mount(){
 if(initialized||!host)return;
 initialized=true;host.innerHTML=html();frame=host.querySelector('#vspack-internal');
 host.querySelector('#pack-home').onclick=()=>window.VS.navigate('home');
 frame.addEventListener('load',()=>{ready=false;setTimeout(()=>{if(frame?.isConnected)send('GET_STATE');},250);});
}
function init(node){
 host=node;
 window.addEventListener('message',event=>{
  if(event.origin!==location.origin||event.source!==frame?.contentWindow||event.data?.source!=='vspack')return;
  const data=event.data;
  if(data.type==='ready'){ready=true;host.querySelector('#pack-runtime-status').textContent='Gestor conectado · Local';send('GET_STATE');for(const fn of readyListeners.splice(0))fn();}
  if(data.type==='RESPONSE'&&pending.has(data.requestId)){const p=pending.get(data.requestId);pending.delete(data.requestId);clearTimeout(p.timer);data.error?p.reject(Error(data.error)):p.resolve(data.result);}
  if(data.type==='change'||data.type==='RESPONSE'){
    if(data.type==='RESPONSE'&&data.error)return;
    const snapshot=data.result&&typeof data.result==='object'?data.result:data;
    if(snapshot.view){current=snapshot.view;manager=snapshot.manager||null;lastState=snapshot;}
  }
 });
}
async function importSound({packId,namespace,eventName,blob,stream=false,subtitle=''}){
 if(!(blob instanceof Blob)||!blob.size||blob.size>32*1048576)throw Error('Audio vacío o mayor que 32 MiB');
 if(!host)throw Error('VSPack aún no está inicializado.');
 mount();
 if(!ready)await new Promise((resolve,reject)=>{
   const timer=setTimeout(()=>reject(Error('VS Pack no respondió a tiempo')),12000);
   readyListeners.push(()=>{clearTimeout(timer);resolve();});
 });
 const requestId='sound-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2);
 const bytes=new Uint8Array(await blob.arrayBuffer());
 const response=new Promise((resolve,reject)=>{
  const timer=setTimeout(()=>{pending.delete(requestId);reject(Error('VS Pack no respondió al guardar el audio'))},30000);
  pending.set(requestId,{resolve,reject,timer});
 });
 frame.contentWindow.postMessage({source:'vsmedia',type:'IMPORT_SOUND',requestId,packId,namespace,eventName,bytes,stream,subtitle},location.origin,[bytes.buffer]);
 return response;
}
window.VSPackApp={init,enter:mount,show:selectedManager=>switchView('managers',selectedManager),state:()=>lastState,importSound};
})();
