/* VS Voice DSP v14: WebRTC-enhanced microphone, automatic voice leveling, optional creative presets. */
(()=>{'use strict';
const profiles={
 auto:{label:'Automático · voz clara (recomendado)',hp:85,lp:14500,low:0,presence:1,threshold:-26,ratio:2.4,gate:-62,deEss:.3,attack:.009,release:.24,gainDb:0,echoMix:0,drive:0,tremolo:0},
 headset:{label:'Chat / auriculares',hp:90,lp:14500,low:0,presence:1,threshold:-25,ratio:2.8,gate:-60,deEss:.3,attack:.008,release:.22,gainDb:0,echoMix:0,drive:0,tremolo:0},
 budget:{label:'Micrófono económico',hp:120,lp:11000,low:-2,presence:2,threshold:-30,ratio:3.4,gate:-53,deEss:.45,attack:.008,release:.24,gainDb:2,echoMix:0,drive:0,tremolo:0},
 natural:{label:'Micrófono de estudio',hp:75,lp:17500,low:0,presence:0,threshold:-20,ratio:1.8,gate:-68,deEss:.15,attack:.015,release:.30,gainDb:0,echoMix:0,drive:0,tremolo:0},
 clean:{label:'Voz limpia',hp:85,lp:14000,low:0,presence:1,threshold:-24,ratio:2.4,gate:-55,deEss:.3,echoMix:0,drive:0,tremolo:0},
 studio:{label:'Locución / radio',hp:95,lp:13000,low:2,presence:3,threshold:-29,ratio:3.5,gate:-50,deEss:.55,echoMix:0,drive:.06,tremolo:0},
 warm:{label:'Voz cálida',hp:75,lp:11000,low:3,presence:0,threshold:-27,ratio:3,gate:-52,deEss:.55,echoMix:0,drive:.03,tremolo:0},
 telephone:{label:'Teléfono',hp:440,lp:3100,low:-5,presence:5,threshold:-29,ratio:4,gate:-50,deEss:0,echoMix:0,drive:.3,tremolo:0},
 oldradio:{label:'Radio antigua',hp:330,lp:4200,low:-2,presence:4,threshold:-29,ratio:4.5,gate:-49,deEss:0,echoMix:.08,drive:.3,tremolo:0},
 megaphone:{label:'Megáfono',hp:390,lp:4800,low:-7,presence:6,threshold:-30,ratio:5,gate:-47,deEss:0,echoMix:.05,drive:.7,tremolo:0},
 robot:{label:'Robótica (modulación)',hp:100,lp:11000,low:0,presence:2,threshold:-26,ratio:3,gate:-54,deEss:.2,echoMix:.04,drive:.14,tremolo:.9},
 ghost:{label:'Fantasma / eco',hp:130,lp:9000,low:-1,presence:0,threshold:-24,ratio:2,gate:-53,deEss:.1,echoMix:.33,drive:0,tremolo:.12}
};
let currentProfile='auto';
const activeSessions=new Set();
const DEFAULT_CAPTURE={noiseSuppression:true,echoCancellation:true,autoGainControl:true};
let captureOptions={...DEFAULT_CAPTURE}, globalParams={}, selectedDevice='';
try{const saved=JSON.parse(localStorage.getItem('vsmedia-mic-settings-v2')||'{}');
 if(saved.capture&&typeof saved.capture==='object')for(const k of Object.keys(DEFAULT_CAPTURE))if(typeof saved.capture[k]==='boolean'&&(k!=='autoGainControl'||saved.capture[k]===true))captureOptions[k]=saved.capture[k];
 // Old v13 saved autoGainControl:false by default. Upgrade to browser AGC ON.
 try{const newer=JSON.parse(localStorage.getItem('vsmedia-mic-capture-v14')||'null');if(newer&&typeof newer.autoGainControl==='boolean')captureOptions.autoGainControl=newer.autoGainControl;}catch{}
 if(typeof saved.deviceId==='string'&&saved.deviceId.length<512)selectedDevice=saved.deviceId;
 if(saved.params&&typeof saved.params==='object')for(const k of ['threshold','ratio','attack','release','gate','deEss','gainDb','echoMix'])if(Number.isFinite(Number(saved.params[k])))globalParams[k]=Number(saved.params[k]);
}catch{}
function persistSettings(){try{localStorage.setItem('vsmedia-mic-settings-v2',JSON.stringify({capture:captureOptions,params:globalParams,deviceId:selectedDevice}));}catch{}}
function setGlobalParams(value){for(const [k,v]of Object.entries(value||{}))if(['threshold','ratio','attack','release','gate','deEss','gainDb','echoMix'].includes(k)&&Number.isFinite(Number(v)))globalParams[k]=Number(v);persistSettings();for(const session of activeSessions)session.setParams(globalParams);}
function setCaptureOptions(value){for(const k of Object.keys(DEFAULT_CAPTURE))if(typeof value?.[k]==='boolean')captureOptions[k]=value[k];persistSettings();try{localStorage.setItem('vsmedia-mic-capture-v14',JSON.stringify({autoGainControl:captureOptions.autoGainControl}));}catch{}}
function setDevice(value){selectedDevice=typeof value==='string'&&value.length<512?value:'';persistSettings();}
async function devices(){const all=await navigator.mediaDevices?.enumerateDevices?.();return (all||[]).filter(x=>x.kind==='audioinput').map((x,i)=>({id:x.deviceId,name:x.label||'Micrófono '+(i+1)}));}


const clamp=(x,min,max)=>Math.min(max,Math.max(min,Number.isFinite(Number(x))?Number(x):min));
function preset(){try{const saved=localStorage.getItem('vsmedia-mic-preset-v14');if(profiles[saved])currentProfile=saved;}catch{}return currentProfile;}
function setPreset(value){if(!profiles[value])return;currentProfile=value;globalParams={};persistSettings();try{localStorage.setItem('vsmedia-mic-preset-v14',value);}catch{};document.querySelectorAll('[data-mic-preset]').forEach(s=>s.value=value);for(const session of activeSessions)session.setProfile(value);}
function controls(){return `<label class="vsvoice-preset">MICRÓFONO <select data-mic-preset title="Filtros de voz y locución">${Object.entries(profiles).map(([id,p])=>`<option value="${id}" ${id===preset()?'selected':''}>${p.label}</option>`).join('')}</select></label><button type="button" class="vs-mic-action" data-vs-mic-settings title="Configuración común de grabación">⚙ Mic</button><button type="button" class="vs-mic-action" data-vs-cue="auto" title="Abrir guion de grabación">▤ Guion</button>`;}
function curve(drive){const c=new Float32Array(1024);const d=clamp(drive,0,1),amount=1+d*18;for(let i=0;i<c.length;i++){const x=i*2/(c.length-1)-1;c[i]=d===0?x:Math.tanh(x*amount)/Math.tanh(amount);}return c;}
async function open({context=null,profile=preset(),record=true,settings={}}={}){
 if(!navigator.mediaDevices?.getUserMedia)throw Error('La captura requiere localhost o HTTPS y permisos del navegador.');
 const audioConstraints={echoCancellation:{ideal:settings.echoCancellation??captureOptions.echoCancellation},noiseSuppression:{ideal:settings.noiseSuppression??captureOptions.noiseSuppression},autoGainControl:{ideal:settings.autoGainControl??captureOptions.autoGainControl},channelCount:{ideal:1},sampleRate:{ideal:48000}};
 const inputDevice=settings.deviceId??selectedDevice;
 if(inputDevice)audioConstraints.deviceId={ideal:inputDevice};
 const raw=await navigator.mediaDevices.getUserMedia({audio:audioConstraints,video:false});
 const actualCapture=raw.getAudioTracks()[0]?.getSettings?.()||{};
 const smart=window.VSAutoVoice?.create({browserAgc:actualCapture.autoGainControl===true})||null;
 let ctx=context,own=false,timer=null,osc=null,monitorEnabled=false;const nodes=[];
 try{
  if(!ctx){ctx=new(window.AudioContext||window.webkitAudioContext)({latencyHint:'interactive'});own=true;}
  await ctx.resume();
  const mk=(fn)=>{const n=fn();nodes.push(n);return n;};
  const source=mk(()=>ctx.createMediaStreamSource(raw));
  const hp=mk(()=>ctx.createBiquadFilter());hp.type='highpass';hp.Q.value=.71;
  const low=mk(()=>ctx.createBiquadFilter());low.type='lowshelf';low.frequency.value=190;
  const presence=mk(()=>ctx.createBiquadFilter());presence.type='peaking';presence.frequency.value=3300;presence.Q.value=.9;
  const lp=mk(()=>ctx.createBiquadFilter());lp.type='lowpass';lp.Q.value=.71;
  const deEsser=mk(()=>ctx.createBiquadFilter());deEsser.type='highshelf';deEsser.frequency.value=5200;
  const distortion=mk(()=>ctx.createWaveShaper());distortion.oversample='2x';
  const tremolo=mk(()=>ctx.createGain());
  const compressor=mk(()=>ctx.createDynamicsCompressor());compressor.knee.value=12;
  const gate=mk(()=>ctx.createGain());
  const autoGain=mk(()=>ctx.createGain()); // soft gain after expander, before final limiter
  const limiter=mk(()=>ctx.createDynamicsCompressor());limiter.threshold.value=-2;limiter.knee.value=0;limiter.ratio.value=20;limiter.attack.value=.003;limiter.release.value=.08;
  const output=mk(()=>ctx.createGain());
  // Keep the pre-gate analyser in the active graph even when monitoring is off.
  const probeSink=mk(()=>ctx.createGain());probeSink.gain.value=0;
  const analyser=mk(()=>ctx.createAnalyser());analyser.fftSize=1024;analyser.smoothingTimeConstant=.75;
  const spectral=mk(()=>ctx.createAnalyser());spectral.fftSize=1024;
  const sourceProbe=mk(()=>ctx.createAnalyser());sourceProbe.fftSize=1024;source.connect(sourceProbe);sourceProbe.connect(probeSink).connect(output);
  const destination=record?mk(()=>ctx.createMediaStreamDestination()):null;
  const echoDelay=mk(()=>ctx.createDelay(.5));echoDelay.delayTime.value=.19;
  const feedback=mk(()=>ctx.createGain());feedback.gain.value=.22;
  const wet=mk(()=>ctx.createGain());
  source.connect(hp).connect(low).connect(presence).connect(lp).connect(deEsser).connect(distortion).connect(tremolo).connect(compressor).connect(gate).connect(autoGain).connect(limiter).connect(output).connect(analyser);
  deEsser.connect(spectral);
  output.connect(echoDelay);echoDelay.connect(feedback).connect(echoDelay);echoDelay.connect(wet).connect(analyser);
  if(destination)analyser.connect(destination);
  osc=mk(()=>ctx.createOscillator());osc.type='sine';osc.frequency.value=33;
  const lfo=mk(()=>ctx.createGain());osc.connect(lfo).connect(tremolo.gain);osc.start();
  let p={...(profiles[profile]||profiles.auto),...(profile==='auto'?{}:globalParams)};
  let lastVoice=0,lastDb=-96,lastInputDb=-96,voiceOpen=false,lastAuto=null;
  const gateHoldMs=260,voiceHoldMs=360;
  const samples=new Float32Array(analyser.fftSize),rawSamples=new Float32Array(analyser.fftSize),freq=new Float32Array(spectral.frequencyBinCount);
  const apply=opts=>{p={...p,...opts};hp.frequency.setTargetAtTime(clamp(p.hp,20,1200),ctx.currentTime,.02);
   lp.frequency.setTargetAtTime(clamp(p.lp,1800,21000),ctx.currentTime,.02);low.gain.setTargetAtTime(clamp(p.low,-15,15),ctx.currentTime,.02);presence.gain.setTargetAtTime(clamp(p.presence,-15,15),ctx.currentTime,.02);
   compressor.threshold.setTargetAtTime(clamp(p.threshold,-60,-3),ctx.currentTime,.03);compressor.ratio.setTargetAtTime(clamp(p.ratio,1,20),ctx.currentTime,.03);
   compressor.attack.setTargetAtTime(clamp(p.attack??.006,.001,.1),ctx.currentTime,.03);compressor.release.setTargetAtTime(clamp(p.release??.2,.04,.8),ctx.currentTime,.03);
   output.gain.setTargetAtTime(Math.pow(10,clamp(p.gainDb??0,-20,12)/20),ctx.currentTime,.03);
   distortion.curve=curve(p.drive||0);wet.gain.setTargetAtTime(clamp(p.echoMix||0,0,.55),ctx.currentTime,.04);
   tremolo.gain.setTargetAtTime(1-clamp(p.tremolo||0,0,1)*.45,ctx.currentTime,.03);
   lfo.gain.setTargetAtTime(clamp(p.tremolo||0,0,1)*.45,ctx.currentTime,.03);
  };
  apply(p);
  const interval=setInterval(()=>{
   if(ctx.state==='closed')return;
   spectral.getFloatFrequencyData(freq);
   // Conservative dynamic attenuation of sibilant frequencies; no proprietary model.
   if(p.deEss>0){let high=0,bass=0,hc=0,bc=0;const hz=ctx.sampleRate/spectral.fftSize;for(let i=0;i<freq.length;i++){let f=i*hz;if(f>4200&&f<9500){high+=freq[i];hc++;}else if(f>350&&f<3500){bass+=freq[i];bc++;}}const excess=(hc&&bc)?high/hc-bass/bc:0;const reduction=clamp((excess+7)*clamp(p.deEss,0,1)*.6,0,8);deEsser.gain.setTargetAtTime(-reduction,ctx.currentTime,.035);}
   else deEsser.gain.setTargetAtTime(0,ctx.currentTime,.04);
   sourceProbe.getFloatTimeDomainData(rawSamples);let rawSum=0,rawPeak=0;for(const sample of rawSamples){rawSum+=sample*sample;rawPeak=Math.max(rawPeak,Math.abs(sample));}const rawDb=20*Math.log10(Math.max(Math.sqrt(rawSum/rawSamples.length),1e-6));
   lastInputDb=rawDb;
   const now=performance.now(),threshold=clamp(p.gate,-90,-18);
   // Hysteresis and hold reduce pumping, clipped word endings and chattering.
   // Soft attenuation (-18 dB), not a binary mute: quiet syllables survive.
   if(rawDb>=threshold+(voiceOpen?0:4)){lastVoice=now;voiceOpen=true;}
   else if(voiceOpen&&rawDb<threshold-3&&now-lastVoice>voiceHoldMs)voiceOpen=false;
   const gateTarget=voiceOpen||now-lastVoice<gateHoldMs?1:.125;
   analyser.getFloatTimeDomainData(samples);let sum=0;for(const s of samples)sum+=s*s;lastDb=20*Math.log10(Math.max(Math.sqrt(sum/samples.length),1e-6));
   if(profile==='auto'&&smart){
     lastAuto=smart.step({inputDb:rawDb,outputDb:lastDb,peak:rawPeak,now});
     // WebRTC echo/noise/AGC + conservative local adaptation, with a final limiter.
     gate.gain.setTargetAtTime(lastAuto.gateFactor,ctx.currentTime,lastAuto.gateFactor===1?.025:.14);
     autoGain.gain.setTargetAtTime(Math.pow(10,lastAuto.gainDb/20),ctx.currentTime,.18);
     voiceOpen=lastAuto.voice;
     if(lastAuto.voice)lastVoice=now;
   }else{
     gate.gain.setTargetAtTime(gateTarget,ctx.currentTime,gateTarget===1?.014:.11);
     autoGain.gain.setTargetAtTime(1,ctx.currentTime,.08);
     lastAuto=null;
   }
  },45);
  timer=interval;
  let closed=false;
  const session={stream:destination?.stream||raw,rawStream:raw,context:ctx,output,profile,settings:raw.getAudioTracks()[0]?.getSettings?.()||{},get params(){return {...p};},setParams:opts=>apply(opts),setProfile:key=>{if(!profiles[key])return;profile=key;p={...profiles[key],...(key==='auto'?{}:globalParams)};smart?.reset();apply(p);},readAutoStatus:()=>lastAuto?{...lastAuto}:null,readMeter:()=>lastDb,readInputMeter:()=>lastInputDb,isSpeaking:()=>profile==='auto'&&lastAuto?lastAuto.voice:voiceOpen||performance.now()-lastVoice<voiceHoldMs,monitor:enabled=>{if(!!enabled===monitorEnabled)return;monitorEnabled=!!enabled;if(enabled)analyser.connect(ctx.destination);else try{analyser.disconnect(ctx.destination);}catch{};},stop:()=>{if(closed)return;closed=true;activeSessions.delete(session);clearInterval(interval);raw.getTracks().forEach(t=>t.stop());try{osc.stop();}catch{};for(const n of nodes)try{n.disconnect();}catch{};if(destination)destination.stream.getTracks().forEach(t=>t.stop());if(own)ctx.close().catch(()=>{});}};
  activeSessions.add(session);return session;
 }catch(err){clearInterval(timer);raw.getTracks().forEach(t=>t.stop());if(own&&ctx)ctx.close().catch(()=>{});throw err;}
}
function settingsDialog(){if(document.getElementById('vs-mic-settings'))return;const shell=document.createElement('div');shell.id='vs-mic-settings';shell.className='vs-mic-overlay';shell.innerHTML=`<section class="vs-mic-modal" role="dialog" aria-modal="true" aria-label="Ajustes globales del micrófono"><header><b>Configuración de micrófono · VS Media</b><button data-close-mic aria-label="Cerrar">✕</button></header><p>Voz automática está activa de forma predeterminada en todo VSMedia. Estos ajustes son opcionales y se comparten entre VSAudio, VSMix, VSRadio y VS Voice.</p><label>Micrófono de entrada<select data-mic-device><option value="">Dispositivo predeterminado</option></select></label><p class="vs-mic-hint">WebRTC reduce ruido, eco y nivela el micrófono si el navegador lo admite. La nivelación adaptativa y el limitador funcionan localmente; los filtros avanzados solo se necesitan para un efecto especial. Los cambios de micrófono o filtros de captura se aplican al volver a abrirlo.</p><div class="vs-mic-config-checks">${[['noiseSuppression','Reducir ruido de fondo'],['echoCancellation','Cancelar eco'],['autoGainControl','Ganancia automática del navegador']].map(([key,label])=>`<label><input type="checkbox" data-capture="${key}" ${captureOptions[key]?'checked':''}> ${label}</label>`).join('')}</div><div class="vs-mic-config-ranges">${[['threshold','Compresor · umbral',-50,-5,1, -25],['ratio','Compresor · relación',1,12,.5,3],['gate','Puerta de ruido',-85,-18,1,-53],['deEss','Control de sibilancias',0,1,.05,.4],['gainDb','Ganancia final',-18,12,.5,0],['echoMix','Eco de voz',0,.5,.02,0]].map(([key,label,min,max,step,fallback])=>`<label>${label}<input type="range" data-mic-param="${key}" min="${min}" max="${max}" step="${step}" value="${globalParams[key]??fallback}"><output data-mic-out="${key}">${globalParams[key]??fallback}</output></label>`).join('')}</div><footer><button data-mic-reset>Restablecer ajustes</button><button data-close-mic>Listo</button></footer></section>`;document.body.appendChild(shell);
 void devices().then(list=>{const select=shell.querySelector('[data-mic-device]');if(!select?.isConnected)return;
  for(const d of list){const option=document.createElement('option');option.value=d.id;option.textContent=d.name;select.append(option);}
  select.value=selectedDevice;
 }).catch(()=>{});
 shell.addEventListener('click',e=>{if(e.target===shell||e.target.closest('[data-close-mic]'))shell.remove();if(e.target.closest('[data-mic-reset]')){globalParams={};captureOptions={...DEFAULT_CAPTURE};selectedDevice='';persistSettings();shell.remove();for(const session of activeSessions)session.setProfile(preset());}});
 shell.addEventListener('input',e=>{const k=e.target.dataset.micParam;if(k){setGlobalParams({[k]:Number(e.target.value)});shell.querySelector(`[data-mic-out="${k}"]`).textContent=e.target.value;}});
 shell.addEventListener('change',e=>{const k=e.target.dataset.capture;if(k)setCaptureOptions({[k]:e.target.checked});if(e.target.matches('[data-mic-device]'))setDevice(e.target.value);});
}
function init(){document.addEventListener('change',e=>{if(e.target.matches('[data-mic-preset]'))setPreset(e.target.value);});document.addEventListener('click',e=>{if(e.target.closest('[data-vs-mic-settings]'))settingsDialog();});}
window.VSMic={profiles,preset,setPreset,setGlobalParams,setCaptureOptions,getGlobalParams:()=>({...globalParams}),getCaptureOptions:()=>({...captureOptions}),setDevice,devices,controls,open,init,_test:{profiles,clamp,curve,get active(){return activeSessions.size;}}};
})();
