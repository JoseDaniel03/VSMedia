/* VSMedia Biblioteca v2: filesystem-like collections shared by VSAudio, VSMix and VSRadio.
   Original files live locally in IndexedDB; metadata, folders and type tags can be edited.
   No network request is made. */
(()=>{'use strict';
const modules={simple:{name:'VSAudio',ext:'.vssimple'},mix:{name:'VSMix',ext:'.vsmedia'},radio:{name:'VSRadio',ext:'.vsradio'}};
const esc=s=>window.VS.escape(s), $=(s,r=document)=>r.querySelector(s);
let dbPromise=null,ui=new Map(),loadedModules=new Set(),memory=new Map();
const MAX_FILE=180*1024*1024;
function db(){if(!('indexedDB' in window))return Promise.resolve(null);if(dbPromise)return dbPromise;dbPromise=new Promise(resolve=>{
 try{const req=indexedDB.open('VSMedia-Media-Library',2);req.onupgradeneeded=()=>{const d=req.result;if(!d.objectStoreNames.contains('items')){const s=d.createObjectStore('items',{keyPath:'id'});s.createIndex('modified','modified');}};req.onsuccess=()=>resolve(req.result);req.onerror=()=>resolve(null);req.onblocked=()=>resolve(null);}catch{resolve(null);}});return dbPromise;}
async function transact(mode,act){const d=await db();if(!d)return act(null);return new Promise((resolve,reject)=>{try{const t=d.transaction('items',mode),s=t.objectStore('items');const req=act(s);if(req?.onsuccess!==undefined){req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);}else{t.oncomplete=()=>resolve();t.onerror=()=>reject(t.error);} }catch(e){reject(e);}});}
async function all(){try{const d=await db();if(!d)return [...memory.values()];return await transact('readonly',s=>s.getAll());}catch{return [...memory.values()];}}
async function byId(id){try{const d=await db();return d?await transact('readonly',s=>s.get(id)):memory.get(id);}catch{return memory.get(id);}}
async function put(item){try{const d=await db();if(d)await transact('readwrite',s=>s.put(item));else memory.set(item.id,item);}catch(e){console.warn('VSMedia Biblioteca sin persistencia:',e);memory.set(item.id,item);window.VS.toast('No se pudo guardar en la biblioteca del navegador (espacio insuficiente).',true);}renderAll();return item;}
async function remove(id){try{const d=await db();if(d)await transact('readwrite',s=>s.delete(id));memory.delete(id);renderAll();}catch(e){window.VS.toast('No se pudo eliminar de biblioteca: '+e.message,true);}}
const classify=(name,type='')=>/\.vsradio$/i.test(name)?'radio':/\.vsmedia$/i.test(name)?'mix':/\.vssimple$/i.test(name)?'simple':type.startsWith('audio/')||/\.(wav|mp3|ogg|m4a|opus|flac|webm|aac)$/i.test(name)?'audio':'otro';
async function addFile(file,module='',opts={}){
 if(!file?.size||file.size>MAX_FILE){if(file?.size>MAX_FILE)window.VS.toast('La biblioteca admite archivos de hasta 180 MiB.',true);return null;}
 const name=String(file.name||opts.name||'Audio').slice(0,200),kind=classify(name,file.type),list=await all();
 const existing=list.find(x=>x.name===name&&x.size===file.size&&x.kind===kind&&x.kind==='audio'&&x.lastModified===(file.lastModified||0));
 if(existing){if(opts.touch!==false){existing.modified=Date.now();await put(existing);}return existing;}
 const item={id:crypto.randomUUID?.()||`${Date.now()}-${Math.random()}`,name,kind,module:module||kind,folder:'',genre:'',mediaType:kind==='audio'?'Música':'Proyecto',size:file.size,lastModified:file.lastModified||0,modified:Date.now(),blob:file};await put(item);return item;
}
function folders(){try{return JSON.parse(localStorage.getItem('vsmedia-library-folders-v2')||'[]')||[];}catch{return [];}}
function saveFolders(f){localStorage.setItem('vsmedia-library-folders-v2',JSON.stringify(f.slice(0,150)));renderAll();}
const msg=(s)=>window.VS.toast(s);
function listHtml(items,active){if(!items.length)return '<div class="vsl-empty">No hay archivos en esta carpeta. Importá o abrí un proyecto para empezar.</div>';
 return items.map(x=>`<div class="vsl-row" data-vsl-id="${esc(x.id)}"><button type="button" class="vsl-open" data-vsl-open="${esc(x.id)}" title="Abrir ${esc(x.name)}"><span> ${x.kind==='audio'?'♫':'▤'} </span><span class="vsl-text"><b>${esc(x.name)}</b><small>${esc(x.genre||x.mediaType||x.kind)} · ${x.size<1048576?Math.round(x.size/1024)+' KB':(x.size/1048576).toFixed(1)+' MB'}</small></span></button><button type="button" data-vsl-edit="${esc(x.id)}" title="Clasificar" class="vsl-mini">⋯</button></div>`).join('');}
function shell(module){return `<div class="vsl-shell" data-vsl-module="${module}"><header class="vsl-head"><span>▤ BIBLIOTECA VS</span><button class="vsl-mini" data-vsl-folders title="Crear carpeta">＋</button></header><div class="vsl-categories"><button data-vsl-cat="audio">Audio</button><button data-vsl-cat="projects">Proyectos</button></div><div class="vsl-folder-tree"></div><input class="vsl-search" type="search" placeholder="Buscar nombre o género…" aria-label="Buscar biblioteca"><div class="vsl-items"></div><div class="vsl-foot"><button data-vsl-import>＋ Importar</button><button data-vsl-start>⌂ Inicio</button></div></div>`;}
function hub(module){const name=modules[module].name;return `<section class="vsl-welcome" data-vsl-welcome="${module}" aria-label="Inicio de ${name}"><div class="vsl-welcome-wrap"><header class="vsl-welcome-head"><span>▽ VSMEDIA / ${name.toUpperCase()}</span><button type="button" data-vsl-close aria-label="Entrar al editor">✕</button></header><p class="vsl-eyebrow">TU ESPACIO DE TRABAJO</p><h1>${name}</h1><p class="vsl-description">Organizá tus archivos, recuperá proyectos y empezá una sesión sin perder lo que ya editaste.</p><div class="vsl-welcome-actions"><button type="button" class="vsl-primary" data-vsl-editor>↗ Abrir editor</button><button type="button" data-vsl-import>＋ Importar archivo</button></div><div class="vsl-hub-content"><section><div class="vsl-section-title">PROYECTOS RECIENTES <span data-vsl-hub-count>0</span></div><div class="vsl-hub-projects"></div></section><section><div class="vsl-section-title">BIBLIOTECA COMPARTIDA</div><p class="vsl-description-small">Archivos locales organizados por carpetas, género y tipo. Se comparten entre Audio, Mix y Radio.</p><div class="vsl-hub-files"></div></section></div><div class="vsl-welcome-footer">Tus archivos se guardan en este navegador mediante IndexedDB. Exportá los proyectos para tener una copia independiente.</div></div></section>`;}
const states={simple:{cat:'all',folder:'all',search:''},mix:{cat:'all',folder:'all',search:''},radio:{cat:'all',folder:'all',search:''}};
async function renderModule(mod){const ctx=ui.get(mod);if(!ctx)return;const items=(await all()).sort((a,b)=>b.modified-a.modified),folderList=folders(),state=states[mod];
 const box=ctx.box;if(!box?.isConnected)return;
 const tree=$('.vsl-folder-tree',box);tree.innerHTML=`<button data-vsl-folder="all" class="${state.folder==='all'?'selected':''}">▦ Todos los archivos</button><button data-vsl-folder="" class="${state.folder===''?'selected':''}">⌑ Sin carpeta</button>`+folderList.map(f=>`<button data-vsl-folder="${esc(f.id)}" class="${state.folder===f.id?'selected':''}" style="padding-left:${12+(f.depth||0)*12}px">▸ ${esc(f.name)}</button>`).join('');
 const query=state.search.toLocaleLowerCase(),filtered=items.filter(x=>(state.folder==='all'||x.folder===state.folder)&&(state.cat==='all'||state.cat==='audio'&&x.kind==='audio'||state.cat==='projects'&&x.kind!=='audio')&&(!query||(x.name+' '+x.genre+' '+x.mediaType).toLocaleLowerCase().includes(query)));
 $('.vsl-items',box).innerHTML=listHtml(filtered,mod);box.querySelectorAll('[data-vsl-cat]').forEach(b=>b.classList.toggle('selected',b.dataset.vslCat===state.cat));
 if(ctx.hub?.isConnected){const projects=items.filter(x=>x.kind===mod).slice(0,8),audio=items.filter(x=>x.kind==='audio').slice(0,8);$('.vsl-hub-projects',ctx.hub).innerHTML=listHtml(projects,mod);$('.vsl-hub-files',ctx.hub).innerHTML=listHtml(audio,mod);$('[data-vsl-hub-count]',ctx.hub).textContent=String(projects.length);}
}
function renderAll(){for(const mod of ui.keys())void renderModule(mod);}
async function openItem(id,mod){const item=await byId(id);if(!item?.blob){msg('Archivo no encontrado.');return;}const file=new File([item.blob],item.name,{type:item.blob.type||'application/octet-stream'}),kind=classify(file.name,file.type);
 try{if(kind==='simple'){window.VS.navigate('simple');await window.VSSimpleApp.openProject(file);}else if(kind==='mix'){window.VS.navigate('mix');await window.VSMixApp.openProject(file);}else if(kind==='radio'){window.VS.navigate('radio');await window.VSRadioApp.openProject(file);}else if(kind==='audio'){
 if(mod==='mix'){window.VS.navigate('mix');await window.VSMixApp.importFile(file);}else if(mod==='radio'){window.VS.navigate('radio');await window.VSRadioApp.importFile(file);}else{window.VS.navigate('simple');await window.VSSimpleApp.loadFile(file);} }
 else{msg('Formato no reconocido por esta biblioteca.');return;}
 hide(kind==='audio'?mod:kind);hide(mod);item.modified=Date.now();await put(item);
 }catch(e){console.error(e);window.VS.toast('No se pudo abrir: '+e.message,true);}}
function hide(mod){const ctx=ui.get(mod);if(ctx?.hub)ctx.hub.hidden=true;}
function show(mod){const ctx=ui.get(mod);if(ctx?.hub){ctx.hub.hidden=false;renderModule(mod);}}
function setup(mod){const page=document.getElementById(mod);if(!page)return;const selector=mod==='simple'?'.simple-library':mod==='mix'?'.audio-library':'.radio-library';const sidebar=page.querySelector(selector);if(!sidebar)return;
 const box=document.createElement('div');box.innerHTML=shell(mod);box.className='vsl-side-container';sidebar.insertBefore(box,sidebar.firstChild.nextSibling||sidebar.firstChild);
 const hubEl=document.createElement('div');hubEl.innerHTML=hub(mod);const welcome=hubEl.firstElementChild;page.append(welcome);page.classList.add('vsl-page');
 const header=page.querySelector('.work-header');if(header){const btn=document.createElement('button');btn.className='work-tool vsl-home-button';btn.textContent='▤ Biblioteca / Inicio';btn.dataset.vslStart='';header.insertBefore(btn,header.children[1]||null);}
 ui.set(mod,{box,hub:welcome});
 page.addEventListener('click',async e=>{const node=e.target.closest('[data-vsl-open],[data-vsl-edit],[data-vsl-folder],[data-vsl-cat],[data-vsl-import],[data-vsl-folders],[data-vsl-editor],[data-vsl-start],[data-vsl-close]');if(!node)return;
 if(node.hasAttribute('data-vsl-open')){void openItem(node.dataset.vslOpen,mod);return;}
 if(node.hasAttribute('data-vsl-editor')||node.hasAttribute('data-vsl-close')){hide(mod);return;}
 if(node.hasAttribute('data-vsl-start')){show(mod);return;}
 if(node.hasAttribute('data-vsl-import')){hide(mod);$(mod==='simple'?'#simple-file-input':mod==='mix'?'#audio-file-input':'#radio-file-input')?.click();return;}
 if(node.hasAttribute('data-vsl-cat')){states[mod].cat=node.dataset.vslCat;renderModule(mod);return;}
 if(node.hasAttribute('data-vsl-folder')){states[mod].folder=node.dataset.vslFolder;if(node.dataset.vslFolder==='all')states[mod].cat='all';renderModule(mod);return;}
 if(node.hasAttribute('data-vsl-folders')){const name=prompt('Nombre de la carpeta o subcarpeta:');if(!name?.trim())return;const parent=states[mod].folder,allFolders=folders(),f=allFolders.find(x=>x.id===parent);if(allFolders.length>=150)return msg('Máximo de 150 carpetas.');const id=crypto.randomUUID?.()||Date.now().toString();allFolders.push({id,name:name.trim().slice(0,70),parent:parent==='all'?'':parent,depth:Math.min(4,f?(f.depth||0)+1:0)});saveFolders(allFolders);states[mod].folder=id;renderModule(mod);return;}
 if(node.hasAttribute('data-vsl-edit')){const item=await byId(node.dataset.vslEdit);if(!item)return;const name=prompt('Nombre del archivo:',item.name);if(name===null)return;item.name=(name.trim()||item.name).slice(0,200);const genre=prompt('Género (Rock, Lo-fi, Voz, Ambiente…):',item.genre||'');if(genre!==null)item.genre=genre.trim().slice(0,60);const type=prompt('Tipo (Música, Voz, Efecto, Ambiente, Cuña…):',item.mediaType);if(type!==null)item.mediaType=type.trim().slice(0,60);const foldersList=folders();const opts=['(sin carpeta)',...foldersList.map(f=>f.name)],ans=prompt('Carpeta (escribí un nombre de la lista):\n'+opts.join(' · '),foldersList.find(f=>f.id===item.folder)?.name||'');if(ans!==null)item.folder=foldersList.find(f=>f.name===ans)?.id||'';await put(item);return;}
 });
 $('.vsl-search',box).addEventListener('input',e=>{states[mod].search=e.target.value;renderModule(mod);});
 renderModule(mod);
}
function onNavigate(mod){if(!modules[mod])return;if(!loadedModules.has(mod)){loadedModules.add(mod);const active=mod==='simple'?window.VSSimpleApp?.inspect?.().loaded:mod==='mix'?window.VSMixApp?.inspect?.().assets>0:window.VSRadioApp?.inspect?.().assets>0;if(!active)show(mod);}}
function init(){for(const mod of Object.keys(modules))setup(mod);
 document.addEventListener('change',e=>{const input=e.target;if(!['simple-file-input','simple-project-input','audio-file-input','audio-project-input','radio-file-input','radio-project-input'].includes(input.id))return;const files=[...input.files||[]];for(const f of files)void addFile(f,input.id.startsWith('simple')?'simple':input.id.startsWith('audio')?'mix':'radio');},true);
 const old=window.VS.download;window.VS.download=(blob,name)=>{try{if(/\.(vssimple|vsmedia|vsradio)$/i.test(name))void addFile(new File([blob],name,{type:'application/zip'}),classify(name));}catch(e){console.warn('No se guardó el proyecto en la biblioteca',e);}return old(blob,name);};
 const first=location.hash.slice(1);if(modules[first])onNavigate(first);
}
window.VSMediaLibrary={init,onNavigate,addFile,all,openItem,show,hide,_test:{classify}};
})();
