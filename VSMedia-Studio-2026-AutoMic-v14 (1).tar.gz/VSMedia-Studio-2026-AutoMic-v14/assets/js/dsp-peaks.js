/* VSMedia Peak Index v1 — exact min/max with an iterative segment tree.
 * The tree indexes blocks of 128 samples and scans only boundary fragments.
 * Memory O(N/128), query O(log(N/128) + 256), even for hour-long audio.
 * Deliberately never subsamples peaks: transients cannot disappear on zoom-out.
 */
(function(host){'use strict';
  const BLOCK=128;
  const cache=new WeakMap();
  function indexChannel(data){
    const n=data.length,blocks=Math.ceil(n/BLOCK);
    let size=1;while(size<blocks)size*=2;
    const lo=new Float32Array(size*2),hi=new Float32Array(size*2),square=new Float64Array(size*2);
    lo.fill(Infinity);hi.fill(-Infinity);
    for(let b=0;b<blocks;b++){
      let low=Infinity,high=-Infinity,energy=0;
      for(let i=b*BLOCK,end=Math.min(n,(b+1)*BLOCK);i<end;i++){
        const v=Number.isFinite(data[i])?data[i]:0;
        if(v<low)low=v;if(v>high)high=v;energy+=v*v;
      }
      lo[size+b]=low;hi[size+b]=high;square[size+b]=energy;
    }
    for(let p=size-1;p>0;p--){lo[p]=Math.min(lo[p*2],lo[p*2+1]);hi[p]=Math.max(hi[p*2],hi[p*2+1]);square[p]=square[p*2]+square[p*2+1];}
    function range(start,end){
      const a=Math.max(0,Math.min(n,Math.floor(start))),z=Math.max(a,Math.min(n,Math.ceil(end)));
      if(a===z)return [0,0];
      let low=Infinity,high=-Infinity;
      const scan=(first,last)=>{for(let i=first;i<last;i++){const v=Number.isFinite(data[i])?data[i]:0;if(v<low)low=v;if(v>high)high=v;}};
      const firstBlock=Math.ceil(a/BLOCK),lastBlock=Math.floor(z/BLOCK);
      if(firstBlock>=lastBlock){scan(a,z);return [low,high];}
      scan(a,firstBlock*BLOCK);scan(lastBlock*BLOCK,z);
      let left=firstBlock+size,right=lastBlock+size;
      while(left<right){
        if(left&1){low=Math.min(low,lo[left]);high=Math.max(high,hi[left]);left++;}
        if(right&1){right--;low=Math.min(low,lo[right]);high=Math.max(high,hi[right]);}
        left>>=1;right>>=1;
      }
      return [low===Infinity?0:low,high===-Infinity?0:high];
    }
    function rms(start,end){
      const a=Math.max(0,Math.min(n,Math.floor(start))),z=Math.max(a,Math.min(n,Math.ceil(end)));
      if(a===z)return 0;
      let power=0;
      const scan=(first,last)=>{for(let i=first;i<last;i++){const v=Number.isFinite(data[i])?data[i]:0;power+=v*v;}};
      const firstBlock=Math.ceil(a/BLOCK),lastBlock=Math.floor(z/BLOCK);
      if(firstBlock>=lastBlock){scan(a,z);return Math.sqrt(power/(z-a));}
      scan(a,firstBlock*BLOCK);scan(lastBlock*BLOCK,z);
      let left=firstBlock+size,right=lastBlock+size;
      while(left<right){if(left&1)power+=square[left++];if(right&1)power+=square[--right];left>>=1;right>>=1;}
      return Math.sqrt(Math.max(0,power/(z-a)));
    }
    return Object.freeze({range,rms,samples:n,blockSize:BLOCK});
  }
  function forBuffer(buffer){
    let channels=cache.get(buffer);
    if(!channels){channels=Array.from({length:buffer.numberOfChannels},(_,i)=>indexChannel(buffer.getChannelData(i)));cache.set(buffer,channels);}
    return channels;
  }
  const api=Object.freeze({indexChannel,forBuffer,BLOCK});
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  host.VSPeaks=api;
})(typeof window!=='undefined'?window:globalThis);
