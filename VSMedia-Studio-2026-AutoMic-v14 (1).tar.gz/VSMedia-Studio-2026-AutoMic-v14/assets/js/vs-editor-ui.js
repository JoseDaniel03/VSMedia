/* VSMedia workspace layout controls. Only affects editors, never the Home. */
(()=>{'use strict';
const KEY='vsmedia-editor-layout-v1';
const pages=['simple','mix','radio','voice','soundboard'];
let state={density:'comfortable',panels:{},trackHeight:'auto'};
try {const saved=JSON.parse(localStorage.getItem(KEY)||'null');if(saved&&typeof saved==='object'){
  state.density=saved.density==='compact'?'compact':'comfortable';
  state.trackHeight=['short','normal','tall'].includes(saved.trackHeight)?saved.trackHeight:'auto';
  for(const id of pages){const row=saved.panels?.[id];if(row&&typeof row==='object')state.panels[id]={library:row.library!==false,inspector:row.inspector!==false,focus:row.focus===true};}
}}catch{}
function prefs(id){return state.panels[id]|| (state.panels[id]={library:true,inspector:true,focus:false});}
function save(){try{localStorage.setItem(KEY,JSON.stringify(state));}catch{}}
function apply(id){const page=document.getElementById(id);if(!page)return;const p=prefs(id);
 page.classList.toggle('vs-ui-compact',state.density==='compact');
 page.classList.toggle('vs-hide-library',!p.library);
 page.classList.toggle('vs-hide-inspector',!p.inspector);
 page.classList.toggle('vs-focus-workspace',p.focus);
 if(id==='mix'){const map={short:'76px',normal:'98px',tall:'144px'};if(map[state.trackHeight])page.style.setProperty('--vs-track-height',map[state.trackHeight]);else page.style.removeProperty('--vs-track-height');}
 const menu=page.querySelector('.vs-view-menu');if(!menu)return;
 for(const button of menu.querySelectorAll('[data-layout]')){
   const active=button.dataset.layout==='density'?state.density==='compact':!!p[button.dataset.layout];
   button.setAttribute('aria-pressed',String(active));
   const marker=button.querySelector('[data-layout-marker]');if(marker)marker.textContent=active?'✓':'';
 }
 for(const button of menu.querySelectorAll('[data-trackheight]'))button.setAttribute('aria-pressed',String(state.trackHeight===button.dataset.trackheight));
}
function closeAll(except){for(const menu of document.querySelectorAll('.vs-view-menu')){
 if(menu===except)continue;menu.hidden=true;const trigger=menu.previousElementSibling;if(trigger)trigger.setAttribute('aria-expanded','false');
}}
function inject(id){const page=document.getElementById(id);if(!page)return;
 const header=page.querySelector('.work-header,.bs-header');if(!header||header.querySelector('.vs-view-controls'))return;
 const pop=document.createElement('div');pop.className='vs-view-controls';
 const isVoice=id==='voice'||id==='soundboard';
 pop.innerHTML=`<button class="vs-view-trigger" type="button" aria-expanded="false" aria-haspopup="true" title="Personalizar el espacio de trabajo">▥ Vista</button><div class="vs-view-menu" hidden role="group" aria-label="Opciones de la vista"><b>ESPACIO DE TRABAJO</b>${!isVoice?'<button type="button" data-layout="library">Biblioteca <span data-layout-marker></span></button><button type="button" data-layout="inspector">'+(id==='radio'?'Programación lateral':'Inspector')+' <span data-layout-marker></span></button><button type="button" data-layout="focus">Modo enfoque <span data-layout-marker></span></button>':''}<button type="button" data-layout="density">Modo compacto <span data-layout-marker></span></button>${id==='mix'?'<div class="vs-view-subheading">ALTURA DE PISTAS</div><button type="button" data-trackheight="auto">Adaptar al modo</button><button type="button" data-trackheight="short">Pistas pequeñas (76 px)</button><button type="button" data-trackheight="normal">Pistas normales (98 px)</button><button type="button" data-trackheight="tall">Pistas grandes (144 px)</button>':''}</div>`;
 const insertBefore=header.querySelector('.work-fill,.bs-spacer');header.insertBefore(pop,insertBefore||null);
 const btn=pop.querySelector('.vs-view-trigger'),menu=pop.querySelector('.vs-view-menu');
 btn.addEventListener('click',e=>{e.stopPropagation();const opening=menu.hidden;closeAll();menu.hidden=!opening;btn.setAttribute('aria-expanded',String(opening));});
 menu.addEventListener('click',e=>{e.stopPropagation();const control=e.target.closest('[data-layout],[data-trackheight]');if(!control)return;const action=control.dataset.layout;
 if(control.dataset.trackheight)state.trackHeight=control.dataset.trackheight;
 else if(action==='density')state.density=state.density==='compact'?'comfortable':'compact';
 else{const p=prefs(id);p[action]=!p[action];}
 save();for(const name of pages)apply(name);
 window.dispatchEvent(new Event('resize'));
 });
 menu.addEventListener('keydown',e=>{const buttons=[...menu.querySelectorAll('button')];const index=buttons.indexOf(document.activeElement);if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();buttons[(index+(e.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length].focus();}if(e.key==='Escape'){e.preventDefault();menu.hidden=true;btn.setAttribute('aria-expanded','false');btn.focus();}});
 btn.addEventListener('keydown',e=>{if(e.key==='ArrowDown'){e.preventDefault();menu.hidden=false;btn.setAttribute('aria-expanded','true');menu.querySelector('button')?.focus();}});
 apply(id);
}
function initMixerResize(){
 const page=document.getElementById('mix'),grid=page?.querySelector('.audio-layout'),caption=page?.querySelector('.audio-bottom .pane-caption');
 if(!grid||!caption||caption.querySelector('.vs-mixer-grip'))return;
 const key='vsmedia-mix-console-height-v1';
 const grip=document.createElement('button');grip.type='button';grip.className='vs-mixer-grip';
 grip.textContent='↕';grip.title='Arrastrar para ajustar la altura de la consola. Doble clic: restaurar.';
 grip.setAttribute('aria-label','Ajustar altura del mezclador');grip.setAttribute('aria-keyshortcuts','ArrowUp ArrowDown');
 caption.insertBefore(grip,caption.firstChild);
 let height=0;try{height=Number(localStorage.getItem(key)||0);}catch{}
 const setHeight=(px,persist=true)=>{const total=grid.getBoundingClientRect().height;
   const maximum=total>390?total-220:Math.max(170,total*.42);
   height=Math.round(Math.min(Math.max(165,px),Math.max(170,maximum)));
   if(Number.isFinite(height))grid.style.gridTemplateRows=`minmax(220px,1fr) ${height}px`;
   if(persist)try{localStorage.setItem(key,String(height));}catch{}
 };
 if(height>=165&&height<1500)grid.style.gridTemplateRows=`minmax(220px,1fr) ${height}px`;
 let dragging=false;
 grip.addEventListener('pointerdown',event=>{
   if(grid.classList.contains('mixer-collapsed')||event.button!==0)return;
   dragging=true;grip.setPointerCapture?.(event.pointerId);event.preventDefault();
 });
 grip.addEventListener('pointermove',event=>{
   if(!dragging)return;const rect=grid.getBoundingClientRect();setHeight(rect.bottom-event.clientY,false);
 });
 const end=event=>{if(!dragging)return;dragging=false;try{grip.releasePointerCapture?.(event.pointerId);}catch{}setHeight(height,true);};
 grip.addEventListener('pointerup',end);grip.addEventListener('pointercancel',end);
 grip.addEventListener('dblclick',()=>{grid.style.removeProperty('grid-template-rows');height=0;try{localStorage.removeItem(key);}catch{}});
 grip.addEventListener('keydown',event=>{if(event.key!=='ArrowUp'&&event.key!=='ArrowDown')return;event.preventDefault();setHeight((height||grid.querySelector('.audio-bottom')?.getBoundingClientRect().height||225)+(event.key==='ArrowUp'?20:-20));});
}
function init(){for(const id of pages)inject(id);initMixerResize();
 document.addEventListener('click',e=>{if(!e.target.closest('.vs-view-controls'))closeAll();});
 document.addEventListener('keydown',e=>{if(e.key==='Escape')closeAll();});
}
window.VSEditorUI={init,apply,inspect:()=>JSON.parse(JSON.stringify(state)),_test:{prefs}};
})();
