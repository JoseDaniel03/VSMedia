# VSMedia Studio · Menús y controles unificados v7

Esta versión corrige un error visual real de Interfaz Limpia v6: «Archivo» aparecía **dos veces** en VSAudio Simple y VSMix.

- **VSAudio Simple:** solo se conserva `Archivo` en la barra del editor. `Abrir proyecto` y `Exportar WebM/Opus` se encuentran allí, junto al resto de acciones de archivo. El selector de precisión WAV y el botón principal de exportación permanecen en la cabecera.
- **VSMix:** se elimina el segundo `Archivo` de la cabecera. El menú nativo mantiene `Exportar mezcla WAV` y `Exportar WebM/Opus`. Se eliminan controles duplicados del inspector del clip: las acciones siguen disponibles en el timeline, en `Más del clip` y en `Editar`.
- **VSRadio:** mantiene su único menú `Archivo` de cabecera, ya que no tenía un menú nativo equivalente.
- **Bibliotecas:** se conservan las pestañas de biblioteca de v6 y se corrigen rótulos repetidos («ARCHIVOS / ARCHIVOS») y etiquetas cortadas de Simple.
- **Home, Pixel Studio, Blockbench, DSP, AutoBuild y radio:** intactos.

Las acciones y atajos siguen funcionando; esta versión no reescribe ningún motor de audio.

**Ejecución:** `./start.sh`

**Pruebas:** `bash verify-clean-ui-v7.sh`
