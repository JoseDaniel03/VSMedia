# VSMedia Studio · Gran tanda de mejoras · 2026-11-09

## Alcance
Se trabajó sobre `VSMedia-Studio-2026-Cuadricula-Capas-Audio-Optimizado.zip`. El Home aprobado se mantiene visual y funcionalmente intacto; se amplían los módulos y la validación sin modificar el repositorio GitHub ni exigir nuevas dependencias para abrir la web.

## VS Pixel Studio (Aseprite-like)
Se agregaron operaciones matemáticas reales bajo **Pixel Art**:

1. **Desplazar textura repetida (wrap)** en X/Y, útil para texturas que se repiten sin costuras, respetando RGBA y desplazamientos negativos.
2. **Umbral de alfa** (0–255) para convertir píxeles semitransparentes a opacos o transparentes.
3. **Eliminar RGB invisible** de píxeles completamente transparentes (limpieza de recursos).
4. **Eliminar píxeles aislados** (con vecindad de cuatro direcciones); requiere confirmación.
5. **Contorno interior de color** en el borde opaco de la capa, sin modificar el alfa.
6. **Vista previa de mosaico 3×3**, para detectar uniones imperfectas antes de exportar.
7. **Estadísticas de RGBA** de la capa actual (visibles, semitransparentes, colores, bounding box).

Las operaciones editables se aplican a la celda activa, respetan selección, bloqueo de capa e historial de deshacer. No afectan otras capas ni fotogramas sin autorización del usuario.

## VSAudio Simple

8. **Buscador de silencios RMS**: ventanas de análisis, umbral configurable en dBFS y duración mínima de 400 ms. No modifica el audio.
9. **Navegación entre silencios**: la selección avanza a la próxima región detectada.
10. **Silenciar regiones detectadas**: operación explícita y reversible sobre el proyecto, sin borrar el audio original.
11. **Motor matemático compartido de análisis**: estadísticas Peak/RMS de muestras reales y ajuste a bordes para VSMix.

## VSMix

12. **Duplicación de pista completa**: todos los clips y parámetros, con IDs únicos.
13. **Reordenamiento de pistas** arriba/abajo sin perder clips.
14. **Marcadores nombrados** en el timeline; atajo `K`.
15. **Ir al marcador anterior/siguiente** desde Reproducción.
16. **Marcadores persistentes** dentro de proyectos `.vsmedia`, incluidos deshacer/rehacer.
17. **Magnetismo a bordes**: clips encajan con otros clips y marcadores cercanos cuando Snap está activo; conserva ajuste a cuartos de segundo como alternativa.
18. **Limpiar marcadores** con confirmación.

## VSRadio

19. **Duplicar playlist** con IDs de bloques independientes.
20. **Orden aleatorio** de una playlist local.
21. **Orden alfabético** por título.
22. **Eliminar duplicados** por tipo/referencia sin borrar archivos fuente.
23. **Duplicar una sesión** completa sin copiar horarios de emisión (evita dobles arranques).
24. **Exportar escaleta TXT** con orden, rol, marcas de tiempo acumuladas y duraciones conocidas. YouTube sigue marcado como duración externa.
25. Confirmaciones al eliminar playlists o sesiones.

## VSPack

26. **Revisión de rutas inseguras** (carpetas relativas, barras invertidas, separadores vacíos).
27. **Namespaces incompatibles con Minecraft** y nombres no estándar.
28. **Choques entre rutas que difieren solo por mayúsculas**.
29. **Verificación PNG IHDR** y aviso de texturas excesivamente grandes.
30. Comprobaciones integradas dentro del diagnóstico ya existente, sin una ventana o interfaz redundante.

## Validación

- Tests Node de cálculos RGBA, espectro, umbral, picos, silencio y reglas de pack: **22 tests aprobados**.
- `verify.sh`: **9 pruebas preexistentes de Blockbench** y tests de composición y viewport pasaron.
- Prueba de interfaz embebida en Chromium (sin localhost, porque el entorno bloquea URLs locales): Home, Simple, creación/duplicación de pistas y marcadores en Mix, playlists y sesiones en Radio: **sin errores JavaScript**.
- **No** se pudo ejecutar una prueba completa de integración con Blockbench 3D, ni un servidor Folia real. El archivo `dist/bundle.js` que compilaste en tu PC no está incluido; es necesario conservarlo de aquella compilación.

## Ejecución

`./start.sh` y abrir `http://127.0.0.1:3060`. No requiere Rust/npm/Trunk para la interfaz JS. El acelerador WASM sigue siendo opcional. Verificar el audio con tus dispositivos reales en CachyOS.
