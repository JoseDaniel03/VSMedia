# VSMedia Studio — Controles y menús unificados v9

Edición **incremental** del ZIP original de VSMedia v8. Conserva los módulos, motores y estructura existentes. No sustituye el editor ni modifica la lógica de mezcla, guardado o formatos.

## Encabezados y menús

- **VSAudio Simple y VSMix:** el acceso a **Paneles y distribución** se mueve, con su nodo y sus listeners originales, al menú **Ver**. Biblioteca, inspector, enfoque, densidad, alturas de pistas y presets siguen disponibles.
- **VSRadio:** como su interfaz tiene menú Archivo pero no menú Ver, **Paneles y distribución** se integra en **Herramientas**. Se conserva el panel existente y sus estados.
- **VSAudio, VSMix y VSRadio:** **Buscar comandos** se mueve dentro de **Herramientas** en vez de ocupar otro botón en la cabecera. Continúa funcionando **Ctrl+K**.
- Se mantiene **un único menú Archivo** por editor, sin duplicar acciones ni cambiar exportadores.

## VSMix

- Se retiran los botones separados **zoom −/＋** de la barra de transporte: el control de zoom, **Ajustar**, los comandos del menú **Ver** y Ctrl/Alt+rueda ya cumplen esas funciones.
- Las acciones de clip permanecen en **Editar**, con menú contextual por clic derecho y atajos. Se reemplazan los dos textos de ayuda repetidos por uno: «Clic derecho: editar · S: dividir».
- Los marcadores **A/B** aparecen mientras está activado el bucle o existe una región definida. Pueden definirse en **Reproducción** o con **I/O** aunque la barra esté limpia.
- «0 pistas» y «0 audios» pasan a una sola etiqueta actualizada automáticamente, con singular correcto («1 audio»).
- **MUTE, SOLO y volumen** se muestran en la consola cuando está abierta, y en la cabecera de la pista cuando se contrae. Son los mismos controles originales, no copias con estado propio.
- **Subir, bajar y eliminar pista** se muestran al colocar el puntero o foco sobre la pista (si el dispositivo no tiene hover, permanecen visibles).
- En ventanas de hasta **950 px**, el transporte puede distribuirse en dos líneas en vez de desbordarse.

## Biblioteca

- Se elimina el segundo filtro «Todos» de los tipos de archivo, que se confundía con «Todos los archivos». El acceso «Todos los archivos» reinicia tanto carpeta como filtro de tipo; «Audio» y «Proyectos» continúan disponibles.

## Pruebas

- `bash verify-controls-v9.sh`: pruebas y sintaxis de JavaScript, compatibilidad v8, integridad de referencias y limpieza de controles.
- Se revisaron las interacciones en Chromium mediante carga aislada del DOM: VSAudio, VSMix y VSRadio; menús, paneles, búsqueda de comandos, control de bucle, consola plegable, importación real de WAV y ancho de 1050/770 px. No aparecieron errores JavaScript en esos recorridos.
- No se han probado en esta entrega dispositivos de sonido físicos, micrófonos, emisoras reales ni la compilación de módulos Rust/Blockbench. No se cambió su código.

## Inicio

Desde la carpeta raíz: `bash start.sh` (flujo habitual del proyecto). Recomendado usar Chromium/Chrome reciente.
