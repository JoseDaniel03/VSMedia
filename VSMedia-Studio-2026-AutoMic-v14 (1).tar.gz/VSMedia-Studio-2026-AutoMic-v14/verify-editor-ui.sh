#!/bin/sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
node --check assets/js/vs-editor-ui.js
node --check assets/js/core.js
node --check modules/vspack/assets/virgoland-theme.js
node --test tests/editor-ui-home.test.cjs
sh ./verify-super-tanda.sh
