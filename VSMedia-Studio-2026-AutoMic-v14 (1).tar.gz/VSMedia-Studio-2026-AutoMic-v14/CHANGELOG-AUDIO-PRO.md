# VSMedia · Audio Pro · Cambios de esta entrega

**Mantiene el Home aprobado sin cambios en `assets/css/app.css`, el HTML del Home o las fuentes de VSPack.**

## VSAudio Simple
- Forma de onda dibujada por canales L/R (o mono), con picos reales min/max, cuadrícula y escalado horizontal.
- Línea de reproducción independiente: se mueve con el audio; muestra selección en milisegundos.
- Estadísticas aproximadas Peak y RMS en dBFS, cantidad de canales, duración y frecuencia de muestreo.
- Acceso a escuchar selección, acercar selección, ajustar al ancho, normalizar y recortar.
- Gate de ruido, limitador suave por tanh y eliminación de desplazamiento DC en render WAV; con deshacer/rehacer.
- Ajuste aproximado de extremos de selección a una muestra cercana de baja amplitud (no garantiza cero exacto).
- El proyecto `.vssimple` sigue incluyendo la fuente y parámetros.

## VSMix
- El ancho del timeline se ajusta a clips reales en lugar de reservar 45 segundos obligatoriamente.
- Etiquetas de clips con duración, escala más legible y acciones de edición accesibles.
- Medidores de pico basados en muestras de los clips activos (antes la barra era un reflejo ficticio del fader).
- Curva del inspector basada en la respuesta de filtros pasa-altos/pasa-bajos (visualización aproximada, no FFT).
- Mejor distribución de la biblioteca, timeline, inspector y consola de mezcla, incluso en pantallas más chicas.

## VSPack y Blockbench
- El módulo VSPack y el código fuente de Blockbench permanecen sin modificaciones.
- El log que aportaste confirma que el build de Blockbench terminó correctamente.
- Para usar ese binario compilado sin volver a invocar npm, trasladá `vs-model-studio/dist/bundle.js` de la instalación donde lo generaste.

## Verificaciones
- `node --check` para todos los módulos JS.
- Prueba de importación y edición estéreo, WAV 16-bit, transferencia a Mix, duplicación, mezcla y playback meter en Chromium con red local bloqueada.
- Se conservaron la lógica de navegación, el Home y los archivos VSPack de la versión anterior.

**No se escribieron cambios al repositorio de GitHub.**
