# VSMedia — todo con `./start.sh`

Este documento es el comportamiento actual. Los readmes históricos de Blockbench
pueden describir el proceso anterior, cuando se compilaba a mano.

## Arranque normal (CachyOS)

```bash
./start.sh
# o simplemente
./start
```

El script verifica **Node 20+, npm, Cargo, Rustup y rustc** y, cuando están
instalados, construye en este orden:

1. **Blockbench web** (`npm ci --ignore-scripts` + `npm run build-web`) cuando
   falta `dist/bundle.js` o cambiaron las fuentes. Reaplica los parches de
   compatibilidad para VSPack cada vez.
2. **Pixel Studio WASM**: `cargo build --release --target wasm32-unknown-unknown`
   con memoria exportada. Copia el resultado a `pixel-studio/web`.
3. **VS Model Core WASM**: `wasm-pack build --release --target web --features wasm`.
   Instala wasm-pack mediante Cargo solo si falta. Habilita automáticamente el
   motor opcional en `embed/wasm-capability.js` cuando el WASM existe.
4. **Servidor HTTP nativo Rust**: compila el fuente `vs_model_server` con
   `rustc -O` y lo inicia sirviendo la aplicación en `127.0.0.1:3060`.

Los archivos HTML, CSS y JavaScript restantes **no tienen paso de compilación**:
el navegador los ejecuta directamente. No se intenta compilarlos con Rust.

## Dependencias

En CachyOS / Arch:

```bash
sudo pacman -S --needed nodejs npm rustup
rustup default stable
```

El lanzador ofrece esa instalación por terminal si detecta que faltan
herramientas y permite que el usuario la apruebe. Los paquetes/targets de Rust
requieren conexión la primera vez, y npm necesita acceso a sus dependencias si
hay que volver a compilar Blockbench.

## Modos

```bash
./start.sh                                  # compilar cambios y servir
VSMEDIA_FORCE_BUILD=1 ./start.sh            # reconstruir todos los núcleos
VSMEDIA_BUILD_ONLY=1 ./start.sh             # compilar sin iniciar servidor
VSMEDIA_VERIFY=1 ./start.sh                 # compilar y ejecutar pruebas
VSMEDIA_SKIP_BUILD=1 ./start.sh             # solo arrancar, sin compilación
VSMEDIA_SERVER=python ./start.sh             # compilar y servir con Python3
VSMEDIA_SERVER=node ./start.sh               # compilar y servir con Node
VSMEDIA_PORT=3061 ./start.sh                 # cambiar puerto
VSMEDIA_KEEP_NODE_MODULES=1 ./start.sh       # conservar deps de npm tras build
VSMEDIA_NO_SETUP=1 ./start.sh                # no ofrecer instalación con sudo
```

La recompilación incremental se basa en fechas de modificación de los fuentes
frente a los artefactos. Para reconstruir con certeza después de un cambio de
herramientas o dependencias, usá `VSMEDIA_FORCE_BUILD=1`.

## Comportamiento ante errores

Si falta una herramienta, la compilación **no se declara terminada**. Se muestra
qué falta y se detiene, sin iniciar un proyecto a medio construir. Si ya tenés
el bundle de Blockbench y querés usar la interfaz JS sin Rust, ejecutá
`VSMEDIA_SKIP_BUILD=1 ./start.sh`; eso no crea ningún WASM nuevo.

El bundle de Blockbench está incluido en el ZIP, por lo que generalmente se
reutiliza y se evitan las cientos de dependencias npm al iniciar.
