// VSMedia local web host and offline, bounded audio conversion.
// No npm dependencies, no internet requests; ffmpeg remains an OS prerequisite.
import { createServer } from 'node:http';
import { stat, realpath } from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import { createBrotliCompress, createGzip, constants as zlibConstants } from 'node:zlib';
import { resolve, extname, sep } from 'node:path';
import { spawn, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { pathToFileURL } from 'node:url';
const root = await realpath(process.cwd());
const port = Number(process.argv[2] || 3060);
if (!Number.isInteger(port) || port < 1 || port > 65535) throw Error('Puerto inválido');
const mime = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.wasm':'application/wasm','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp','.ico':'image/x-icon','.zip':'application/zip','.map':'application/json','.woff':'font/woff','.woff2':'font/woff2','.ttf':'font/ttf'};
export const PRESETS = Object.freeze({
  'voice-32': { label:'Voz NPC · Opus 32k', codec:'libopus', bitrate:'32k',channels:1,ext:'opus',contentType:'audio/ogg' },
  'voice-40': { label:'Locución · Opus 40k', codec:'libopus', bitrate:'40k',channels:1,ext:'opus',contentType:'audio/ogg' },
  'sfx-48': { label:'Efecto · Opus 48k', codec:'libopus', bitrate:'48k',channels:1,ext:'opus',contentType:'audio/ogg' },
  'radio-96': { label:'Radio · Opus 96k', codec:'libopus', bitrate:'96k',channels:2,ext:'opus',contentType:'audio/ogg' },
  'radio-128': { label:'Música · Opus 128k', codec:'libopus', bitrate:'128k',channels:2,ext:'opus',contentType:'audio/ogg' },
  'webm-voice-40': { label:'Chrome · Voz WebM/Opus 40k', codec:'libopus', bitrate:'40k',channels:1,ext:'webm',contentType:'audio/webm',container:'webm' },
  'webm-radio-96': { label:'Chrome · Radio WebM/Opus 96k', codec:'libopus', bitrate:'96k',channels:2,ext:'webm',contentType:'audio/webm',container:'webm' },
  'webm-music-128': { label:'Chrome · Música WebM/Opus 128k', codec:'libopus', bitrate:'128k',channels:2,ext:'webm',contentType:'audio/webm',container:'webm' },
  'mc-sfx': { label:'Minecraft Vanilla · Vorbis mono', codec:'libvorbis',quality:'4',channels:1,ext:'ogg',contentType:'audio/ogg' },
  'mc-music': { label:'Minecraft Vanilla · Vorbis estéreo', codec:'libvorbis',quality:'5',channels:2,ext:'ogg',contentType:'audio/ogg' },
});
export function ffmpegArgs(key, normalize = false) {
  const p = PRESETS[key]; if (!p) throw Error('Preset desconocido');
  const args = ['-hide_banner','-loglevel','error','-nostdin','-protocol_whitelist','pipe','-i','pipe:0','-vn','-map_metadata','-1','-ac',String(p.channels),'-ar',p.codec==='libopus'?'48000':'44100'];
  if (normalize) args.push('-af','loudnorm=I=-16:TP=-1.5:LRA=11');
  if (p.codec === 'libopus') args.push('-c:a','libopus','-b:a',p.bitrate,'-vbr','on','-compression_level','8','-application',p.channels===1?'voip':'audio');
  else args.push('-c:a','libvorbis','-q:a',p.quality);
  return [...args,'-f',p.container||'ogg','pipe:1'];
}
const MAX_INPUT=384*1024*1024,MAX_OUTPUT=128*1024*1024;
function json(res,status,data){const b=Buffer.from(JSON.stringify(data));res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Content-Length':b.length,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(b);}
function ffmpegPresent(){try {const r=spawnSync('ffmpeg',['-hide_banner','-version'],{timeout:3000,encoding:'utf8'});return r.status===0;}catch{return false;}}
const available=ffmpegPresent();
// The input is piped directly to FFmpeg; large recordings are never concatenated
// in server memory. Content-Length and output caps still apply to local requests.
async function encodeStream(req,preset,normalize,expectedBytes){
 return new Promise((resolvePromise,reject)=>{
  const child=spawn('ffmpeg',ffmpegArgs(preset,normalize),{stdio:['pipe','pipe','pipe'],windowsHide:true});
  let received=0,outputBytes=0,stderr='',settled=false;const chunks=[];
  const done=(err,value)=>{if(settled)return;settled=true;clearTimeout(watchdog);if(err){try{child.kill('SIGKILL');}catch{}}err?reject(err):resolvePromise(value);};
  const watchdog=setTimeout(()=>done(Error('FFmpeg excedió el tiempo de conversión (6 min).')),360000);
  child.on('error',e=>done(Error('No se pudo iniciar FFmpeg: '+e.message)));
  child.stdin.on('error',()=>{});
  child.stdout.on('data',chunk=>{outputBytes+=chunk.length;if(outputBytes>MAX_OUTPUT){done(Error('Salida comprimida demasiado grande (máximo 128 MiB).'));return;}chunks.push(chunk);});
  child.stderr.on('data',chunk=>{stderr=(stderr+chunk.toString()).slice(-2200);});
  child.on('close',code=>code===0&&received===expectedBytes&&outputBytes?done(null,Buffer.concat(chunks)):done(Error(received!==expectedBytes?'Archivo de entrada incompleto.':'FFmpeg no pudo convertir el audio. '+stderr.slice(-500))));
  req.on('data',chunk=>{received+=chunk.length;if(received>MAX_INPUT||received>expectedBytes)done(Error('Archivo de entrada demasiado grande o incompleto.'));});
  req.on('aborted',()=>done(Error('La conexión de conversión se interrumpió.')));
  req.on('error',e=>done(Error('Error de lectura del audio: '+e.message)));
  req.pipe(child.stdin);
 });
}
async function audioConvert(req,res,url){
 const expected=`http://127.0.0.1:${port}`;
 if(req.headers.origin && req.headers.origin!==expected && req.headers.origin!==`http://localhost:${port}`)return json(res,403,{error:'Origen no autorizado'});
 if(req.headers['x-vsmedia-local']!=='1')return json(res,403,{error:'Falta confirmación de origen local'});
 const preset=url.searchParams.get('preset'),normalize=url.searchParams.get('normalize')==='1';
 if(!PRESETS[preset])return json(res,400,{error:'Preset no reconocido'});
 if(!available)return json(res,503,{error:'FFmpeg no está instalado. En CachyOS: sudo pacman -S ffmpeg'});
 const size=Number(req.headers['content-length']);
 if(!Number.isSafeInteger(size)||size<=0||size>MAX_INPUT)return json(res,413,{error:'Se requiere audio de hasta 384 MiB con Content-Length'});
 try{const result=await encodeStream(req,preset,normalize,size);res.writeHead(200,{'Content-Type':PRESETS[preset].contentType,'Content-Length':result.length,'Cache-Control':'no-store','X-VSMedia-Codec':PRESETS[preset].codec,'X-Content-Type-Options':'nosniff'});res.end(result);}
 catch(e){if(!res.headersSent)json(res,422,{error:e.message});}
}
export function startServer(){
 const server=createServer(async(req,res)=>{try{
  const url=new URL(req.url,'http://localhost');
  if(url.pathname==='/api/audio/capabilities'&&req.method==='GET')return json(res,200,{ok:true,ffmpeg:available,server:'node',maxBytes:MAX_INPUT,presets:PRESETS,pluginConnected:false});
  if(url.pathname==='/api/audio/convert'&&req.method==='POST')return audioConvert(req,res,url);
  if(!['GET','HEAD'].includes(req.method))return json(res,405,{error:'Método no permitido'});
  let p;try{p=decodeURIComponent(url.pathname);}catch{return json(res,400,{error:'Ruta inválida'});}
  if(p.includes('\0')||p.includes('\\'))return json(res,400,{error:'Ruta inválida'});
  const requested=resolve(root,'.'+(p.endsWith('/')?p+'index.html':p));
  if(!requested.startsWith(root+sep))return json(res,403,{error:'Acceso denegado'});
  const file=await realpath(requested).catch(()=>null);
  if(!file||!file.startsWith(root+sep))return json(res,404,{error:'No encontrado'});
  const s=await stat(file);if(!s.isFile())return json(res,404,{error:'No encontrado'});
  // v11: avoid reading entire bundles into RAM for each request. Stream files,
  // negotiate Brotli/gzip only for compressible assets, and honor revalidation.
  // ETag includes size and modification time; editable local files update on reload.
  const kind=mime[extname(file)]||'application/octet-stream';
  const etag=`W/"${s.size.toString(16)}-${Math.trunc(s.mtimeMs).toString(16)}"`;
  const shared={'Content-Type':kind,'ETag':etag,'Cache-Control':'private, max-age=0, must-revalidate','Vary':'Accept-Encoding','X-Content-Type-Options':'nosniff'};
  if((req.headers['if-none-match']||'').split(',').some(v=>v.trim()===etag||v.trim()==='*')){
    res.writeHead(304,shared);res.end();return;
  }
  const compressible=/^(text\/|application\/(?:javascript|json|wasm)|image\/svg\+xml)/.test(kind);
  const encodings=String(req.headers['accept-encoding']||'');
  // Respect explicit q=0 (encoding forbidden) and modern browser preferences.
  const accepts=token=>encodings.split(',').some(part=>{
    const [name,...params]=part.trim().split(';');
    if(name.trim().toLowerCase()!==token)return false;
    const qParam=params.map(p=>p.trim()).find(p=>/^q\s*=/.test(p));
    if(!qParam)return true;
    const q=Number(qParam.split('=')[1]);
    return Number.isFinite(q)&&q>0&&q<=1;
  });
  const useBrotli=compressible&&s.size>=1024&&accepts('br');
  const useGzip=!useBrotli&&compressible&&s.size>=1024&&accepts('gzip');
  if(useBrotli)shared['Content-Encoding']='br';
  else if(useGzip)shared['Content-Encoding']='gzip';
  else shared['Content-Length']=s.size;
  res.writeHead(200,shared);
  if(req.method==='HEAD'){res.end();return;}
  const input=createReadStream(file);
  input.on('error',()=>{if(!res.destroyed)res.destroy();});
  const codec=useBrotli?createBrotliCompress({params:{[zlibConstants.BROTLI_PARAM_QUALITY]:4}}):useGzip?createGzip({level:5}):null;
  if(codec){codec.on('error',()=>{if(!res.destroyed)res.destroy();});input.pipe(codec).pipe(res);}
  else input.pipe(res);
 }catch(e){json(res,500,{error:'Error local: '+e.message});}});
 server.listen(port,'127.0.0.1',()=>console.log(`VSMedia Studio · Node + FFmpeg ${available?'disponible':'no instalado'} · http://127.0.0.1:${port}`));
 return server;
}
if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href)startServer();
