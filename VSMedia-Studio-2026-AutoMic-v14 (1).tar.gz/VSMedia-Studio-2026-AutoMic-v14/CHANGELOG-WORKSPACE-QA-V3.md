# VSMedia Studio — Workspace & Quality v3

**Base:** VSMedia Studio UX Research v2. Se conserva el Home original y el código compilado de Blockbench, los núcleos Rust/WASM y el AutoBuild.

## Mejoras de la interfaz

- Divisores laterales en VSAudio Simple, VSMix y VSRadio; permiten ajustar los anchos con arrastre o flechas del teclado. Los anchos se guardan **por módulo**.
- Doble clic sobre un divisor (o tecla Inicio con el divisor enfocado) restaura sus dimensiones.
- En **Vista → Distribución rápida**: Equilibrada, Solo editor + consola, Mesa de mezcla / Mesa DJ, y Restaurar anchos. Siguen existiendo foco, modo compacto y altura de pistas.
- Selección de pista/clip mejor indicada; controles enfocados tienen resaltado consistente con el dorado/crema del Home.
- La barra de transporte de VSMix puede desplazarse horizontalmente si la ventana es demasiado pequeña, sin solapar **Grabar** con **Efecto voz**.
- Las ondas de VSAudio, VSMix y VSRadio se redibujan al cambiar de tamaño el espacio de edición. El nuevo redibujado usa `requestAnimationFrame`, evitando repetirlo en cada evento de resize.
- En VSMix, el timeline conserva su posición al cambiar el ancho de paneles y ya no genera un salto fantasma de 144 px.

## Correcciones funcionales

- **Clip recortado:** VSMix respetará siempre el tramo realmente visible al reproducir o renderizar la mezcla. Antes, si el clip empezaba después del cursor, podía programar audio de más desde la fuente.
- **Exportación larga:** si la mezcla supera el límite actual de 15 minutos, se muestra una advertencia en lugar de truncar el resultado en silencio. Sigue pendiente un exportador por bloques para sesiones más largas.
- **Atajos seguros:** comandos del timeline no interrumpen campos de texto, el buscador `Ctrl+K` ni los diálogos abiertos.
- **Soundboard:** las teclas 1–9 no activan sonidos mientras editás una ranura o hay un diálogo activo.
- **VSAudio Simple:** admite arrastrar y soltar audio en el editor y pide confirmación antes de reemplazar una sesión abierta.

## Uso

Extraer el ZIP y ejecutar `./start.sh` en CachyOS. La compilación continúa siendo automática e incremental. Si la instalación ya tiene dependencias configuradas, no es necesario tocar npm ni Cargo manualmente.

## Pruebas

`bash verify-workspace-v3.sh`

- 77 pruebas JS automatizadas, incluidas 6 nuevas de programación de audio, layout, atajos y compatibilidad.
- Prueba de interacción en Chromium cargando componentes de forma aislada: atajos de división lateral, anchos persistentes, presets de vista, importación WAV a VSMix y respuesta a 1440/1050 px sin errores JavaScript.
- El navegador de prueba bloquea direcciones locales: **no equivale a haber probado el servidor HTTP completo en Firefox/CachyOS.** Tampoco se modificó ni volvió a compilar el motor Rust ni Blockbench en esta entrega.
