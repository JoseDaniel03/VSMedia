#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
bash verify-clean-ui-v6.sh
node --test tests/menu-unificado-v7.test.mjs
node --check assets/js/simple.js
node --check assets/js/mix.js
node --check assets/js/vs-compact-ui-v6.js
printf '\n[VSMedia] Menú unificado v7 verificado.\n'
