#!/bin/sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
if ! command -v node >/dev/null 2>&1;then
  echo 'ERROR: Node.js es necesario para correr las pruebas de desarrollo, no para usar la web.' >&2;exit 1
fi
for file in assets/js/*.js modules/vspack/assets/app.js modules/vspack/assets/pack-quality.js;do node --check "$file" >/dev/null;done
node --check modules/vspack/pixel-studio/web/pixel-power.mjs >/dev/null
node --check modules/vspack/pixel-studio/web/vs-pixel-studio.mjs >/dev/null
node --test tests/blockbench-build.test.mjs tests/optimization.test.mjs tests/pixel-power.test.mjs tests/audio-analysis.test.cjs tests/pack-quality.test.cjs modules/vspack/test-pixel-layers.mjs
sh ./verify.sh
