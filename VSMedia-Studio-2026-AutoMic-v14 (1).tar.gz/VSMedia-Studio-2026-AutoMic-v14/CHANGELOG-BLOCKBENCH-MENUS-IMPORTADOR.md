# VSMedia — Blockbench / VSPack: menús, importador y limpieza

## Qué se cambió (sin modificar Home, Simple, VSMix, VSRadio ni Pixel Studio)

1. **Menús nativos**: el manejador de clic del menú de Blockbench ya no deja que el clic burbujee hasta el cerrador global del documento. Se aseguró una capa visible (z-index) para los menús flotantes dentro del iframe. Se agregó recuperación suave cuando la apertura nativa falla y soporte de teclado Enter, Espacio y Flecha Abajo; no se crea una barra duplicada.
2. **Inicio más limpio**: ocultación/eliminación de la promoción Discord, Bluesky, banners de actualización, acceso de descarga de escritorio y onboarding innecesario en el editor embebido. Se eliminó además el bloque de publicidad Discord del código fuente para futuras compilaciones.
3. **ZIP de Minecraft → Blockbench**: desde *VSPack → Gestores → Modelos* se pueden seleccionar JSON en `assets/<namespace>/models/` y definiciones sencillas en `items/` o `blockstates/`. El cargador resuelve el árbol de padres (hasta 24 niveles), las referencias de texturas (incluyendo `#alias`) y aporta los PNG al codec Java de Blockbench sin exportar ni alterar automáticamente el ZIP original.
4. **Geometría de padres vanilla**: se ofrecen plantillas geométricas para `minecraft:block/cube_all`, `cube`, `cube_column`, `cube_bottom_top` y `cross` cuando dichos JSON no están presentes en el ZIP. Cuando otros padres faltan, se avisa en lugar de inventar la geometría.
5. **Rutas entre namespaces**: el editor usa un prefijo virtual solo durante la carga, de modo que referencias como `minecraft:block/cube_all` se resuelven en `minecraft`, incluso si el modelo es de otro namespace.
6. **Herramientas auxiliares**: restauradas las funciones faltantes para sugerir rutas de texturas PNG y proyectos `.aseprite` que se referenciaban desde VSPack.
7. **Menor peso**: eliminado `dist/bundle.js.map` (13,1 MB descomprimido), que no es necesario para ejecutar Blockbench. `dist/bundle.js` permanece incluido, con menú nativo reparado. Se conserva el código fuente y la licencia GPL.

## Límites conscientes

- Una definición de ítem de Minecraft con selectores condicionales/rangos o un blockstate con variantes múltiples no determina un único modelo. En esos casos se pide seleccionar el archivo específico en `models/` y **no se inventa** una variante.
- El editor 3D sigue siendo el Blockbench original (Vue/Three.js). El JSON y las texturas se pasan a sus codecs; **no** es un motor 3D reescrito en Rust.
- No se extraen archivos externos, recursos de Internet ni modelos faltantes que no se incluyan en el pack, salvo los padres vanilla básicos descritos.
- Modificar un modelo referenciado desde `items/` guarda en el archivo de `models/` que se abrió. El JSON selector del ítem original no se sobrescribe.
- Se comprobaron sintaxis, importadores, flujos de `postMessage` y menús mediante pruebas simuladas. **No se pudo completar una prueba visual interactiva de Chromium** en este entorno: las políticas del navegador bloquean páginas locales.

## Uso

```sh
./start.sh
```

Entra en `http://127.0.0.1:3060`, abre VSPack, importa un pack ZIP, selecciona **Gestores → Modelos → Abrir VS Model Studio** sobre un archivo (o **Ítems / Bloques → Ver modelo 3D** cuando la referencia es sencilla). Los modelos padre y PNG asociados se proporcionan en memoria al editor. Guarda explícitamente para reemplazar el modelo dentro de la biblioteca local de VSPack y exporta el ZIP desde Publicador.

Verificación:

```sh
./verify-blockbench-vspack.sh
```

## Licencias

Blockbench: GPL-3.0-or-later. Se conserva `modules/vspack/vs-model-studio/LICENSE.MD` junto al código fuente. Revisar esa licencia antes de redistribuir la edición compilada.
