# VSMedia Studio v10 — Ecosistema unificado

Fecha: 9 de noviembre de 2026. Base: v9 Controles Unificados.

## Interfaz y código compartido

- La web principal muestra una sola navegación de VS Pack. El iframe integrado conserva su propia navegación como fuente de verdad; la cabecera de VSMedia mantiene Inicio y el estado de conexión.
- En modo independiente aparecen las acciones Importar ZIP / Nuevo pack en la barra superior; en modo incrustado, aparecen junto a Mis Packs. No se muestran ambas parejas al mismo tiempo.
- Quitadas acciones de validación/exportación duplicadas de encabezados de compositor y publicador. La acción real permanece en su contexto.
- Quitado el botón «Abrir VS Pixel Studio» repetido en el encabezado y en la ficha de textura seleccionada.
- Eliminado el motor antiguo de dibujo PNG (pincel/fill/undo del canvas oculto) que ya no se renderizaba. Se usa únicamente VS Pixel Studio para editar sprites; no se cambia su interfaz original.
- Duplicar archivo ahora usa una implementación común para Biblioteca y Gestores. Duplicar pack y exportar pack usan lectura/escritura por lotes de IndexedDB.
- Ajustes limitados de espaciado, cabeceras y colores grafito/dorado compartidos. No se reemplazan los estilos internos de Blockbench.

## VS Pack — resguardo y publicación

- «Gestores → Packs → Copia completa»: genera un **ZIP de respaldo** con packs, bytes de archivos, carpetas virtuales, etiquetas, favoritos, orden, estado habilitado y selección de versiones en conflictos.
- «Gestores → Packs → Restaurar copia»: importa el formato de respaldo con IDs nuevos para evitar colisiones. **Suma** packs a la biblioteca existente. Se solicita confirmación y se validan rutas y límites antes de escribir.
- Los ZIP comunes de Resource Packs se siguen importando desde «Importar ZIP». El ZIP de respaldo no se trata como pack normal.
- Análisis y publicación reutilizan las mismas rutinas para rutas duplicadas/casos distintos, `pack.mcmeta`, JSON y cabeceras PNG. El diagnóstico también revisa referencias de modelos y sonidos.
- El publicador no inventa el `pack_format` del Minecraft de destino; debe indicarse si no existe `pack.mcmeta`.
- El respaldo tiene límites conservadores: 100 packs, 4.000 archivos, 128 MiB total extraído, 32 MiB por archivo, 140 MiB tamaño ZIP. Utiliza ZIP32 sin compresión para la copia; puede ocupar más que los ZIP de Resource Pack normales.

## Blockbench, modelos y sprites

- VS Model Studio utiliza el bundle compilado de Blockbench que ya viene incluido en el proyecto original. El manifiesto y el indicador de carga reflejan ese hecho.
- Reintento al fallar la carga del editor. Estado de cambios sincronizado con las acciones de guardado y diagnósticos del modelo.
- Botón «Editar textura en Pixel» dentro de VS Model Studio: primero permite guardar el `.bbmodel` si tiene cambios; luego elige una textura, la guarda como PNG dentro del pack y abre VS Pixel Studio.
- Editar y guardar un PNG **no vuelve a incrustar automáticamente** esa imagen en el `.bbmodel`. Esta integración no sustituye la revisión del atlas/UV dentro de Blockbench.
- En VS Pixel Studio guardar PNG con varias capas o cuadros advierte que se aplana el proyecto. No marca como conservado el trabajo editable: para mantener capas y animación se usa `.aseprite`.
- «Guardar como…» actualiza la ruta activa tras guardar y los atajos Ctrl/Cmd+S y los menús de guardado emplean el mismo puente a VSPack.

## Comprobaciones y límites conocidos

- Pruebas Node y suites de integración anteriores, además de validación del ZIP de respaldo, detección de referencias peligrosas y estructura de los recursos.
- Las pruebas automatizadas no reemplazan una sesión manual real de Chromium/CachyOS para usar todos los efectos de audio, las pestañas y las imágenes 3D.
- **No se ha instalado ni modificado** ningún plugin Folia, recurso del servidor, ni repositorio GitHub. No se realiza publicación automática en Minecraft.
- Los datos en IndexedDB dependen del origen/navegador. Antes de borrar datos del navegador, generar y comprobar una copia completa.

## Inicio y verificación

```bash
./start.sh
# Para ejecutar con los artefactos ya incluidos, sin recompilar:
VSMEDIA_SKIP_BUILD=1 ./start.sh
# Tests sin levantar el servidor:
node --test tests/*.test.mjs tests/*.test.cjs
./verify.sh
```
