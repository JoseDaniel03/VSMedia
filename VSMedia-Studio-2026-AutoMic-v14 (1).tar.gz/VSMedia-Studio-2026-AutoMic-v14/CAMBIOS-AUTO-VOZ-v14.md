# VSMedia v14 — Voz automática (sin configurar el micrófono)

- Nuevo perfil predeterminado **Automático · voz clara** para VSAudio, VSMix, VSRadio y VS Voice Studio.
- WebRTC se solicita con `noiseSuppression`, `echoCancellation` y `autoGainControl`. La disponibilidad real depende de navegador y hardware.
- Un controlador local calcula el piso de ruido, evita amplificar los silencios y corrige suavemente niveles de voz, con un límite más conservador cuando WebRTC ya aplica AGC.
- La puerta se vuelve un expansor suave en modo automático; las sílabas tranquilas no se silencian por completo.
- La ganancia automática se inserta antes del limitador para proteger la grabación y el stream de salida.
- Los perfiles y controles manuales se conservan. Solo aparecen las perillas avanzadas cuando se elige un perfil distinto de Automático.
- Todo se ejecuta en el navegador, sin RNNoise/Krisp, FFmpeg ni tráfico de micrófono hacia el servidor Folia.

**Límites:** no puede restaurar audio saturado en la entrada, eliminar ruido no estacionario de forma perfecta ni compensar un micrófono físicamente averiado. Para mejores resultados, usar auriculares si hay eco físico.
