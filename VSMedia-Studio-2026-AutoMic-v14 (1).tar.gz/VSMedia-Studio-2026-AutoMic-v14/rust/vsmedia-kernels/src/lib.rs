//! Optional VSMedia Rust/WASM kernels. Browser JS implementations remain fully
//! functional when this WASM file is not distributed. No JS bindings or npm.
//! Input RGBA is 4 bytes/pixel; alpha is always preserved.
use std::alloc::{alloc,dealloc,Layout};

#[no_mangle]
pub extern "C" fn vm_alloc(bytes: u32) -> *mut u8 {
    let Some(layout) = Layout::from_size_align(bytes.max(1) as usize, 8).ok() else { return std::ptr::null_mut() };
    unsafe { alloc(layout) }
}
#[no_mangle]
pub unsafe extern "C" fn vm_free(ptr: *mut u8, bytes: u32) {
    if ptr.is_null(){return;}
    if let Ok(layout) = Layout::from_size_align(bytes.max(1) as usize, 8) { dealloc(ptr,layout); }
}
fn clamped(input: f32)->u8{input.round().clamp(0.0,255.0) as u8}

pub fn posterize(pixels: &mut [u8], levels: u32) {
    let step=255.0/((levels.clamp(2,32)-1) as f32);
    for pixel in pixels.chunks_exact_mut(4) {
        if pixel[3]==0 {continue;}
        for channel in &mut pixel[..3]{*channel=clamped((*channel as f32/step).round()*step);}
    }
}
pub fn grayscale(pixels: &mut [u8]){
    for px in pixels.chunks_exact_mut(4){
        if px[3]==0{continue;}
        let y=clamped(0.2126*px[0] as f32+0.7152*px[1] as f32+0.0722*px[2] as f32);
        px[..3].fill(y);
    }
}
fn distance(p: &[u8],c: &[u8])->u32 {
    let dr=p[0] as i32-c[0] as i32;
    let dg=p[1] as i32-c[1] as i32;
    let db=p[2] as i32-c[2] as i32;
    (3*dr*dr+4*dg*dg+2*db*db) as u32
}
pub fn quantize(pixels:&mut[u8],palette:&[u8]){
    if palette.len()<3{return;}
    for pixel in pixels.chunks_exact_mut(4){
        if pixel[3]==0{continue;}
        let mut selected=0;let mut minimum=u32::MAX;
        for (n,c) in palette.chunks_exact(3).enumerate(){let d=distance(pixel,c);if d<minimum{minimum=d;selected=n;}}
        pixel[..3].copy_from_slice(&palette[selected*3..selected*3+3]);
    }
}
pub fn rms_and_peak(samples:&[f32])->(f32,f32,f32){
    if samples.is_empty(){return(0.0,0.0,0.0);}
    let mut lo=f32::INFINITY;let mut hi=f32::NEG_INFINITY;let mut sum=0.0f64;
    for &v in samples{let v=if v.is_finite(){v}else{0.0};lo=lo.min(v);hi=hi.max(v);sum+=(v as f64)*(v as f64);}
    (lo,hi,(sum/samples.len() as f64).sqrt() as f32)
}
#[no_mangle]
pub unsafe extern "C" fn vm_posterize(ptr:*mut u8,len:u32,levels:u32){
    if ptr.is_null()||len>256*1024*1024||len%4!=0{return;}
    posterize(std::slice::from_raw_parts_mut(ptr,len as usize),levels);
}
#[no_mangle]
pub unsafe extern "C" fn vm_grayscale(ptr:*mut u8,len:u32){
    if ptr.is_null()||len>256*1024*1024||len%4!=0{return;}
    grayscale(std::slice::from_raw_parts_mut(ptr,len as usize));
}
#[no_mangle]
pub unsafe extern "C" fn vm_quantize(ptr:*mut u8,len:u32,palette_ptr:*const u8,n:u32){
    if ptr.is_null()||palette_ptr.is_null()||len>256*1024*1024||len%4!=0||n==0||n>64{return;}
    quantize(std::slice::from_raw_parts_mut(ptr,len as usize),std::slice::from_raw_parts(palette_ptr,n as usize*3));
}
#[no_mangle]
pub unsafe extern "C" fn vm_peak_rms(ptr:*const f32,len:u32,result:*mut f32){
    if ptr.is_null()||result.is_null()||len>128_000_000{return;}
    let (lo,hi,rms)=rms_and_peak(std::slice::from_raw_parts(ptr,len as usize));
    std::slice::from_raw_parts_mut(result,3).copy_from_slice(&[lo,hi,rms]);
}
#[cfg(test)]mod tests{
    use super::*;
    #[test]fn rgba_alpha_unchanged(){let mut p=[10,20,30,0,128,129,255,127];posterize(&mut p,2);assert_eq!(p[3],0);assert_eq!(p[7],127);assert_eq!(&p[..4],&[10,20,30,0]);}
    #[test]
    fn exact_signal() {
        let samples = [-1.0_f32, 0.5, 0.25, 1.0];
        let (minimum, maximum, rms) = rms_and_peak(&samples);
        assert_eq!(minimum, -1.0);
        assert_eq!(maximum, 1.0);
        assert!((rms - (2.3125_f32 / 4.0).sqrt()).abs() < 1.0e-6);
    }
    #[test]fn quantize_keeps_alpha(){let mut p=[14,14,14,99,250,250,250,255];quantize(&mut p,&[0,0,0,255,255,255]);assert_eq!(p,[0,0,0,99,255,255,255,255]);}
}
