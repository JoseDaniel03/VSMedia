#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
bash verify-safe-v5.sh
node --test tests/compact-ui-v6.test.mjs
node --check assets/js/vs-compact-ui-v6.js
echo "[VSMedia] Interfaz limpia v6 verificada"
