# Reparación de AutoBuild — Blockbench 5.2.2 / Node.js 26

El error:

```
Error: Unexpected Blockbench bundle contents: window.ErrorLog.length: 1 != 2
[VSMedia · Error] No se pudieron aplicar los parches de Blockbench.
```

no viene de `npm` ni indica un fallo de esbuild. La compilación terminó correctamente y generó `dist/bundle.js`. El fallo estaba en el script `modules/vspack/vs-model-studio/scripts/patch-embedded-bundle.mjs`, que exigía un número fijo de coincidencias en el JavaScript minificado. La salida cambia entre compilaciones.

## Solución

El parche ahora:

- Reemplaza todas las coincidencias **sin exigir 2** (admite 1, 2 o más).
- Respeta los fragmentos ya modificados y puede volver a ejecutarse sin duplicarlos.
- No detiene la compilación si una versión de Blockbench ya no incluye un fragmento opcional.
- Guarda el archivo compilado de manera atómica para evitar un `bundle.js` incompleto.
- Mantiene las correcciones de `ErrorLog`, Service Worker y estadísticas CORS de la integración.
- Funciona tanto al ejecutar `./start.sh` como `./build-blockbench-once.sh`.

## Uso

```bash
./start.sh
```

El arranque comprobará el bundle existente y seguirá con Rust/WASM y el servidor. No hace falta borrar `node_modules` ni `dist/bundle.js`.

Si querés reconstruir todo desde cero:

```bash
VSMEDIA_FORCE_BUILD=1 ./start.sh
```

Para comprobar el parche sin compilar ni iniciar el servidor:

```bash
node modules/vspack/vs-model-studio/scripts/patch-embedded-bundle.mjs
node tests/blockbench-autopatch.test.mjs
```

Las líneas `npm warn deprecated ...` son advertencias de dependencias antiguas del código original de Blockbench, no errores de compilación. La salida `Done in ... ms` confirma que ese paso finalizó correctamente.

## Alcance de las pruebas

Las pruebas automatizadas cubren bundles simulados con una coincidencia, dos coincidencias, fragmentos parcialmente parcheados, ejecución repetida y patrones ausentes, además de verificar la sintaxis del bundle compilado incluido. No equivalen a un test completo de los menús 3D en Firefox/CachyOS.
