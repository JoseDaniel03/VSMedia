#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
bash verify-fluid-v4.sh
node --test tests/edicion-segura-v5.test.mjs
for file in assets/js/{mix,vs-mix-export-v5,vs-mix-recovery-v5,vs-codecs}.js serve.mjs; do node --check "$file"; done
printf '%s\n' '[VSMedia] Edición segura v5 verificada.'
