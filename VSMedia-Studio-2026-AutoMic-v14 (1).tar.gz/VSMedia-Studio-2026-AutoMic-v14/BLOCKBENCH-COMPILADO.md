# Blockbench 5.2.2 compilado e integrado — paquete del 9/11/2026

**Incluido en este ZIP**: `modules/vspack/vs-model-studio/dist/bundle.js` (4,366,491 bytes).

SHA-256 del archivo proporcionado por el usuario:
`27d4f9ada83814509144f88b1ff27808adf33b0f507bb867589eccfbfc46a41e`

También se conserva `bundle.js.map`, los recursos del editor, su código fuente y `LICENSE.MD` (Blockbench, GPL-3.0 o posterior).

## Uso

1. Extraer el ZIP.
2. Ejecutar `./start.sh` en CachyOS (necesita Python 3 o Node.js *ya instalado*, no npm/Trunk/Rust).
3. Abrir `http://127.0.0.1:3060` y acceder a **VSPack → Modelos → Abrir Blockbench**.
4. El host sirve el editor original en el componente `<vs-model-studio>` y emplea el puente del mismo origen para cargar/guardar proyectos.

**No ejecutar `npm install` ni `build-blockbench-once.sh`: la compilación ya está incluida.** El script de compilación única sigue disponible solo para desarrollo.

## Comprobaciones realizadas

- `bundle.js` está presente, supera los 4 MB y pasa la comprobación de sintaxis de Node.
- `index.html` carga `dist/bundle.js` y `embed/bridge.js`.
- El servidor local respondió HTTP 200 al consultar `dist/bundle.js`.
- Pasaron las pruebas de código de VSMedia (audio, píxeles, VSPack, puente Blockbench).
- El navegador automatizado de este entorno **bloquea las direcciones locales y de prueba**. No está confirmado aún el arranque visual real de Blockbench 3D, ni la importación/exportación dentro de Chromium/CachyOS. Si al abrirlo falla, revisar la consola y compartir el mensaje.

## Procedencia

El bundle fue compilado por el usuario a partir de los archivos de Blockbench 5.2.2 y adjuntado en `VSMedia-Studio-2026-SuperTanda.tar.gz`. No se modificó su contenido binario en esta entrega. El Home, Simple, Mix y Radio mantienen sus archivos originales.
