#!/usr/bin/env bash
# Punto único de entrada: compilar lo necesario y arrancar VSMedia.
set -Eeuo pipefail
cd -- "$(dirname -- "$(realpath -- "${BASH_SOURCE[0]}")")"
PORT="${VSMEDIA_PORT:-3060}"
[[ "$PORT" =~ ^[0-9]+$ ]] && ((PORT>=1 && PORT<=65535)) || { echo 'VSMEDIA_PORT inválido' >&2; exit 1; }
if [[ "${VSMEDIA_SKIP_BUILD:-0}" != 1 ]]; then
  bash ./scripts/build-all.sh
else
  echo '[VSMedia] Compilación omitida por VSMEDIA_SKIP_BUILD=1.'
fi
if [[ "${VSMEDIA_BUILD_ONLY:-0}" == 1 ]]; then
  echo '[VSMedia] Build terminado, sin abrir el servidor (VSMEDIA_BUILD_ONLY=1).'
  exit 0
fi
if [[ "${VSMEDIA_VERIFY:-0}" == 1 ]]; then
  command -v node >/dev/null || { echo 'Se necesita Node para verificar.' >&2; exit 1; }
  bash ./verify-model-engine-v2.sh
fi
MODE="${VSMEDIA_SERVER:-auto}"
RUST_SERVER='./modules/vspack/vs-model-studio/bin/vs_model_server'
# Node sirve el conversor Opus/Vorbis local; el servidor Rust sigue
# disponible con VSMEDIA_SERVER=rust para uso de solo archivos estáticos.
if [[ "$MODE" == auto || "$MODE" == node ]]; then
  if ! command -v ffmpeg >/dev/null 2>&1; then
    echo '[VSMedia] Aviso: FFmpeg no está instalado; no estará disponible la conversión a Opus/Vorbis.'
    echo '[VSMedia] En CachyOS: sudo pacman -S --needed ffmpeg'
  fi
  if command -v node >/dev/null 2>&1; then
    echo "[VSMedia] Servidor Node + API de audio en http://127.0.0.1:${PORT}"
    exec node ./serve.mjs "$PORT"
  fi
  [[ "$MODE" == node ]] && { echo 'Falta Node.js.' >&2; exit 1; }
fi
if [[ "$MODE" == auto || "$MODE" == rust ]]; then
  if [[ -x "$RUST_SERVER" ]]; then
    export VS_MODEL_BIND="127.0.0.1:${PORT}"
    echo "[VSMedia] Servidor Rust en http://127.0.0.1:${PORT}"
    exec "$RUST_SERVER" .
  fi
  [[ "$MODE" == rust ]] && { echo 'No existe el servidor Rust. Probá sin VSMEDIA_SKIP_BUILD=1.' >&2; exit 1; }
fi
if [[ "$MODE" == auto || "$MODE" == python ]]; then
  if command -v python3 >/dev/null 2>&1; then
    echo "[VSMedia] Servidor Python en http://127.0.0.1:${PORT}"
    exec python3 -m http.server "$PORT" --bind 127.0.0.1
  fi
  [[ "$MODE" == python ]] && { echo 'Falta Python3.' >&2; exit 1; }
fi
if [[ "$MODE" == auto || "$MODE" == node ]]; then
  if ! command -v ffmpeg >/dev/null 2>&1; then
    echo '[VSMedia] Aviso: FFmpeg no está instalado; no estará disponible la conversión a Opus/Vorbis.'
    echo '[VSMedia] En CachyOS: sudo pacman -S --needed ffmpeg'
  fi
  if command -v node >/dev/null 2>&1; then
    echo "[VSMedia] Servidor Node en http://127.0.0.1:${PORT}"
    exec node ./serve.mjs "$PORT"
  fi
fi
echo "No hay servidor disponible (VSMEDIA_SERVER=$MODE). Instalá Python3 o Node.js." >&2
exit 1
