# Corrección del error Rust en `vsmedia-kernels`

El compilador de Rust exige un cero antes del punto decimal: `0.5` y `0.25`, no `.5` ni `.25`.
El origen del fallo era el test `exact_signal` en `rust/vsmedia-kernels/src/lib.rs`.

Esta corrección no modifica la lógica del editor, la web, los parches de Blockbench ni el resto de los núcleos.

## Parche sobre la instalación existente

Extraer **VSMedia-Fix-Rust-Literales.zip** dentro del directorio principal de VSMedia
(el que contiene `start.sh`), aceptando reemplazar `rust/vsmedia-kernels/src/lib.rs`.
Luego ejecutar `./start.sh` normalmente. No es necesario borrar cachés ni recompilar Blockbench desde cero.

## Verificación local en CachyOS

```bash
cargo test --manifest-path rust/vsmedia-kernels/Cargo.toml
./start.sh
```

El compilador podría informar otros errores de otros núcleos en una etapa posterior;
esta corrección soluciona el fallo concreto de los literales. No se ha realizado aquí
una compilación real con Cargo porque no está instalado en el entorno de generación.
