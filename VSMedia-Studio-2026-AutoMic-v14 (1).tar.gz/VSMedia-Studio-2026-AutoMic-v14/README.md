# VSMedia Studio v10 · Ecosistema unificado (09/11/2026)

Esta versión parte de la **v9** y mantiene los editores originales. Se ha eliminado código obsoleto de edición de texturas y acciones repetidas; los cambios se documentan en [CHANGELOG-ECOSISTEMA-V10.md](CHANGELOG-ECOSISTEMA-V10.md).

**Nuevo en VSPack:** Centro de gestores → Packs → **Copia completa** para exportar un ZIP con la biblioteca de packs (archivos, carpetas, favoritos, etiquetas, prioridades y resoluciones), y **Restaurar copia** para importarlo sin borrar la biblioteca actual. Este formato de respaldo NO es el ZIP que Minecraft consume.

**Flujo de edición:** desde un modelo en VS Model Studio se puede **Editar textura en Pixel** para exportar al pack una textura PNG y abrirla en VS Pixel Studio. Las texturas modificadas en Pixel Studio quedan guardadas en el pack; no se reescriben automáticamente dentro del `.bbmodel`.

**Límites:** la biblioteca permanece en IndexedDB local. El respaldo admite hasta 100 packs, 4.000 archivos y 128 MiB sin comprimir. La validación de pack.mcmeta/PNG/JSON detecta fallos estructurales, pero no sustituye la prueba en Minecraft de una versión concreta.

---

## Edición segura v5 (novedades)

- **VSMix:** exportación WAV por bloques de 30 segundos, sin corte arbitrario a los 15 minutos, con progreso/cancelación; render continuo mediante preroll de efectos.
- **Recuperación:** copia incremental del montaje y sus archivos de audio en IndexedDB; el usuario decide cuándo restaurarla desde **Recuperar**. Seguís pudiendo guardar archivos `.vsmedia`.
- **Timeline:** «Ajustar» muestra toda la sesión; zoom multiplicativo y Alt+flechas para desplazar el clip seleccionado.
- **Compresión:** el conversor local WebM/Opus usa FFmpeg por streaming y admite hasta 384 MiB de entrada.
- Todo sigue iniciándose con **`./start.sh`**. Revisá `CHANGELOG-EDICION-SEGURA-V5.md` y `verify-safe-v5.sh`.

---

> **Versión actual — Edición fluida v4:** bucles A/B en VSMix, seguimiento opcional del cursor en VSMix y VSAudio Simple, regla de tiempo adaptativa, silencios optimizados y ondas de VSRadio con picos exactos. Leé [CHANGELOG-EDICION-FLUIDA-V4.md](CHANGELOG-EDICION-FLUIDA-V4.md). Para verificar: `./verify-fluid-v4.sh`.

## NUEVO · VSMix Pro + VSRadio DJ + WebM/Opus (09/11/2026)

- VSMix tiene un timeline más estable: cabeceras fijas, navegación horizontal con Shift+rueda, zoom anclado con Ctrl/Alt+rueda, panorámica con botón central, mezcla por pistas y consola plegable.
- La mesa de VSMix incorpora EQ de 3 bandas, compresor, eco por envío, paneo, volumen y máster/limitador. El procesamiento también se aplica al exportar.
- VSRadio incorpora auto-crossfade A/B, entrada anticipada de la siguiente canción, EQ y volumen independiente por deck y bajada de música al abrir el micrófono. La configuración se conserva en la estación guardada.
- La salida se **pausa al abandonar el módulo o al ocultarse la pestaña**, sin reanudación automática.
- VSAudio Simple y VSMix añaden exportación a **WebM/Opus** usando el servidor Node local y FFmpeg. No se elimina WAV ni OGG.
- Detalles y pruebas en [`CHANGELOG-VSMIX-VSRADIO-DJ-2026.md`](CHANGELOG-VSMIX-VSRADIO-DJ-2026.md).

---

## NUEVO · VS Guiones y micrófono compartido

- Marca corregida a **VS**: VS Voice Studio, VS Soundboard, VSAudio, VSMix y VSRadio.
- Botón **▤ Guion** presente al lado del grabador de VSAudio, VSMix, VSRadio y VS Voice Studio.
  Cada editor conserva su propio guion local; incluye título, lectura en pantalla flotante, ajuste de tamaño,
  desplazamiento automático, salto de línea e importación/exportación de texto plano. El guion **nunca se mezcla
  con el audio grabado**. Datos guardados en `localStorage`, limitados al perfil del navegador.
- Botón **⚙ Mic** común en VSAudio, VSMix y VSRadio: cancelación de eco, supresión de ruido,
  ganancia automática opcional, compresor, puerta, de-esser, ganancia y eco. Los ajustes se guardan y
  se aplican a **todas las sesiones de micrófono abiertas**; los controles nativos necesitan reabrir la captura.
- VS Voice Studio también comparte presets y parámetros con los otros editores.
- Se corrigió un fallo de inicialización del analizador de voz que podía impedir activar el micrófono.
- Los bancos nuevos exportan `format: vsmedia.soundbank`. La importación sigue aceptando
  bancos antiguos `bsmedia.soundbank` para no perder archivos creados con versiones previas.
- Sigue incluida la conversión FFmpeg y el sistema de AutoBuild `./start.sh` de la versión anterior.

## NUEVO · VS Voice Studio / Soundboard / Códecs de Minecraft

Entrá desde el menú a **VS Voice Studio** (grabación con DSP, efectos y exportación Opus/Vorbis) y **VS Soundboard** (bancos de sonidos para VSMedia). El Home original, VSAudio, VSMix, VSRadio, Pixel Studio y Blockbench se conservan. La integración con el plugin se realiza **después**, mediante el formato `.vssoundbank` definido en `docs/VSMEDIA-PLUGIN-EXPORT-v2.md`.

Leé `README-VS-MEDIA-2026.md` para instalación local de FFmpeg y límites; verificá con `./verify-vs-media.sh`. En modo automático `./start.sh` selecciona el servidor Node para habilitar la conversión, mientras conserva la compilación de los núcleos Rust/WASM.

---

> **Actualización 2026-11-09:** biblioteca compartida VSAudio/Mix/Radio, pantallas de inicio, filtros de voz y paletas con selector HSV y Pixel Studio a pantalla completa. Ver [`MEJORAS-BIBLIOTECA-VOZ-PIXEL-2026.md`](MEJORAS-BIBLIOTECA-VOZ-PIXEL-2026.md).

# VSMedia Studio 2026 · Home + VSAudio Simple + VSMix + VSRadio + VSPack

Esta entrega continúa la **nueva base 2026** y mantiene intacta la estética y el contenido del Home aprobado. Los editores están separados. No se ha modificado ningún repositorio de GitHub ni el plugin Folia.

## Nuevo arranque unificado — compilación automática

**Desde esta versión**, `./start.sh` (o `./start`) compila automáticamente los componentes que faltan o cambiaron y después levanta la web. Incluye: Blockbench 5.2.2 con npm; motor Rust/WASM de píxeles; motor Rust/WASM de geometría; y servidor HTTP nativo en Rust. En modo automático se utiliza el servidor Node local, porque habilita la API de conversión Opus/Vorbis; el servidor Rust sigue disponible con `VSMEDIA_SERVER=rust` para contenido estático.

La primera compilación de Rust/WASM necesita acceso a Internet para descargar toolchains y dependencias. El paquete ya contiene un `dist/bundle.js` funcional de Blockbench, así que **se reutiliza mientras no cambien sus fuentes**. Las compilaciones posteriores se evitan cuando los artefactos están actualizados.

En CachyOS, si faltan Node o Rust, el script ofrece instalar herramientas mediante `pacman` **con tu autorización** (solo en terminal interactiva). Para instalarlas manualmente:

```bash
sudo pacman -S --needed nodejs npm rustup
rustup default stable
./start.sh
```

El script descarga automáticamente `wasm-pack` mediante Cargo si es necesario y construye ambos WASM. Si preferís no compilar nada y usar los archivos disponibles: `VSMEDIA_SKIP_BUILD=1 ./start.sh`. Para **recompilarlo todo**: `VSMEDIA_FORCE_BUILD=1 ./start.sh`. Para ejecutar pruebas luego del build: `VSMEDIA_VERIFY=1 ./start.sh`. `VSMEDIA_SERVER=python` o `node` fuerza ese servidor en lugar del nativo. El puerto se cambia con `VSMEDIA_PORT=3061`.

**Importante:** no se ofrece compilación Rust ficticia. Si falta una herramienta o falla la red, `start.sh` informa el error y detiene la compilación; el arranque precompilado sigue disponible con `VSMEDIA_SKIP_BUILD=1`. Para detalles, ver `COMPILACION-AUTOMATICA.md`.

---

## Arranque en CachyOS

```bash
./start.sh
```

Abrí `http://127.0.0.1:3060` en la misma PC. El arranque principal compila de forma incremental y utiliza el servidor Node para la API local de códecs; Rust y Python se pueden elegir como servidores estáticos alternativos. Para grabar desde el micrófono abrí por `localhost` o HTTPS, aceptá los permisos del navegador y preferí auriculares al monitorear audio.

## Cambios de interfaz

- **VSAudio Simple:** eliminada la antigua sección inferior «Proyecto y exportación» por duplicar las funciones de la barra superior. Los controles de abrir/guardar, deshacer/rehacer, selector PCM 16/32 bits y exportación ahora quedan arriba. Eliminada la barra de estado inferior decorativa.
- **VSMix:** quitada la pestaña inferior «Transporte», repetida en la barra de reproducción superior. Conservado el **Mezclador**, que es una herramienta real de trabajo. Eliminada la barra de estado inferior decorativa; estado operativo cerca del nombre del proyecto.
- **Home:** no se rediseñó. VSRadio es accesible desde el menú hamburguesa y desde los editores.

## Grabación de micrófono

- **Simple:** botón explícito «● Grabar» / «■ Detener», contador REC, captura de voz mediante MediaRecorder. Al finalizar se importa como el audio de la **única pista**. Si había un archivo abierto, pregunta antes de reemplazarlo.
- **VSMix:** mismo botón y contador, pero la toma aparece como **pista nueva Micrófono** a partir de la posición donde estaba el cursor al comenzar la grabación. No reemplaza las pistas existentes. El audio grabado se puede editar/exportar igual que un archivo importado.
- La captura necesita permiso de micrófono y compatibilidad del navegador. No se envían grabaciones a Internet.

## VSRadio · Estación local

- Crear estación con **nombre de emisora y programa**.
- Biblioteca de audio con archivos locales y **cola de programación reordenable**, con Auto DJ para pasar al siguiente elemento en Deck A.
- Dos reproductores independientes (A/B), controles de reproducción, búsqueda, forma de onda y **crossfader** con transición de potencia constante, más ganancia master.
- Entrada de micrófono en directo (para locución local) y grabación del **audio combinado** de ambos decks y micrófono a WebM/Opus u OGG/Opus (según soporte del navegador).
- **Guardar estación `.vsradio`** como ZIP que incluye la programación, la configuración y los archivos de audio importados. «Abrir estación» recupera todo ello. También exporta una programación `.json` sin audio.
- **Enviar a VSRadio** desde el menú Archivo de VSAudio Simple o VSMix: renderiza el WAV real antes de importarlo a la estación.

**Límite importante:** esta estación **NO transmite** aún a Minecraft/Folia/Plasmo Voice ni a Internet. Funciona como mesa de reproducción y grabadora **local**. Para emitir hacia el servidor hará falta conectar un backend de streaming/autorización; no se simula ni se presenta como activo.

## VSPack y Blockbench

Se conserva sin cambios la integración de VSPack y los archivos de Blockbench presentes en la versión anterior. Si ya compilaste Blockbench, preservá y copiá tu propio `modules/vspack/vs-model-studio/dist/bundle.js` a la misma ruta en esta entrega. Los mensajes `npm warn deprecated` que compartiste son avisos; tu log terminó generando correctamente `dist/bundle.js`.

## Pruebas ejecutadas

- `node --check` de `core.js`, `simple.js`, `mix.js` y `radio.js`: correcto.
- Chromium automatizado sin HTTP de localhost (el navegador del entorno bloquea esa URL): flujo de importación, micrófono **simulado con una pista sintética MediaStream**, generación WebM, reproducción de decks, exportación de grabación y JSON, guardado/apertura `.vsradio` y envíos Simple → VSRadio y VSMix → VSRadio.
- Sin errores JavaScript en dichos recorridos. **No equivale a una prueba con el micrófono físico del usuario**; corresponde validarlo en CachyOS.

## Estructura

- `index.html`: páginas Home, Simple, Mix, Radio, VSPack.
- `assets/js/simple.js`, `assets/js/mix.js`: edición de audio.
- `assets/js/radio.js`: estación local, reproductores, micrófono, programas y proyectos.
- `assets/css/radio.css`: diseño de VSRadio.
- `docs/preview-radio.png`, `docs/preview-simple-mic.png`, `docs/preview-mix-mic.png`: vistas de las pruebas.

## VSRadio 2.0 · Programas finitos y playlists (9/11/2026)

El nuevo botón **«▦ Programación»** abre el guion de la estación. **«🎚 Consola A/B»** conserva la mesa de dos reproductores y la grabación clásica.

1. Importá canciones, jingles, separadores, locuciones o un episodio ya grabado como **archivo local**. También podés pegar un video o una playlist pública de YouTube en el campo de URL.
2. Armá playlists independientes; pueden importarse listas **.m3u / .m3u8** con referencias a nombres de archivos locales (se enlazan por nombre al importar esos audios) o URLs de YouTube.
3. En el **Guion de la sesión**, creá varios programas, agregá una playlist completa o bloques individuales, y ordenalos con flechas. También podés insertar pausas cronometradas.
4. **Iniciar sesión** reproduce las piezas locales consecutivamente con Web Audio; si hay un bloque de YouTube, se muestra su reproductor oficial. Al terminar el último bloque, el programa **se detiene**, sin repetir ni quedarse transmitiendo.
5. Fecha y hora: opcionales; activá la casilla de programación **solo mientras la página esté abierta**. El navegador puede exigir una interacción de usuario antes de permitir reproducción automática. No hay procesos en segundo plano ni un scheduler de servidor.
6. **Guardar estación .vsradio** incluye los audios locales y los guiones de playlists y sesiones. Los videos/las listas de YouTube se guardan como **enlaces**, no se descargan. La programación también se puede exportar como JSON.
7. Cuando terminás de grabar tu programa en la consola A/B, se descarga y también se incorpora a la biblioteca local cuando el navegador puede decodificarlo; desde la pestaña Programación lo podés usar como bloque **Programa grabado**.

**YouTube:** se integra mediante el reproductor oficial visible y requiere conexión a Internet; no se extrae audio, no se mezclan fuentes de YouTube con Web Audio y las canciones de YouTube **no se incluyen en la grabación local**. Las playlists de YouTube se tratan como un bloque externo de duración variable; para controlar cada entrada de canción por separado, añadí los videos individuales o creá una playlist local/M3U. Ciertas playlists pueden no permitir reproducción incrustada. No se garantiza reproducción desatendida por bloqueos de autoplay del navegador. Para reproducir una sesión de forma desatendida y/o dentro de Minecraft se necesitará un servicio de backend y contenidos de audio con derechos adecuados.

### Verificaciones de esta versión

- `node --check` para `radio.js` y `radio-program.js`.
- Prueba de lógica en Node con reproductor de audio simulado: validación de URL de YouTube, lectura M3U, añadir audio a playlist, añadir playlist a una sesión, inicio/final de sesión local y restauración de guiones: **aprobada**.
- Inspección de diferencias: **Home, VSAudio Simple, VSMix, VSPack y Blockbench sin cambios**.
- **No se realizó prueba de interfaz en navegador**: Chromium del entorno bloqueó el acceso a localhost y a archivos locales. YouTube embebido tampoco pudo probarse con la red externa. Validar ese flujo en CachyOS.


## Reparación VS Model Studio / Blockbench (9/11/2026)

VSPack carga ahora Blockbench como un componente **integrado y aislado**, conservando su HTML, CSS, Vue y Three.js. Corregida la importación de `.bbmodel` y JSON Java, el guardado a la biblioteca del pack, los avisos al salir y el uso de espacio de pantalla. Consultar `CHANGELOG-BLOCKBENCH.md` para detalles y límites.

**ESTADO ACTUAL:** esta entrega ya incluye el Blockbench 5.2.2 compilado en `modules/vspack/vs-model-studio/dist/bundle.js`, proporcionado por el usuario. No hay que copiar ni compilar nada para cargar ese componente. Se incluyen también las fuentes originales, licencias y el mapa de depuración. Si las fuentes de Blockbench cambian, el arranque recompila su bundle con npm.

## Optimizaciones matemáticas y Pixel Studio (9/11/2026)

Incluye un índice de picos exactos y cacheado para VSAudio Simple/VSMix, métricas Peak/RMS exactas, reducción matemática de paleta, tramado Floyd–Steinberg, posterización, extracción de paleta y recorte de transparencias en VS Pixel Studio. La representación del canvas reutiliza memoria y el historial establece un límite de 96 MiB.

**Opcional Rust/WASM:** `rust/vsmedia-kernels` contiene operaciones acelerables y `./build-rust-kernels-once.sh` permite compilarlas una sola vez. El archivo generado es `modules/vspack/pixel-studio/web/vsmedia-kernels.wasm`. Sin ese archivo se ejecuta el motor JS, **sin instalar nada extra para iniciar la aplicación**.

Pruebas: `node --test tests/optimization.test.mjs modules/vspack/test-compositor.mjs modules/vspack/test-viewport.mjs`. Requieren Node.js solo en desarrollo, no al usar VSMedia con el servidor Python ya disponible. Consultá `CHANGELOG-OPTIMIZACIONES-2026.md` para límites, medidas y archivos modificados.

## Gran tanda de herramientas — 9 de noviembre de 2026

Las mejoras están enumeradas en [CHANGELOG-SUPER-TANDA-2026.md](CHANGELOG-SUPER-TANDA-2026.md).

- **Pixel Studio → Pixel Art:** mover textura repetida, limpieza de alfa, contorno interior, píxeles aislados, vista de mosaico y estadísticas de color.
- **VSAudio Simple → Herramientas:** detección y navegación de silencios y silenciamiento reversible.
- **VSMix → Editar / Reproducción:** copiar y ordenar pistas, marcadores nombrados, Snap inteligente y persistencia de marcadores.
- **VSRadio → Programación:** duplicar, mezclar y ordenar playlists; duplicar sesiones y exportar escaleta.
- **VSPack → Gestores → Diagnóstico:** rutas, colisiones de nombres y cabeceras/dimensiones PNG.

### Pruebas

`./verify-super-tanda.sh` ejecuta los tests de desarrollo cuando Node.js está disponible. Para **usar** la web no hace falta instalar Node: ejecutá el `start.sh` existente si tu sistema dispone de Python 3 o Node.

**Blockbench (esta entrega):** los archivos fuente y `modules/vspack/vs-model-studio/dist/bundle.js` están incluidos en este ZIP; ahora hay compilación automática incremental al ejecutar `./start.sh`. Consultá `BLOCKBENCH-COMPILADO.md` para comprobaciones y límites.


### Blockbench integrado — reparación e importador (noviembre 2026)

Ver `CHANGELOG-BLOCKBENCH-MENUS-IMPORTADOR.md`. La edición de modelos desde ZIP ahora resuelve padres y texturas de Minecraft y corrige el acceso a los menús nativos. El bundle compilado está incluido: no hace falta npm para arrancar. Para pruebas, `./verify-blockbench-vspack.sh`.


### Reparación Blockbench 5.2.2 integrada (9/11/2026)

Consultar [REPARACION-BLOCKBENCH-2026.md](REPARACION-BLOCKBENCH-2026.md): diagnósticos, errores de consola, menús, Firefox, traducción y pruebas. El bundle compilado se incluye en el ZIP y la interfaz nativa de modelado se mantiene.


## Interfaz limpia v6

Ver [CHANGELOG-INTERFAZ-LIMPIA-V6.md](CHANGELOG-INTERFAZ-LIMPIA-V6.md) para controles consolidados.
