# Contrato de integración VS Media → VSMedia (versión 1)

Este documento describe un **formato de intercambio implementado** en la web. **No implica que el plugin Folia o VSClient ya lo consuman**. El adaptador del plugin se desarrolla en una etapa posterior, sin rediseñar los editores.

## Archivo `.vssoundbank`

Es un ZIP32 con entradas almacenadas (sin deflate; el códec ya comprimió el audio):

```text
Mi-Banco.vssoundbank
├── bank.json
└── audio/
    ├── <assetId>.opus  # Ogg Opus · VSClient/Plasmo, necesita decodificador y transporte de cliente
    └── <assetId>.ogg   # Ogg Vorbis · sonidos de Minecraft Vanilla
```

El `bank.json` usa esquema `vsmedia.soundbank` versión `1`. Ejemplo ilustrativo (sin archivo de audio real):

```json
{
  "format": "vsmedia.soundbank",
  "schema": 1,
  "bankId": "virgoland.banco-principal",
  "name": "Banco principal",
  "distribution": "plugin-adapter-required",
  "assets": [{
    "id": "8f6d3210-fake-id",
    "name": "alarma",
    "path": "audio/8f6d3210-fake-id.opus",
    "codec": "opus",
    "preset": "sfx-48",
    "bytes": 4831,
    "sha256": "SHA-256 real del contenido"
  }],
  "slots": [{
    "id": "slot-id",
    "assetId": "8f6d3210-fake-id",
    "name": "Alarma",
    "category": "Vehículos",
    "scope": "nearby",
    "radius": 24,
    "volume": 80,
    "loop": false,
    "cooldownMs": 500,
    "trigger": { "type": "vehicle" },
    "context": { "minigameId": "carreras" },
    "permission": "vsmedia.sound.slot-id"
  }]
}
```

Los datos `assets.path` se resuelven **exclusivamente dentro del ZIP** y los hashes SHA-256 verifican la integridad de cada recurso. No aceptar `..`, rutas absolutas, ni esquemas externos; imponer límites de tamaño y número de archivos. En esta implementación la web valida ambos al reimportar.

## Reglas de adaptación a Minecraft

- **Opus Ogg (`.opus`)**: opción para audio propio del cliente/Plasmo Voice. Minecraft Vanilla no usa Opus para sus entradas normales de `sounds.json`; el adaptador necesita VSClient o una capa de reproducción compatible. No basta con copiar `.opus` al resource pack.
- **Vorbis Ogg (`.ogg`)**: opción para generar `assets/<namespace>/sounds/<nombre>.ogg` y entradas en `assets/<namespace>/sounds.json`. El plugin debe asignar nombres de recurso legales.
- `scope=personal` solo para el jugador objetivo; `nearby` requiere cálculo de distancia y posicionamiento espacial; `global` requiere permisos administrativos.
- `context.minigameId` permite restringir a una sesión/juego. El adaptador determina qué constituye una sesión activa.
- `trigger.type` contempla `manual`, `interact`, `vehicle`, `npc`, `quest`, `join`. Son metadatos hasta implementar los eventos en Folia.
- `cooldownMs`, límites de simultaneidad y permisos se deben aplicar **en el servidor**, nunca confiar en el cliente.
- El mismo `sha256` puede servir como clave de caché para evitar descargas repetidas.
- Proyectos de radio (`.vsradio`) y playlists de YouTube se mantienen separados. No transformar YouTube en archivos de audio sin una fuente local autorizada.

## Futura API sugerida del plugin (NO implementada)

1. `importBank(zip)`: validar tamaño, esquema, SHA-256 y permisos; guardar biblioteca.
2. `attachEvent(bankId, slotId, trigger)`: conectar eventos de Typewriter, vehículos, minijuegos o comandos.
3. `play(slotId, audience, position)`: limitar concurrencia, validar autorización y emitir evento de audio.
4. `stop(slotId, audience)`: cancelar loops/ambientes al salir de un juego o área.
5. `getMissingAssets(clientHashes)`: transferir solo contenido no presente en caché.
6. `radio.schedule(sessionId, startedAt)`: resolver programa/playlist y estado de la estación en el servidor, aunque la web no esté abierta.

La web ya permite **crear, editar, previsualizar, comprimir, exportar y reimportar** el soundboard; no transmite nada a Minecraft en esta entrega.

### Compatibilidad con versiones anteriores

El importador acepta bancos antiguos con `format: "bsmedia.soundbank"`. La exportación nueva usa `format: "vsmedia.soundbank"`, `schema: 1`, y mantiene la estructura `bank.json` + `audio/` para evitar pérdida de contenido.
