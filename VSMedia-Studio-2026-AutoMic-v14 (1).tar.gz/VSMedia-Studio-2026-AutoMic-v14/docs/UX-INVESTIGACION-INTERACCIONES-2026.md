# VS Media Studio — Investigación aplicada de UI/UX, noviembre de 2026

## Objetivo

Mantener el Home cinematográfico aprobado y mejorar el manejo diario de editores densos: VSAudio Simple, VSMix, VSRadio, Voice Studio, Soundboard y el Pixel Studio embebido en VSPack. No se reemplazan motores de audio, Blockbench ni el sistema de compilación.

## Investigación utilizada

1. Jakob Nielsen, «10 Usability Heuristics for User Interface Design», Nielsen Norman Group, revisado 2024. [Enlace](https://www.nngroup.com/articles/ten-usability-heuristics/). Aplicación: acciones reconocibles, consistencia, estados visibles, deshacer y prevención de errores.
2. W3C WAI, «Developing a Keyboard Interface» (ARIA Authoring Practices). [Enlace](https://www.w3.org/WAI/ARIA/apg/practices/keyboard-interface/). Aplicación: manejo de flechas, Escape, Enter, foco y navegación de menús.
3. W3C WAI, «WCAG 2.2 Understanding 2.5.8 Target Size (Minimum)». [Enlace](https://www.w3.org/WAI/WCAG22/Understanding/target-size-minimum). Aplicación: controles compactos, pero con área clicable de al menos ~24×24 CSS px donde es viable.
4. W3C WAI, «Understanding Focus Appearance». [Enlace](https://www.w3.org/WAI/WCAG22/Understanding/focus-appearance). Aplicación: anillo de foco de 2 px con contraste en controles.
5. Ableton, «Navigation and View Options in Live 12 FAQ». [Enlace](https://help.ableton.com/hc/en-us/articles/12243771208092-Navigation-and-View-Options-in-Live-12-FAQ). Aplicación: paneles del mixer personalizables, visibilidad opcional, navegación por teclado y ajuste de vista.
6. Ableton Live 12 Reference Manual, «Arrangement View». [Enlace](https://www.ableton.com/en/manual/arrangement-view/). Aplicación: conservar timeline de trabajo, edición de pistas y consola separada, sin forzar una distribución única.
7. Sean A. McGrath, tesis doctoral «Investigating the usability of software systems for music production and distribution», Brunel University London, 2015. [Enlace](https://bura.brunel.ac.uk/handle/2438/13127). Señala problemas de eficiencia, satisfacción y curva de aprendizaje en DAWs.
8. Petri Myllys, «User interface paradigms in digital audio workstations: examining and modernising established models», Sibelius Academy, 2014. [Enlace](https://taju.uniarts.fi/items/56d8e0aa-fd63-49f9-b87f-cc5839984036). Motiva reconsiderar paneles analógicos rígidos y favorecer interfaces escalables.
9. «Investigation of the audio mixing interface», tesis doctoral, University of Huddersfield, 2023. [Enlace](https://pure.hud.ac.uk/en/studentTheses/investigation-of-the-audio-mixing-interface/). Menciona saturación de controles, administración multicanal, vista general y foco sobre un canal.
10. Metatla et al., «Audio-haptic interfaces for digital audio workstations», *Journal on Multimodal User Interfaces*, 2016. [Enlace](https://link.springer.com/article/10.1007/s12193-016-0217-8). Motiva accesibilidad por teclado y no depender exclusivamente de representaciones visuales.

**Alcance**: estas fuentes guían decisiones. No se hicieron estudios con usuarios de Virgoland ni se certifica conformidad WCAG completa.

## Cambios construidos

| Área | Implementación | Comprobación |
|---|---|---|
| Encontrar operaciones | `Ctrl/Cmd+K`, acciones contextualizadas, tildes ignoradas, flechas, Enter y Escape | Navegación y ejecución de comandos en Chromium |
| Descubrimiento | Botón «Comandos» junto a «Vista», tecla `?` para ayuda | Chromium |
| Menús de VSAudio/VSMix | Roles semánticos, estado expandido, teclado, Escape, foco restaurado | Chromium |
| Diálogos | Foco contenido y restauración tras cerrar, Escape | Chromium |
| Pistas de VSMix | Altura de pista automática / 76 / 98 / 144 px y persistencia local | Chromium |
| Timeline y consola | Contraste, recorte de nombres largos, scroll contenido y tirador más grande | Estático + prueba a 1050 px |
| Pixel Studio | Selector 2D de color con teclado, menús con navegación, anillos de foco y mejores zonas clicables | Sintaxis y pruebas de contrato; falta navegador de origen completo |
| Todos los editores | Controles de foco visibles, layout responsivo, estado y contraste con colores del Home | Chromium inyectado a 1440 y 1050 px |

## Comandos

- `Ctrl+K` / `Cmd+K`: buscar y ejecutar acciones.
- `?` cuando no se está escribiendo: ayuda de teclado.
- `↑` / `↓`: mover la selección del comando o del menú.
- `Enter`: ejecutar comando.
- `Esc`: cerrar búsqueda, menú o diálogo (con restauración del foco).
- En VSMix: `Vista → ALTURA DE PISTAS` ajusta tamaño persistente.
- En Pixel Studio: foco sobre selector de saturación/luminosidad, flechas para cambios de 1%; Mayús+flechas para 10%.

## Límites y pendientes

- El entorno de pruebas prohíbe navegar al origen local, por lo que la prueba de navegador fue mediante carga directa de HTML/JS/CSS. No se verificó el Web Component de Pixel Studio dentro de Firefox en CachyOS.
- La paleta de comandos solo ejecuta acciones ya disponibles en la web anfitriona. No inspecciona ni modifica menús de Blockbench dentro del iframe.
- No se sustituyeron gestos ni atajos del motor de audio. No se tocó el servidor Minecraft ni GitHub.
- No se eliminó ninguna función; los paneles siguen siendo reversibles y sus preferencias se guardan localmente.
