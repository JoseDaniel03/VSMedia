# VS Model Studio / Blockbench 5.2.2 — reparación de integración

La web host mantiene los módulos Home, Simple, VSMix, VSRadio y Pixel Studio. **No** se reescribió el motor 3D de Blockbench: se conserva su editor original basado en Vue/Three.js y sus codecs, dentro del componente aislado, para evitar perder compatibilidad con `.bbmodel`, modelos Minecraft y las herramientas nativas. Rust (`crates/vs_model_core`) queda como núcleo geométrico/WASM opcional, no obligatorio al iniciar VSMedia.

## Reparaciones verificables

- `managerTab is not defined`: los listeners `vspack:model-return` y `beforeunload` ahora se registran **dentro del cierre de VSPack**. Un clic en Volver no hace referencia a variables fuera de su scope.
- `window.ErrorLog is undefined`: se actualizaron el código original de menú y el `bundle.js` compilado con acceso tolerante a ausencia de datos. Se mantiene el menú nativo, no se creó una segunda barra.
- Menús: el fallback encuentra el `BarMenu` correcto por su referencia `label` (elemento `<li>`) y solo abre cuando falló el clic nativo. Se mejoró teclado/foco y se observa únicamente el menú y la pantalla de inicio, no todo el DOM.
- `service_worker.js` fallaba al instalar: no se registra el SW dentro de VSPack; se suministra un trabajador mínimo sin caché para la edición independiente.
- Firefox `Feature Policy clipboard-read/clipboard-write`: eliminado el atributo `allow` no compatible del iframe. Copiar/pegar sigue sujeto a los permisos ordinarios del navegador.
- CORS `stats/plugins?weeks=2`: en modo embebido no se consulta la estadística externa de la tienda de plugins; las herramientas de modelado no la requieren.
- `file:///`: para texturas de un pack ausentes, el importador carga una muestra visual temporal en memoria en vez de disparar un intento de leer un archivo local. El JSON original del pack **no se modifica**. Además, se impide navegar a enlaces `file:` desde el componente web; se usa el selector nativo de archivos.
- Fuente `icomoon.ttf`: recalculadas las cajas geométricas de glifos para evitar advertencias de tipografía en Firefox (no se alteran las formas de los glifos).
- Idioma: traducción **español/inglés** incluida; el componente integrado solicita `es` por defecto y la página se marca con `lang=es`.
- Inicio: se mantienen ocultas las promociones y enlaces Discord/Bluesky que no se usan en VSPack.
- Herramienta nueva `Diagnóstico`: dentro de VSPack -> VS Model Studio, al abrir un modelo muestra conteo de cubos/mallas, triángulos estimados, límites de la geometría, dimensiones cero y referencias duplicadas de textura. **No edita el modelo**.
- Arranque: `start.sh` conserva el permiso de ejecución. El `bundle.js` está incluido: no hace falta npm en runtime.

## Recompilación única (solo desarrolladores)

`./build-blockbench-once.sh` recompila si no existe `dist/bundle.js`. Tanto este script como `scripts/start.sh` vuelven a aplicar `scripts/patch-embedded-bundle.mjs` después de compilar para conservar las correcciones del empaquetado. El script es idempotente.

## Pruebas realizadas

`sh verify-blockbench-vspack.sh` y `node --test tests/blockbench-integrated-regression.test.mjs`.

**Límites:** faltó una prueba interactiva en Firefox/CachyOS de todos los menús y del renderizado WebGL completo. El browser de este entorno bloquea el acceso a localhost, así que no se puede afirmar que cada función del editor 3D esté reparada al 100%. Si vuelve a fallar, proporcionar el primer error rojo y sus líneas `source`, no los avisos secundarios.

## Licencia

Se conserva `modules/vspack/vs-model-studio/LICENSE.MD` y el código fuente derivado original (GPL-3.0-o-posterior).
