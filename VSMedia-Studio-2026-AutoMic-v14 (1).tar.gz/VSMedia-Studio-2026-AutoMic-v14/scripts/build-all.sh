#!/usr/bin/env bash
# VSMedia: automatic, incremental builds for Blockbench, both Rust/WASM cores
# and the optional native Rust HTTP server. Called by ./start.sh.
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
MODEL="$ROOT/modules/vspack/vs-model-studio"
PIXEL_WASM="$ROOT/modules/vspack/pixel-studio/web/vsmedia-kernels.wasm"
MODEL_WASM="$MODEL/wasm/vs_model_core_bg.wasm"
MODEL_JS="$MODEL/wasm/vs_model_core.js"
MODEL_FLAG="$MODEL/embed/wasm-capability.js"
BUNDLE="$MODEL/dist/bundle.js"
NATIVE_BIN="$MODEL/bin/vs_model_server"
FORCE="${VSMEDIA_FORCE_BUILD:-0}"

say() { printf '\n[VSMedia · Build] %s\n' "$*"; }
die() { printf '\n[VSMedia · Error] %s\n' "$*" >&2; exit 1; }

# A cache hit requires every required output to exist, and its source files
# to be older than those outputs. To discard the cache use VSMEDIA_FORCE_BUILD=1.
newer_files() {
  local output="$1"; shift
  [[ "$FORCE" == 1 || ! -s "$output" ]] && return 0
  local item
  for item in "$@"; do
    [[ -e "$item" ]] || continue
    if [[ -f "$item" && "$item" -nt "$output" ]]; then return 0; fi
    if [[ -d "$item" ]] && [[ -n "$(find "$item" -type f \( -name '*.rs' -o -name '*.ts' -o -name '*.js' -o -name '*.vue' -o -name '*.css' -o -name '*.glsl' -o -name '*.json' \) -newer "$output" -print -quit)" ]]; then return 0; fi
  done
  return 1
}

prepare_tools() {
  # rustup installed with the official installer puts tool shims in ~/.cargo/bin.
  [[ -d "${HOME:-/nonexistent}/.cargo/bin" ]] && export PATH="$HOME/.cargo/bin:$PATH"
  local missing=() tool
  for tool in node npm cargo rustc rustup; do
    command -v "$tool" >/dev/null 2>&1 || missing+=("$tool")
  done
  ((${#missing[@]}==0)) && return 0
  say "Faltan herramientas: ${missing[*]}"
  if [[ "${VSMEDIA_NO_SETUP:-0}" != 1 && -t 0 && -t 1 && $(uname -s) == Linux ]] && command -v pacman >/dev/null 2>&1; then
    printf '¿Instalar dependencias con pacman (sudo) para compilarlo todo? [s/N] '
    read -r reply
    if [[ "$reply" == [sSyY] ]]; then
      # pacman requests its own authorization and displays the package list.
      sudo pacman -S --needed nodejs npm rustup
    fi
  fi
  # A fresh rustup installation might not expose cargo/rustc until the first
  # default toolchain is chosen; let rustup set it up automatically.
  if command -v rustup >/dev/null 2>&1; then
    if ! command -v cargo >/dev/null 2>&1 || ! command -v rustc >/dev/null 2>&1; then
      say 'Preparando Rust estable mediante rustup...'
      rustup default stable || die 'Rustup no pudo preparar el toolchain estable.'
      [[ -d "${HOME:-/nonexistent}/.cargo/bin" ]] && export PATH="$HOME/.cargo/bin:$PATH"
    fi
  fi
  missing=()
  for tool in node npm cargo rustc rustup; do
    command -v "$tool" >/dev/null 2>&1 || missing+=("$tool")
  done
  if ((${#missing[@]}>0)); then
    die "Se necesita ${missing[*]} para compilar el proyecto. En CachyOS: sudo pacman -S --needed nodejs npm rustup; rustup default stable. Para abrir la copia precompilada sin reconstruir: VSMEDIA_SKIP_BUILD=1 ./start.sh"
  fi
}

prepare_rust() {
  if ! rustup show active-toolchain >/dev/null 2>&1; then
    say 'Instalando toolchain Rust estable (primera ejecución)'
    rustup default stable || die 'Rustup no tiene toolchain. Ejecutá: rustup default stable'
  fi
  if ! rustup target list --installed | grep -qx 'wasm32-unknown-unknown'; then
    say 'Agregando target wasm32-unknown-unknown'
    rustup target add wasm32-unknown-unknown || die 'No pude instalar el target wasm32; comprobá la conexión.'
  fi
}

build_blockbench() {
  if newer_files "$BUNDLE" "$MODEL/js" "$MODEL/css" "$MODEL/lib" "$MODEL/build.js" "$MODEL/package.json" "$MODEL/package-lock.json"; then
    say 'Compilando Blockbench web desde las fuentes (npm)...'
    (cd "$MODEL" && npm ci --ignore-scripts --no-audit --no-fund && npm run build-web) || die 'Falló npm. Revisá las advertencias anteriores; se necesita Internet para instalar dependencias la primera vez.'
    [[ -s "$BUNDLE" ]] || die 'Blockbench no generó dist/bundle.js'
    if [[ "${VSMEDIA_KEEP_NODE_MODULES:-0}" != 1 ]]; then
      rm -rf -- "$MODEL/node_modules"
    fi
  else
    say 'Blockbench ya está compilado; reutilizando bundle.js.'
  fi
  # Reapply safe upstream fixes even when an existing bundle is reused.
  (cd "$MODEL" && node scripts/patch-embedded-bundle.mjs) || die 'No se pudieron aplicar los parches de Blockbench.'
}

build_pixel_rust() {
  if newer_files "$PIXEL_WASM" "$ROOT/rust/vsmedia-kernels/src" "$ROOT/rust/vsmedia-kernels/Cargo.toml" "$ROOT/rust/vsmedia-kernels/Cargo.lock"; then
    say 'Compilando Rust/WASM del editor de píxeles...'
    bash "$ROOT/build-rust-kernels-once.sh" || die 'Error al compilar el motor Rust de píxeles.'
    [[ -s "$PIXEL_WASM" ]] || die 'Cargo no produjo vsmedia-kernels.wasm.'
  else
    say 'Rust/WASM de píxeles actualizado; no se recompila.'
  fi
}

build_model_rust() {
  if [[ "$FORCE" == 1 || ! -s "$MODEL_JS" || ! -s "$MODEL_WASM" ]] || newer_files "$MODEL_WASM" "$MODEL/crates/vs_model_core/src" "$MODEL/crates/vs_model_core/Cargo.toml" "$MODEL/Cargo.toml"; then
    if ! command -v wasm-pack >/dev/null 2>&1; then
      say 'Instalando wasm-pack con Cargo (solo la primera vez)...'
      cargo install wasm-pack --locked || die 'No pude instalar wasm-pack. Se necesita acceso a crates.io.'
      export PATH="$HOME/.cargo/bin:$PATH"
    fi
    say 'Compilando Rust/WASM del motor geométrico...'
    (cd "$MODEL/crates/vs_model_core" && wasm-pack build --release --target web --out-dir ../../wasm -- --features wasm) || die 'Falló la compilación WASM del modelo.'
    [[ -s "$MODEL_JS" && -s "$MODEL_WASM" ]] || die 'Faltan archivos generados por wasm-pack.'
  else
    say 'Rust/WASM geométrico actualizado; no se recompila.'
  fi
  if ! grep -q 'RUST_MODEL_WASM_READY = true' "$MODEL_FLAG" 2>/dev/null; then
    printf '// Generado automáticamente por scripts/build-all.sh.\nexport const RUST_MODEL_WASM_READY = true;\n' > "$MODEL_FLAG"
  fi
}

build_native_server() {
  if newer_files "$NATIVE_BIN" "$MODEL/crates/vs_model_server/src" "$MODEL/crates/vs_model_server/Cargo.toml"; then
    say 'Compilando el servidor HTTP en Rust (sin dependencias externas)...'
    mkdir -p -- "$MODEL/bin"
    rustc --edition=2021 -O "$MODEL/crates/vs_model_server/src/main.rs" -o "$NATIVE_BIN" || die 'No se pudo compilar el servidor Rust.'
    chmod +x "$NATIVE_BIN"
  else
    say 'Servidor Rust actualizado; no se recompila.'
  fi
}

main() {
  say 'Inicio de compilación automática e incremental.'
  prepare_tools
  local node_major
  node_major="$(node -p 'Number(process.versions.node.split(".")[0])')"
  [[ "$node_major" =~ ^[0-9]+$ ]] && ((node_major>=20)) || die 'Blockbench 5.2.2 requiere Node.js 20 o superior.'
  # Blockbench and Rust compile independently, with explicit output checks.
  build_blockbench
  prepare_rust
  build_pixel_rust
  build_model_rust
  build_native_server
  say 'Todo compilado. Arrancando VSMedia.'
}
main "$@"
