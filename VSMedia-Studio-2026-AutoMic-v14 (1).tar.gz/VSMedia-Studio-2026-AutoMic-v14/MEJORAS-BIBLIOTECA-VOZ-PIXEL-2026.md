# VSMedia Studio 2026 · Biblioteca BS, voz y paletas

## Inicio

Abrí la app con `./start.sh` o `./start`. Se mantiene intacto el AutoBuild de Blockbench, Rust/WASM de píxeles, Rust/WASM geométrico y servidor nativo. Este cambio añade HTML, CSS y JavaScript que no necesitan un paso adicional de compilación.

## Biblioteca BS para Audio / Mix / Radio

- En cada editor hay un botón **Biblioteca / Inicio** y una pantalla inicial con proyectos recientes y audios registrados.
- Panel de biblioteca a la izquierda. Conserva el espíritu de la biblioteca clásica: carpetas, subcarpetas, búsqueda, género y tipo de archivo.
- Los proyectos `.vssimple`, `.vsmedia` y `.vsradio` descargados desde VSMedia pasan a la biblioteca automáticamente cuando el navegador admite IndexedDB. Los audios importados desde las entradas nativas también se registran.
- Si abrís un proyecto registrado, se carga en su editor correspondiente; los archivos de música se abren en el editor desde el que se seleccionan.
- El contenido permanece **en el almacenamiento del navegador** (IndexedDB), no en un servidor. La cuota depende de Firefox/Chromium y la configuración del equipo; las sesiones privadas o el borrado de datos pueden eliminarlo. **Conservá los archivos de proyecto descargados como copia de seguridad**.
- No se modifica el contenido de una pista al cambiar su clasificación o carpeta.

## Micrófono y voces

- Se solicita `echoCancellation`, `noiseSuppression` y `autoGainControl` al navegador (cada navegador puede aplicar estas restricciones de forma distinta).
- Procesamiento local: filtro pasa altos, shelf de graves, presencia, pasa bajos, compresor dinámico y puerta de ruido suave controlada por RMS.
- Perfiles: **Voz limpia**, **Locución/radio**, **Voz cálida** y **Teléfono**. Cambiar de perfil afecta la siguiente grabación o la próxima activación de micrófono.
- Simple y Mix graban el resultado filtrado en un `MediaStreamDestination`, y no cierran ese destino hasta que `MediaRecorder` emita el evento final (`onstop`), para no perder los últimos fragmentos.
- VSRadio conecta el efecto de micrófono a la mezcla de programa local, de modo que la locución se puede grabar con la música.
- Estos filtros no son los algoritmos propietarios Krisp de Discord. No se descarga ni transfiere audio a terceros. Se recomiendan auriculares para evitar realimentación.

## Pixel Studio

- Selector HSV con posición visible del cursor de saturación/brillo y actualización bidireccional al seleccionar muestras y al modificar el tono.
- Selección arrastrando sobre el cuadro de color, con `setPointerCapture` para no perder el seguimiento.
- Paletas: Aseprite/actual, PICO-8, DawnBringer 32, grises, pastel, Minecraft/tierra. Importar paletas propias se conserva.
- Se marcarán las muestras que coincidan con el color seleccionado; un color personalizado fuera de la paleta aparece como «PERSONALIZADO».
- Los paneles del editor ocupan el ancho/alto del contenedor de VSPack y se redujeron paddings y alturas fijas innecesarias. El tamaño del sprite mantiene su propio zoom pixelado.

## Compatibilidad / seguridad

- Se retiraron los permisos `clipboard-read` y `clipboard-write` del atributo `allow` del iframe. Eran responsables de advertencias de Feature Policy en algunos Firefox. La integración es del mismo origen y conserva `fullscreen`.
- Los mensajes de seguridad sobre `file:///` pueden aparecer si una extensión, un archivo antiguo o un modelo intenta abrir rutas locales desde HTTP. Por seguridad, un navegador no debe permitirse saltar esta restricción; importá el recurso mediante los selectores de archivo o desde VSPack.
- Blockbench 5.2.2, motor 3D, VSPack, Home general, archivos de Rust y AutoBuild mantienen sus versiones previas.

## Pruebas

- `node --test tests/*.test.mjs tests/*.test.cjs`: 49 pruebas aprobadas.
- `bash tests/test-geometry-autobuild.sh`: verificaciones del comando wasm-pack y caché incremental aprobadas.
- `./verify.sh`: integridad/JavaScript, composición y pruebas de viewport aprobadas.
- Chromium con inyección de archivos (red local bloqueada por el entorno): tres inicios, entradas al editor, selector de voz, indexación de WAV local sin errores JS.
- No se verificó micrófono físico, Firefox en CachyOS ni ejecución del editor de píxeles mediante el iframe 3D real. No se recompiló Rust en este entorno.
