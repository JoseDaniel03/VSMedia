# VS Media Studio — Voice / Soundboard / Opus-Vorbis

Esta entrega se construyó sobre la última VSMedia funcional; no sustituye Home, VSAudio Simple, VSMix, VSRadio, Pixel Studio ni Blockbench.

## Iniciar en CachyOS

```sh
sudo pacman -S --needed ffmpeg  # Solo si te falta FFmpeg: libopus + libvorbis
./start.sh
```

`./start.sh` sigue compilando Rust/WASM, Blockbench y servidor nativo de forma incremental. Para la conversión de audio el modo automático usa **Node.js** (ya disponible por Blockbench) como servidor local en `127.0.0.1:3060`; éste ejecuta `ffmpeg` sin nube ni npm adicional. Podés usar `VSMEDIA_SKIP_BUILD=1 ./start.sh` para abrir los archivos ya compilados. Con `VSMEDIA_SERVER=rust` se conserva el servidor estático Rust anterior, **pero su API de conversión no está incorporada**: usá el modo automático/Node para exportar Opus y Vorbis.

## Nuevos módulos

- **VS Voice Studio** (`#voice`): grabación desde micrófono, monitorización opcional, medidor dBFS, perfiles (limpia, locución, cálida, teléfono, radio vieja, megáfono, robótica, fantasma), controles de umbral/ratio/ataque/release, de-esser adaptativo, puerta de ruido, saturación y limitador. Guarda tomas en biblioteca y las envía al Soundboard.
- **VS Soundboard** (`#soundboard`): 8 ranuras iniciales, hasta 48, categorías, búsqueda en biblioteca, reproducción local simultánea limitada, volumen, loop, alcance personal/cercano/global, radio, cooldown, juego/minijuego y tipo de disparador para el futuro VSMedia. Exporta e importa bancos **con archivos reales** `.vssoundbank`.
- **Conversión**: perfiles Opus 32/40/48/96/128 kbps y OGG Vorbis para Vanilla. FFmpeg se ejecuta localmente en el proceso de servidor Node; sin envío a servicios externos.
- **VSRadio**: los programas grabados ahora se incorporan también a la biblioteca compartida, para usarlos después en el Soundboard.
- **Biblioteca compartida**: conserva carpetas, clasificación, proyectos y archivos locales mediante IndexedDB (exportá copias de seguridad).

## Seguridad y límites

- El servidor escucha únicamente en `127.0.0.1`. La API de conversión exige `X-VSMedia-Local: 1` y el mismo origen cuando se informa `Origin`.
- Límite **64 MiB por fuente** y **40 MiB por resultado**, tiempo máximo FFmpeg de **120 segundos**; los bancos de hasta 48 sonidos se convierten secuencialmente.
- Los efectos de voz usan **Web Audio API** y las opciones de supresión de ruido, eco y ganancia automática que implemente el navegador. No incluyen software de Krisp ni RNNoise compilado. Son mejoras reales de voz, no una réplica propietaria de Discord.
- El procesamiento de compresión/eco puede modificar el sonido original; previsualizá antes de guardar.
- Reproducir audios dentro de Minecraft aún requiere el plugin VSMedia/VSClient; los botones del Soundboard funcionan **localmente** en esta versión.
- El exportador de bancos contiene archivos Opus o Vorbis, SHA-256, permisos sugeridos y metadatos. Ver `docs/VSMEDIA-PLUGIN-EXPORT-v2.md`.

## Pruebas

```sh
node --test tests/vs-media-integration.test.mjs
node --test tests/vs-library-voice-ui.test.mjs
```

La prueba de conversión requiere FFmpeg, que se usa también durante la ejecución normal. La compilación Rust sigue siendo opcional para **ejecutar una copia precompilada**, no para recompilar todo.
