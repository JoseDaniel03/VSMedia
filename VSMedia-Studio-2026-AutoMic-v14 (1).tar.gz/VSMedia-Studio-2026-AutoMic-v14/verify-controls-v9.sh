#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$(realpath -- "${BASH_SOURCE[0]}")")"
bash verify-controls-v8.sh >/dev/null
for file in assets/js/core.js assets/js/mix.js assets/js/media-library.js assets/js/vs-clean-controls-v9.js; do node --check "$file"; done
node --test tests/controles-depurados-v9.test.mjs
printf '\n[VSMedia] Controles unificados v9: pruebas completadas.\n'
