# VSMedia 2026 — Optimización matemática / Rust / Pixel Studio

Esta entrega continúa de `VSMedia-Studio-2026-Blockbench-Reparado.zip`.
El Home, VSRadio, el aspecto de VSAudio, y la integración de Blockbench mantienen su estructura.
No se han publicado cambios en GitHub ni en Folia.

## VSAudio Simple y VSMix: formas de onda sin perder picos

- **Índice min/max + RMS exacto** sobre una estructura iterativa de segmentos (segment tree). Indexa grupos de 128 muestras; no decima ni descarta transitorios como el muestreo aproximado anterior.
- El índice se genera una vez por `AudioBuffer` y se conserva en un `WeakMap`, evitando recalcularlo en cada redibujado, zoom o selección.
- Simple dibuja los canales L/R a partir de picos exactos; el indicador de Peak/RMS ya no depende de recorrer solo una muestra cada N posiciones.
- VSMix usa el índice de **todos los canales**, no solo el izquierdo, y normaliza el clip a partir de máximos reales. Se conserva el audio original y la edición no destructiva.
- Rendimiento medido en Node.js v22 sobre este entorno (2.000.000 muestras, 1.800 columnas, 15 redibujados): crear índice 9,6 ms; consultas indexadas 23,3 ms; consultas completas de comparación 49,3 ms (**2,12×**). Los números dependen del equipo y del audio; no son una garantía universal.

## VS Pixel Studio (estilo Aseprite): herramientas nuevas

Menú **Pixel Art** dentro de VSPack > Texturas > Editar:

1. **Reducir paleta (k-means):** histogramas 5-bit de tamaño acotado, inicialización determinista de centroides con distancia cromática ponderada y asignación a colores.
2. **Tramado Floyd–Steinberg:** difusión de error 7/16, 3/16, 5/16, 1/16 sin contaminar píxeles transparentes ni bordes de filas.
3. **Posterizar:** discretiza canales RGB de 2 a 32 niveles, conservando el alfa.
4. **Extraer paleta:** genera los colores de la imagen sin alterar los píxeles y los expone en el panel de color.
5. **Recortar transparencia:** ajusta el lienzo a la unión de todas las capas y fotogramas, manteniendo el proyecto animado.

Todas las operaciones sobre una capa respetan su bloqueo y la región seleccionada; el motor de Pixel Studio conserva deshacer/rehacer. El compositor JavaScript reutiliza el mismo búfer ImageData en la visualización, reduciendo asignaciones durante el dibujo. El historial limita las copias retenidas a 96 MiB para evitar consumo de memoria sin límite.

**Aviso:** VS Pixel Studio es una implementación integrada independiente; no se afirma que sea el binario completo de Aseprite.

## Rust/WASM opcional, compilación única

Se añadió `rust/vsmedia-kernels`, con núcleos sin dependencias de terceros para posterizado, escala de grises, cuantización a paleta y estadísticas de audio. Se exporta una interfaz C ABI consumible desde WebAssembly. Cuando está presente `modules/vspack/pixel-studio/web/vsmedia-kernels.wasm`, el editor lo usa automáticamente para algunas operaciones de color de toda la imagen; para selección regional y tramado usa la versión JS.

`./build-rust-kernels-once.sh` genera ese artefacto de forma opcional en una PC de desarrollo con Cargo y target WASM. Copiá el `.wasm` generado junto a la app. En la PC que **usa** VSMedia **no** se necesita instalar Rust, Cargo, npm ni Trunk. Sin WASM el motor JavaScript funciona como siempre.

**Limitación de validación:** el contenedor de desarrollo no dispone de Rust/Cargo ni permite instalarlo; el código de la crate Rust no se compiló aquí. Sí se validó que los fallbacks JS y los comandos integrados pasan las pruebas. Tampoco se completó smoke test HTTP en el Chromium corporativo, que bloquea `localhost` explícitamente. Es necesario validar el WASM compilado y la interfaz interactiva en CachyOS.

## Calidad / pruebas

- `node --test tests/optimization.test.mjs modules/vspack/test-compositor.mjs modules/vspack/test-viewport.mjs` → 8/8 pruebas.
- `node --check` para scripts de audio y módulos Pixel Studio → aprobado.
- `node tests/benchmark-peaks.mjs` → conserva exactamente los mismos extremos de señal que el escaneo completo.
- Home, CSS de inicio, VSRadio y los fuentes originales de Blockbench no se modificaron.
- El bundle compilado de Blockbench de tu PC **no** está incluido; conservalo en `modules/vspack/vs-model-studio/dist/bundle.js` como en la versión anterior. No hay que recompilarlo si ya lo tenés.
