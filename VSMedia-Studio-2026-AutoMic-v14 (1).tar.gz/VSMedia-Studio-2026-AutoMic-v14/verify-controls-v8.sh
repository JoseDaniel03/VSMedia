#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
bash verify-clean-ui-v7.sh
node --check assets/js/vs-compact-ui-v6.js
node --check assets/js/mix.js
node --test tests/controles-depurados-v8.test.mjs
printf '\n[VSMedia] Controles depurados v8: pruebas completas.\n'
