# VSRadio · programación tipo GTA (2026-11-09)

## Implementación

- Nuevo espacio `Programación`: playlists guardables, sesiones con guion, tipos de bloques (canción, locución, separador, programa pregrabado), pausas, orden y tiempos estimados.
- Importación M3U/M3U8 con vinculación por nombre para fuentes locales; entradas de videos y playlists YouTube válidas.
- Reproductor oficial de YouTube, siempre visible mientras se utiliza; un bloque de playlist se reproduce como lista externa (sin extracción ni mezcla de su audio).
- Sesiones finitas: después del último segmento la estación queda en espera; no hay emisión permanente.
- Programación opcional de inicio por fecha/hora, **solo con pestaña abierta**, sin garantías de autoplay.
- Guardado `.vsradio` recupera playlist, sesiones y audios locales, además de la cola de la consola A/B; enlaces YouTube quedan como URL/ID.
- Grabación de programa desde mesa A/B: descarga y biblioteca, para poder programar el episodio grabado (si el formato se puede decodificar).

## Conservado

Home, VSAudio Simple, VSMix, VSPack y archivos originales de Blockbench: sin cambios.

## Límites conocidos

- No emisión a Minecraft/Plasmo Voice, no segundo plano ni scheduler autónomo del servidor.
- YouTube utiliza iframe; no se captura su audio para WAV/WebM ni se descarga. El contenido puede estar restringido por el propietario.
- El backend del plugin será una fase diferente. El guardado `.vsradio` incluye solo audios importados desde el equipo.
