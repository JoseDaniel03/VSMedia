#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v cargo >/dev/null 2>&1; then
  echo 'Rust/Cargo solo se necesita UNA VEZ en la computadora de desarrollo.' >&2
  echo 'La aplicación funciona sin compilar gracias al motor JavaScript.' >&2
  exit 1
fi
rustup target add wasm32-unknown-unknown
# Explicitly export WASM linear memory for our no-bundler JS loader.
export RUSTFLAGS="${RUSTFLAGS:+${RUSTFLAGS} }-C link-arg=--export-memory"
cargo build --manifest-path rust/vsmedia-kernels/Cargo.toml --release --target wasm32-unknown-unknown
cp rust/vsmedia-kernels/target/wasm32-unknown-unknown/release/vsmedia_kernels.wasm modules/vspack/pixel-studio/web/vsmedia-kernels.wasm
printf 'Motor Rust/WASM listo: modules/vspack/pixel-studio/web/vsmedia-kernels.wasm\n'
