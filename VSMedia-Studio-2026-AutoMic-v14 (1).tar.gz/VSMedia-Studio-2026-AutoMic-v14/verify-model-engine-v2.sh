#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
test -s modules/vspack/vs-model-studio/dist/bundle.js
node --check modules/vspack/assets/app.js
node --check modules/vspack/assets/model-native.mjs
for js in modules/vspack/vs-model-studio/embed/{bridge,component,menu-repair,geometry-performance,geometry-worker,geometry-runner,rust-engine,wasm-capability}.js; do
 node --check "$js"
done
node --test tests/*.test.mjs tests/*.test.cjs modules/vspack/vs-model-studio/tests/*.test.mjs
node modules/vspack/test-compositor.mjs
node modules/vspack/test-pixel-layers.mjs
node modules/vspack/test-viewport.mjs
printf '\nVALIDADO: editor compilado incluido, tests y sintaxis JavaScript correctos.\n'
