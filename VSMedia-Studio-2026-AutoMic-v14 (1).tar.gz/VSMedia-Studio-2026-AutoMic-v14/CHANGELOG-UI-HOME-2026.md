# VSMedia Studio · Home DNA UI · 9 de noviembre de 2026

Nueva tanda enfocada en **organización, densidad y coherencia visual**, manteniendo intacto el Home original y sin rehacer los motores de audio, Blockbench o Pixel Studio.

## Cambios

- **Design system:** paleta auténtica del Home (`#242023`, `#e8c6aa`, `#cdb9a7`), controles crema, paneles carbón, tipografía y estados unificados. Se aplica solo a los editores, sin afectar el Home.
- **VSAudio Simple:** onda y lienzo central con mayor espacio, biblioteca/inspector más estrechos, barras de herramientas y márgenes compactos; colores del canvas adaptados a carbón, crema y verde suave.
- **VSMix:** timeline más grande, cabeceras de pista compactas, inspector y biblioteca más estrechos, consola con canales legibles y desplazamiento horizontal. Colores de pistas nuevos, menos saturados.
- **VSRadio:** decks A/B con más protagonismo, formas de onda color crema/verde, controles DJ y micrófono compactos, barras de programación menos intrusivas.
- **VS Voice Studio y VS Soundboard:** mismas superficies y acento cálido del Home, rejillas y paneles mejor distribuidos.
- **Biblioteca VS:** colores unificados (incluida su pantalla de inicio), listas y botones más compactos.
- **VSPack:** tema cálido y compacto en la interfaz de administración. La interfaz original de Blockbench **no se reescribió**.
- **Pixel Studio:** nuevo tema cálido en modo embebido, panel de color y timeline más finos, lienzo central flexible a tamaño completo. La versión independiente conserva el aspecto original.
- **Controles de vista:** desde el botón `▥ Vista` (editores), ocultar biblioteca, inspector/programación, modo enfoque y modo compacto. Se guardan en `localStorage` cuando está disponible.
- **Mezclador redimensionable:** arrastrar `↕` a la izquierda del título «MEZCLADOR · CONSOLA» en VSMix; doble clic restaura la altura, flechas ↑/↓ con foco permiten ajustar de 20 en 20 píxeles.

## Uso

Ejecutar `./start.sh` como antes. No se añadieron dependencias para el arranque.
El botón **▥ Vista** permite concentrarte en el editor sin borrar biblioteca ni proyectos. Las preferencias se recuerdan en este navegador.

## Validación

- `sh ./verify-editor-ui.sh` comprueba enlaces, archivos, Home idéntico, JS y regresión anterior.
- En Chromium se cargaron los cinco editores vía componentes en memoria; se comprobaron focus, navegación y carga de un WAV real en VSMix, sin errores JavaScript y sin desbordamiento a anchos de 1440 y 1024 px.
- No se verificó la ruta HTTP localhost en el entorno de pruebas debido a una restricción de navegación. La integración visual completa de VSPack y Pixel Studio en Firefox/CachyOS necesita comprobación local.

**Importante:** la optimización es de interfaz y layout, no es un nuevo DSP ni un cambio del motor Rust.
