import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
const source=p=>readFileSync(new URL('../'+p,import.meta.url),'utf8');
class FakeNode{
 constructor(){for(const p of ['gain','frequency','Q','threshold','ratio','knee','attack','release','delayTime'])this[p]={value:0,setTargetAtTime(v){this.value=v;}};this.fftSize=1024;this.frequencyBinCount=512;this.stream={getTracks:()=>[{stop(){}}]};}
 connect(target){return target;}
 disconnect(){}
 start(){}
 stop(){}
 getFloatFrequencyData(a){a.fill(-100)}
 getFloatTimeDomainData(a){a.fill(0)}
}
const context={currentTime:0,sampleRate:48000,state:'running',destination:new FakeNode(),resume:async()=>{},close:async()=>{}};
for(const key of ['MediaStreamSource','BiquadFilter','WaveShaper','Gain','DynamicsCompressor','Analyser','MediaStreamDestination','Delay','Oscillator'])context['create'+key]=()=>new FakeNode();
const store=new Map(),storage={getItem:k=>store.get(k)??null,setItem:(k,v)=>store.set(k,v)};
const stream={getTracks:()=>[{stop(){}}],getAudioTracks:()=>[{getSettings:()=>({sampleRate:48000})}]};
const win={VS:{},VSMic:null};
const sandbox={window:win,localStorage:storage,document:{querySelectorAll:()=>[]},navigator:{mediaDevices:{getUserMedia:async()=>stream}},performance:{now:()=>0},setInterval:()=>1,clearInterval:()=>{},Float32Array,Number,Math,console};
vm.runInNewContext(source('assets/js/voice-engine.js'),sandbox);

test('La inicialización de VSMic.open no usa el analizador antes de crearlo',async()=>{
 const session=await win.VSMic.open({context,record:true});
 assert.ok(session.stream);assert.equal(win.VSMic._test.active,1);
 assert.equal(session.params.hp,85);session.stop();assert.equal(win.VSMic._test.active,0);
});
test('La selección de perfil y los parámetros comparten estado con sesiones abiertas',async()=>{
 const a=await win.VSMic.open({context,record:false}),b=await win.VSMic.open({context,record:false});
 win.VSMic.setPreset('oldradio');
 assert.equal(a.params.lp,4200);assert.equal(b.params.lp,4200);
 win.VSMic.setGlobalParams({threshold:-36,ratio:6.5});
 assert.equal(a.params.threshold,-36);assert.equal(b.params.ratio,6.5);
 assert.equal(JSON.parse(storage.getItem('vsmedia-mic-settings-v2')).params.threshold,-36);
 a.stop();b.stop();assert.equal(win.VSMic._test.active,0);
});
test('Los guiones se almacenan separados por editor y permiten recuperar borradores',()=>{
 const sandbox={window:{},localStorage:storage,Math,Number};vm.runInNewContext(source('assets/js/vs-guiones.js'),sandbox);
 const guide=sandbox.window.VSGuiones;
 assert.equal(guide._test.key('simple'),'vsmedia-guion-v1:simple');
 assert.notEqual(guide._test.key('mix'),guide._test.key('radio'));
 store.set(guide._test.key('simple'),JSON.stringify({title:'NPC',text:'Hola\nBienvenido',font:35,speed:120}));
 assert.equal(guide.read('simple').text,'Hola\nBienvenido');
 assert.equal(guide.read('mix').text,'');
 assert.equal(guide._test.clamp(800,30,250),250);
});
test('Todos los módulos de grabación muestran selector de voz y botón de guion',()=>{
 for(const [file,pattern]of [['assets/js/simple.js',/VSMic\.controls\(\)/],['assets/js/mix.js',/VSMic\.controls\(\)/],['assets/js/radio.js',/VSMic\.controls\(\)/],['assets/js/vs-voice-studio.js',/data-vs-cue="voice"/]])assert.match(source(file),pattern);
 assert.match(win.VSMic.controls(),/data-vs-cue="auto"/);
 assert.match(win.VSMic.controls(),/data-vs-mic-settings/);
});
test('El manifiesto nuevo es VS y acepta reimportación de bancos anteriores',()=>{
 const src=source('assets/js/vs-soundboard.js');
 assert.match(src,/format:'vsmedia\.soundbank'/);
 assert.match(src,/bsmedia\.soundbank/);
});
