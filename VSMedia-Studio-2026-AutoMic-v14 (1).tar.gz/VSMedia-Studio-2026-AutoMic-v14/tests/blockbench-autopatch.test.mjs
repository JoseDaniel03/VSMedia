/** Regression cases for Blockbench bundles built by different Node/esbuild versions. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const script = fs.readFileSync(path.join(root, 'modules/vspack/vs-model-studio/scripts/patch-embedded-bundle.mjs'), 'utf8');
const sourceFile = path.join(root, 'modules/vspack/vs-model-studio/dist/bundle.js');

function runCase(name, contents, expected, sourceCounts = []) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'vs-bb-patch-'));
  try {
    fs.mkdirSync(path.join(dir, 'scripts'));
    fs.mkdirSync(path.join(dir, 'dist'));
    fs.writeFileSync(path.join(dir, 'package.json'), '{"type":"module"}');
    fs.writeFileSync(path.join(dir, 'scripts/patch-embedded-bundle.mjs'), script);
    const file = path.join(dir, 'dist/bundle.js');
    fs.writeFileSync(file, contents);
    const call = () => execFileSync(process.execPath, [path.join(dir, 'scripts/patch-embedded-bundle.mjs')], { encoding: 'utf8' });
    call();
    const first = fs.readFileSync(file, 'utf8');
    for (const [text, count] of expected) assert.equal(first.split(text).length - 1, count, `${name}: expected ${count} ${text}`);
    for (const [text, count] of sourceCounts) assert.equal(first.split(text).length - 1, count, `${name}: source ${text}`);
    call();
    assert.equal(fs.readFileSync(file, 'utf8'), first, `${name}: a second run changed the bundle`);
    console.log(`PASS ${name}`);
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
}

const rawLength = 'window.ErrorLog.length';
const fixedLength = '(window.ErrorLog||[]).length';
const rawMap = 'window.ErrorLog.map(';
const fixedMap = '(window.ErrorLog||[]).map(';
const rawWorker = 'if("serviceWorker"in navigator)try';
const fixedWorker = 'if(!document.documentElement.classList.contains("vs-embedded")&&"serviceWorker"in navigator)try';
const rawStats = '$.getJSON("https://blckbn.ch/api/stats/plugins?weeks=2",i=>';
const fixedStats = '!document.documentElement.classList.contains("vs-embedded")&&$.getJSON("https://blckbn.ch/api/stats/plugins?weeks=2",i=>';

// The Node 26 compilation reported exactly one raw ErrorLog.length.
runCase('one ErrorLog length (Node 26)',
  `${rawLength}; ${rawMap}; ${rawWorker}; ${rawStats}`,
  [[fixedLength, 1], [fixedMap, 1], [fixedWorker, 1], [fixedStats, 1]],
  [[rawLength, 0], [rawMap, 0]]);
// Older builds duplicated the same expression.
runCase('two ErrorLog lengths (older builds)',
  `${rawLength}; ${rawLength}; ${rawMap}; ${rawWorker}; ${rawStats}`,
  [[fixedLength, 2], [fixedMap, 1], [fixedWorker, 1], [fixedStats, 1]]);
// A partially patched file must have remaining expressions fixed, not skipped.
runCase('mixed old/new occurrences',
  `${fixedLength}; ${rawLength}; ${fixedMap}; ${rawWorker}; ${fixedStats}`,
  [[fixedLength, 2], [fixedMap, 1], [fixedWorker, 1], [fixedStats, 1]],
  [[rawLength, 0]]);
// Guard against the nested-substring case: stats path includes its raw form.
runCase('already patched bundle',
  `${fixedLength}; ${fixedLength}; ${fixedMap}; ${fixedWorker}; ${fixedStats}`,
  [[fixedLength, 2], [fixedMap, 1], [fixedWorker, 1], [fixedStats, 1]]);
// Newer source may remove a legacy expression entirely.
runCase('upstream changed, missing optional patterns',
  'console.log("Blockbench web");', [], []);

// The real, packaged, minified bundle remains syntactically parseable.
assert.ok(fs.existsSync(sourceFile));
execFileSync(process.execPath, ['--check', sourceFile]);
console.log('PASS real compiled bundle syntax');
