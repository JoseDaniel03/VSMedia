import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read=path=>fs.readFileSync(new URL('../'+path,import.meta.url),'utf8');
const packHtml=read('modules/vspack/index.html');
const packJs=read('modules/vspack/assets/app.js');
const wrapper=read('assets/js/vspack.js');
const pixel=read('modules/vspack/assets/pixel-bridge.mjs');
const model=read('modules/vspack/assets/model-native.mjs');
test('VSMedia embeds VSPack with one navigation source',()=>{
 assert.doesNotMatch(wrapper,/class="pack-navigation"/);
 assert.match(wrapper,/send\('NAVIGATE',\{view,manager:selectedManager\}\)/);
 assert.match(wrapper,/if\(data.type==='RESPONSE'&&data.error\)return/);
 assert.match(packHtml,/id="main-nav"/);
});
test('VSPack has only one set of visible create/import actions per hosting context',()=>{
 assert.match(packHtml,/id="add-pack-side"/);
 assert.match(packHtml,/id="import-pack-side"/);
 assert.match(read('modules/vspack/assets/virgoland-theme.css'),/body\.vspack-embed \.embed-pack-actions\{display:flex\}/);
 assert.match(packJs,/#import-pack-side/);
 assert.doesNotMatch(packJs,/'Validá y exportá tus packs en ZIP, sin modificar el servidor\.',btn/);
});
test('sprite save does not clear dirty after flattening layers or animation',()=>{
 assert.match(pixel,/hasProjectStructure/);
 assert.match(pixel,/if\(flatten&&hasProjectStructure\(\)\)/);
 assert.match(pixel,/dirty=true/);
 assert.match(pixel,/host\.removeEventListener\('keydown',shortcuts,true\)/);
});
test('model integration uses detected version and keeps native Blockbench bundle',()=>{
 assert.match(model,/details\.editorVersion/);
 assert.match(model,/method:'HEAD'/);
 assert.match(read('modules/vspack/vspack.module.json'),/compiled-blockbench-bundle-included/);
 assert.ok(fs.statSync(new URL('../modules/vspack/vs-model-studio/dist/bundle.js',import.meta.url)).size>1024*1024);
});
