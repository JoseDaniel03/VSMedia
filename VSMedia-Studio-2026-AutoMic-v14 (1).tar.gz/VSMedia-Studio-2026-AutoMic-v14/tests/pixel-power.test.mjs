import assert from 'node:assert/strict';
import {test} from 'node:test';
import {offsetTile,alphaThreshold,clearTransparentRGB,eraseIsolated,innerOutline,spriteStatistics} from '../modules/vspack/pixel-studio/web/pixel-power.mjs';
const pixels=(...rgba)=>new Uint8ClampedArray(rgba.flat());
test('wrapped offset is invertible and preserves all rgba',()=>{
 const src=pixels([255,1,2,255],[5,6,7,20],[10,12,14,0],[80,81,82,255],[2,3,4,255],[9,8,7,1]);
 const shifted=offsetTile(src,3,2,-4,7);assert.deepEqual(offsetTile(shifted,3,2,4,-7),src);
});
test('threshold alpha changes only alpha, including alpha zero',()=>{
 const src=pixels([7,8,9,0],[10,11,12,127],[13,14,15,128]);
 assert.deepEqual(alphaThreshold(src,3,1,128),pixels([7,8,9,0],[10,11,12,0],[13,14,15,255]));
});
test('transparent RGB cleanup does not erase visible RGB',()=>{
 const src=pixels([90,60,30,0],[9,8,7,1]);
 assert.deepEqual(clearTransparentRGB(src,2,1),pixels([0,0,0,0],[9,8,7,1]));
});
test('isolation removal keeps adjacent pixels and erases lonely pixels',()=>{
 const src=pixels([1,1,1,255],[1,1,1,255],[0,0,0,0],[0,0,0,0],[0,0,0,0],[1,1,1,255]);
 const out=eraseIsolated(src,3,2);assert.equal(out[3],255);assert.equal(out[7],255);assert.equal(out[23],0);
});
test('inner outline only changes opaque perimeter and preserves alpha',()=>{
 const src=new Uint8ClampedArray(4*4*4);for(let y=1;y<3;y++)for(let x=1;x<3;x++)src.set([255,255,255,160],(y*4+x)*4);
 const out=innerOutline(src,4,4,'#123456');assert.deepEqual([...out.slice((1*4+1)*4,(1*4+1)*4+4)],[18,52,86,160]);assert.equal(out[3],0);
});
test('sprite statistics counts visible, translucent and bounds',()=>{
 const src=pixels([1,2,3,0],[1,2,3,254],[1,2,3,255],[1,2,3,255]);
 const r=spriteStatistics(src,2,2);assert.equal(r.visible,3);assert.equal(r.partial,1);assert.equal(r.transparent,1);assert.deepEqual(r.bounds,[0,0,1,1]);
});
