'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('fs'),path=require('path'),vm=require('vm'),crypto=require('crypto');
const root=path.resolve(__dirname,'..');
const read=f=>fs.readFileSync(path.join(root,f),'utf8');
test('Paleta de comandos: búsqueda tolerante a tildes y navegación de módulos',()=>{
 const context={window:{addEventListener:()=>{}},document:{},console};vm.createContext(context);
 vm.runInContext(read('assets/js/vs-quick-actions.js'),context);
 assert.equal(context.window.VSQuickActions._test.normalize('MÚSICA · Mezclador'),'musica · mezclador');
 for(const action of ['matchOptions','open','close','refreshButtons'])assert.equal(typeof context.window.VSQuickActions[action],'function');
 const source=read('assets/js/vs-quick-actions.js');
 assert.match(source,/Ctrl\+K/);assert.match(source,/role="listbox"/);assert.match(source,/aria-activedescendant/);
 assert.match(source,/run:\(\)=>b\.click\(\)/,'Los comandos existentes ejecutan sus acciones originales');
});
test('Los menús de audio soportan foco, teclado y Escape',()=>{
 const ctx={window:{addEventListener:()=>{}},document:{},setTimeout,clearTimeout,TextEncoder,crypto:{},console};vm.createContext(ctx);vm.runInContext(read('assets/js/core.js'),ctx);
 const html=ctx.window.VS.menu([{label:'Archivo',actions:[{label:'Abrir',action:'open'},{label:'Guardar',action:'save'}]}]);
 assert.match(html,/aria-haspopup="menu"/);assert.match(html,/aria-expanded="false"/);assert.match(html,/role="menu"/);assert.match(html,/role="menuitem"/);
 const src=read('assets/js/core.js');for(const key of ['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Escape','aria-modal','document.activeElement'])assert.ok(src.includes(key),key);
});
test('Altura de pistas configurable e independiente del modo compacto',()=>{
 const context={window:{},localStorage:{getItem:()=>null},document:{}};vm.createContext(context);vm.runInContext(read('assets/js/vs-editor-ui.js'),context);
 assert.equal(context.window.VSEditorUI.inspect().trackHeight,'auto');
 const js=read('assets/js/vs-editor-ui.js');
 assert.match(js,/data-trackheight="tall"/);assert.match(js,/144px/);assert.match(js,/trackHeight/);
});
test('Pixel Studio admite editar color y menús mediante teclado',()=>{
 const src=read('modules/vspack/pixel-studio/web/vs-pixel-studio.mjs');
 for(const k of ['picker-square','ArrowLeft','ArrowRight','ArrowUp','ArrowDown','aria-description','aria-expanded','menu-bar'])assert.ok(src.includes(k),k);
 const css=read('modules/vspack/pixel-studio/web/styles.css');assert.match(css,/:host\(\[embedded\]\) :is\(button,input,select,\.picker-square\):focus-visible/);
});
test('La nueva identidad visual se aplica solamente a editores, nunca al Home aprobado',()=>{
 assert.equal(crypto.createHash('sha256').update(read('assets/css/app.css')).digest('hex'),'9db3fff15803a8e9e0aed5863e235934737be879cdf6bf56144fc0917c9e6a49');
 const css=read('assets/css/vs-ux-research.css');assert.match(css,/#mix/);assert.match(css,/\.vs-command-dialog/);
 assert.doesNotMatch(css,/\.home-page\s*[,{]/);
 assert.ok(read('index.html').includes('assets/css/vs-ux-research.css'));
});
