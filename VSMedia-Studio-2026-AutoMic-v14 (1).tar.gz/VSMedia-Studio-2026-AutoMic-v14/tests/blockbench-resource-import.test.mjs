import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {prepareMinecraftModel,resourceModelPath,vanillaModelIds} from '../modules/vspack/assets/model-resource-import.mjs';
const encoder = new TextEncoder();
const png = new Uint8Array([137,80,78,71,13,10,26,10,0,0,0,13,73,72,68,82,0,0,0,1]);
function env(record){
 const data=new Map(Object.entries(record).map(([key,value])=>[key,typeof value==='string'?encoder.encode(value):value]));
 const files=Array.from(data.keys(),(p,i)=>({path:p,id:'id'+i}));
 return {files,readBytes:async asset=>data.get(asset.path)};
}
test('modelo JSON directo con textura PNG, sin tocar archivo original',async()=>{
 const main='assets/test/models/item/boton.json';
 const raw='{"elements":[{"from":[0,0,0],"to":[16,16,16]}],"textures":{"layer0":"test:item/boton"}}';
 const result=await prepareMinecraftModel({path:main,...env({[main]:raw,'assets/test/textures/item/boton.png':png})});
 assert.equal(result.path,main);assert.equal(result.text,raw);
 assert.equal(result.resources[main],raw);
 assert.match(result.resources['assets/test/textures/item/boton.png'],/^data:image\/png;base64,/);
 assert.equal(result.warnings.length,0);
});
test('resuelve herencia de otro namespace y conserva cada JSON para el codec',async()=>{
 const path='assets/test/models/block/panel.json';
 const model=JSON.stringify({parent:'minecraft:block/cube_all',textures:{all:'test:block/panel'}});
 const result=await prepareMinecraftModel({path,...env({[path]:model,'assets/test/textures/block/panel.png':png})});
 assert.equal(result.text,model);
 assert.match(result.resources['assets/minecraft/models/block/cube_all.json'],/elements/);
 assert.match(result.resources['assets/test/textures/block/panel.png'],/^data:image\/png/);
 assert.equal(result.warnings.length,1);
});
test('herencia personalizada de dos niveles, mantiene claves en recursos',async()=>{
 const a='assets/mypack/models/block/child.json',b='assets/mypack/models/block/base.json';
 const result=await prepareMinecraftModel({path:a,...env({[a]:JSON.stringify({parent:'mypack:block/base'}),[b]:JSON.stringify({elements:[{from:[0,0,0],to:[16,16,16]}]})})});
 assert.ok(result.resources[b].includes('elements'));assert.equal(result.warnings.length,0);
});
test('un ítem moderno con referencia directa abre el modelo, sin sobrescribir items JSON',async()=>{
 const item='assets/demo/items/silla.json',model='assets/demo/models/item/silla.json';
 const result=await prepareMinecraftModel({path:item,...env({[item]:JSON.stringify({model:{type:'minecraft:model',model:'demo:item/silla'}}),[model]:'{"elements":[]}'})});
 assert.equal(result.path,model);assert.equal(result.originalPath,item);assert.ok(result.sourceId);
});
test('un blockstate de variante única abre su modelo real',async()=>{
 const block='assets/demo/blockstates/cubo.json',model='assets/demo/models/block/cubo.json';
 const result=await prepareMinecraftModel({path:block,...env({[block]:JSON.stringify({variants:{'':{model:'demo:block/cubo'}}}),[model]:'{"elements":[]}'})});
 assert.equal(result.path,model);
});
test('no inventa una variante condicional o ponderada',async()=>{
 const path='assets/demo/items/silla.json';
 await assert.rejects(()=>prepareMinecraftModel({path,...env({[path]:JSON.stringify({model:{type:'minecraft:condition',on_true:{type:'minecraft:model',model:'demo:item/a'},on_false:{type:'minecraft:model',model:'demo:item/b'}}})})}),/minecraft:condition/);
});
test('no sigue referencias circulares ni rutas peligrosas',async()=>{
 const path='assets/test/models/a.json',parent='assets/test/models/b.json';
 await assert.rejects(()=>prepareMinecraftModel({path,...env({[path]:'{"parent":"test:b"}',[parent]:'{"parent":"test:a"}'})}),/circular/);
 await assert.rejects(()=>prepareMinecraftModel({path,...env({[path]:'{"parent":"../../etc/passwd"}'})}),/inválida/);
});
test('padre ausente ofrece advertencia, sin inventar geometría',async()=>{
 const path='assets/test/models/block/unknown.json';
 const result=await prepareMinecraftModel({path,...env({[path]:'{"parent":"test:block/no_existe"}'})});
 assert.ok(result.warnings.some(w=>w.includes('Falta el modelo padre')));
});
test('rutas válidas y colección de modelos vanilla básicos',()=>{
 assert.equal(resourceModelPath('models','test:block/example'),'assets/test/models/block/example.json');
 assert.ok(vanillaModelIds().includes('minecraft:block/cube_all'));
});
test('el bundle web expone el menú nativo y conserva el editor 3D',()=>{
 const dir=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../modules/vspack/vs-model-studio');
 const bundle=readFileSync(path.join(dir,'dist/bundle.js'),'utf8');
 assert.ok(bundle.includes('window.VSModelMenuBar=wn'));
 assert.ok(bundle.includes('open_bar_menu'));
 assert.ok(bundle.includes('Three')||bundle.includes('three'));
 assert.ok(!bundle.includes('sourceMappingURL=bundle.js.map'));
 const html=readFileSync(path.join(dir,'index.html'),'utf8');
 assert.ok(html.includes('embed/menu-repair.js'));
});
