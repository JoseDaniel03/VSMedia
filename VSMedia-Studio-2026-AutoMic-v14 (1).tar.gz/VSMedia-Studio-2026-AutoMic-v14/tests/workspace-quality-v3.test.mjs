import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
const read=p=>readFileSync(new URL('../'+p,import.meta.url),'utf8');

test('mezcla: audio recortado nunca se programa más allá de su longitud visible',()=>{
 const window={VS:{}};const context={window,crypto:{randomUUID:()=>''},console};vm.runInNewContext(read('assets/js/mix.js'),context);
 const route=window.VSMixApp._test.routeBuffer;
 function run(position,c){const scheduled=[];const gain={gain:{setValueAtTime(){},linearRampToValueAtTime(){}} ,connect(){return {}}};
  const ctx={createBufferSource:()=>({connect(){return gain},start(...args){scheduled.push(args)}}),createGain:()=>gain};
  const clip={start:5,offset:3,length:2,gain:1,fadeIn:0,fadeOut:0,...c};
  const buses=new Map([['t1',{input:{}}]]);
  route(ctx,{duration:12},clip,{id:'t1'},0,position,buses);return JSON.parse(JSON.stringify(scheduled));
 }
 assert.deepEqual(run(0),[[5,3,2]],'clip trimmed to two seconds from position 0');
 assert.deepEqual(run(6),[[0,4,1]],'playhead inside clip schedules remaining one second');
 assert.deepEqual(run(8),[],'clip outside playhead must not schedule');
 assert.deepEqual(run(0,{length:3,offset:11}),[[5,11,1]],'never read past source duration');
});
test('exportación v5 no trunca a 15 minutos y protege la memoria con render por bloques',()=>{
 const src=read('assets/js/mix.js');
 assert.ok(!src.includes('La mezcla excede el límite de exportación de 15 minutos'));
 assert.ok(!src.includes('length=Math.min(length,15*60)'));
 assert.ok(src.includes('window.VSMixExport.render({duration:length'));
 assert.ok(src.includes('spec.bytes>MAX_BROWSER'));
 assert.ok(src.includes('cancelled:()=>S.renderCancel'));
});
test('el redimensionado de ondas usa RAF y detecta cambios visibles',()=>{
 for(const name of ['mix','simple','radio']){
  const src=read(`assets/js/${name}.js`);
  assert.match(src,/function refreshLayout\(/,name);assert.match(src,/requestAnimationFrame\(/,name);assert.match(src,/refreshLayout,/,name);
 }
});
test('paneles redimensionables persisten por módulo, permiten teclado y reset',()=>{
 const store=new Map();const window={addEventListener:()=>{}};
 const localStorage={getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,v)};
 const ctx={window,localStorage,document:{},setTimeout};vm.runInNewContext(read('assets/js/vs-workspace-v3.js'),ctx);
 const api=window.VSWorkspaceV3;
 assert.equal(api.inspect().mix.left,180);assert.equal(api.inspect().radio.right,220);
 assert.equal(api._test.clamp(590,130,400),400);
 assert.equal(api._test.clamp(50,130,400),130);
 const src=read('assets/js/vs-workspace-v3.js');
 for(const token of ['role','separator','aria-valuenow','ArrowLeft','ArrowRight','pointercancel','dblclick','localStorage','selectPreset'])assert.ok(src.includes(token),token);
 const css=read('assets/css/vs-workspace-v3.css');assert.match(css,/\.vs-resizer/);assert.doesNotMatch(css,/\.home-page\s*[,{]/);
});
test('atajos de reproducción no interceptan comandos ni diálogos',()=>{
 for(const name of ['mix','simple']){
  const src=read(`assets/js/${name}.js`);
  assert.ok(src.includes('.vs-command-layer:not([hidden]),.dialog-layer:not([hidden])'));
  assert.ok(src.includes('e.defaultPrevented'));
 }
});
test('VSAudio pide confirmación al soltar audio y Soundboard bloquea atajos sobre diálogos',()=>{
 const simple=read('assets/js/simple.js'),soundboard=read('assets/js/vs-soundboard.js');
 assert.ok(simple.includes('root.ondrop=async e=>'));
 assert.ok(simple.includes('Reemplazar audio abierto'));
 assert.ok(soundboard.includes('#bs-editor-overlay'));
 assert.ok(soundboard.includes('.vs-command-layer:not([hidden])'));
});
test('Home sigue usando su hoja original y cargan los nuevos assets',()=>{
 const src=read('index.html');
 assert.ok(src.includes('assets/css/vs-workspace-v3.css'));
 assert.ok(src.includes('assets/js/vs-workspace-v3.js'));
 assert.ok(!read('assets/css/vs-workspace-v3.css').includes('#home '));
});
