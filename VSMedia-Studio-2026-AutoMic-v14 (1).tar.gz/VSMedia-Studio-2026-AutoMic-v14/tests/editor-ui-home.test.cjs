'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const root=path.join(__dirname,'..'),read=p=>fs.readFileSync(path.join(root,p),'utf8');
test('Approved Home stylesheet is unchanged',()=>{
 const crypto=require('node:crypto'),hash=crypto.createHash('sha256').update(read('assets/css/app.css')).digest('hex');
 assert.equal(hash,'9db3fff15803a8e9e0aed5863e235934737be879cdf6bf56144fc0917c9e6a49');
});
test('Editor stylesheet is the final stylesheet, without touching Home markup',()=>{
 const html=read('index.html');assert.ok(html.includes('vs-editor-ui.css'));assert.ok(html.lastIndexOf('vs-editor-ui.css')>html.indexOf('vs-guiones.css'));
 assert.ok(html.includes('vs-editor-ui.js'));assert.ok(read('assets/js/core.js').includes('window.VSEditorUI?.init()'));
});
test('Home-derived accents and all five editor scopes are declared',()=>{
 const css=read('assets/css/vs-editor-ui.css');
 for(const token of ['#242023','#e8c6aa','#cdb9a7','#simple','#mix','#radio','#voice','#soundboard'])assert.ok(css.includes(token),token);
 for(const classname of ['vs-hide-library','vs-hide-inspector','vs-focus-workspace','vs-ui-compact','vs-mixer-grip'])assert.ok(css.includes(classname),classname);
});
test('UI controller exposes density, focus and persistence independently per editor',()=>{
 const storage=new Map(),context={window:{},localStorage:{getItem:key=>storage.get(key)||null,setItem:(key,val)=>storage.set(key,val)},document:{}};
 vm.createContext(context);vm.runInContext(read('assets/js/vs-editor-ui.js'),context);
 const api=context.window.VSEditorUI;assert.equal(typeof api.init,'function');assert.equal(typeof api.apply,'function');
 assert.equal(api.inspect().density,'comfortable');assert.equal(api._test.prefs('simple').focus,false);
 assert.equal(api._test.prefs('radio').library,true);assert.ok(!api.inspect().panels.mix);
});
test('VSPack shell uses its own scoped Home skin; Blockbench compiled file is kept',()=>{
 const html=read('modules/vspack/index.html');
 assert.ok(html.includes('virgoland-theme.css'));assert.ok(html.includes('virgoland-theme.js'));
 assert.ok(read('modules/vspack/pixel-studio/web/styles.css').includes(':host([embedded])'));
 assert.ok(fs.statSync(path.join(root,'modules/vspack/vs-model-studio/dist/bundle.js')).size>4000000);
});
