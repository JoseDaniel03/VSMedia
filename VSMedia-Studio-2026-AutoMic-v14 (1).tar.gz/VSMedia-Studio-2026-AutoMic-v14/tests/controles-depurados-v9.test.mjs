import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read=rel=>fs.readFileSync(new URL('../'+rel,import.meta.url),'utf8');
const js=read('assets/js/vs-clean-controls-v9.js');
const css=read('assets/css/vs-clean-controls-v9.css');
const core=read('assets/js/core.js');
const html=read('index.html');
const library=read('assets/js/media-library.js');
const mix=read('assets/js/mix.js');
test('v9 corre sobre v8 y no elimina el editor original',()=>{
 assert.match(core,/window\.VSCompactUI\?\.init\(\);\s*window\.VSCleanControlsV9\?\.init\(\);/);
 assert.match(html,/vs-clean-controls-v9\.css/);
 assert.match(html,/vs-clean-controls-v9\.js/);
 assert.match(html,/vs-compact-ui-v6\.js/);
 assert.match(html,/assets\/js\/mix\.js/);
 assert.doesNotMatch(css,/#home\b|#vspack\b|#model\b|#voice\b|#soundboard\b/);
});
test('Paneles de los tres editores usan sus nodos originales y mantienen Ver/ Herramientas',()=>{
 assert.match(js,/popup\.append\(panelHost\)/);
 assert.match(js,/page\.id==='radio'/);
 assert.match(js,/\.work-menubar \.menu-wrap/);
 assert.match(js,/\.vs-compact-dropdown\[data-kind="navigate"\]/);
 assert.match(js,/tools\.append\(command\)/);
 assert.match(js,/trigger\.setAttribute\('role','menuitem'\)/);
});
test('VSMix conserva rutas reales para zoom, bucles, operaciones, proyectos y exportación',()=>{
 for(const a of ['zoomin','zoomout','zoomfit','loopin','loopout','split','duplicateclip','saveproject','export','exportwebm'])
   assert.match(mix,new RegExp(`action:'${a}'`));
 assert.match(js,/\[data-a="zoomout"\]/);
 assert.match(js,/\[data-a="zoomin"\]/);
 assert.match(js,/vs-v9-loop-editing/);
 assert.match(js,/mixer-collapsed/);
 assert.match(mix,/\$\{S\.assets\.size===1\?'audio':'audios'\}/);
});
test('Biblioteca tiene un solo acceso a Todos y la acción limpia ambos filtros',()=>{
 assert.doesNotMatch(library,/data-vsl-cat="all" class="selected"/);
 assert.match(library,/data-vsl-folder="all"/);
 assert.match(library,/if\(node\.dataset\.vslFolder==='all'\)states\[mod\]\.cat='all'/);
 assert.match(library,/data-vsl-cat="audio"/);
 assert.match(library,/data-vsl-cat="projects"/);
});
test('El script no agrega botones nuevos de exportación ni proyectos',()=>{
 assert.doesNotMatch(js,/createElement\('button'\)/);
 assert.doesNotMatch(js,/innerHTML\s*=\s*`/);
});
