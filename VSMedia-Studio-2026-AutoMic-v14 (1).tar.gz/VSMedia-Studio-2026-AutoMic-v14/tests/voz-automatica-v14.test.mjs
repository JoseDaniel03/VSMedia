import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
const root=path.resolve(import.meta.dirname,'..');
const ctx=vm.createContext({window:{},console});
vm.runInContext(fs.readFileSync(path.join(root,'assets/js/vs-auto-voice-v14.js'),'utf8'),ctx);
const auto=ctx.window.VSAutoVoice;

test('Voz automática se instala en el cliente sin red ni dependencia servidor',()=>{
  assert.equal(typeof auto.create,'function');
  const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
  assert.match(html,/vs-auto-voice-v14\.js[\s\S]*voice-engine\.js/);
  const engine=fs.readFileSync(path.join(root,'assets/js/voice-engine.js'),'utf8');
  assert.match(engine,/auto:\{label:'Automático/);
  assert.match(engine,/currentProfile='auto'/);
  assert.match(engine,/autoGainControl:true/);
  assert.match(engine,/connect\(gate\)\.connect\(autoGain\)\.connect\(limiter\)/);
});
test('En silencio no se amplifica el ruido ni se abre una puerta brusca',()=>{
 const x=auto.create({browserAgc:false});let v;
 for(let i=0;i<130;i++)v=x.step({inputDb:-72,outputDb:-72,peak:.002,now:i*45});
 assert.equal(v.gainDb,0);
 assert.ok(v.gateFactor>=.4&&v.gateFactor<=1);
 assert.equal(v.voice,false);
});
test('Voz suave se nivela gradualmente sin saturarse',()=>{
 const x=auto.create({browserAgc:false});let v;
 for(let i=0;i<25;i++)x.step({inputDb:-74,outputDb:-74,peak:.001,now:i*45});
 for(let i=25;i<120;i++)v=x.step({inputDb:i%3===0?-41:-38,outputDb:-39,peak:.12,now:i*45});
 assert.ok(v.gainDb>0,`ganancia=${v.gainDb}`);
 assert.ok(v.gainDb<=12,`ganancia=${v.gainDb}`);
 assert.equal(v.voice,true);
});
test('Si WebRTC ya tiene AGC no suma ganancia excesiva',()=>{
 const x=auto.create({browserAgc:true});let v;
 for(let i=0;i<20;i++)x.step({inputDb:-75,outputDb:-75,peak:.001,now:i*50});
 for(let i=20;i<200;i++)v=x.step({inputDb:-35,outputDb:-43,peak:.18,now:i*50});
 assert.ok(v.gainDb<=3&&v.gainDb>=0);
 assert.equal(v.webRtcAgc,true);
});
test('Voz fuerte baja la ganancia y mantiene techo de seguridad',()=>{
 const x=auto.create({browserAgc:false});let v;
 for(let i=0;i<20;i++)x.step({inputDb:-75,outputDb:-75,peak:0,now:i*100});
 for(let i=20;i<120;i++)v=x.step({inputDb:-5,outputDb:-4,peak:.99,now:i*100});
 assert.ok(v.gainDb<0);
 assert.ok(v.gainDb>=-10);
 assert.equal(v.clipping,true);
});
test('Reset vuelve a nivel neutro y solo se mantiene estado en RAM',()=>{
 const x=auto.create({browserAgc:false});
 for(let i=0;i<50;i++)x.step({inputDb:-36,outputDb:-39,peak:.2,now:i*100});
 x.reset();
 assert.equal(x.state.gainDb,0);
 assert.equal(x.state.steps,0);
});
