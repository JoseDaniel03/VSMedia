import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
import {ffmpegArgs,PRESETS} from '../serve.mjs';

test('Fundido DJ de potencia constante: extremos, centro y límites', async()=>{
 const src=await readFile(new URL('../assets/js/radio.js',import.meta.url),'utf8');
 const window={};vm.runInNewContext(src,{window,Math,Number});
 const f=window.VSRadioApp._test.crossfadeGains;
 for(const [x,a,b] of [[-1,1,0],[0,Math.SQRT1_2,Math.SQRT1_2],[1,0,1]]){
   const out=f(x);assert.ok(Math.abs(out.A-a)<1e-10,`A x=${x}`);assert.ok(Math.abs(out.B-b)<1e-10,`B x=${x}`);
 }
 for(let x=-1;x<=1;x+=.04){const {A,B}=f(x);assert.ok(Math.abs(A*A+B*B-1)<1e-10,'potencia constante');}
 assert.ok(f(-100).A>=.999999);assert.ok(f(100).B>=.999999);
});

test('Los tres perfiles de Chrome usan WebM/Opus, sin retirar OGG',()=>{
 for(const key of ['webm-voice-40','webm-radio-96','webm-music-128']){
   assert.equal(PRESETS[key].container,'webm');assert.equal(PRESETS[key].contentType,'audio/webm');
   const args=ffmpegArgs(key);assert.ok(args.includes('libopus'));assert.ok(args.includes('webm'));
 }
 assert.ok(PRESETS['mc-sfx']);assert.ok(PRESETS['radio-96']);
});
