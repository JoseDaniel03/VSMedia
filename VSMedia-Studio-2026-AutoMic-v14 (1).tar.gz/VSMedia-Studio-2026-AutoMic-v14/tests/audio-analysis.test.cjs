const assert=require('node:assert/strict');const {test}=require('node:test');
const {detectSilences,audioStats,snapToEdge}=require('../assets/js/audio-analysis.js');
function b(data,sr=100){return {numberOfChannels:1,sampleRate:sr,length:data.length,duration:data.length/sr,getChannelData:()=>Float32Array.from(data)}}
test('RMS/peak actual samples and no slider estimate',()=>{const r=audioStats(b([0,1,-1,0]));assert.equal(r.peak,1);assert.equal(r.rms,Math.sqrt(.5));assert.equal(r.samples,4)});
test('silence scan detects start and end with duration and handles full silence',()=>{const samples=[...Array(100).fill(0),...Array(100).fill(.75),...Array(100).fill(0)];const x=detectSilences(b(samples),{thresholdDb:-30,minSeconds:.5,hopSeconds:.02});assert.equal(x.length,2);assert.ok(x[0][1]>=.98);assert.ok(x[1][0]>=1.98);assert.equal(detectSilences(b(Array(200).fill(0))).length,1);});
test('short gaps are suppressed; quiet sound under threshold',()=>{const a=b([...Array(10).fill(0),...Array(100).fill(1)]);assert.equal(detectSilences(a,{minSeconds:.3}).length,0)});
test('snap edge selects close boundary only',()=>{assert.equal(snapToEdge(2.06,[0,2,8]),2);assert.equal(snapToEdge(2.2,[0,2,8]),2.2)});
test('invalid buffers/threshold rejected',()=>{assert.throws(()=>detectSilences(null));assert.throws(()=>detectSilences(b([1]),{thresholdDb:20}))});
