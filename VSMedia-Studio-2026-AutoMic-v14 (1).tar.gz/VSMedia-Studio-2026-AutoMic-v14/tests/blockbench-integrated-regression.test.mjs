import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { inspectModel } from '../modules/vspack/vs-model-studio/embed/model-diagnostics.js';
const from=(p)=>fs.readFileSync(new URL(p,import.meta.url),'utf8');

test('model diagnostics: bounds and triangles are deterministic',()=>{
  const result=inspectModel({name:'Modelo',meta:{model_format:'java_block'},elements:[
    {type:'cube',from:[0,0,0],to:[16,16,16],faces:{north:{},south:{}}},
    {type:'mesh',vertices:{a:[-3,2,4],b:[4,5,6],c:[0,1,2]},faces:{q:{vertices:['a','b','c']}}}
  ], textures:[{uuid:'a'}],groups:[],animations:[]},{javaFormat:true});
  assert.equal(result.elements,2);assert.equal(result.cubes,1);assert.equal(result.meshes,1);
  assert.deepEqual(result.bounds,{min:[-3,0,0],max:[16,16,16]});
  assert.equal(result.estimatedTriangles,5);assert.equal(result.issues.length,0);
});
test('diagnostics warn for non-finite coordinates and zero-size elements',()=>{
 const r=inspectModel({elements:[{type:'cube',from:[0,0,0],to:[0,4,4]},{type:'cube',from:[NaN,1,0],to:[3,3,3]}],textures:[{id:'same'},{id:'same'}]});
 assert.equal(r.cubes,2); assert.ok(r.issues.some(i=>/dimensión cero/.test(i.what)));
 assert.ok(r.issues.some(i=>/from\/to/.test(i.what)));assert.ok(r.issues.some(i=>/repetida/.test(i.what)));
});
test('no model mutation from analysis',()=>{
 const a={name:'x',elements:[{type:'cube',from:[0,0,0],to:[2,3,4]}]}; const orig=JSON.stringify(a);
 inspectModel(a);assert.equal(JSON.stringify(a),orig);
});
test('manager event listeners remain inside VSPack module scope',()=>{
 const s=from('../modules/vspack/assets/app.js');
 assert.ok(s.lastIndexOf("window.addEventListener('vspack:model-return'")<s.lastIndexOf('})();'));
 assert.ok(s.lastIndexOf("window.addEventListener('beforeunload'")<s.lastIndexOf('})();'));
});
test('compiled bundle has guarded ErrorLog and no embedded service worker',()=>{
 const s=from('../modules/vspack/vs-model-studio/dist/bundle.js');
 assert.equal((s.match(/window\.ErrorLog\.length/g)||[]).length,0);
 assert.ok(s.includes('(window.ErrorLog||[]).length'));
 assert.ok(s.includes('!document.documentElement.classList.contains("vs-embedded")&&"serviceWorker"in navigator'));
 assert.ok(s.includes('!document.documentElement.classList.contains("vs-embedded")&&$.getJSON("https://blckbn.ch/api/stats/plugins'));
});
test('component removes unsupported clipboard permissions and defaults to Spanish',()=>{
 const s=from('../modules/vspack/vs-model-studio/embed/component.js');
 assert.ok(s.includes("setAttribute('allow', 'fullscreen')"));
 assert.ok(!s.includes("clipboard-read; clipboard-write"));
 assert.ok(s.includes("'vs_lang'"));
 const html=from('../modules/vspack/vs-model-studio/index.html');
 assert.ok(html.includes('<html lang="es">'));
 const menu=from('../modules/vspack/vs-model-studio/embed/menu-repair.js');
 assert.ok(menu.includes('menu?.label===label')); // Real BarMenu.label DOM identity, not translated text
 assert.ok(!menu.includes('observer.observe(document.documentElement'));
});

test('native menu fallback finds the real BarMenu and opens on failed click',async()=>{
 const vm=await import('node:vm');
 const handlers={};const css={};
 const classes=new Set();
 const li={classList:{contains:k=>classes.has(k)},attributes:{},closest:s=>s==='li.menu_bar_point'?li:null,hasAttribute:()=>false,setAttribute(){},getBoundingClientRect:()=>({width:100})};
 const bar={contains:x=>x===li,addEventListener:(kind,fn)=>handlers[kind]=fn,querySelectorAll:()=>[li]};
 const node={isConnected:false,style:{},getBoundingClientRect:()=>({width:175})};
 let opened=0;
 const menu={label:li,node,open(){node.isConnected=true;opened++;classes.add('opened')},hide(){node.isConnected=false;classes.delete('opened')}};
 const doc={getElementById:id=>id==='menu_bar'?bar:null,querySelectorAll:()=>[],addEventListener:()=>{},documentElement:{},};
 const win={parent:{},VSModelMenuBar:{menus:{file:menu}},Blockbench:{showQuickMessage(){}}};
 const context={window:win,document:doc,location:{search:'?vs_embed=1'},URLSearchParams,MutationObserver:class {observe(){}},requestAnimationFrame:fn=>fn(),queueMicrotask,WeakMap,Set,getComputedStyle:()=>({display:'block'})};
 vm.runInNewContext(from('../modules/vspack/vs-model-studio/embed/menu-repair.js'),context);
 assert.equal(li.tabIndex,0);
 const event={target:li};
 handlers.pointerdown(event);handlers.click(event);
 await new Promise(resolve=>setImmediate(resolve));
 assert.equal(opened,1);
 // Next click while the menu is already open should never reopen it.
 handlers.pointerdown(event);handlers.click(event);await new Promise(resolve=>setImmediate(resolve));
 assert.equal(opened,1);
});
