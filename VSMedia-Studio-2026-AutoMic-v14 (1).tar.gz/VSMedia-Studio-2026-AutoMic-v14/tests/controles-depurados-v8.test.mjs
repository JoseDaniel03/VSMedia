import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = path => fs.readFileSync(new URL('../'+path,import.meta.url),'utf8');
const ui=read('assets/js/vs-compact-ui-v6.js');
const mix=read('assets/js/mix.js');
const simple=read('assets/js/simple.js');
const radio=read('assets/js/radio.js');
const css=read('assets/css/vs-compact-ui-v6.css');
test('La limpieza se ejecuta después de los cambios v6 y no vuelve a crear barras',()=>{
 assert.match(ui,/simplifyOther\(\);tidyV8\(\)/);
 assert.equal((ui.match(/function tidyV8\(/g)||[]).length,1);
 assert.doesNotMatch(css,/#home\b/);
});
test('Simple conserva acciones del menú Archivo y formato WAV 16/32',()=>{
 for (const action of ['save','export','exportwebm']) assert.match(simple,new RegExp(`action:'${action}'`));
 assert.match(ui,/simple\.querySelector\('\.work-header \[data-simple="save"\]'\)\?\.remove/);
 assert.match(ui,/simple\.querySelector\('\.work-header \[data-simple="export"\]'\)\?\.remove/);
 assert.match(ui,/fileMenu\.querySelector\('\[data-action="export"\]'\)\?\.after\(quality\)/);
 assert.match(simple,/id="simple-wav-format"/);
});
test('Herramientas de silencio únicas siguen accesibles y se conservan atajos de selección',()=>{
 for(const action of ['findsilence','nextsilence','maskdetected'])assert.match(simple,new RegExp(`data-simple="${action}"`));
 assert.match(ui,/onlyUnique=\['findsilence','nextsilence','maskdetected'\]/);
 assert.match(simple,/e\.key\.toLowerCase\(\)==='a'/);
 assert.match(simple,/data-simple="crop"/);
});
test('VSMix deja una ruta visible al exportar, y mantiene acciones de clip en el menú',()=>{
 for(const action of ['export','saveproject','import','split','duplicateclip','normalizeclip','deleteclip'])assert.match(mix,new RegExp(`action:'${action}'`));
 for(const action of ['saveproject','export'])assert.match(ui,new RegExp(`mix\\.querySelector\\('\\.work-header \\[data-a="${action}"\\]'\\)\\?\\.remove`));
 assert.match(ui,/mix\.querySelector\('\.audio-tools \[data-a="import"\]'\)\?\.remove/);
 assert.match(ui,/mix\.querySelector\('\.timeline-top \.right \.vs-compact-dropdown/);
});
test('El menú contextual de VSMix sigue usando el mismo controlador de acciones',()=>{
 assert.match(mix,/id='mix-clip-context'/);
 assert.match(mix,/clipMenu\.innerHTML=/);
 assert.match(mix,/root\.addEventListener\('contextmenu'/);
 assert.match(mix,/clipMenu\.addEventListener\('click',hideClipMenu\)/);
 assert.match(mix,/data-clip="\$\{c\.id\}" tabindex="0"/);
});
test('VSRadio reagrupa las operaciones de archivo sin borrar sus acciones',()=>{
 for(const action of ['openstation','savestation','schedule','import'])assert.match(radio,new RegExp(`data-radio="${action}"`));
 assert.match(ui,/\['savestation','import'\]/);
 assert.match(ui,/file\.append\(button\)/);
 assert.match(ui,/\[data-vsl-start\]/);
});
