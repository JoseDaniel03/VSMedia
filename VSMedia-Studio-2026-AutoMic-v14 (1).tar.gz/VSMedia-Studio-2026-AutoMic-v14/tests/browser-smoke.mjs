/* Optional Chromium CDP smoke test. Requires an existing Chrome on port 9222. */
import assert from 'node:assert/strict';
const targets=await (await fetch('http://127.0.0.1:9222/json/list')).json();
const page=targets.find(t=>t.type==='page');if(!page)throw Error('No hay página de Chromium');
const ws=new WebSocket(page.webSocketDebuggerUrl);
await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true});});
let id=0;const pending=new Map(),exceptions=[];
ws.addEventListener('message',ev=>{const msg=JSON.parse(ev.data);if(msg.id&&pending.has(msg.id)){const p=pending.get(msg.id);pending.delete(msg.id);msg.error?p.reject(Error(JSON.stringify(msg.error))):p.resolve(msg.result);}if(msg.method==='Runtime.exceptionThrown')exceptions.push(msg.params.exceptionDetails.text);});
function send(method,params={}){return new Promise((resolve,reject)=>{const num=++id;pending.set(num,{resolve,reject});ws.send(JSON.stringify({id:num,method,params}));});}
async function evaluate(source){const r=await send('Runtime.evaluate',{expression:source,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.text+' '+JSON.stringify(r.exceptionDetails.exception));return r.result.value;}
await send('Runtime.enable');await send('Page.enable');await send('Page.navigate',{url:'http://127.0.0.1:3060/'});
let ready=false;for(let i=0;i<80;i++){await new Promise(r=>setTimeout(r,100));if(await evaluate("document.readyState==='complete'&&!!window.VS&&!!window.VSPackApp")){ready=true;break;}}
assert.ok(ready,'La aplicación no inició');
const nav=await evaluate(`(()=>{const routes=['simple','mix','vspack','radio','home'];const result={};for(const id of routes){window.VS.navigate(id);result[id]=!document.querySelector('#'+id).hidden;}return result;})()`);
assert.ok(Object.values(nav).every(Boolean),'No cargaron todas las páginas: '+JSON.stringify(nav));
const pixel=await evaluate(`(async()=>{
  await import('/modules/vspack/pixel-studio/web/vs-pixel-studio.mjs');
  const editor=document.createElement('vs-pixel-studio');editor.setAttribute('width','8');editor.setAttribute('height','8');document.body.append(editor);
  if(!editor.engine)await new Promise((resolve,reject)=>{editor.addEventListener('vs-pixel-ready',resolve,{once:true});setTimeout(()=>reject(Error('editor timeout')),5000);});
  const initial=new Uint8ClampedArray(8*8*4);
  for(let y=2;y<6;y++)for(let x=1;x<6;x++){const i=(y*8+x)*4;initial.set([x*34,y*35,x*y*10,255],i);}
  editor.engine.setCelPixels(initial);
  window.prompt=()=> '8';
  await editor.pixelColorAction('quantize');
  const palette=editor.projectMeta.palette?.length||0;
  const alpha=editor.engine.getCelPixels().filter((_,i)=>i%4===3);
  const opaque=Array.from(alpha).filter(n=>n===255).length;
  await editor.pixelColorAction('dither');await editor.pixelColorAction('posterize');
  await editor.trimTransparent();
  const result={palette,opaque,width:editor.engine.width,height:editor.engine.height,engine:editor.engine.kind};
  editor.remove();return result;
})()`);
assert.ok(pixel.palette>0&&pixel.palette<=8);assert.equal(pixel.opaque,20);assert.equal(pixel.width,5);assert.equal(pixel.height,4);
assert.equal(exceptions.length,0,'Errores del navegador '+exceptions.join(','));
console.log(JSON.stringify({navigation:nav,pixel,exceptions},null,2));ws.close();
