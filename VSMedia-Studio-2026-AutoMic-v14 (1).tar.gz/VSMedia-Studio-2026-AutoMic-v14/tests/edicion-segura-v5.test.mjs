import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFileSync} from 'node:fs';
const require=createRequire(import.meta.url);
const render=require('../assets/js/vs-mix-export-v5.js');
const fromPath=p=>readFileSync(new URL('../'+p,import.meta.url),'utf8');

test('plan de exportación v5: 65 segundos se dividen sin perder ni duplicar cuadros',()=>{
 const p=render.plan(65,10000,30,2.4);
 assert.equal(p.total,650000);assert.equal(p.bytes,2600044);
 assert.deepEqual(p.regions.map(r=>r.frames),[300000,300000,50000]);
 assert.deepEqual(p.regions.map(r=>r.preroll),[0,24000,24000]);
 assert.ok(p.regions.every(r=>r.renderFrames===r.frames+r.preroll));
 assert.equal(p.regions.map(r=>r.frames).reduce((a,b)=>a+b),p.total);
});
test('el plan valida duración y límites RIFF',()=>{
 for(const secs of [0,-1,NaN,Infinity])assert.throws(()=>render.plan(secs));
 assert.throws(()=>render.plan((render.MAX_WAV_FRAMES+2)/44100));
});
test('segmento PCM toma exactamente el tramo después del preroll',()=>{
 const buffer={numberOfChannels:2,length:4,getChannelData(c){return c===0?new Float32Array([.9,.7,-1,1]):new Float32Array([-.5,.5,0,-.5]);}};
 const pcm=render.pcmSegment(buffer,2,2);const v=new DataView(pcm.buffer);
 assert.deepEqual([v.getInt16(0,true),v.getInt16(2,true),v.getInt16(4,true),v.getInt16(6,true)],[-32768,0,32767,-16384]);
});
test('render multibloque continuo en fase sin saltos artificiales',async()=>{
 class FakeOffline{
  constructor(channels,frames,rate){this.channels=channels;this.frames=frames;this.rate=rate;this.offset=0;}
  async startRendering(){const rate=this.rate,offset=this.offset,n=this.frames;return {numberOfChannels:2,length:n,getChannelData(channel){const v=new Float32Array(n);for(let i=0;i<n;i++){const global=Math.round(offset*rate)+i;v[i]=channel===0?((global%200)/100-1):((global%500)/250-1);}return v;}};}
 }
 let segments=0;const progress=[];
 const {blob,frames}=await render.render({duration:5,rate:10000,blockSeconds:1.5,prerollSeconds:.2,Context:FakeOffline,
  schedule(ctx,offset){ctx.offset=offset;segments++;},onProgress:p=>progress.push(p),yieldUI:async()=>{}});
 assert.equal(segments,4);assert.equal(frames,50000);assert.equal(blob.size,44+50000*4);assert.equal(progress.at(-1),1);
 const b=await blob.arrayBuffer(),v=new DataView(b);
 assert.equal(String.fromCharCode(...new Uint8Array(b,0,4)),'RIFF');
 assert.equal(v.getUint32(40,true),50000*4);
 for(const i of [0,14999,15000,29999,30000,49999]){
  const value=(i%200)/100-1,expected=value<0?Math.round(value*32768):Math.round(value*32767);
  assert.equal(v.getInt16(44+4*i,true),expected,`muestra sin salto ${i}`);
 }
});
test('se puede cancelar un render largo sin generar un WAV parcial',async()=>{
 class FakeOffline{constructor(_,frames){this.frames=frames;}async startRendering(){return {numberOfChannels:2,length:this.frames,getChannelData(){return new Float32Array(this.frames);}};}}
 let count=0;
 await assert.rejects(()=>render.render({duration:9,rate:10000,blockSeconds:3,Context:FakeOffline,
  schedule(){},onProgress(){count++;},cancelled:()=>count>=1,yieldUI:async()=>{}}),/cancelada/i);
 assert.equal(count,1);
});
test('autosave v5 no repite media en cada edición y requiere recuperación explícita',()=>{
 const src=fromPath('assets/js/vs-mix-recovery-v5.js'),app=fromPath('assets/js/mix.js'),html=fromPath('index.html');
 assert.ok(src.includes('if(!old.has(a.id))'));assert.ok(src.includes("meta.put({savedAt,model,ids:[...ids]},'active')"));
 assert.ok(app.includes('async function recoverSession()'));assert.ok(app.includes('await dialog(\'Recuperar sesión de VSMix\''));
 assert.ok(app.includes('clearTimeout(S.recoveryTimer)'));assert.ok(html.includes('vs-mix-recovery-v5.js'));
});
test('cliente y servidor admiten WebM/Opus largo con tope local e input en streaming',()=>{
 const server=fromPath('serve.mjs'),client=fromPath('assets/js/vs-codecs.js');
 assert.ok(server.includes('MAX_INPUT=384*1024*1024'));
 assert.ok(server.includes('req.pipe(child.stdin)'));
 assert.ok(client.includes('file.size>384*1048576'));
 assert.ok(client.includes('AbortSignal.timeout(380000)'));
});
