import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));
const embed=path.resolve(here,'../modules/vspack/vs-model-studio/embed');
test('bridge abre Java JSON con ruta completa y entrega recursos del pack al codec original',async()=>{
 const received=[];let onMessage;
 const parent={postMessage(msg){received.push(msg)}};
 const opened=[];
 const codec={load(model,file,args){opened.push({model,file,args})}};
 const blockbench={setup_successful:true,version:'5.2.2',Project:null,on(){}};
 const w={parent,Blockbench:blockbench,Codecs:{project:{load(){}},java_block:codec},Formats:{},addEventListener(n,fn){if(n==='message')onMessage=fn}};
 const doc={addEventListener(){}};
 const context={window:w,document:doc,location:{search:'?vs_embed=1&vs_parent_origin=http%3A%2F%2F127.0.0.1%3A3060',origin:'http://127.0.0.1:3060'},
   URL,URLSearchParams,TextDecoder,setTimeout:()=>0,console,Array,Uint8Array};
 vm.runInNewContext(fs.readFileSync(path.join(embed,'bridge.js'),'utf8'),context);
 const src={protocol:'vs-model-studio/v1',type:'hello'};
 onMessage({source:parent,origin:'http://127.0.0.1:3060',data:src});
 assert.ok(received.some(x=>x.type==='ready'));
 const resources={
  'assets/demo/models/block/chair.json':'{"parent":"minecraft:block/cube_all"}',
  'assets/minecraft/models/block/cube_all.json':'{"elements":[]}',
  'assets/demo/textures/block/chair.png':'data:image/png;base64,aGVsbG8='
 };
 onMessage({source:parent,origin:'http://127.0.0.1:3060',data:{protocol:'vs-model-studio/v1',type:'request',id:1,command:'open',payload:{model:'{"parent":"minecraft:block/cube_all"}',name:'assets/demo/models/block/chair.json',resources}}});
 await new Promise(resolve=>setImmediate(resolve));
 assert.equal(opened.length,1);
 assert.equal(opened[0].file.path,'__vspack__/assets/demo/models/block/chair.json');
 assert.equal(opened[0].args.externalDataLoader('__vspack__/assets/minecraft/models/block/cube_all.json'),resources['assets/minecraft/models/block/cube_all.json']);
 assert.equal(opened[0].args.externalDataLoader('__vspack__/assets/demo/textures/block/chair.png'),resources['assets/demo/textures/block/chair.png']);
 assert.ok(received.some(x=>x.type==='response'&&x.ok));
});
test('guard de menús reabre el menú original si el clic se pierde, sin duplicar navegación',async()=>{
 const listeners={};let opened=0;let nativeOpen=false;
 const li={classList:{contains:()=>false},closest(sel){return sel==='li.menu_bar_point'?this:null},hasAttribute:()=>true,setAttribute(){}};
 const node={isConnected:false,style:{},getBoundingClientRect(){return {width:this.isConnected?140:0}},};
 const menu={label:li,node,open(){opened++;node.isConnected=true;},hide(){node.isConnected=false;}};
 const bar={addEventListener(name,fn){listeners[name]=fn},contains(el){return el===li},querySelectorAll(){return []}};
 const doc={getElementById(id){return id==='menu_bar'?bar:null},querySelectorAll(){return []},documentElement:{}};
 const ctx={window:{parent:{},VSModelMenuBar:{menus:{file:menu}}},document:doc,location:{search:'?vs_embed=1'},URLSearchParams,
  MutationObserver:class{observe(){}},getComputedStyle:()=>({display:'block'}),queueMicrotask,console};
 vm.runInNewContext(fs.readFileSync(path.join(embed,'menu-repair.js'),'utf8'),ctx);
 listeners.click({target:li});
 await new Promise(resolve=>setImmediate(resolve));
 assert.equal(opened,1);
 node.isConnected=true;opened=0;
 listeners.click({target:li});await new Promise(resolve=>setImmediate(resolve));
 assert.equal(opened,0,'no debe abrir un segundo menú cuando el nativo está visible');
});
