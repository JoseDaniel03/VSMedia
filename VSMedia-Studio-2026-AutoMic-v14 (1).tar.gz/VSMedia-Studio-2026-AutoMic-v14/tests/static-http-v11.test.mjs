import test from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createServer as createProbe} from 'node:net';
import {request} from 'node:http';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {brotliDecompressSync, gunzipSync} from 'node:zlib';

const root=resolve(import.meta.dirname,'..');
const asset='/modules/vspack/vs-model-studio/dist/bundle.js';
async function freePort(){return new Promise((ok,no)=>{const s=createProbe().once('error',no).listen(0,'127.0.0.1',()=>{const port=s.address().port;s.close(()=>ok(port));});});}
function fetchRaw(port,url,{method='GET',headers={}}={}){
 return new Promise((ok,no)=>{const req=request({hostname:'127.0.0.1',port,path:url,method,headers},r=>{const list=[];r.on('data',d=>list.push(d));r.on('end',()=>ok({status:r.statusCode,headers:r.headers,body:Buffer.concat(list)}));});req.on('error',no);req.end();});
}
async function ready(port){for(let n=0;n<40;n++){try {const r=await fetchRaw(port,'/');if(r.status===200)return;}catch{}await new Promise(ok=>setTimeout(ok,100));}throw Error('Servidor local no inició');}

test('v11 HTTP optimiza transferencia sin alterar recursos ni caché',async()=>{
 const port=await freePort();
 const child=spawn(process.execPath,['serve.mjs',String(port)],{cwd:root,stdio:'ignore'});
 try{
  await ready(port);
  const expected=await readFile(resolve(root,'.'+asset));
  const plain=await fetchRaw(port,asset);assert.equal(plain.status,200);assert.equal(Buffer.compare(plain.body,expected),0);
  const br=await fetchRaw(port,asset,{headers:{'Accept-Encoding':'br, gzip'}});
  assert.equal(br.status,200);assert.equal(br.headers['content-encoding'],'br');assert.deepEqual(brotliDecompressSync(br.body),expected);
  assert.ok(br.body.length < expected.length*0.5,'bundle should compress to less than half');
  const gzip=await fetchRaw(port,asset,{headers:{'Accept-Encoding':'br;q=0, gzip'}});
  assert.equal(gzip.headers['content-encoding'],'gzip');assert.deepEqual(gunzipSync(gzip.body),expected);
  assert.equal(br.headers.etag,plain.headers.etag);
  const cached=await fetchRaw(port,asset,{headers:{'If-None-Match':br.headers.etag,'Accept-Encoding':'br'}});
  assert.equal(cached.status,304);assert.equal(cached.body.length,0);
  const head=await fetchRaw(port,asset,{method:'HEAD',headers:{'Accept-Encoding':'br'}});
  assert.equal(head.status,200);assert.equal(head.body.length,0);
  const missing=await fetchRaw(port,'/no-existe.js');assert.equal(missing.status,404);
  const denied=await fetchRaw(port,'/%2e%2e/%2e%2e/etc/passwd');assert.notEqual(denied.status,200);
  const audio=await fetchRaw(port,'/api/audio/capabilities');assert.equal(audio.status,200);assert.equal(JSON.parse(audio.body).ok,true);
  console.log(`BUNDLE_BYTES original=${expected.length}, brotli=${br.body.length}, gzip=${gzip.body.length}`);
 }finally{child.kill();}
});
