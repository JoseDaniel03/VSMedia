import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
const read=p=>readFileSync(new URL('../'+p,import.meta.url),'utf8');
function app(filename,property){
  const window={VS:{},addEventListener(){}};
  const localStorage={getItem:()=>null,setItem(){}};
  const ctx={window,localStorage,crypto:{randomUUID:()=> 'test'},console};
  vm.runInNewContext(read(`assets/js/${filename}.js`),ctx,{filename});
  return window[property];
}
test('VSMix: regla adaptativa nunca se amontona al hacer zoom',()=>{
 const {rulerStep,rulerHtml}=app('mix','VSMixApp')._test;
 for(const pp of [.1,.2,.5,1,2,5,10,20,55,150,400]){
  const step=rulerStep(pp);
  assert.ok(step*pp>=84,`espaciado de ${step*pp}px a ${pp}px/s`);
  const html=rulerHtml(5000,pp);
  assert.ok((html.match(/class="ruler-tick"/g)||[]).length<=400);
 }
});
test('VSMix: bucle ignora regiones vacías o invertidas y acepta tiempos válidos',()=>{
 const {loopBounds}=app('mix','VSMixApp')._test;
 assert.equal(loopBounds({start:null,end:2}),null);
 assert.equal(loopBounds({start:9,end:4}),null);
 assert.equal(loopBounds({start:1,end:1.02}),null);
 assert.equal(loopBounds({start:-1,end:2}),null);
 const r=loopBounds({start:2.25,end:4.75});
 assert.equal(r.start,2.25);assert.equal(r.end,4.75);
});
test('VSMix: región se guarda, recupera y participa en el historial',()=>{
 const mix=read('assets/js/mix.js');
 assert.match(mix,/loopRegion:S\.loopRegion,assets:/);
 assert.match(mix,/loopRegion:S\.loopRegion\}/);
 assert.match(mix,/S\.loopRegion=v\.loopRegion\|\|/);
 assert.match(mix,/loopin.*loopout.*clearloop/);
 assert.match(mix,/function followHead\(/);
 assert.match(mix,/vsmedia-follow-mix-v4/);
});
test('VSAudio: intervalos de silencio cubren exactamente sus bordes, sin perder audio',()=>{
 const walk=app('simple','VSSimpleApp')._test.silenceWalker;
 const intervals=[[5,8],[2,3],[3,4],[7,9],[20,21],[30,29]];
 const expected=t=>intervals.some(([a,b])=>t>=Math.min(a,b)&&t<=Math.max(a,b));
 const forward=walk(intervals);
 for(let t=0;t<=35;t+=.05)assert.equal(forward(t),expected(t),`forward ${t}`);
 const reverse=walk(intervals,true);
 for(let t=35;t>=0;t-=.05)assert.equal(reverse(t),expected(t),`reverse ${t}`);
});
test('VSAudio: la búsqueda de silencios es monótona y se reinicia por canal',()=>{
 const simple=read('assets/js/simple.js');
 assert.ok(simple.includes('const target=out[c],isSilent=silenceWalker'));
 assert.ok(!simple.includes('o.silences.some('));
 assert.ok(simple.includes('followSimple();'));
 assert.ok(simple.includes('vsmedia-follow-simple-v4'));
});
test('VSRadio: usa índice de picos compartido para representar transitorios',()=>{
 const s=read('assets/js/radio.js');
 assert.match(s,/window\.VSPeaks\.forBuffer\(a\.buffer\)/);
 assert.ok(!s.includes('Math.floor(samples/24)'));
});
test('Home no cambia en v4 y hojas de estilos solo modifican módulos',()=>{
 const h=read('index.html'),css=read('assets/css/vs-fluid-edit-v4.css');
 assert.match(h,/assets\/css\/vs-fluid-edit-v4.css/);
 assert.doesNotMatch(css,/\#home|\.home-page/);
 assert.ok(!h.includes('vs-fluid-edit-v4.js'));
});
