const {test}=require('node:test'),assert=require('node:assert/strict');
const {checkPath,checkCaseCollisions,pngInfo}=require('../modules/vspack/assets/pack-quality.js');
test('accepts valid Minecraft resource paths',()=>assert.deepEqual(checkPath('assets/minecraft/textures/block/stone.png'),[]));
test('rejects traversal and invalid namespace',()=>{
 assert.ok(checkPath('../pack.mcmeta').some(x=>x.level==='error'));
 assert.ok(checkPath('assets/MyPack/textures/a.png').some(x=>x.title==='Namespace inválido'));
 assert.ok(checkPath('assets/test/textures/BadName.png').some(x=>x.title==='Ruta de recurso no estándar'));
});
test('detect case-insensitive collisions without false positives for matching names',()=>{
 const r=checkCaseCollisions(['assets/test/a.png','assets/test/A.png','assets/test/a.png']);assert.equal(r.length,1);
});
test('validates PNG signature and dimensions without decoding compressed pixels',()=>{
 const png=new Uint8Array(24);png.set([137,80,78,71,13,10,26,10],0);png.set([73,72,68,82],12);
 new DataView(png.buffer).setUint32(16,16);new DataView(png.buffer).setUint32(20,32);
 assert.deepEqual(pngInfo(png),{valid:true,width:16,height:32,warnings:[]});
 png[0]=4;assert.equal(pngInfo(png).valid,false);
});
