import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
const {indexChannel}=require('../assets/js/dsp-peaks.js');
import {reducePalette,quantizeRGBA,paletteFromPixels,posterizeRGBA,alphaContentBounds} from '../modules/vspack/pixel-studio/web/color-math.mjs';
import {PixelEngine} from '../modules/vspack/pixel-studio/web/fallback.mjs';

const close=(a,b,e=1e-6)=>assert.ok(Math.abs(a-b)<e,`${a} ≠ ${b}`);
const seed=()=>{let x=0x1dad5;return()=>{x^=x<<13;x^=x>>>17;x^=x<<5;return(x>>>0)/4294967296;};};
test('segment tree captures exact positive/negative transients in any range',()=>{
 const rnd=seed();
 for(const n of [1,2,127,128,129,255,256,257,777,131071]){
  const data=Float32Array.from({length:n},()=>rnd()*2-1);
  if(n>3){data[3]=-1;data[n-1]=1;}
  const tree=indexChannel(data);
  for(let k=0;k<90;k++){
    const lo=Math.floor(rnd()*n),hi=Math.min(n,lo+1+Math.floor(rnd()*(n-lo)));
    const exact=data.subarray(lo,hi);
    let min=Infinity,max=-Infinity,sum=0;for(const v of exact){min=Math.min(min,v);max=Math.max(max,v);sum+=v*v;}
    const [a,b]=tree.range(lo,hi);close(a,min);close(b,max);close(tree.rms(lo,hi),Math.sqrt(sum/exact.length));
  }
 }
});
test('large zoom-out cannot lose one-sample impulse',()=>{
 const signal=new Float32Array(3_000_000);signal[1_234_567]=-1;
 const idx=indexChannel(signal);
 assert.deepEqual(idx.range(0,signal.length),[-1,0]);
 close(idx.rms(0,signal.length),Math.sqrt(1/signal.length));
});
test('palette reduction deterministic, preserves all alpha and source bytes',()=>{
 const w=64,h=64,rnd=seed(),src=new Uint8ClampedArray(w*h*4);
 for(let i=0;i<src.length;i+=4){src[i]=rnd()*255;src[i+1]=rnd()*255;src[i+2]=rnd()*255;src[i+3]=i%12===0?0:i%7===0?64:255;}
 const snapshot=new Uint8ClampedArray(src);
 for(const dither of [false,true]){
  const {palette,pixels}=reducePalette(src,w,h,12,{dither});
  assert.ok(palette.length<=12&&palette.length>0);assert.equal(pixels.length,src.length);
  const colors=new Set();for(let i=0;i<src.length;i+=4){assert.equal(pixels[i+3],src[i+3]);if(src[i+3]>0)colors.add([pixels[i],pixels[i+1],pixels[i+2]].join(','));}
  assert.ok(colors.size<=palette.length);
 }
 assert.deepEqual(src,snapshot);
 const a=paletteFromPixels(src,w,h,8),b=paletteFromPixels(src,w,h,8);assert.deepEqual(a,b);
});
test('region restriction cannot write outside selected image area',()=>{
 const src=new Uint8ClampedArray([20,20,20,255,90,90,90,255,170,170,170,255,250,250,250,255]);
 const after=quantizeRGBA(src,4,1,[[0,0,0],[255,255,255]],{region:[1,0,2,0],dither:true});
 assert.deepEqual([...after.slice(0,4)],[...src.slice(0,4)]);
 assert.deepEqual([...after.slice(12)],[...src.slice(12)]);
});
test('posterize preserves alpha and trim searches all animation frames',()=>{
 const src=new Uint8ClampedArray([120,60,90,0,160,40,170,125]);
 const a=posterizeRGBA(src,2,1,2);
 assert.deepEqual([...a.slice(0,4)],[...src.slice(0,4)]);assert.equal(a[7],125);
 const x=new Uint8ClampedArray(4*4*4),y=new Uint8ClampedArray(x);x[(1*4+2)*4+3]=255;y[(3*4+0)*4+3]=255;
 assert.deepEqual(alphaContentBounds([{cels:[x]},{cels:[y]}],4,4),[0,1,2,3]);
 assert.equal(alphaContentBounds([{cels:[new Uint8ClampedArray(x.length)]}],4,4),null);
});
test('pixel engine can reuse output buffer; undo and redo remain correct',()=>{
 const e=new PixelEngine(16,16),dest=new Uint8ClampedArray(16*16*4);
 e.transaction(()=>e.pixel(5,8,0xff112233));
 assert.deepEqual(e.render(0,dest),e.render(0));
 const snapshot=new Uint8ClampedArray(dest);
 e.transaction(()=>e.pixel(5,8,0xff445566));
 assert.equal(e.undo(),true);assert.deepEqual(e.render(0),snapshot);
 assert.equal(e.redo(),true);assert.notDeepEqual(e.render(0),snapshot);
 e.render(0,dest);assert.deepEqual(dest,e.render());
});
