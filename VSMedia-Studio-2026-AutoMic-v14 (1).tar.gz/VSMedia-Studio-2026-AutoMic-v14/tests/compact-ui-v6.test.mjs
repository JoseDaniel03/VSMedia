import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const load = name=>fs.readFileSync(new URL('../'+name, import.meta.url),'utf8');
const ui=load('assets/js/vs-compact-ui-v6.js');
const core=load('assets/js/core.js');
const html=load('index.html');
const css=load('assets/css/vs-compact-ui-v6.css');
test('El Home conserva su código y estilos previos',()=>{
 assert.match(html,/<section class="home-hero">/);
 assert.match(html,/<div class="home-cards">/);
 assert.doesNotMatch(css,/#home/);
});
test('La navegación usa un solo menú en lugar de botones inyectados repetidos',()=>{
 assert.match(core,/window\.VSCompactUI\?\.init\(\)/);
 assert.doesNotMatch(core,/bs-header-shortcut/);
 assert.match(ui,/function nav\(page\)/);
 for(const id of ['simple','mix','radio','voice','soundboard','vspack'])assert.ok(ui.includes(`'${id}'`));
});
test('Acciones esenciales siguen presentes en los controladores originales',()=>{
 assert.match(load('assets/js/simple.js'),/data-simple="export"/);
 assert.match(load('assets/js/simple.js'),/data-simple="import"/);
 assert.match(load('assets/js/mix.js'),/data-a="saveproject"/);
 assert.match(load('assets/js/mix.js'),/data-a="export"/);
 assert.match(load('assets/js/radio.js'),/data-radio="savestation"/);
 assert.match(load('assets/js/radio.js'),/data-radio="djnext"/);
});
test('Los controles trasladados conservan los mismos nodos y eventos',()=>{
 assert.match(ui,/content\.append\(el\)/);
 assert.match(ui,/content\.append\(btn\)/);
 assert.match(ui,/toolbarMenu\(page,'Archivo'/);
});
test('No se oculta el único control de importación cuando el editor está en enfoque',()=>{
 assert.match(ui,/page\.classList\.contains\('vs-hide-library'\)/);
 assert.match(ui,/top\.hidden=!topVisible;side\.hidden=topVisible/);
});
test('Accesibilidad de menús compactos',()=>{
 assert.match(ui,/e\.key==='Escape'/);
 assert.match(ui,/ArrowDown/);
 assert.match(ui,/summary\.focus\(\)/);
 assert.match(css,/:focus-visible/);
 assert.match(css,/:not\(\[open\]\)/);
});
test('Se reduce duplicación de Zoom, Importar y Recortar sin borrar funciones',()=>{
 assert.ok(ui.includes('.timeline-top [data-a=\"zoomfit\"]'));
 assert.ok(ui.includes('.audio-lib-tools [data-a=\"import\"]'));
 assert.ok(ui.includes('.simple-library .simple-tips [data-simple=\"crop\"]'));
});
