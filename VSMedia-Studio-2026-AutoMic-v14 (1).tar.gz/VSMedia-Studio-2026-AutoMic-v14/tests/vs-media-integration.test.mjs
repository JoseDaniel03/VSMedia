import test from 'node:test';import assert from 'node:assert/strict';
import {spawn,spawnSync} from 'node:child_process';
import {readFile} from 'node:fs/promises';
import {PRESETS,ffmpegArgs} from '../serve.mjs';
import {webcrypto} from 'node:crypto';
import vm from 'node:vm';
import {setTimeout as sleep} from 'node:timers/promises';
const hasFfmpeg=spawnSync('ffmpeg',['-version'],{stdio:'ignore'}).status===0;
const executable=process.execPath;
test('Perfiles compatibles con Opus / Vorbis y comandos cerrados',()=>{
 assert.equal(Object.keys(PRESETS).length,10);
 for(const [name,p] of Object.entries(PRESETS)){const args=ffmpegArgs(name);assert.ok(args.includes(p.codec));assert.equal(args.at(-1),'pipe:1');assert.ok(args.includes('-protocol_whitelist'));}
 assert.throws(()=>ffmpegArgs('malicioso'),/Preset/);
 assert.ok(ffmpegArgs('voice-32',true).includes('loudnorm=I=-16:TP=-1.5:LRA=11'));
});
test('Motor de voz conserva parámetros y perfiles adicionales',async()=>{
 const src=await readFile(new URL('../assets/js/voice-engine.js',import.meta.url),'utf8');
 const window={};const c={window,Float32Array,Number,Math};vm.runInNewContext(src,c);
 assert.ok(window.VSMic.profiles.robot);assert.ok(window.VSMic.profiles.oldradio);
 assert.equal(window.VSMic._test.clamp(-100,0,100),0);assert.equal(window.VSMic._test.clamp(123,0,100),100);
 assert.ok(Math.abs(window.VSMic._test.curve(0)[512]-(512*2/1023-1))<1e-5);
});
test('Manifest contiene alcance, contexto de minijuego y recursos',async()=>{
 const src=await readFile(new URL('../assets/js/vs-soundboard.js',import.meta.url),'utf8');
 const a={id:'01234567',name:'Alarma.wav',kind:'audio',blob:new Blob([Buffer.from('wav')]),size:3};
 const window={VS:{escape:x=>String(x),toast:()=>{}},VSMediaLibrary:{all:async()=>[a]}};
 const localStorage={setItem:()=>{},getItem:()=>null};const crypto={randomUUID:()=>`id${Math.random()}`};
 vm.runInNewContext(src,{window,localStorage,crypto,Math,Number,JSON,document:{},Blob});
 assert.equal(await window.VSSoundboard.addAsset(a.id,a.name),true);
 const manifest=window.VSSoundboard._test.describeBank([{id:a.id,name:a.name,path:'audio/01234567.opus',codec:'opus'}]);
 assert.equal(manifest.format,'vsmedia.soundbank');assert.equal(manifest.schema,1);
 assert.equal(manifest.slots.length,1);assert.equal(manifest.slots[0].scope,'nearby');
 assert.equal(manifest.slots[0].context.minigameId,'global');assert.equal(manifest.slots[0].trigger.type,'manual');
 assert.equal(manifest.assets.length,1);
});
test('ZIP de banco conserva contenido y SHA-256 sin servidor',async()=>{
 const src=await readFile(new URL('../assets/js/zip.js',import.meta.url),'utf8');const window={};
 vm.runInNewContext(src,{window,TextEncoder,TextDecoder,Blob,Uint8Array,Uint32Array,ArrayBuffer,DataView,Response,Math});
 const audio=new Uint8Array([79,103,103,83,0,1,2,3]);const hash=Buffer.from(await webcrypto.subtle.digest('SHA-256',audio)).toString('hex');
 const b=window.VSZip.write({'bank.json':new TextEncoder().encode(JSON.stringify({schema:1,sha256:hash})),'audio/one.opus':audio});
 const d=await window.VSZip.read(b);assert.deepEqual(Array.from(d.get('audio/one.opus')),Array.from(audio));assert.equal(JSON.parse(new TextDecoder().decode(d.get('bank.json'))).sha256,hash);
 assert.throws(()=>window.VSZip.write({'../bad':audio}),/Ruta/);
});
test('Conversión local real: Opus 48 kHz mono, Vorbis 44.1 kHz estéreo, y cabecera anti-CSRF', {skip:!hasFfmpeg},async()=>{
 const port=38000+Math.floor(Math.random()*3000);
 const child=spawn(executable,['serve.mjs',String(port)],{cwd:new URL('..',import.meta.url).pathname,stdio:['ignore','pipe','pipe']});
 try{
  let live=false;for(let i=0;i<45;i++){if(child.exitCode!==null)throw Error('Servidor falló al iniciar');await sleep(80);try{const res=await fetch(`http://127.0.0.1:${port}/api/audio/capabilities`);live=res.ok;if(live)break;}catch{}}
  assert.ok(live,'El servidor local no arrancó');
  const wav=spawnSync('ffmpeg',['-loglevel','error','-f','lavfi','-i','sine=frequency=440:duration=0.25','-f','wav','pipe:1'],{encoding:null,maxBuffer:2*1024*1024});assert.equal(wav.status,0);
  for(const [preset,codec,channels,sampleRate] of [['voice-32','opus',1,48000],['mc-music','vorbis',2,44100],['webm-radio-96','opus',2,48000]]){
   const response=await fetch(`http://127.0.0.1:${port}/api/audio/convert?preset=${preset}`,{method:'POST',headers:{'X-VSMedia-Local':'1','Content-Type':'application/octet-stream'},body:wav.stdout});if(response.status!==200)throw Error('HTTP '+response.status+' '+await response.text());
   const output=Buffer.from(await response.arrayBuffer());assert.ok(output.length>300);assert.equal(output.subarray(0,4).toString('hex'),preset.startsWith('webm')?'1a45dfa3':'4f676753');assert.equal(response.headers.get('content-type'),preset.startsWith('webm')?'audio/webm':'audio/ogg');
   const probe=spawnSync('ffprobe',['-v','error','-show_entries','stream=codec_name,channels,sample_rate','-of','json','pipe:0'],{input:output,encoding:'utf8'});assert.equal(probe.status,0);const info=JSON.parse(probe.stdout).streams[0];assert.equal(info.codec_name,codec);assert.equal(info.channels,channels);assert.equal(Number(info.sample_rate),sampleRate);
  }
  const rejection=await fetch(`http://127.0.0.1:${port}/api/audio/convert?preset=voice-32`,{method:'POST',body:wav.stdout});assert.equal(rejection.status,403);
 }finally{child.kill('SIGTERM');}
});
