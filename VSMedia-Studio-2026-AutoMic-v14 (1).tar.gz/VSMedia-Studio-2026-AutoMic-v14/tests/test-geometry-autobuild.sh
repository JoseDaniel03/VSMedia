#!/usr/bin/env bash
# Prueba aislada: comprueba la sintaxis del comando de wasm-pack y el caché.
# No descarga paquetes, no ejecuta cargo, no modifica la instalación real.
set -Eeuo pipefail
PROJECT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf -- "$TMP"' EXIT
P="$TMP/project"
BIN="$TMP/mock-bin"
MODEL="$P/modules/vspack/vs-model-studio"
mkdir -p "$P/scripts" "$P/modules/vspack/pixel-studio/web" \
  "$MODEL/crates/vs_model_core" "$MODEL/embed" "$MODEL/dist" "$BIN"
cp "$PROJECT/scripts/build-all.sh" "$P/scripts/build-all.sh"
printf 'bundle' > "$MODEL/dist/bundle.js"
printf 'pixel' > "$P/modules/vspack/pixel-studio/web/vsmedia-kernels.wasm"
cat > "$BIN/node" <<'MOCK'
#!/bin/bash
[[ "${1:-}" == '-p' ]] && { echo 26; exit 0; }
exit 0
MOCK
cat > "$BIN/npm" <<'MOCK'
#!/bin/bash
exit 0
MOCK
cat > "$BIN/cargo" <<'MOCK'
#!/bin/bash
echo "Unexpected cargo $*" >&2
exit 66
MOCK
cat > "$BIN/rustc" <<'MOCK'
#!/bin/bash
while (( $# )); do
  if [[ "$1" == '-o' ]]; then shift; printf 'binary' > "$1"; exit 0; fi
  shift
done
exit 71
MOCK
cat > "$BIN/rustup" <<'MOCK'
#!/bin/bash
[[ "${1:-}" == target && "${2:-}" == list ]] && echo wasm32-unknown-unknown
exit 0
MOCK
cat > "$BIN/wasm-pack" <<'MOCK'
#!/bin/bash
set -euo pipefail
printf '%s\n' "$*" >> "$VSMEDIA_MOCK_LOG"
[[ $# == 9 ]] || { echo "Wrong argument count: $#" >&2; exit 73; }
[[ "$1" == build && "$2" == --release && "$3" == --target && "$4" == web \
 && "$5" == --out-dir && "$6" == ../../wasm && "$7" == -- \
 && "$8" == --features && "$9" == wasm ]] || { echo "Wrong wasm-pack argument sequence: $*" >&2; exit 74; }
mkdir -p -- ../../wasm
printf 'js' > ../../wasm/vs_model_core.js
printf 'wasm' > ../../wasm/vs_model_core_bg.wasm
MOCK
chmod +x "$BIN"/*
export PATH="$BIN:$PATH" VSMEDIA_NO_SETUP=1 VSMEDIA_MOCK_LOG="$TMP/wasm.log"
(cd "$P" && bash scripts/build-all.sh > "$TMP/build-1.log")
[[ -s "$MODEL/wasm/vs_model_core.js" && -s "$MODEL/wasm/vs_model_core_bg.wasm" ]] || {
  echo 'No se generaron JS + WASM' >&2; exit 1;
}
[[ -s "$MODEL/bin/vs_model_server" ]] || { echo 'No se generó servidor nativo' >&2; exit 1; }
[[ $(wc -l < "$TMP/wasm.log") -eq 1 ]] || { echo 'wasm-pack no ejecutado exactamente una vez' >&2; exit 1; }
(cd "$P" && bash scripts/build-all.sh > "$TMP/build-2.log")
[[ $(wc -l < "$TMP/wasm.log") -eq 1 ]] || { echo 'wasm-pack recompiló sin cambios' >&2; exit 1; }
grep -q 'Rust/WASM geométrico actualizado; no se recompila' "$TMP/build-2.log"
# A missing WASM invalidates the cache and requires a new build.
rm "$MODEL/wasm/vs_model_core_bg.wasm"
(cd "$P" && bash scripts/build-all.sh > "$TMP/build-3.log")
[[ $(wc -l < "$TMP/wasm.log") -eq 2 ]] || { echo 'No se reconstruyó el WASM faltante' >&2; exit 1; }
echo '[OK] argumento de wasm-pack, salidas JS/WASM, cache y regeneración probados.'
