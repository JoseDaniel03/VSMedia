import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const load = path => fs.readFileSync(new URL('../'+path,import.meta.url),'utf8');
const simple=load('assets/js/simple.js'),mix=load('assets/js/mix.js'),radio=load('assets/js/radio.js'),ui=load('assets/js/vs-compact-ui-v6.js');
test('Simple tiene un único menú Archivo nativo y exportación WebM accesible',()=>{
 assert.equal((simple.match(/label:'Archivo'/g)||[]).length,1);
 assert.match(simple,/label:'Exportar WebM\/Opus \(Chrome\)',action:'exportwebm'/);
 assert.match(ui,/page\.querySelector\('\.work-header \[data-simple="open"\]'\)\?\.remove\(\)/);
 assert.match(ui,/page\.querySelector\('\.work-header \[data-simple="exportwebm"\]'\)\?\.remove\(\)/);
});
test('VSMix no inyecta un segundo Archivo ni pierde acciones de exportación',()=>{
 assert.equal((mix.match(/label:'Archivo'/g)||[]).length,1);
 assert.match(mix,/label:'Exportar WebM\/Opus para Chrome…',action:'exportwebm'/);
 assert.match(ui,/page\.querySelector\('\.work-header \[data-a="exportwebm"\]'\)\?\.remove\(\)/);
 assert.doesNotMatch(ui,/toolbarMenu\(page,'Archivo', \['\.work-header \[data-a/);
});
test('La función única de Archivo solo se usa en VSRadio, que no tiene menú nativo',()=>{
 assert.equal((ui.match(/toolbarMenu\(page,'Archivo'/g)||[]).length,1);
 assert.match(ui,/function simplifyRadio\(page\)/);
 assert.doesNotMatch(radio,/window\.VS\.menu\(/);
});
test('El inspector deja de duplicar acciones que permanecen en Editar y timeline',()=>{
 assert.doesNotMatch(mix,/<button class="panel-btn" data-a="split">✂ Dividir<\/button>/);
 for (const command of ['split','duplicateclip','normalizeclip','deleteclip']) {
   assert.match(mix,new RegExp(`action:'${command}'`));
   assert.match(mix,new RegExp(`data-a="${command}"`));
 }
});
