import {createRequire} from 'node:module';
const require=createRequire(import.meta.url),{indexChannel}=require('../assets/js/dsp-peaks.js');
const n=2_000_000,cols=1800,passes=15;
const signal=Float32Array.from({length:n},(_,i)=>Math.sin(i*.01)*Math.sin(i*.00037));signal[1234567]=1;
const query=(index)=>{let total=0;for(let j=0;j<passes;j++)for(let i=0;i<cols;i++){
 const from=Math.floor(i*n/cols),to=Math.floor((i+1)*n/cols);
 const [a,b]=index.range(from,to);total+=b-a;
}return total;};
const brute=()=>{let total=0;for(let j=0;j<passes;j++)for(let i=0;i<cols;i++){
 const from=Math.floor(i*n/cols),to=Math.floor((i+1)*n/cols);let lo=Infinity,hi=-Infinity;
 for(let k=from;k<to;k++){const v=signal[k];if(v<lo)lo=v;if(v>hi)hi=v;}
 total+=hi-lo;
}return total;};
const t0=performance.now(),index=indexChannel(signal),t1=performance.now();
const indexed=query(index),t2=performance.now();const original=brute(),t3=performance.now();
if(Math.abs(original-indexed)>1e-6)throw Error(`Peak result mismatch ${original} vs ${indexed}`);
console.log(JSON.stringify({samples:n,columns:cols,passes,build_ms:+(t1-t0).toFixed(1),indexed_ms:+(t2-t1).toFixed(1),brute_exact_ms:+(t3-t2).toFixed(1),speedup_query:+((t3-t2)/(t2-t1)).toFixed(2)},null,2));
