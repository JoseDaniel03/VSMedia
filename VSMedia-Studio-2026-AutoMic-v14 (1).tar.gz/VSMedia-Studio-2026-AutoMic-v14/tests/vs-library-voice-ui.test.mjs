import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const read=file=>fs.readFileSync(new URL('../'+file,import.meta.url),'utf8');
function loadLibrary(){const win={VS:{escape:x=>String(x),toast:()=>{},download:()=>{}},console};const context={window:win,console,crypto:{randomUUID:()=>String(Math.random())},File,Map,Date,Math};vm.runInNewContext(read('assets/js/media-library.js'),context);return win.VSMediaLibrary;}
test('Biblioteca antigua reconoce proyecto Audio, Mix, Radio y archivos de música',()=>{
 const lib=loadLibrary();assert.equal(lib._test.classify('sesion.vsmedia'),'mix');assert.equal(lib._test.classify('voz.vssimple'),'simple');assert.equal(lib._test.classify('estacion.vsradio'),'radio');assert.equal(lib._test.classify('track.wav'),'audio');
});
test('Biblioteca guarda una vez los mismos archivos locales e identifica sus metadatos',async()=>{
 const lib=loadLibrary();const file=new File([Uint8Array.of(1,2,3)],'Cancion.wav',{type:'audio/wav',lastModified:171100000});const a=await lib.addFile(file,'mix');const b=await lib.addFile(file,'radio');assert.equal(a.id,b.id);assert.equal((await lib.all()).length,1);assert.equal(a.kind,'audio');
});
test('Voice Engine ofrece perfiles de EQ y voz sin usar servicios externos',()=>{
 const ctx={window:{VS:{}},document:{querySelectorAll:()=>[]},localStorage:{_state:{},getItem(k){return this._state[k]??null;},setItem(k,v){this._state[k]=v;}}};vm.runInNewContext(read('assets/js/voice-engine.js'),ctx);const mic=ctx.window.VSMic;assert.ok(mic.profiles.clean);assert.ok(mic.profiles.studio);assert.ok(mic.profiles.telephone);mic.setPreset('studio');assert.equal(mic.preset(),'studio');assert.match(mic.controls(),/MICRÓFONO/);assert.ok(mic.profiles.auto);
});
test('Pixel Studio incluye paletas y seguimiento de punto HSV',()=>{
 const source=read('modules/vspack/pixel-studio/web/vs-pixel-studio.mjs');assert.match(source,/picker-indicator/);assert.match(source,/setPointerCapture/);assert.match(source,/syncPicker\(\)/);for(const word of ['pico8','dawn','grayscale','pastel','minecraft'])assert.ok(source.includes(word));
});
test('La integración no vuelve a pedir permisos no soportados de iframe',()=>{
 const source=read('assets/js/vspack.js');assert.doesNotMatch(source,/clipboard-read|clipboard-write/);assert.match(source,/allow="fullscreen"/);
});
