import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, statSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const bb=resolve(root,'modules/vspack/vs-model-studio');
test('compiled Blockbench 5.x bundle is shipped',()=>{
 const file=resolve(bb,'dist/bundle.js');
 assert.ok(statSync(file).size>4_000_000,'El bundle compilado no está incluido');
 assert.ok(readFileSync(file,'utf8').includes('Blockbench'),'El bundle no parece contener la aplicación');
});
test('original Blockbench document loads compiled bundle and embed bridge',()=>{
 const html=readFileSync(resolve(bb,'index.html'),'utf8');
 assert.match(html,/src="dist\/bundle\.js"/);
 assert.match(html,/src="embed\/bridge\.js"/);
});
test('VSPack mounts the compiled editor via original component',()=>{
 const mod=readFileSync(resolve(root,'modules/vspack/assets/model-native.mjs'),'utf8');
 assert.match(mod,/dist\/bundle\.js/);
 assert.match(mod,/vs-model-studio/);
 assert.match(mod,/mountModelStudio/);
});
