const {test}=require('node:test');
const assert=require('node:assert/strict');
const {checkPackMeta,inspectEntries}=require('../modules/vspack/assets/pack-quality.js');
const enc=new TextEncoder();
const png=new Uint8Array(24);png.set([137,80,78,71,13,10,26,10],0);png.set([73,72,68,82],12);new DataView(png.buffer).setUint32(16,16);new DataView(png.buffer).setUint32(20,16);
test('validates pack mcmeta without guessing a Minecraft version',()=>{
 assert.deepEqual(checkPackMeta({pack:{pack_format:22,description:'Mi pack'}}),[]);
 assert.deepEqual(checkPackMeta({pack:{min_format:15,max_format:30,description:{text:'Mi pack'}}}),[]);
 assert.ok(checkPackMeta({pack:{description:''}}).some(x=>x.level==='error'));
 assert.ok(checkPackMeta({pack:{pack_format:-2,description:'Mi pack'}}).some(x=>x.title==='pack_format inválido'));
});
test('detects invalid PNG and malformed model JSON during publication, not just diagnostics',()=>{
 const issues=inspectEntries([
  {path:'pack.mcmeta',bytes:enc.encode('{"pack":{"pack_format":22,"description":"Perfecto"}}')},
  {path:'assets/demo/models/block/chair.json',bytes:enc.encode('{not json}')},
  {path:'assets/demo/textures/item/chair.png',bytes:new Uint8Array([1,2,3])},
  {path:'assets/demo/textures/item/Chair.png',bytes:png}
 ]);
 assert.ok(issues.some(x=>x.title==='JSON inválido'&&x.path.includes('chair.json')));
 assert.ok(issues.some(x=>x.title==='PNG inválido'&&x.path.endsWith('chair.png')));
 assert.ok(issues.some(x=>x.title==='Colisión por mayúsculas'));
 assert.ok(issues.some(x=>x.title==='Ruta de recurso no estándar'));
});
test('rejects duplicate paths and records missing bytes without losing path',()=>{
 const issues=inspectEntries([{path:'pack.mcmeta',bytes:null},{path:'pack.mcmeta',bytes:enc.encode('{}')}]);
 assert.ok(issues.some(x=>x.title==='Ruta duplicada'));
 assert.ok(issues.some(x=>x.title==='Archivo ausente'&&x.path==='pack.mcmeta'));
});
