# VSMedia Studio — VSMix, Mesa DJ y WebM/Opus (09/11/2026)

## VSMix: edición y movimiento en el timeline

- Contenedores y controles de pistas mejorados: controles fijos mientras se desplaza horizontalmente la línea de tiempo, tamaños mínimos y ajustes responsivos que reducen el corte de botones y medidores.
- Navegación con rueda: **Shift + rueda** desplaza horizontalmente; **Ctrl/Alt + rueda** acerca o aleja alrededor del puntero; **botón central** permite arrastrar el área de tiempo.
- Ajuste de zoom a la posición observada, controles de acercar/alejar, marcadores y ajuste magnético de clips conservados.
- Mezclador real por pista: volumen, panorámica, ecualizador de tres bandas, compresión y envío a eco. El máster incluye ganancia y limitador. Los cambios se utilizan durante la escucha y el renderizado offline.
- Consola de pistas plegable, para disponer de más altura para el timeline.
- Exportación de la mezcla a **WAV** o **WebM/Opus** (Chrome/Chromium). Esta última utiliza el servidor Node local + FFmpeg instalado.
- Proyecto `.vsmedia` guarda también la ganancia máster. Carga compatible con proyectos anteriores que no tienen este campo.

## VSAudio Simple

- Se pausa al cambiar a otra sección; conserva el cursor y no continúa en segundo plano.
- Exportación de audio editado a **WebM/Opus** mediante el conversor local; WAV permanece disponible.

## VSRadio: operación de DJ

- Decks **A/B** con volumen, graves y agudos independientes.
- Crossfade automático de potencia constante: inicia el audio siguiente **antes del final** de la pista actual. Duración ajustable entre 1 y 20 segundos; también existe el botón manual «Mezclar siguiente».
- Opción de atenuar la música al abrir el micrófono.
- Guardado y recuperación de configuración DJ, duración de transición y ecualización de los decks en proyectos de estación.
- Si se oculta el navegador o se sale de VSRadio, detiene la reproducción y la transición activa. No se reanuda sola al regresar.

## Reproducción en toda la aplicación

- Al cambiar de sección o minimizar/ocultar la pestaña se ejecuta una pausa global de Simple, VSMix, VSRadio, Voice Studio y Soundboard. No quedan grabadores ni sonidos ocultos intencionalmente activos.
- No se reanuda audio automáticamente al volver. En sistemas donde el navegador suspenda la página o se cierre abruptamente, prevalecen sus límites de ejecución.

## Formatos de salida

- **WebM/Opus** para reproducción eficiente en Chrome/Chromium; perfiles de voz, radio y música (FFmpeg local).
- **OGG/Opus**, **OGG/Vorbis** y **WAV** continúan disponibles cuando corresponda.
- La exportación comprimida necesita `ffmpeg` y ejecutar la aplicación mediante `./start.sh` con servidor Node. No usa servicios externos para convertir.
- La compatibilidad de decodificación de cada archivo depende del navegador y del códec disponible.

## Verificación

- `node --test tests/*.test.mjs tests/*.test.cjs`: **61 pruebas aprobadas, 0 errores**.
- `node --check` para todos los scripts de la aplicación y `serve.mjs`: sin errores de sintaxis.
- Conversión real de audio a WebM/Opus y comprobación de cabecera y códec en el test de integración.
- Pruebas visuales en Chromium mediante HTML/JS/CSS embebidos (por política de bloqueo de `localhost` en el entorno): reproducción de dos WAV, pausa de VSMix al salir, crossfade A→B solapado y detención de VSRadio al ocultar la pestaña.
- No se ha comprobado todavía la grabación con micrófono físico ni el comportamiento en Firefox/CachyOS del usuario; no se ha modificado el plugin Minecraft ni GitHub.
