#!/usr/bin/env sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
node --check modules/vspack/assets/app.js
node --check modules/vspack/assets/model-native.mjs
node --check modules/vspack/assets/model-resource-import.mjs
node --check modules/vspack/vs-model-studio/dist/bundle.js
node --check modules/vspack/vs-model-studio/embed/bridge.js
node --check modules/vspack/vs-model-studio/embed/component.js
node --check modules/vspack/vs-model-studio/embed/menu-repair.js
node --test tests/blockbench-resource-import.test.mjs tests/blockbench-bridge-ui.test.mjs
node --test tests/blockbench-build.test.mjs
node modules/vspack/test-compositor.mjs
echo 'Blockbench / VSPack: comprobaciones locales completadas.'
