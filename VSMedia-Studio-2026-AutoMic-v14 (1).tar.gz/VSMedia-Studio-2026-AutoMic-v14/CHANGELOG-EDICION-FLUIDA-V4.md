# VSMedia Studio — Edición fluida v4

**Base:** Workspace & Quality v3. Los módulos existentes, Home, Blockbench compilado y scripts de AutoBuild se conservan.

## VSMix

- Bucle A/B definido por puntos de entrada y salida del cursor: **I** marca A, **O** marca B y **L** activa el bucle. Se puede limpiar desde Reproducción.
- Reproducción desde la región cuando el cursor está fuera; retorno al inicio A al pasar B. Se detiene realmente el grafo anterior antes de volver a programarlo.
- La región se visualiza en el timeline, se incluye en deshacer/rehacer y se guarda/restaura en proyectos `.vsmedia` sin romper proyectos antiguos.
- **⌖ Seguir:** desplazamiento automático cuando el cabezal se sale del área visible, con opción de apagarlo para editar otra zona mientras se escucha. Preferencia local persistente.
- Marcas de tiempo de la regla adaptativas según el zoom; evita etiquetas amontonadas en sesiones largas.
- El botón de bucle indica su estado con `aria-pressed` y color, sin crear otra barra inferior.

## VSAudio Simple

- **⌖ Seguir** para acompañar el cabezal al reproducir audios ampliados. Desactivación y preferencia local.
- Optimización del procesamiento de silencios: ordena y fusiona intervalos y después recorre las muestras en tiempo lineal. Soporta reproducción invertida. Antes buscaba toda la lista para cada muestra, multiplicando el trabajo.

## VSRadio

- Forma de onda A/B con picos exactos en mono o estéreo: reutiliza el índice de picos compartido. A diferencia del antiguo muestreo disperso, los transitorios breves no desaparecen al cambiar el ancho del deck.

## Ejecución y pruebas

`./start.sh` inicia VSMedia con su compilador incremental. `bash verify-fluid-v4.sh` ejecuta las regresiones existentes y las nuevas.

Limitaciones: La exportación de mezclas sigue con el límite explícito de 15 minutos de v3. El bucle es para reproducción/monitorización y no recorta automáticamente el archivo exportado. No se reescribió el motor 3D ni se modificó el plugin Minecraft.
