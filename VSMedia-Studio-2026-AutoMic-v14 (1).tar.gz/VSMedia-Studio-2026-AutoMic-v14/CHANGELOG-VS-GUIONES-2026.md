# VS Media Studio — Nomenclatura VS, guiones y micrófono compartido

## Identidad y compatibilidad

- Cambiadas las etiquetas visibles de BS a VS: VS Voice Studio, VS Soundboard, VSAudio, VSMix y VSRadio.
- Nuevas rutas JS `assets/js/vs-codecs.js`, `vs-voice-studio.js`, `vs-soundboard.js`, `vs-guiones.js`, y CSS `vs-tools.css`, `vs-guiones.css`.
- Los nuevos bancos `.vssoundbank` utilizan `bank.json` con `format: "vsmedia.soundbank", schema: 1`. El importador acepta también el `format: "bsmedia.soundbank"` de bancos antiguos.
- No se modificaron ni la estructura ni la estética del Home, ni VSPack, Blockbench, Pixel Studio, VSAudio/VSMix/VSRadio salvo los controles compartidos del micrófono.

## Guiones de voz

El botón `▤ Guion` aparece junto al micrófono en VSAudio Simple, VSMix, VSRadio y VS Voice Studio.

- Título, texto multilínea y guardado automático en el almacenamiento local del navegador **por módulo**.
- Modo Lectura con textos grandes, salto de línea, resaltado de la línea seleccionada y desplazamiento automático configurable (30–250 PPM).
- Importación/exportación `.txt`, controles de tamaño de letra y atajo `Ctrl+Enter` en el panel.
- El panel es flotante y redimensionable; permanece visible durante la grabación y se cierra al cambiar de módulo.
- **No se graba ni se exporta el texto en el audio.** Los guiones no se envían a servicios remotos. Para transportar guiones entre navegadores se debe exportar `.txt`.

## Micrófono compartido

- Corregido un error de inicialización que intentaba acceder a `sourceProbe` antes de declararlo.
- Perfiles de voz sincronizados: cambiar el perfil afecta a las sesiones de captura que ya están abiertas.
- Controles `⚙ Mic` disponibles en VSAudio, VSMix y VSRadio: cancelación de eco, supresión de ruido, ganancia automática del navegador opcional, compresor, puerta, control de sibilancias, ganancia y eco.
- Los controles de captura del navegador requieren apagar y volver a encender el micrófono. Los parámetros DSP se aplican en vivo.
- El rack de VS Voice Studio comparte perfiles y ajustes de compresión con los demás módulos.
- Todo se procesa localmente con Web Audio y las API nativas del navegador. No incluye los filtros cerrados de Discord/Krisp.

## Validación

- `./verify-vs-media.sh` ejecuta pruebas JavaScript y regresiones de Blockbench, Pixel Studio y VSPack.
- `node --test tests/vs-mic-guiones.test.mjs` prueba las sesiones de voz simuladas, la sincronización de ajustes y guiones.
- Prueba de navegador Chromium con carga de JS/CSS en página aislada: los cuatro paneles de guion y controles globales abrieron sin errores JavaScript.
- **Pendiente:** prueba del micrófono físico y de persistencia IndexedDB/localStorage en Firefox/CachyOS del usuario; el navegador de pruebas aislado bloquea almacenamiento por su origen `about:blank`.

## Inicio

```bash
./start.sh
```

Luego `http://127.0.0.1:3060`. La compilación incremental Rust/Blockbench y el servidor FFmpeg se conservan.
