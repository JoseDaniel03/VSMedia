# VSMedia Studio — UI/UX Research v2

Noviembre de 2026. Base: `VSMedia-Studio-2026-Home-UI-Compacto.zip`.

- Paleta de comandos contextual (Ctrl/Cmd+K), accesos a todos los módulos, buscador sin problemas por acentos, teclado y listado de acciones existentes.
- Ayuda de atajos (?) sin afectar edición de guiones.
- Menús de los editores de audio accesibles con teclado: ArrowUp/Down, ArrowLeft/Right, Home, End, Escape.
- Diálogos de la web: Tab cicla dentro del modal, Escape lo cierra, retorno de foco.
- Vista de VSMix: presets de altura de pista, persistencia y adaptabilidad al modo compacto.
- Mejor feedback de foco, contraste, botones y scroll.
- VS Pixel Studio: selector de color navegable por teclado, menús navegables, foco más visible, herramientas más cómodas.
- Home original, Blockbench compilado, Rust/WASM, audio y VSRadio sin cambios de motor.

Ver: `docs/UX-INVESTIGACION-INTERACCIONES-2026.md`.

Verificación: `bash verify-ux-research.sh`.
