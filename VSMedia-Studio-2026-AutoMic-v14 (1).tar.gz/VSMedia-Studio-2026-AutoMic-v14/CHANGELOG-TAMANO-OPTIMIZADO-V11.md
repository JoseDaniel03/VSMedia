# VSMedia v11 — Optimización de tamaño y transferencia

## Paquete completo (editable)
- Mantiene los motores y el código fuente de VSMedia, Blockbench, sprites, VS Pack y los tests.
- Se excluyen solamente imágenes históricas de documentación y formatos de iconos de instaladores de escritorio (`.icns`, `.ico` dentro de `build/`), que no participan en la web.
- `serve.mjs` transmite archivos en streaming y negocia `br`/`gzip` para HTML, JS, CSS y WASM; conserva los medios PNG/JPEG/OGG/WebP originales.
- ETag + revalidación condicional evita volver a transmitir recursos que el navegador ya tiene.

## Paquete compacto (solo ejecución)
- Incluye el Bundle web compilado del modelador, el editor de sprites y VS Pack con su biblioteca local.
- No incluye los fuentes de recompilación de Blockbench, Rust, Electron ni las suites de pruebas. Es apropiado para usar VSMedia, NO para desarrollar ni recompilar componentes.
- Arrancar con `bash start.sh` (usa Node, o Python para servir estáticos si no hay Node). El servicio de conversión de audio Opus/Vorbis requiere Node y FFmpeg.
- Las funciones Rust/WASM opcionales siguen sujetas a disponibilidad del módulo compilado: no se agregan binarios nuevos que no estaban en v10.
- No reemplaza a los ZIP de resource packs ni altera la compresión de imágenes/texturas del usuario.

## ZIP de VS Pack
- La exportación individual, composición y copia de biblioteca usa ZIP32 DEFLATE para JSON/texto cuando es útil. PNG, OGG y otros medios precomprimidos se guardan sin recomprimir.
- La lectura sigue verificando CRC32 y puede importar tanto archivos STORE como DEFLATE.
- Compresión de texto con `CompressionStream(deflate-raw)`: cuando no esté soportado, el ZIP sigue siendo válido mediante STORE.

## Notas
- El tamaño depende de la compresión y los assets. Comparar los ZIP mediante bytes exactos, no solamente el espacio de disco.
- Los contenidos de IndexedDB no forman parte de la instalación: usar la función de respaldo de la biblioteca de VS Pack.
- La edición completa conserva `LICENSE.MD` upstream de Blockbench y `pixel-studio/LICENSE`.
