# VSMedia Studio — Interfaz limpia v6

## Alcance

Esta versión parte de Edición Segura v5 y no altera el Home, el motor de audio, VSRadio DJ ni Blockbench/Rust. Ordena los controles sin retirar capacidades.

## Accesos consolidados

- **VSAudio, VSMix y VSRadio**: los enlaces separados a otros módulos se sustituyen por **Herramientas**, que contiene los destinos anteriores más VS Voice Studio, VS Soundboard y VSPack. Ctrl+K y el menú principal siguen disponibles.
- **VSAudio Simple**: la cabecera agrupa abrir proyecto, exportar WebM y calidad WAV en **Archivo**. El botón para importar audio se muestra solo donde resulte útil (biblioteca vacía o barra de edición). La acción de recortar ya no se duplica en la barra lateral: queda junto a la selección, y también en el menú Editar.
- **VSMix**: se elimina el segundo botón de **Ajustar**, el importador extra de la biblioteca y se agrupan normalización/eliminación del clip en **Más del clip**. WebM pasa a **Archivo**; WAV y Guardar proyecto siguen visibles.
- **VSRadio**: apertura de estación y exportación de guion JSON en **Archivo**. Se aclara la distinción entre Cola automática y Transición anticipada: son funciones distintas.
- **VS Voice Studio**: los dos envíos al Soundboard ahora dicen si envían la toma original o el audio convertido.
- **Soundboard**: el manifiesto JSON indica que no incluye archivos de audio.

- **Bibliotecas de VSAudio, VSMix y VSRadio**: eliminada la visualización simultánea de dos bibliotecas; ahora son pestañas exclusivas **Biblioteca VS / En sesión (o Audio actual)**, con persistencia y navegación por teclado.

## Interacciones

Los menús tienen navegación con teclado, Escape para cerrar, clic exterior para descartar, foco visible y no modifican los selectores/eventos del editor. Los botones originales se recolocan en el DOM, preservando los listeners y atributos de los controladores.

## Arranque

```bash
./start.sh
```

## Pruebas

```bash
./verify-clean-ui-v6.sh
```

Verificar en Firefox/CachyOS el foco y los menús con teclado; los tests y Chromium de este entorno no reemplazan esta revisión en el equipo del usuario.
