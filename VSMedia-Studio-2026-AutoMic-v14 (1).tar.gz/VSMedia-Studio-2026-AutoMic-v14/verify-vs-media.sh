#!/usr/bin/env bash
# Verificación de la interfaz, los contratos y los códecs (sin reinstalar dependencias).
set -Eeuo pipefail
cd -- "$(dirname -- "$(realpath -- "${BASH_SOURCE[0]}")")"
for f in assets/js/*.js serve.mjs; do node --check "$f" >/dev/null; done
node --test tests/vs-media-integration.test.mjs tests/vs-library-voice-ui.test.mjs
bash ./verify-model-engine-v2.sh
printf '\n[VS Media] Verificación completada.\n'
