# VSMedia v13 - Sound packs, DJ y grabación local

- VSAudio, VSMix, VSRadio, VS Voice y VS Soundboard: guardar sonidos en Resource Pack.
- OGG/Vorbis real generado en Worker sin FFmpeg ni CPU del servidor Folia.
- sounds.json se extiende con nueva variante, sin borrar eventos existentes.
- VSRadio crossfade de potencia constante: entrada del tema siguiente antes de terminar el actual, tanto para AUTO DJ como para Siguiente.
- Ducking por voz detectada: micrófono, deck marcado como Voz y locución local programada.
- Puerta/expansor suave con hysteresis, control de dinámica y limitador en micrófono (WebAudio/WebRTC).
- Perfiles: Chat/auriculares, Micrófono económico, Micrófono de estudio, voz limpia, radio y efectos anteriores.
- Micrófono seleccionable desde Ajustes de micrófono; cambios de dispositivo/captura requieren reabrir la fuente.
- VS Voice Studio: pausar/continuar toma, medidor, monitor optativo, guardar a VS Pack.

Los archivos editables se guardan localmente en IndexedDB del navegador (origen). Exportá periódicamente respaldos desde VS Pack. Para Minecraft, publicá el ZIP final en una URL HTTPS accesible desde los jugadores. El servidor Folia no ejecuta codecs.

### Limitaciones
- Krisp es propietario: no se distribuye su algoritmo ni se promete aislamiento idéntico al de Discord. WebRTC/NS/AEC dependen del navegador/dispositivo.
- El crossfade y el ducking de la web son de **monitorización local**; para una emisión remota se requiere el backend de difusión.
- Una voz con recorte digital, distorsión física, captura de mala calidad o compresión previa agresiva no puede recuperarse perfectamente.
