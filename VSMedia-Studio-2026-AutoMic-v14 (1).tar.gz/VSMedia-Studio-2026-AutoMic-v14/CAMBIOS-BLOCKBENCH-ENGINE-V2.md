# VSMedia · VS Model Studio / Blockbench — Engine v2

Esta entrega parte de **VSMedia-Studio-2026-Blockbench-Refactor-Reparado.zip** y mantiene el Blockbench web 5.2.2 original compilado (`modules/vspack/vs-model-studio/dist/bundle.js`). No sustituye Three.js ni sus herramientas de modelado con un renderer propio.

## Problemas reparados

1. **Menús nativos**: el fallback antiguo intentaba comparar un objeto HTMLElement (`li`) con un texto de menú. Ahora identifica el `BarMenu` mediante la identidad de su `label` y espera a que el evento de clic nativo termine antes de intentar recuperarlo. Si ya se abrió, no lo abre otra vez. También mejora el control por teclado.
2. **Estado de proyecto**: se escuchan los eventos nativos `finished_edit`, `undo`, `redo`, `edit_texture` y `edit_layer_properties`; los cambios se agrupan con una ventana de 75 ms para evitar saturar `postMessage`. Las acciones que cambian el proyecto se ejecutan de manera secuencial.
3. **Texturas**: se agregó un botón **Guardar PNG** al editor integrado. Exporta imágenes con el propio motor de Blockbench y permite guardarlas dentro del pack mediante el flujo de VSPack. Protecciones: 64 texturas y 32 MiB de datos base64 por operación. Se pide confirmación sobre sobrescrituras según las reglas existentes de VSPack.
4. **Diagnóstico sin congelamientos**: el análisis geométrico corre en `geometry-worker.js`, fuera del hilo que dibuja el modelo. Si Worker no está disponible se ejecuta un fallback JavaScript que no modifica el proyecto. Hay límites y tiempo máximo de 45 s.
5. **Métricas**: detección de cubos de volumen cero, vértices inválidos y caras con menos de 3 puntos; estimaciones del volumen y área de cubos en espacio local. No se presentan como recuentos exactos de GPU ni como geometría rotada.
6. **Peso del build**: `build.js` ya no genera `bundle.js.map` en compilaciones de producción; el mapa sigue disponible para desarrollo o con `VS_DEBUG_SOURCEMAP=1`.

## Rust / WebAssembly

Se amplió la biblioteca existente `vs_model_core` con `geometry_performance` y exportación WASM `geometryPerformance` (además de las operaciones previas de estadísticas, transformaciones matriciales 4×4 y UV). Los kernels son opcionales: el editor funciona completamente con el bundle original de JS y con el motor de análisis JavaScript.

- **Uso normal**: `./start.sh` (no requiere Cargo ni npm).
- **Compilar Rust una sola vez**: `./build-rust-model-once.sh` con Cargo/Rustup, target `wasm32-unknown-unknown` y `wasm-bindgen-cli` ya instalados. Copiar la carpeta `wasm/` y `embed/wasm-capability.js` para distribuir el acelerador. Este entorno **no tiene Cargo** y no se ha compilado el `.wasm`, por eso la bandera incluida es `false` y no intenta hacer peticiones 404.
- **El código fuente Rust está presente**, pero no se debe afirmar que esta entrega ejecuta Rust/WASM. De momento ejecuta Worker + JS optimizado para geometría.

## Qué está validado

- Test automatizado del menú nativo simulado, incluidas aperturas desde teclado y prevención de doble apertura.
- Test del protocolo del iframe: origen permitido, codecs JSON y BBModel, guardado, exportación de PNG, lectura de estado.
- Test determinístico de métricas geométricas en JS, geometría degenerada y 20.000 cubos.
- Pruebas anteriores de imports JSON, pack compositor, audio, píxeles y viewport.
- `node --check` de archivos nuevos/alterados; bundle compilado sigue incluido.

**Limitación**: el Chromium de este entorno devuelve `ERR_BLOCKED_BY_ADMINISTRATOR` al abrir URLs HTTP locales. No se pudo validar de punta a punta el render 3D real, la interacción completa de menús en CachyOS ni la compilación Rust. Esta es una reparación real con tests, no una garantía de que todos los fallos de Blockbench han desaparecido.

## Cómo probar

1. Extraer el ZIP.
2. Ejecutar `./start.sh`.
3. Abrir `http://127.0.0.1:3060/`, entrar en VSPack → Modelos → VS Model Studio.
4. Probar Archivo, Editar y Ver, crear un modelo, pintar una textura, usar **Guardar PNG**, editar y guardar el `.bbmodel` o JSON. Confirmar que al regresar avisa si hay cambios sin guardar.
5. Correr `./verify-model-engine-v2.sh` para repetir las verificaciones disponibles.

No se ha modificado GitHub ni el plugin Folia. El Home, VSAudio, VSMix, VSRadio y Pixel Studio no recibieron cambios funcionales.
