#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
bash verify-workspace-v3.sh
node --test tests/fluid-edit-v4.test.mjs
for script in assets/js/{mix,simple}.js; do node --check "$script"; done
printf '%s\n' '[VSMedia] Edición fluida v4 verificada.'
