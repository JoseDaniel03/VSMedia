# VSMedia Studio — Edición segura v5

Base: Edición Fluida v4. No se rediseñó el Home, ni se cambiaron Blockbench, Pixel Studio, VSPack o VSRadio.

## VSMix: sesiones largas sin corte fijo de 15 minutos

- El renderizado WAV se procesa con `OfflineAudioContext` por segmentos de 30 segundos, en lugar de alocar un único contexto del tamaño total de la sesión.
- Cada segmento incluye un preroll de 2,4 segundos que reconstruye el estado de filtros, compresor y eco antes de escribir solo las muestras del tramo final. Esta técnica reduce discontinuidades en los límites de los bloques, aunque efectos futuros con colas superiores al preroll requerirían ampliar la ventana.
- El WAV es PCM estéreo a 44,1 kHz, 16 bits. Se ensamblan exactamente las muestras necesarias; no hay truncado por duración.
- Barra de progreso y cancelación entre bloques; la cancelación no entrega un archivo parcial.
- Para WAV grandes, navegadores compatibles con File System Access pueden guardar por partes directamente al disco. En otros se construye un Blob con límite de seguridad de 512 MiB; la función muestra una advertencia antes de exportaciones grandes. El formato WAV RIFF tiene además su límite técnico de 4 GiB.
- WebM/Opus sigue dependiendo del conversor FFmpeg **local**; ahora admite hasta 384 MiB de WAV y recibe los datos como flujo, sin concatenar toda la entrada en memoria del servidor. El límite de salida es 128 MiB y el proceso tiene 6 minutos de margen.

## VSMix: recuperación de sesión

- Copia incremental en IndexedDB: se guardan montajes, marcadores, ajustes y audio original. Cada archivo de audio solo se vuelve a escribir si su ID es nuevo; mover clips actualiza solo el manifiesto.
- Tras un cierre y reinicio, **Recuperar** permite volver al proyecto guardado, con confirmación explícita. Nunca reemplaza automáticamente el trabajo actual.
- `Archivo → Borrar copia de recuperación` permite eliminar los datos guardados. `Nuevo proyecto` también borra la copia después de confirmar.
- Se guardan los cambios después de editar con una espera breve y al abandonar VSMix. Si IndexedDB no está disponible o no hay espacio, se advierte y se conserva el guardado manual como opción confiable.
- Importante: recuperación no equivale a archivo de respaldo permanente. Seguir exportando `.vsmedia` con regularidad.

## Navegación y edición

- `Ajustar` ahora encuadra la sesión completa, también cuando contiene horas de audio. El zoom es logarítmico (multiplicativo) y conserva el tiempo bajo el cursor al ampliar o alejar.
- Alt+← / Alt+→ desplaza el clip seleccionado 50 ms. Con Shift+Alt, 500 ms. Participa en deshacer/rehacer.
- Corrección de posición para zooms inferiores a 1 píxel/segundo y de la regla cuando se visualiza una sesión larga.

## Validación

- `bash verify-safe-v5.sh` ejecuta regresiones y pruebas de cálculo, cancelación y estabilidad de render.
- Se probó con OfflineAudioContext real una señal estéreo de 3,2 s ensamblada en cuatro segmentos y se comprobó que sus muestras no cambian de longitud.
- Se verificó conversión local WebM/Opus con FFmpeg y rechazo de orígenes no autorizados.
- **Pendiente en el equipo del usuario:** prueba de recuperación IndexedDB y de exportación extensa con Firefox/CachyOS en archivos de tamaño real. No se ejecutó compilación Rust aquí.
