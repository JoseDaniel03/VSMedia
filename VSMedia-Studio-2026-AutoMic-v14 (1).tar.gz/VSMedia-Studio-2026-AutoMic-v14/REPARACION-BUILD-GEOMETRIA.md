# VSMedia — corrección de compilación geométrica (9 noviembre 2026)

## Problema corregido

Después de compilar correctamente Blockbench y `vsmedia-kernels`, `./start.sh` fallaba en el núcleo geométrico:

```
error: unexpected argument '--out-dir' found
Usage: cargo build [OPTIONS]
```

La invocación previa mezclaba los argumentos de `wasm-pack` con los reenviados a `cargo`. Ahora todas las opciones de `wasm-pack` se pasan antes del separador `--`, y la característica de Cargo después:

```bash
wasm-pack build --release --target web --out-dir ../../wasm -- --features wasm
```

La corrección se aplicó en `scripts/build-all.sh` (invocado automáticamente por `./start.sh`) y en `build-rust-model-once.sh` para que ambos caminos produzcan los mismos archivos:

- `modules/vspack/vs-model-studio/wasm/vs_model_core.js`
- `modules/vspack/vs-model-studio/wasm/vs_model_core_bg.wasm`

No se modifica el motor Blockbench, VSAudio ni VSRadio.

## Instalar parche en una copia existente

Extraer el ZIP de parche en la raíz del proyecto, sobrescribiendo `scripts/build-all.sh` y `build-rust-model-once.sh`, y ejecutar:

```bash
./start.sh
```

No es necesario borrar la caché ni desinstalar dependencias. Para forzar todas las compilaciones: `VSMEDIA_FORCE_BUILD=1 ./start.sh` (no recomendado para este error).

## Verificación

`bash -n` en los scripts; prueba con simulaciones de las herramientas de compilación, verificando el orden de opciones y la caché incremental. El entorno donde se preparó el parche carece de Cargo real y no se afirma haber compilado el WASM en él.
