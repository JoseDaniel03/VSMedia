# VSMedia Studio — Controles depurados v8

Continuación de **Menú unificado v7**, centrada exclusivamente en eliminar botones redundantes sin perder acciones ni modificar los motores de audio.

## VSAudio Simple

- `Archivo` reúne abrir, guardar proyecto y exportar WAV/WebM/Opus. Ya no hay botones Guardar y Exportar WAV duplicados en la cabecera.
- El selector **WAV 16/32 bits** queda dentro del mismo menú `Archivo`, junto a Exportar WAV.
- En la biblioteca lateral se mantienen a la vista las herramientas de silencios que **no** estaban en los menús: detectar, buscar el siguiente y silenciar los detectados. Normalización, fades, invertir, recortar, etc. siguen en `Editar` y `Efectos`.
- Se quitaron las duplicaciones de `Seleccionar todo`, `Limpiar selección` y `Restablecer efectos` que tenían alternativas de teclado y menú. Doble clic/ Ctrl+A seleccionan; Escape limpia la selección.

## VSMix

- La cabecera ya no duplica Guardar proyecto ni Exportar WAV; ambas acciones quedan en `Archivo` junto a WebM/Opus.
- Se quitó el botón de importación adicional de la barra de transporte; la biblioteca VS y el menú Archivo mantienen importación.
- El timeline deja de tener botones permanentes de Dividir, Duplicar, Normalizar y Eliminar, que ya estaban en `Editar`. **Clic derecho sobre un clip** muestra las acciones contextuales, incluyendo fades. Los atajos **S**, **D** y **Supr** continúan.
- Los clips tienen foco de teclado y el menú contextual también se puede abrir con **Shift+F10**.
- Se quitaron las dos entradas repetidas `Ajustar zoom` y `Nueva pista / Insertar silencio` del menú Editar; la acción sigue en `Ver` y en `Nueva pista`.

## VSRadio y bibliotecas

- `Archivo` ahora agrupa **Abrir estación, Guardar estación, Guion JSON e Importar audio**. El encabezado mantiene controles propios de programación y consola DJ.
- Se eliminó el botón `Inicio` de las bibliotecas laterales, duplicado del botón `Proyectos` de la cabecera.
- La opción `Vista` del encabezado se renombró a `Paneles` para distinguirla del menú `Ver` (zoom).
- Se redujeron encabezados de biblioteca redundantes; las pestañas `Biblioteca VS` y `En sesión` siguen presentes.

## Pruebas

- `./verify-controls-v8.sh`: ejecuta el suite de versiones anteriores, nuevas pruebas de estructura y chequeos de sintaxis.
- Se probó con Chromium cargando directamente los recursos: exportación WAV de un archivo real, duplicación de clip por clic derecho, menús de Archivo de radio y disposición a **1050 px**, sin errores JavaScript en esas rutas.
- La prueba en Firefox/CachyOS sigue pendiente. El Home, VSPack/Blockbench compilado, Rust/WASM, VS Voice y VS Soundboard no reciben modificaciones funcionales en esta versión.

## Arranque

`./start.sh` (AutoBuild habitual).
