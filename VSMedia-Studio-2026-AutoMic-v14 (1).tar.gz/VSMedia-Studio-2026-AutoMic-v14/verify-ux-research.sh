#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$(realpath "${BASH_SOURCE[0]}")")"
for file in assets/js/*.js modules/vspack/pixel-studio/web/vs-pixel-studio.mjs; do node --check "$file"; done
node --test tests/*.test.cjs tests/*.test.mjs
printf '\n[VS Media · UI/UX] Verificación de sintaxis y pruebas completadas.\n'
