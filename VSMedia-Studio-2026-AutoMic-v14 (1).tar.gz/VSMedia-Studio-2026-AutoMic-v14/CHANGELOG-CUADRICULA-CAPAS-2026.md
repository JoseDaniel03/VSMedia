# VSMedia Studio — Interacción y capas (noviembre de 2026)

## VS Pixel Studio / Aseprite

- Transparencia: checkerboard con tamaño enlazado al zoom, origen 0,0 y sin deriva al mover el lienzo.
- Rejilla: cada línea corresponde a un píxel del sprite, con el mismo origen y escala CSS del canvas.
- Cursor: previsualización del píxel y la huella del pincel en **cada movimiento**, no solo durante el trazado; usa la transformación real del canvas incluso con scroll y zoom fraccionario.
- Capas: duplicar todos los fotogramas, subir/bajar capa conservando cels y vínculos, historial de cambios, bloqueo coherente con Undo/Redo, opacidad en tiempo real y selector de fusión.
- Estado de capas: opacidad, fusión y flags de bloqueo restaurados en proyectos `.vspixel.json` y manipulables desde el editor.
- Seguridad: límites de 128 capas y 512 fotogramas; confirmación antes de crear o abrir otro sprite cuando hay cambios sin guardar.
- La implementación JS completa gestiona el documento cuando la ABI de Rust/WASM carece de las operaciones de capas; los kernels de procesamiento de color Rust/WASM siguen siendo opcionales y no son requisito para ejecutar VSMedia.

## VSAudio Simple y VSMix

- VSAudio Simple: teclado ←/→ para avanzar/rebobinar 100 ms; Shift+←/→ para saltos de 1 segundo, respetando el estado de reproducción.
- VSMix: zoom **anclado al instante bajo el puntero** (rueda con Ctrl) o centro visible (botones/slider), sin saltos al volver a pintar el timeline.
- VSMix: ←/→ mueve el cabezal 100 ms, Shift+flecha 1 segundo, Home/End a límites. Historial de rehacer limitado a 60 estados.

## VSRadio

- Se preserva exactamente el volumen master igual a cero en ajustes guardados; no se sustituye inadvertidamente por el volumen inicial.
- Se reduce la frecuencia de actualización del display en modo local de 160 ms a 300 ms; no pinta si la página no está visible.

## VSPack, Blockbench, Home y otros módulos

- **No se modificaron** el código del Home, los archivos CSS principales, el motor de Blockbench, VSRadio Playlist/Sesiones ni VSPack Foundry. Se optimizó la carga de VSPack y la frecuencia de consulta de estado del puente Model Studio.
- Se añadieron pruebas de geometría del zoom, coherencia de capas y fotogramas y regresión del compositor de packs. Los tests del puente original de Blockbench también pasaron.
- VSPack y Blockbench: gestor con carga diferida solo al entrar a su sección y reducción de sondeos cuando el editor está oculto.
- Blockbench requiere que el archivo compilado `modules/vspack/vs-model-studio/dist/bundle.js` esté disponible como en la versión anterior. No se incluye un bundle ficticio.

## Pruebas hechas

- `node --check`: scripts `.js` y `.mjs` de la aplicación.
- `node modules/vspack/test-viewport.mjs`.
- `node modules/vspack/test-pixel-layers.mjs`.
- `node modules/vspack/test-compositor.mjs`.
- `node --test modules/vspack/vs-model-studio/tests/*.test.mjs`: 9/9.
- Chromium: en un entorno aislado sin red se probaron grid, hover, zoom 1600%, duplicación/reordenamiento de 3 capas, cambios de opacidad/fusión, y la colocación real de un píxel en (10,13). Sin errores JavaScript.

**Alcance de las pruebas:** se comprobó el componente Pixel Studio de forma aislada, no todas las funciones de Blockbench, la ejecución nativa del servidor CachyOS ni el acceso al micrófono físico.
