# VSPack Foundry v2.3 — Entrega a VSMedia

## Alcance

Web sola, sin cambios en GitHub, plugins, VSRender ni VSEngine. Conservar la carpeta completa, los scripts y los recursos de VS Pixel Studio / VS Model Studio.

## Nuevo recorrido dentro de un único workspace

1. `./start.sh` y abrir `http://127.0.0.1:3060`.
2. Importar un ZIP con un `.bbmodel` que contenga un PNG incrustado o crearlo dentro de un pack.
3. Ir a **Gestores → Modelos**, abrir el modelo y elegir **Texturas del modelo**.
4. Seleccionar una textura PNG y tocar **Editar en Pixel Studio**. El editor reemplaza *solo el área central*, sin abrir otra web.
5. Dibujar; usar **Guardar PNG** para guardar la textura en el pack. La definición interna del modelo se sincroniza si ese formato/modo lo admite.
6. Si se quieren conservar capas, guardar también el proyecto **.aseprite** en el mismo pack.
7. Usar **Volver al modelo**, después **Guardar en pack** para persistir la modificación del `.bbmodel` o modelo JSON.
8. Exportar el ZIP desde Publicador y verificar que contiene PNG y modelo actualizados.

## Seguridad y reversibilidad

- Si el guardado de PNG es cancelado, **no se modifica el modelo**.
- Una edición local de `.bbmodel` actualiza únicamente la textura correspondiente y conserva estructura, UV y animaciones restantes.
- Blockbench utiliza su comando de sustitución de textura con historial propio; una textura multicapa se debe editar allí.
- Si Blockbench rechaza la sincronización, la UI avisa que solo se guardó la copia PNG externa; no declara que la textura del modelo fue modificada.
- Navegar fuera del módulo pregunta si hay cambios pendientes. El texto de un modelo JSON mal formado no se guarda.
- Se mantiene IndexedDB `vspack-local-v1`, sin migraciones ni limpiezas. Exportar un ZIP de respaldo antes de actualizar es una medida prudente.

## Pruebas realizadas

Suite de Node.js sobre el motor de modelos, composición, rutas y sincronización de texturas, y suite original de Pixel Studio. La validación del arranque visual de Chromium no pudo completarse en el entorno; probar el recorrido completo en CachyOS.

## Integración posterior en VSMedia

Usar `index.html?embed=1&view=managers&manager=models` en el mismo origen y `window.VSPackHost` / mensajes `vspack-host-v1` según PARA-VSMEDIA-LEER-PRIMERO.md. No duplicar biblioteca ni copiar los assets entre dominios distintos. El host comunica navegación y metadatos, no bytes de archivos.
