# VS Model Studio / Blockbench original — estado verificado

Esta entrega preserva los **432 archivos** del ZIP `VS-Model-Studio-v0.2-Bilingue-UI-Limpia-CachyOS(1).zip` sin alterar sus bytes. El ZIP fuente también está incluido íntegro. Se restauraron los 29 archivos que no estaban en la v2.7: tipografías, componente, demo, pruebas y metadatos.

## Integración realizada
- VSPack → Gestores → Modelos → **Abrir Blockbench** abre el montaje original en el mismo documento (sin iframe), cuando el runtime compilado está presente.
- Usa `window.Codecs.project` para `.bbmodel` y `window.Codecs.java_block` para modelos `.json`; ambas rutas invocan el código original de Blockbench.
- Admite entrar sin seleccionar archivo y abrir el asistente de proyectos original.
- Al guardar un proyecto nuevo, pide una ruta `.bbmodel` dentro del pack y la escribe en la biblioteca IndexedDB.
- Conserva módulos Pixel Studio, biblioteca, compositor y resto de gestores.

## Bloqueo pendiente
**No hay un `vs-model-studio/dist/bundle.js` en ninguno de los ZIP del usuario.** Node está disponible, pero no lo están las dependencias npm y la red no permite descargarlas. Por eso no se pudo compilar ni ejecutar el editor Blockbench original. El proyecto conserva el código real y el adaptador, pero **NO es un ZIP final 1:1 listo para usar sin compilación**. No lo presentes como tal. No se requieren comandos adicionales para arrancar la web principal, pero Model Studio no funcionará completo hasta disponer del bundle.

No se ha cambiado GitHub, ni plugins, ni instalado una web secundaria.
