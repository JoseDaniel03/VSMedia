# VSPack Foundry — integración original v2.8 (no final)

La aplicación principal inicia con `./start.sh` y usa `http://127.0.0.1:3060`.

**ESTADO DE ESTE PAQUETE:** el usuario adjuntó `vs-model-studio/dist/bundle.js` compilado (Blockbench 5.2.2). Se incluye, junto con el editor original, su fuente, licencia y el puente de integración de VSPack. La verificación del arranque del 3D en navegador real queda pendiente: los tests estructurales no la reemplazan. No hace falta compilar npm al ejecutar VSMedia.

Consultá `INTEGRACION-REAL-ESTADO-v2.8.md`.
