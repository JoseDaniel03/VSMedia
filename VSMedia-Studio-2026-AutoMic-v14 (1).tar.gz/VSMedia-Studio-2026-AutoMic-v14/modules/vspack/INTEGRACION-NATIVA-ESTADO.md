# Estado de integración nativa

Se solicitó conservar el Blockbench original 1:1 y volverlo componente interno de VSPack, sin iframe ni recrear otra interfaz.

## Adaptador implementado

`assets/model-native.mjs` monta la jerarquía HTML de la interfaz original (header, herramientas, preview, paneles, diálogos y áreas de animación) en el documento de VSPack. Inyecta las hojas de estilo originales y las deshabilita al regresar al gestor. No reemplaza Blockbench con un visor propio. La aplicación original se inicializa una sola vez y su estado se conserva mientras se navega. Los datos de modelos se abren y exportan con los propios codecs de Blockbench.

## Condición imprescindible, no satisfecha

El paquete fuente no contiene el bundle original `dist/bundle.js`, ni hay dependencias disponibles para compilarlo aquí. Por eso esta entrega no se debe etiquetar como editor funcionando/port 1:1 terminado. No se le pide al usuario compilarlo.

## Conexiones del módulo

1. VSPack Gestores → Modelos → nuevo proyecto `.bbmodel` o seleccionar existente.
2. Los bytes se obtienen desde IndexedDB, sin modificar el pack de origen hasta guardar.
3. El adaptador monta en el mismo documento la UI original; **requiere bundle**.
4. `Codecs.project.load()` abre el archivo original; `Codecs.project.compile({bitmaps:true})` lo serializa.
5. Guardar escribe los bytes al mismo archivo del pack, con gestión de cambios pendientes y navegación de vuelta.

**Nota:** la parte 3 no puede comprobarse sin la compilación original. El código está preparado, pero el flujo completo aún no está validado.
