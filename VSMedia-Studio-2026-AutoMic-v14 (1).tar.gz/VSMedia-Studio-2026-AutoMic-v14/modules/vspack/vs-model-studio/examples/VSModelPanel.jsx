import { useEffect, useRef } from 'react';
import '../embed/component.js';

// Custom element with the original Blockbench editor, no custom reimplementation.
export function VSModelPanel({ editorUrl, onReady, onModelChange, height = 750 }) {
  const editorRef = useRef(null);
  useEffect(() => {
    const editor = editorRef.current;
    if (!editor) return;
    const ready = event => onReady?.(event.detail);
    const changed = event => onModelChange?.(event.detail);
    editor.addEventListener('vs-ready', ready);
    editor.addEventListener('vs-project-changed', changed);
    return () => {
      editor.removeEventListener('vs-ready', ready);
      editor.removeEventListener('vs-project-changed', changed);
    };
  }, [onReady, onModelChange]);
  return <vs-model-studio ref={editorRef} editor-url={editorUrl} style={{display:'block', width:'100%', height}} />;
}
