<template>
  <section class="model-studio-panel">
    <vs-model-studio
      ref="host"
      :editor-url="editorUrl"
      @vs-ready="onReady"
      @vs-project-changed="onChange"
    />
  </section>
</template>

<script setup lang="ts">
import { ref, onMounted, onBeforeUnmount } from 'vue';
import type { VSModelStudio, VSModelInfo } from '../embed/component';
// In the consuming site, resolve this import to the published component.js asset.
import '../embed/component.js';

const props = defineProps<{ editorUrl: string }>();
const emit = defineEmits<{
  (event: 'ready', value: VSModelInfo): void;
  (event: 'changed', value: unknown): void;
}>();
const host = ref<VSModelStudio | null>(null);
function onReady(event: CustomEvent<VSModelInfo>) { emit('ready', event.detail); }
function onChange(event: CustomEvent) { emit('changed', event.detail); }

defineExpose({
  openModel: (file: File) => host.value?.openModel(file, file.name),
  newProject: (format = 'free') => host.value?.newProject(format),
  exportModel: () => host.value?.exportModel(),
  getSnapshot: () => host.value?.getSnapshot(),
});
</script>

<style scoped>
.model-studio-panel { width: 100%; height: 100%; min-height: 550px; overflow: hidden; }
vs-model-studio { width: 100%; height: 100%; }
</style>
