/** Optional Rust/WASM accelerator. Generated wasm package is not checked in. */
let corePromise;
export async function loadRustModelCore(wasmUrl = new URL('../wasm/vs_model_core.js', import.meta.url).href) {
  if (!corePromise) {
    corePromise = import(wasmUrl).then(async module => {
      await module.default();
      return module;
    }).catch(error => { corePromise = undefined; throw error; });
  }
  return corePromise;
}
export async function analyzeBBModelRust(model) {
  const core = await loadRustModelCore();
  return core.analyzeBBModel(typeof model === 'string' ? model : JSON.stringify(model));
}
export async function transformVerticesRust(positions, matrix) {
  const core = await loadRustModelCore();
  return core.transformPositions(Float32Array.from(positions), Float32Array.from(matrix));
}
export async function normalizeUVRust(pairs, width, height) {
  const core = await loadRustModelCore();
  return core.normalizeUV(Float32Array.from(pairs), width, height);
}

export async function geometryPerformanceRust(model) {
  const core = await loadRustModelCore();
  if(typeof core.geometryPerformance !== 'function') throw Error('El módulo Rust es una versión anterior; recompilá el núcleo');
  return core.geometryPerformance(typeof model==='string'?model:JSON.stringify(model));
}
