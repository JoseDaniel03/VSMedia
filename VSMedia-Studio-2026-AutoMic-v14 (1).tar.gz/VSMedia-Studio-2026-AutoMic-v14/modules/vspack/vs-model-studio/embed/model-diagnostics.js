/** Safe, dependency-free quality analysis; never alters Blockbench model data.
 * The optional Rust/WASM engine performs heavier geometric transforms.
 * GPL-3.0-or-later, derived interface package.
 */
const validVec = value => Array.isArray(value) && value.length >= 3
  && value.slice(0,3).every(Number.isFinite);
export function inspectModel(model, opts={}) {
  if (!model || typeof model!=='object' || Array.isArray(model)) throw Error('Modelo inválido');
  const issues=[];
  const warn=(level,what)=>{if(issues.length<50)issues.push({level,what});};
  const elements=Array.isArray(model.elements)?model.elements:[];
  const textures=Array.isArray(model.textures)?model.textures:[];
  const types={cube:0,mesh:0,other:0};
  let triangles=0;
  const min=[Infinity,Infinity,Infinity],max=[-Infinity,-Infinity,-Infinity];
  const point=vec=>{for(let i=0;i<3;i++){min[i]=Math.min(min[i],vec[i]);max[i]=Math.max(max[i],vec[i]);}};
  for (const [i,el] of elements.entries()) {
    if (!el || typeof el!=='object') {warn('error',`Elemento ${i+1} no es un objeto`);continue;}
    if (el.type === 'mesh') {
      types.mesh++;
      const vertices=el.vertices && typeof el.vertices==='object'?Object.values(el.vertices):[];
      for (const v of vertices) validVec(v)?point(v):warn('error',`Malla ${i+1}: vértice inválido`);
      const faces=el.faces && typeof el.faces==='object'?Object.values(el.faces):[];
      triangles+=faces.reduce((count,face)=>count+Math.max(0,(face?.vertices?.length||0)-2),0);
    } else if (!el.type || el.type === 'cube') {
      types.cube++;
      if (!validVec(el.from) || !validVec(el.to)) {warn('error',`Cubo ${i+1}: faltan coordenadas from/to válidas`);continue;}
      point(el.from);point(el.to);
      const lengths=el.from.slice(0,3).map((v,a)=>Math.abs(el.to[a]-v));
      if (lengths.some(x=>x<1e-7)) warn('warning',`Cubo ${i+1}: dimensión cero`);
      if (opts.javaFormat && [...el.from,...el.to].some(x=>x< -16 || x>32)) warn('warning',`Cubo ${i+1}: geometría fuera del rango habitual de bloques`);
      const faces=el.faces && typeof el.faces==='object'?Object.values(el.faces):null;
      triangles+=(faces?faces.filter(x=>x&&x.enabled!==false).length:6)*2;
    } else types.other++;
  }
  const ids=new Set();
  textures.forEach((t,i)=>{
    if(!t || typeof t !== 'object'){warn('warning',`Textura ${i+1} inválida`);return;}
    const key=t.uuid || t.id || t.name;
    if(key && ids.has(key))warn('warning',`Textura repetida: ${String(key).slice(0,60)}`);
    if(key) ids.add(key);
  });
  if(!elements.length) warn('info','Este proyecto todavía no tiene elementos 3D');
  const bounds=min.every(Number.isFinite)?{min,max}:null;
  return {name:String(model.name||'Sin nombre').slice(0,128),format:String(model.meta?.model_format||'free'),elements:elements.length,cubes:types.cube,meshes:types.mesh,other:types.other,estimatedTriangles:triangles,textures:textures.length,groups:Array.isArray(model.groups)?model.groups.length:0,animations:Array.isArray(model.animations)?model.animations.length:0,bounds,issues};
}
