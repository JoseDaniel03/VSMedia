# VS Model Studio — componente web reutilizable

Version base: **Blockbench 5.2.2**, conservado en su interfaz original. El componente **no sustituye** su editor, motor Three.js, manipulación de UV, texturas ni codecs. Integra una instancia completa, aislada mediante iframe y una API `postMessage` con validación de origen.

## Instalación en otra web

1. Publicá la carpeta de la aplicación Blockbench modificada en un subdominio/ruta, por ejemplo `https://editor.example.com/`. Necesita **`dist/bundle.js` compilado** con `npm ci && npm run build-web`; el ZIP de código fuente original no lo incluía.
2. Copiá `embed/component.js` a tu web host, o importalo desde la URL de tu servidor de recursos.
3. Montá el elemento (puede usarse desde Vue, React, Svelte, Leptos o HTML básico):

```html
<script type="module" src="/assets/vs-model-studio/component.js"></script>
<vs-model-studio id="model" editor-url="https://editor.example.com/index.html" language="es" accent="#c8a96c" style="display:block;height:750px;width:100%"></vs-model-studio>
<script type="module">
  const editor = document.querySelector('#model');
  editor.addEventListener('vs-ready', async () => {
    await editor.newProject('free');
  });
  // Otros usos:
  // await editor.openModel(file, file.name);
  // const project = await editor.getSnapshot(); // JS object con todo el .bbmodel
  // await editor.downloadModel('modelo.bbmodel');
</script>
```

La propia página del editor usa `embed/bridge.js` para reconocer **únicamente** al padre cuyo origen se haya pasado por el componente. Los mensajes de origen inesperado son ignorados. No se permite configurar un origen comodín (`*`).

### Idioma y marca

El componente acepta `language="es"` o `language="en"` y `accent="#c8a96c"`.
También se pueden modificar mediante `editor.language = 'en'` y `editor.accent = '#a8bf7d'`.
Cambiar cualquiera de estos atributos recarga el iframe; guardá el proyecto antes del cambio.
En modo embebido se desactivan el carrusel y los anuncios de inicio, pero se mantiene el editor 3D original.

## API

| Método | Función |
|---|---|
| `whenReady` | Promise de inicialización del editor original |
| `newProject('free')` | Crea un proyecto en el formato elegido (`free`, `java_block`, `bedrock`, etc.) |
| `openModel(fileOrObjectOrString, name)` | Abre un `.bbmodel` usando el codec de Blockbench |
| `getSnapshot()` | Retorna modelo completo como objeto JSON (incluye texturas embebidas) |
| `exportModel()` | Retorna `.bbmodel` como cadena JSON |
| `downloadModel(filename)` | Descarga el modelo desde la web contenedora |
| `getInfo()` | Nombre, formato, elementos, texturas, animaciones |
| `undo()`, `redo()` | Historial del editor |
| `analyzeModelRust()` | Estadísticas y AABB mediante WASM Rust (requiere `wasm/` generado) |
| `transformVerticesRust(vertices, matrix)` | Transformación matricial en Rust/WASM |
| `normalizeUVRust(uv, width, height)` | UV normalizadas en Rust/WASM |
| `focusEditor()` | Activa el foco del iframe |

Eventos: `vs-ready`, `vs-project-changed`, `vs-event`, `vs-error`.

## Núcleo Rust

`crates/vs_model_core` es una biblioteca Rust independiente con:

- `analyze_bbmodel`: valida y obtiene estadísticas y límites (AABB) de `.bbmodel` sin alterar el JSON original.
- `transform_positions`: transformaciones 4×4 de vértices, usando convención Three.js columna mayor.
- `normalize_uv`: coordenadas UV pixel → coordenadas normalizadas, validando entradas.
- Exports WASM opcionales con `wasm-bindgen`; `embed/rust-engine.js` permite consumirlos desde una app web cuando el paquete WASM esté compilado.

Compilar y probar Rust: `cargo test -p vs_model_core`.
Compilar WASM con `wasm-pack`: `cd crates/vs_model_core && wasm-pack build --release --target web --features wasm --out-dir ../../wasm`.

Rust también sirve el editor desde el puerto 3070 con `cargo run -p vs_model_server -- .` (o `./scripts/start.sh` para compilación y arranque automáticos) (servidor de desarrollo sin dependencias). La demo está en `/demo/`.

**Estado real de la migración:** el servidor y las rutinas de geometría están escritas en Rust. La UI original sigue en Vue/JavaScript y el render 3D original en Three.js; un port completo 1:1 de toda la base de Blockbench a Rust no está realizado. Esta decisión mantiene la compatibilidad y los plugins existentes. Los fuentes originales de este paquete requieren compilar la web antes de ejecutarse porque el ZIP facilitado no incluía el bundle construido.

## VSMedia / otras webs

Un módulo del contenedor puede montar el editor como una página/panel interno, no como web separada: `<vs-model-studio>` ocupa 100 % de la región que le asignes. La interfaz que se ve adentro es la de Blockbench sin rediseño. `VSModelStudio` puede abrirse/cerrarse desde el router de la web anfitriona conservando su propia barra superior.

## Licencia

Este paquete contiene código original de Blockbench y cambios derivados bajo **GPL-3.0-or-later**. Se conserva `LICENSE.MD` y los archivos de origen. Si vas a redistribuir una versión modificada a terceros, revisá las obligaciones de distribución de código fuente y avisos bajo la GPL. No implica afiliación oficial con Blockbench.
