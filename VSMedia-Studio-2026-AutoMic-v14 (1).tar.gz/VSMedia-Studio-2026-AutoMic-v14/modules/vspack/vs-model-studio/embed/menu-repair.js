/**
 * Small, embed-only guard for Blockbench's native menus. This intentionally
 * does not replace BarMenu or create an alternate navigation system.
 * Restores focus, keyboard handling and visible popovers if the normal click
 * handler failed in the nested VSPack web component.
 */
const embedded = window.parent!==window && new URLSearchParams(location.search).get('vs_embed')==='1';
if(embedded){
 const hiddenSections=new Set(['discord_link','bluesky_link','new_version','psa','quick_setup','splash_screen']);
 const removePromotions=()=>{
  for(const el of document.querySelectorAll('#start_screen [section_id],#start_screen #quick_setup')){
   if(hiddenSections.has(el.getAttribute('section_id')||el.id))el.remove();
  }
  for(const el of document.querySelectorAll('#start_screen a[href*="discord.gg"],#start_screen a[href*="bsky.app"],#start_screen a[href*="blockbench.net/quickstart"]'))el.closest('li,section')?.remove();
 };
 const findMenu=label=>{
  const registry=window.Blockbench?.MenuBar?.menus || window.VSModelMenuBar?.menus || window.MenuBar?.menus;
  if(!registry || !label)return null;
  // Native BarMenu.label is the actual <li> in #menu_bar, not a string.
  // Aliases (e.g. filter/tools) may point to the same menu instance.
  const values=new Set(Object.values(registry));
  for(const menu of values){
   if(menu?.label===label || menu?.label?.contains?.(label))return menu;
  }
  return null;
 };
 const menuIsVisible=menu=>{
  const n=menu?.node;
  return Boolean(n?.isConnected&&getComputedStyle(n).display!=='none'&&n.getBoundingClientRect().width);
 };
 function ensureMenuVisible(menu){
  if(!menuIsVisible(menu))return false;
  menu.node.style.zIndex='550';
  menu.node.style.pointerEvents='auto';
  menu.node.style.maxHeight='calc(100dvh - 36px)';
  menu.node.style.overflowY='auto';
  return true;
 }
 const pending=new WeakMap();
 // Browser security forbids file:/// navigation from the local HTTP host.
 // Prefer VSPack's File API importers; keep Blockbench's real file picker.
 if(typeof document.addEventListener==='function') document.addEventListener('click',event=>{
  const anchor=event.target instanceof Element ? event.target.closest('a[href]') : null;
  if(anchor && anchor.protocol==='file:'){
   event.preventDefault();
   event.stopImmediatePropagation();
   window.Blockbench?.showQuickMessage?.('Abrí los archivos desde VSPack o el selector local de Blockbench.');
  }
 }, true);
 const bar=document.getElementById('menu_bar');
 if(bar){
  bar.addEventListener('pointerdown',e=>{
   const li=e.target.closest('li.menu_bar_point');
   if(li&&bar.contains(li))pending.set(li,li.classList.contains('opened'));
  },true);
  bar.addEventListener('click',e=>{
   const li=e.target.closest('li.menu_bar_point');if(!li||!bar.contains(li))return;
   const wasOpen=pending.get(li)??li.classList.contains('opened');
   pending.delete(li);
   // The native BarMenu click runs first. Inspect after native event handling;
   // never double-toggle a correctly opened menu.
   (typeof requestAnimationFrame==='function'?requestAnimationFrame:queueMicrotask)(()=>{
    if(li.isConnected===false)return;
    const menu=findMenu(li);if(!menu)return;
    if(!wasOpen&&!menuIsVisible(menu)){
     try{menu.open();}catch(err){console.warn('VS Model Studio menu fallback:',err);}
    }
    ensureMenuVisible(menu);
   });
  },true);
  bar.addEventListener('keydown',e=>{
   if(!['Enter',' ','ArrowDown'].includes(e.key))return;
   const li=e.target.closest('li.menu_bar_point');if(!li||!bar.contains(li))return;
   const menu=findMenu(li);if(!menu)return;
   e.preventDefault();e.stopPropagation();
   if(menuIsVisible(menu)&&e.key!=='ArrowDown')menu.hide();
   else {try{menu.open();ensureMenuVisible(menu);}catch(err){console.warn('VS Model Studio menu keyboard:',err);}}
  },true);
 }
 const enhanceLabels=()=>{
  if(!bar)return;
  for(const li of bar.querySelectorAll('li.menu_bar_point')){
   if(!li.hasAttribute('tabindex'))li.tabIndex=0;
   li.setAttribute('role','menuitem');li.setAttribute('aria-haspopup','menu');
  }
 };
 // Observe only the components we modify, rather than the entire animated
 // 3D application. Avoid a per-frame querySelectorAll performance regression.
 let queued=false;
 const observer=new MutationObserver(()=>{
  if(queued)return;
  queued=true;
  requestAnimationFrame(()=>{queued=false;removePromotions();enhanceLabels();});
 });
 if(bar)observer.observe(bar,{childList:true,subtree:true});
 const start=document.getElementById('start_screen');
 if(start)observer.observe(start,{childList:true,subtree:true});
 removePromotions();enhanceLabels();
}
