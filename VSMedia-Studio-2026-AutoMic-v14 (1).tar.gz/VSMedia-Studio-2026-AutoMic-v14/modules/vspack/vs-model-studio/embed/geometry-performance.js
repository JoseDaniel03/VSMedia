/** Deterministic fallback matching Rust vs_model_core::geometry_performance.
 * Does not mutate geometry. Estimates do not bake rotations/modifiers.
 */
const vec3 = v => Array.isArray(v) && v.length>=3 && v.slice(0,3).every(Number.isFinite) ? v : null;
export function geometryPerformance(model) {
  if(typeof model==='string') {
    if(model.length>64*1024*1024) throw Error('Model exceeds 64 MiB');
    model=JSON.parse(model);
  }
  if(!model || !Array.isArray(model.elements)) throw Error('Model has no elements array');
  const result={cubeCount:0,meshCount:0,zeroVolumeCubes:0,invalidVertices:0,zeroAreaFaces:0,
    estimatedCubeVolume:0,estimatedCubeSurface:0};
  for(const element of model.elements) {
    if(element?.type==='mesh'){
      result.meshCount++;
      for(const point of Object.values(element.vertices||{})) {
        if(Array.isArray(point)&&!vec3(point))result.invalidVertices++;
      }
      for(const face of Object.values(element.faces||{})) {
        if(!Array.isArray(face?.vertices)||face.vertices.length<3)result.zeroAreaFaces++;
      }
    } else if(!element?.type||element.type==='cube'){
      result.cubeCount++;
      const a=vec3(element?.from),b=vec3(element?.to);
      if(!a||!b){result.invalidVertices++;continue;}
      const w=Math.abs(a[0]-b[0]),h=Math.abs(a[1]-b[1]),d=Math.abs(a[2]-b[2]);
      if(w<1e-7||h<1e-7||d<1e-7)result.zeroVolumeCubes++;
      result.estimatedCubeVolume+=w*h*d;
      result.estimatedCubeSurface+=2*(w*h+w*d+h*d);
    }
  }
  if(!Number.isFinite(result.estimatedCubeVolume)||!Number.isFinite(result.estimatedCubeSurface))
    throw Error('Geometry dimensions overflow');
  return result;
}
