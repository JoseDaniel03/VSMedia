/** Background diagnostics with worker fallback for older or restrictive browsers. */
import {inspectModel} from './model-diagnostics.js';
import {geometryPerformance} from './geometry-performance.js';
export async function analyzeGeometry(model,opts={}) {
  const json=typeof model==='string'?model:JSON.stringify(model);
  if(json.length>64*1024*1024)throw Error('Modelo demasiado grande');
  if(typeof Worker==='undefined')return synchronous(json,opts);
  let worker;
  try {worker=new Worker(new URL('./geometry-worker.js',import.meta.url),{type:'module',name:'VSModel Geometry'});}
  catch{return synchronous(json,opts);}
  return new Promise((resolve,reject)=>{
    let settled=false;
    const finish=(callback,value)=>{if(settled)return;settled=true;clearTimeout(timer);worker.terminate();callback(value);};
    const timer=setTimeout(()=>finish(reject,Error('Análisis de geometría excedió 45 segundos')),45000);
    worker.onmessage=event=>{
      const m=event.data||{};
      if(m.id!==1)return;
      if(m.ok)finish(resolve,m.result);else finish(reject,Error(m.error||'Falló el análisis'));
    };
    const fallback=()=>{try{finish(resolve,synchronous(json,opts));}catch(err){finish(reject,err);}};
    worker.onerror=fallback;
    try{worker.postMessage({id:1,json,options:opts});}catch{fallback();}
  });
}
function synchronous(json,opts){const model=JSON.parse(json);return {...inspectModel(model,opts),performance:geometryPerformance(model),engine:'javascript'};}
