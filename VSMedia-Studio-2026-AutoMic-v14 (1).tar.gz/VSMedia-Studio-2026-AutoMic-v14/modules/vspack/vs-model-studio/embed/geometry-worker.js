/** Dedicated worker: never lets a large model inspection block viewport input. */
import {inspectModel} from './model-diagnostics.js';
import {geometryPerformance} from './geometry-performance.js';
import {RUST_MODEL_WASM_READY} from './wasm-capability.js';
let wasmAvailable = RUST_MODEL_WASM_READY;
self.addEventListener('message', async event => {
  const {id,json,options} = event.data || {};
  if(!Number.isSafeInteger(id)||typeof json!=='string')return;
  try {
    if(json.length>64*1024*1024)throw Error('Modelo demasiado grande');
    const model=JSON.parse(json);
    const report=inspectModel(model,options||{});
    let performance;
    let engine='javascript';
    if(wasmAvailable) {
      try{
        const {geometryPerformanceRust}=await import('./rust-engine.js');
        performance=await geometryPerformanceRust(json);
        engine='rust-wasm';
      }catch{wasmAvailable=false;}
    }
    if(!performance)performance=geometryPerformance(model);
    self.postMessage({id,ok:true,result:{...report,performance,engine}});
  }catch(err){self.postMessage({id,ok:false,error:String(err?.message||err)});}
});
