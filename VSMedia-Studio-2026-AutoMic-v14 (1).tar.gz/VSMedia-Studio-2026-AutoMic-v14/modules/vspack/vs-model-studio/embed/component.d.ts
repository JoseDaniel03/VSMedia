export const VS_MODEL_PROTOCOL: string;
export interface VSModelInfo {
  editorVersion: string;
  hasProject: boolean;
  name: string | null;
  format: string | null;
  uuid: string | null;
  elements: number;
  textures: number;
  animations: number;
  saved: boolean;
}
export declare class VSModelStudio extends HTMLElement {
  language: "es" | "en";
  accent: string;
  readonly ready: boolean;
  readonly whenReady: Promise<VSModelInfo>;
  readonly frame: HTMLIFrameElement;
  request(command: string, payload?: object, timeoutMs?: number): Promise<unknown>;
  ping(): Promise<{protocol: string; info: VSModelInfo}>;
  getInfo(): Promise<VSModelInfo>;
  newProject(format?: string): Promise<VSModelInfo>;
  openModel(model: File | Blob | string | Record<string, unknown>, name?: string): Promise<VSModelInfo>;
  getSnapshot(): Promise<Record<string, unknown>>;
  exportModel(): Promise<string>;
  diagnose(): Promise<{name:string;format:string;elements:number;cubes:number;meshes:number;estimatedTriangles:number;textures:number;groups:number;animations:number;bounds:null|{min:number[];max:number[]};issues:{level:string;what:string}[]}>;
  analyzeModelRust(): Promise<{format: string; elements: number; cubes: number; meshes: number; vertices: number; estimatedTriangles: number; textures: number; groups: number; animations: number; bounds: {min: number[]; max: number[]} | null}>;
  transformVerticesRust(values: Iterable<number>, matrix: Iterable<number>): Promise<number[]>;
  normalizeUVRust(values: Iterable<number>, width: number, height: number): Promise<number[]>;
  undo(): Promise<VSModelInfo>;
  redo(): Promise<VSModelInfo>;
  focusEditor(): Promise<{focused: boolean}>;
  downloadModel(filename?: string): Promise<void>;
}
declare global {
  interface HTMLElementTagNameMap { 'vs-model-studio': VSModelStudio; }
}
