/**
 * VS Model Studio embedded bridge for the original Blockbench web editor.
 * GPL-3.0-or-later; see LICENSE.MD. No external JS dependencies.
 * The bridge is disabled for normal standalone Blockbench use.
 */
const PROTOCOL = 'vs-model-studio/v1';
const params = new URLSearchParams(location.search);
const embedding = window.parent !== window && params.get('vs_embed') === '1';

if (embedding) {
  // A missing origin means same-origin only. Never default to wildcard.
  const requestedOrigin = params.get('vs_parent_origin');
  let allowedOrigin;
  try {
    allowedOrigin = requestedOrigin ? new URL(requestedOrigin).origin : location.origin;
  } catch {
    allowedOrigin = location.origin;
  }
  const parentWindow = window.parent;
  let handshake = false;
  let listenersInstalled = false;
  let started = false;
  const post = (type, data = {}) => {
    if (!handshake) return;
    parentWindow.postMessage({ protocol: PROTOCOL, type, ...data }, allowedOrigin);
  };
  const ready = () => Boolean(window.Blockbench?.setup_successful && window.Codecs?.project && window.Formats);
  const info = () => {
    const project = window.Blockbench?.Project;
    return {
      editorVersion: window.Blockbench?.version || 'unknown',
      hasProject: Boolean(project),
      name: project?.name || null,
      format: project?.format?.id || null,
      uuid: project?.uuid || null,
      elements: Array.isArray(project?.elements) ? project.elements.length : 0,
      textures: Array.isArray(project?.textures) ? project.textures.length : 0,
      animations: Array.isArray(project?.animations) ? project.animations.length : 0,
      saved: project?.saved ?? true
    };
  };
  const postProjectEvent = (name) => post('event', { name, payload: info() });
  let changeTimer = 0;
  const scheduleProjectEvent = (name) => {
    // A sculpt/paint stroke can dispatch many events in rapid succession.
    // Keep the host dirty indicator current without spamming postMessage.
    if(changeTimer) clearTimeout(changeTimer);
    changeTimer = setTimeout(() => {changeTimer=0;postProjectEvent(name);}, 75);
  };
  // In embedded mode Ctrl/Cmd+S saves to the selected VSPack project, not
  // to a detached local file. The host performs the actual IndexedDB write.
  document.addEventListener('keydown', event => {
    if (!handshake || !ready() || event.repeat) return;
    if ((event.ctrlKey || event.metaKey) && !event.altKey && !event.shiftKey && event.key?.toLowerCase() === 's') {
      event.preventDefault();
      event.stopImmediatePropagation();
      postProjectEvent('save_shortcut');
    }
  }, true);
  const setupListeners = () => {
    if (listenersInstalled) return;
    listenersInstalled = true;
    const immediate = ['new_project', 'select_project', 'close_project', 'save_project'];
    for(const name of immediate) window.Blockbench.on(name, () => postProjectEvent(name));
    for(const name of ['finished_edit', 'undo', 'redo', 'edit_texture', 'edit_layer_properties']) {
      window.Blockbench.on(name, () => scheduleProjectEvent(name));
    }
  };
  const signalReady = () => {
    if (!handshake || !ready() || started) return;
    started = true;
    setupListeners();
    post('ready', { info: info() });
  };
  const boot = () => {
    if (ready()) signalReady();
    else setTimeout(boot, 100);
  };
  boot();

  function parseModel(value, name = '') {
    if (typeof value === 'string') {
      if (value.length > 64 * 1024 * 1024) throw new Error('Model exceeds 64 MiB limit');
      value = JSON.parse(value);
    }
    if (!value || typeof value !== 'object' || Array.isArray(value)) {
      throw new Error('Invalid model: expected a JSON object');
    }
    if (!/\.json$/i.test(name) && (!value.meta || typeof value.meta !== 'object')) {
      throw new Error('Invalid .bbmodel: missing meta');
    }
    return value;
  }

  async function execute(command, payload) {
    const p = payload ?? {};
    if (command === 'ping') return { protocol: PROTOCOL, info: info() };
    if (command === 'info') return info();
    if (command === 'open') {
      // Keep the full resource-pack path: the original Minecraft codec uses
      // /assets/<namespace>/models/... to resolve parent models and PNGs.
      const incoming = typeof p.name === 'string' ? p.name.replaceAll('\\','/') : '';
      const safe = /^(?:assets\/[a-z0-9_.-]+\/(?:models|items|blockstates)\/[a-z0-9_./-]+\.json|[a-z0-9_.\/-]+\.bbmodel|[a-z0-9_.-]+\.json)$/.test(incoming)
        && !incoming.split('/').some(x => x==='.'||x==='..'||!x);
      // Blockbench's Java parser needs a nonempty pack root to honor the
      // namespace of references such as minecraft:block/cube_all. Without
      // it, a relative assets/foo/models path is resolved under foo even
      // when the parent belongs to minecraft.
      const path = safe ? (incoming.startsWith('assets/') ? '__vspack__/'+incoming.slice(0,256) : incoming.endsWith('.json') ? '__vspack__/assets/minecraft/models/block/'+incoming.slice(0,128) : incoming.slice(0,256)) : 'embedded.bbmodel';
      const name = path.split('/').pop();
      const model = parseModel(p.model, path);
      const codec = /\.json$/i.test(path) ? window.Codecs.java_block : window.Codecs.project;
      if (!codec || typeof codec.load !== 'function') throw Error('Blockbench no dispone del codec para '+name);
      const lookup = p.resources && typeof p.resources==='object' ? p.resources : {};
      let checked = 0, size = 0;
      for(const [key,value] of Object.entries(lookup)){
        if(++checked>160 || typeof value!=='string' || typeof key!=='string' || key.length>250
          || !/^assets\/[a-z0-9_.-]+\/(?:models|textures)\/[a-z0-9_./-]+\.(?:json|png)$/.test(key)
          || key.split('/').some(x=>x==='.'||x==='..'||!x)
          || (size+=value.length)>36*1024*1024)
          throw Error('El pack contiene referencias externas demasiado grandes o inválidas.');
      }
      const externalDataLoader = resourcePath => {
        const key=String(resourcePath).replaceAll('\\','/').replace(/^__vspack__\//,'');
        if (Object.prototype.hasOwnProperty.call(lookup,key)) return lookup[key];
        // Web browsers cannot read file:/// paths. A temporary visible PNG
        // placeholder prevents Blockbench's missing-texture fallback from
        // trying to load the host's filesystem; it is never written to packs.
        if (/^assets\/[a-z0-9_.-]+\/textures\/[a-z0-9_./-]+\.png$/.test(key))
          return 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAALklEQVR42mP8z/D/PwMewMjAiE+agYmBQjBqwGAwgJGBgQFvOviPX3o0EIeHAQAx+gYb4dE3FQAAAABJRU5ErkJggg==';
        return undefined;
      };
      // Reuse the actual Blockbench Java codec (not an invented 3D renderer).
      codec.load(model, { path, name }, { externalDataLoader });
      return info();
    }
    if (command === 'new') {
      const format = typeof p.format === 'string' && p.format in window.Formats
        ? p.format : 'free';
      // setupProject is exposed as a global by the upstream app.
      if (typeof window.newProject !== 'function') {
        throw new Error('Upstream newProject API is unavailable');
      }
      window.newProject(format);
      return info();
    }
    if (command === 'export_textures') {
      if (!window.Blockbench.Project) throw Error('No hay un proyecto abierto');
      const textures = Array.isArray(window.Blockbench.Project.textures) ? window.Blockbench.Project.textures : [];
      if (textures.length > 64) throw Error('Demasiadas texturas: exportá en grupos de hasta 64');
      let total = 0;
      return textures.map((texture, index) => {
        if (!texture || typeof texture.getDataURL !== 'function') return null;
        const dataUrl = texture.getDataURL();
        if (!/^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(dataUrl)) return null;
        total += dataUrl.length;
        if (total > 32 * 1024 * 1024) throw Error('Texturas demasiado grandes para el guardado masivo');
        return { name: String(texture.name || `textura_${index+1}.png`).slice(0,128), dataUrl };
      }).filter(Boolean);
    }
    if (command === 'snapshot') {
      if (!window.Blockbench.Project) throw new Error('No project is open');
      // raw:true returns a lossless JS object including embedded texture data.
      const result = window.Codecs.project.compile({ raw: true, bitmaps: true });
      return typeof result === 'string' ? JSON.parse(result) : result;
    }
    if (command === 'export') {
      if (!window.Blockbench.Project) throw new Error('No project is open');
      const codec = p.format === 'java_block' ? window.Codecs?.java_block : window.Codecs?.project;
      if (!codec) throw Error('Codec de exportación no disponible');
      const result = codec.compile({ bitmaps: true });
      return typeof result === 'string' ? result : JSON.stringify(result);
    }
    if (command === 'mark_saved') {
      if (!window.Blockbench.Project) throw Error('No project is open');
      window.Blockbench.Project.saved = true;
      postProjectEvent('save_project');
      return info();
    }
    if (command === 'diagnose') {
      if (!window.Blockbench.Project) throw Error('No hay un proyecto abierto');
      const raw = window.Codecs.project.compile({raw:true, bitmaps:false});
      const model = typeof raw==='string' ? JSON.parse(raw) : raw;
      const {analyzeGeometry} = await import('./geometry-runner.js');
      return analyzeGeometry(model, {javaFormat: window.Blockbench.Project?.format?.id==='java_block'});
    }
    if (command === 'analyze_rust') {
      if (!window.Blockbench.Project) throw new Error('No project is open');
      const raw = window.Codecs.project.compile({ raw: true, bitmaps: false });
      const { analyzeBBModelRust } = await import('./rust-engine.js');
      return await analyzeBBModelRust(raw);
    }
    if (command === 'transform_rust' || command === 'normalize_uv_rust') {
      const { transformVerticesRust, normalizeUVRust } = await import('./rust-engine.js');
      const values = p.values;
      if (!Array.isArray(values) || values.length > 1_000_000) throw new Error('Invalid array payload');
      if (command === 'transform_rust') {
        if (!Array.isArray(p.matrix) || p.matrix.length !== 16) throw new Error('Expected 4x4 matrix');
        return Array.from(await transformVerticesRust(values, p.matrix));
      }
      return Array.from(await normalizeUVRust(values, p.width, p.height));
    }
    if (command === 'undo' || command === 'redo') {
      if (!window.Blockbench.Project) throw new Error('No project is open');
      const undo = window.Undo;
      if (!undo || typeof undo[command] !== 'function') throw new Error('Undo/redo not available');
      undo[command]();
      postProjectEvent('edit');
      return info();
    }
    if (command === 'focus') {
      window.focus();
      document.getElementById('preview')?.focus();
      return { focused: true };
    }
    throw new Error(`Unsupported command: ${String(command)}`);
  }

  let operationQueue = Promise.resolve();
  window.addEventListener('message', async (event) => {
    if (event.source !== parentWindow || event.origin !== allowedOrigin) return;
    const message = event.data;
    if (!message || message.protocol !== PROTOCOL) return;
    if (message.type === 'hello') {
      handshake = true;
      signalReady();
      return;
    }
    if (!handshake || message.type !== 'request' || !ready()) return;
    const id = message.id;
    if (!Number.isSafeInteger(id) || id < 1) return;
    try {
      // Blockbench codecs mutate global project state; operations must be serialized.
      const operation = operationQueue.catch(() => {}).then(() => execute(message.command, message.payload));
      operationQueue = operation;
      const result = await operation;
      post('response', { id, ok: true, result });
    } catch (error) {
      post('response', { id, ok: false, error: error?.message || String(error) });
    }
  });
}
