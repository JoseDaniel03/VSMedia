/**
 * <vs-model-studio> framework-independent Web Component (GPL-3.0-or-later).
 * Mount original Blockbench web app in a frame, retaining its native controls.
 * Security: the frame and parent validate origins and window identity.
 */
export const VS_MODEL_PROTOCOL = 'vs-model-studio/v1';

const css = `:host{display:block;width:100%;height:100%;min-height:360px;position:relative;overflow:hidden;background:#121418} iframe{display:block;width:100%;height:100%;border:0;background:#121418} .error{display:none;position:absolute;inset:0;place-items:center;background:#1a1e25;color:#fff;font:14px system-ui;padding:24px;text-align:center} :host([data-error]) .error{display:grid}`;

export class VSModelStudio extends HTMLElement {
  static get observedAttributes() { return ['editor-url', 'language', 'accent']; }
  #frame;
  #ready = false;
  #readyPromise;
  #resolveReady;
  #rejectReady;
  #pending = new Map();
  #nextId = 1;
  #frameOrigin;
  #boundMessage;
  #startupTimer;
  #connected = false;

  constructor() {
    super();
    const root = this.attachShadow({ mode: 'open' });
    const style = document.createElement('style');
    style.textContent = css;
    this.#frame = document.createElement('iframe');
    this.#frame.title = 'VS Model Studio · Blockbench';
    this.#frame.setAttribute('allow', 'fullscreen');
    this.#frame.setAttribute('loading', 'eager');
    this.#frame.addEventListener('load', () => {
      this.#post({ type: 'hello' });
    });
    const error = document.createElement('div');
    error.className = 'error';
    error.setAttribute('part', 'error');
    root.append(style, this.#frame, error);
    this.#resetReady();
    this.#boundMessage = this.#onMessage.bind(this);
  }

  connectedCallback() {
    if (this.#connected) return;
    this.#connected = true;
    window.addEventListener('message', this.#boundMessage);
    this.#navigate();
  }

  disconnectedCallback() {
    this.#connected = false;
    window.removeEventListener('message', this.#boundMessage);
    clearTimeout(this.#startupTimer);
    this.#cancelPending(new Error('VS Model Studio has been disconnected'));
    this.#rejectReady?.(new Error('VS Model Studio has been disconnected'));
    // Avoid unhandled rejection if no caller was awaiting readiness.
    this.#readyPromise?.catch(() => {});
  }

  attributeChangedCallback(name, before, after) {
    if (before !== after && this.#connected && ['editor-url', 'language', 'accent'].includes(name)) this.#navigate();
  }

  #resetReady() {
    this.#ready = false;
    this.#readyPromise = new Promise((resolve, reject) => {
      this.#resolveReady = resolve;
      this.#rejectReady = reject;
    });
    this.#readyPromise.catch(() => {});
  }

  #cancelPending(reason) {
    for (const [, { reject, timer }] of this.#pending) {
      clearTimeout(timer);
      reject(reason);
    }
    this.#pending.clear();
  }

  #navigate() {
    clearTimeout(this.#startupTimer);
    this.#cancelPending(new Error('Editor was reloaded'));
    this.#rejectReady?.(new Error('Editor was reloaded'));
    this.#resetReady();
    this.removeAttribute('data-error');
    let target;
    try {
      // The provided URL points to the ORIGINAL editor's index.html.
      // Relative URL defaults to a sibling editor/ folder on the host.
      target = new URL(this.getAttribute('editor-url') || './editor/index.html', document.baseURI);
      if (!['http:', 'https:'].includes(target.protocol)) throw Error('Only HTTP(S) editor URLs are allowed');
      this.#frameOrigin = target.origin;
      target.searchParams.set('vs_embed', '1');
      const preferredLanguage = this.getAttribute('language') || (typeof navigator !== 'undefined' && navigator.language?.toLowerCase().startsWith('es') ? 'es' : 'en');
      target.searchParams.set('vs_lang', preferredLanguage === 'en' ? 'en' : 'es');
      const requestedAccent = this.getAttribute('accent') || '#c8a96c';
      target.searchParams.set('vs_accent', /^#[a-fA-F0-9]{6}$/.test(requestedAccent) ? requestedAccent : '#c8a96c');
      target.searchParams.set('vs_parent_origin', location.origin);
      this.#frame.src = target.href;
      this.#startupTimer = setTimeout(() => {
        if (!this.#ready) this.#fail(new Error('Editor did not become ready. Verify that dist/bundle.js is built and the editor URL is correct.'));
      }, 45000);
    } catch (err) {
      this.#fail(err);
    }
  }

  #post(message) {
    if (!this.#frame.contentWindow || !this.#frameOrigin) return;
    this.#frame.contentWindow.postMessage({ protocol: VS_MODEL_PROTOCOL, ...message }, this.#frameOrigin);
  }

  #onMessage(event) {
    if (event.source !== this.#frame.contentWindow || event.origin !== this.#frameOrigin) return;
    const data = event.data;
    if (!data || data.protocol !== VS_MODEL_PROTOCOL) return;
    if (data.type === 'ready') {
      clearTimeout(this.#startupTimer);
      this.#ready = true;
      this.#resolveReady?.(data.info);
      this.dispatchEvent(new CustomEvent('vs-ready', { detail: data.info }));
      return;
    }
    if (data.type === 'event') {
      this.dispatchEvent(new CustomEvent('vs-event', { detail: data }));
      this.dispatchEvent(new CustomEvent('vs-project-changed', { detail: data }));
      return;
    }
    if (data.type === 'response') {
      const task = this.#pending.get(data.id);
      if (!task) return;
      this.#pending.delete(data.id);
      clearTimeout(task.timer);
      if (data.ok) task.resolve(data.result);
      else task.reject(new Error(data.error || 'Unknown editor failure'));
    }
  }

  #fail(error) {
    clearTimeout(this.#startupTimer);
    this.setAttribute('data-error', '');
    this.shadowRoot.querySelector('.error').textContent = String(error?.message || error);
    this.#rejectReady?.(error);
    this.dispatchEvent(new CustomEvent('vs-error', { detail: error }));
  }

  get language() { return this.getAttribute('language') || 'es'; }
  set language(value) { this.setAttribute('language', value === 'en' ? 'en' : 'es'); }
  get accent() { return this.getAttribute('accent') || '#c8a96c'; }
  set accent(value) { this.setAttribute('accent', value); }
  get ready() { return this.#ready; }
  get whenReady() { return this.#readyPromise; }
  get frame() { return this.#frame; }

  async request(command, payload = {}, timeoutMs = 30000) {
    if (!this.#connected) throw new Error('Attach <vs-model-studio> before calling methods');
    await this.whenReady;
    const id = this.#nextId++;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.#pending.delete(id);
        reject(new Error(`Timed out waiting for ${command}`));
      }, timeoutMs);
      this.#pending.set(id, { resolve, reject, timer });
      this.#post({ type: 'request', id, command, payload });
    });
  }

  ping() { return this.request('ping'); }
  getInfo() { return this.request('info'); }
  newProject(format = 'free') { return this.request('new', { format }); }
  async openModel(model, name = 'embedded.bbmodel', resources = null) {
    if (model instanceof File || model instanceof Blob) model = await model.text();
    return this.request('open', { model, name, resources }, 120000);
  }
  getSnapshot() { return this.request('snapshot', {}, 60000); }
  exportTextures() { return this.request('export_textures', {}, 90000); }
  exportModel(format = 'project') { return this.request('export', { format }, 60000); }
  markSaved() { return this.request('mark_saved'); }
  /** Rust/WASM-only methods require a compiled wasm/vs_model_core package. */
  diagnose() { return this.request('diagnose', {}, 60000); }
  analyzeModelRust() { return this.request('analyze_rust', {}, 60000); }
  transformVerticesRust(values, matrix) { return this.request('transform_rust', { values: Array.from(values), matrix: Array.from(matrix) }, 60000); }
  normalizeUVRust(values, width, height) { return this.request('normalize_uv_rust', { values: Array.from(values), width, height }, 60000); }
  undo() { return this.request('undo'); }
  redo() { return this.request('redo'); }
  focusEditor() { return this.request('focus'); }

  async downloadModel(filename = 'model.bbmodel') {
    const contents = await this.exportModel();
    const blob = new Blob([contents], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    try {
      const a = document.createElement('a');
      a.href = url;
      a.download = String(filename).replace(/[\\/]/g, '_');
      a.click();
    } finally {
      setTimeout(() => URL.revokeObjectURL(url), 1500);
    }
  }
}

if (!customElements.get('vs-model-studio')) {
  customElements.define('vs-model-studio', VSModelStudio);
}
