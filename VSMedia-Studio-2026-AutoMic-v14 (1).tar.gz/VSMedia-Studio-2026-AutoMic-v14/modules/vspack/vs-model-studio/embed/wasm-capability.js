// Set to true only by build-rust-model-once.sh after the WASM binary exists.
// The shipped static app avoids 404s and repeated failed imports.
export const RUST_MODEL_WASM_READY = false;
