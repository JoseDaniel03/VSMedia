#!/usr/bin/env bash
# Inicio rápido de la demo local VS Model Studio en CachyOS/Linux.
set -Eeuo pipefail
cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")"
PORT="${VS_MODEL_PORT:-3070}"
URL="http://127.0.0.1:${PORT}/demo/"
printf '\n===============================================\n'
printf '   VS Model Studio — vista previa del componente\n'
printf '===============================================\n'
printf 'URL: %s\n' "$URL"
if ! command -v node >/dev/null; then
  echo 'Falta Node.js >=20. En CachyOS: sudo pacman -S nodejs npm'
  exit 1
fi
if ! command -v npm >/dev/null; then
  echo 'Falta npm. En CachyOS: sudo pacman -S npm'
  exit 1
fi
if ! command -v python3 >/dev/null && ! command -v rustc >/dev/null; then
  echo 'Falta un servidor HTTP. Instalá Python: sudo pacman -S python'
  exit 1
fi
if [ ! -f dist/bundle.js ]; then
  printf '\nPrimera ejecución: necesita descargar dependencias de npm\n'
  printf 'y compilar el Blockbench original. Requiere internet.\n\n'
fi
# Abrir la pestaña cuando el servidor realmente esté disponible, no antes.
(
  for _ in $(seq 1 1200); do
    if command -v curl >/dev/null && curl -fsS --max-time 1 "$URL" >/dev/null 2>&1; then
      printf '\nVISTA PREVIA DISPONIBLE: %s\n' "$URL"
      if command -v xdg-open >/dev/null; then xdg-open "$URL" >/dev/null 2>&1 || true; fi
      exit 0
    fi
    sleep 1
  done
) &
watcher=$!
cleanup() { kill "$watcher" 2>/dev/null || true; }
trap cleanup EXIT
bash ./scripts/start.sh
