#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
npm ci --ignore-scripts --no-audit --no-fund
npm run build-web
if command -v wasm-pack >/dev/null 2>&1; then
  cd crates/vs_model_core
  wasm-pack build --release --target web --features wasm --out-dir ../../wasm
  echo 'WASM generado en wasm/'
else
  echo 'wasm-pack no instalado: compilación WebAssembly opcional omitida.'
fi
