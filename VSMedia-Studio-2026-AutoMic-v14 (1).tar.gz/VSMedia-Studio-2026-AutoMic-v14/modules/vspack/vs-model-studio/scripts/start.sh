#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
PORT="${VS_MODEL_PORT:-3070}"
if [[ ! -f dist/bundle.js ]]; then
  echo 'Preparando el bundle web original de Blockbench (requiere npm y acceso a los paquetes)…'
  npm ci --ignore-scripts --no-audit --no-fund
  npm run build-web
fi
node scripts/patch-embedded-bundle.mjs
if command -v rustc >/dev/null 2>&1; then
  mkdir -p bin
  if [[ ! -x bin/vs_model_server || crates/vs_model_server/src/main.rs -nt bin/vs_model_server ]]; then
    rustc --edition=2021 -O crates/vs_model_server/src/main.rs -o bin/vs_model_server
  fi
  export VS_MODEL_BIND="${VS_MODEL_BIND:-127.0.0.1:$PORT}"
  exec ./bin/vs_model_server .
fi
echo 'Rust no disponible; usando servidor HTTP Python como alternativa de prueba.'
exec python3 -m http.server "$PORT" --bind 127.0.0.1
