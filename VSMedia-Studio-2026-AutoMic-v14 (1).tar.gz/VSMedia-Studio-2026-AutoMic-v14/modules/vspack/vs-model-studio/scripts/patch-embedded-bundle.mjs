/**
 * Apply small compatibility fixes to the original Blockbench web bundle.
 *
 * Blockbench/esbuild can produce different numbers of identical expressions
 * between builds (for example ErrorLog.length occurs once on Node 26 and
 * twice in the previously distributed bundle). Never rely on fixed counts.
 *
 * The script is idempotent and retains existing patched occurrences while
 * patching any remaining original occurrences. This is a packaging step,
 * not a runtime replacement of Blockbench or Three.js.
 *
 * GPL-3.0-or-later; upstream-derived integration patch.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const dirname = path.dirname(fileURLToPath(import.meta.url));
const bundle = path.resolve(dirname, '../dist/bundle.js');
if (!fs.existsSync(bundle) || !fs.statSync(bundle).size) {
  throw Error(`No se encontró el bundle compilado de Blockbench: ${bundle}`);
}
let source = fs.readFileSync(bundle, 'utf8');
const original = source;
const guards = [
  {
    name: 'ErrorLog: menú de errores',
    from: 'window.ErrorLog.length',
    to: '(window.ErrorLog||[]).length',
  },
  {
    name: 'ErrorLog: lista de errores',
    from: 'window.ErrorLog.map(',
    to: '(window.ErrorLog||[]).map(',
  },
  {
    name: 'Service Worker: desactivar en iframe',
    from: 'if("serviceWorker"in navigator)try',
    to: 'if(!document.documentElement.classList.contains("vs-embedded")&&"serviceWorker"in navigator)try',
  },
  {
    name: 'Estadísticas remotas: evitar CORS en iframe',
    from: '$.getJSON("https://blckbn.ch/api/stats/plugins?weeks=2",i=>',
    to: '!document.documentElement.classList.contains("vs-embedded")&&$.getJSON("https://blckbn.ch/api/stats/plugins?weeks=2",i=>',
  },
];

let changed = 0;
for (const [idx, guard] of guards.entries()) {
  // The destination may include the original string (notably the jQuery
  // expression). Protect already-patched spans before searching for raw ones.
  // Otherwise a second run could add the same prefix repeatedly.
  const marker = `\u0000VSMEDIA_PATCHED_${idx}_\u0000`;
  if (source.includes(marker)) throw Error('Marker conflict in Blockbench bundle');
  const prepatched = source.split(guard.to).length - 1;
  const masked = source.replaceAll(guard.to, marker);
  const pending = masked.split(guard.from).length - 1;
  source = masked.replaceAll(guard.from, guard.to).replaceAll(marker, guard.to);
  changed += pending;
  if (prepatched + pending === 0) {
    // Some upstream releases remove or rewrite these snippets entirely.
    // A missing optional compatibility pattern must NOT prevent startup.
    console.warn(`[Blockbench] Patrón no presente (${guard.name}); no se aplica.`);
  } else {
    console.log(`[Blockbench] ${guard.name}: ${pending} cambios, ${prepatched} existentes.`);
  }
}

if (source !== original) {
  // Write to a temp file and atomically replace to avoid a truncated bundle.
  const temp = `${bundle}.vsmedia-tmp-${process.pid}`;
  try {
    fs.writeFileSync(temp, source, { mode: fs.statSync(bundle).mode });
    fs.renameSync(temp, bundle);
  } finally {
    if (fs.existsSync(temp)) fs.unlinkSync(temp);
  }
}
console.log(`[Blockbench] Parches de integración listos (${changed} aplicados; bundle ${source.length} caracteres).`);
