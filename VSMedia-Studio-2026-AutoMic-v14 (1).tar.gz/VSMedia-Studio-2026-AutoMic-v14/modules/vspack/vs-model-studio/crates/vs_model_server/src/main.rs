//! Tiny zero-dependency Rust development web server for embedded Blockbench.
//! Not an internet-facing reverse proxy. Deploy built files via nginx/Caddy for production.
use std::{env, fs, io::{Read, Write}, net::{TcpListener, TcpStream}, path::{Path, PathBuf}, time::Duration};

fn mime(path: &Path) -> &'static str {
    match path.extension().and_then(|s| s.to_str()).unwrap_or("") {
        "html" => "text/html; charset=utf-8", "js" | "mjs" => "text/javascript; charset=utf-8",
        "css" => "text/css; charset=utf-8", "json" | "bbmodel" | "webmanifest" => "application/json",
        "png" => "image/png", "jpg" | "jpeg" => "image/jpeg", "svg" => "image/svg+xml",
        "gif" => "image/gif", "webp" => "image/webp", "ico" => "image/x-icon",
        "wasm" => "application/wasm", "woff" => "font/woff", "woff2" => "font/woff2",
        "ttf" => "font/ttf", "map" => "application/json", _ => "application/octet-stream",
    }
}

fn decode_path(input: &str) -> Option<String> {
    let bytes = input.as_bytes();
    let mut decoded = Vec::with_capacity(bytes.len());
    let mut pos = 0;
    while pos < bytes.len() {
        if bytes[pos] == b'%' {
            let hi = (bytes.get(pos + 1)?.to_ascii_lowercase() as char).to_digit(16)?;
            let lo = (bytes.get(pos + 2)?.to_ascii_lowercase() as char).to_digit(16)?;
            decoded.push((hi * 16 + lo) as u8);
            pos += 3;
        } else {
            decoded.push(bytes[pos]);
            pos += 1;
        }
    }
    String::from_utf8(decoded).ok()
}

fn response(stream: &mut TcpStream, status: &str, content_type: &str, contents: &[u8], head: bool) {
    let header = format!("HTTP/1.1 {status}\r\nContent-Type: {content_type}\r\nContent-Length: {}\r\nX-Content-Type-Options: nosniff\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n", contents.len());
    let _ = stream.write_all(header.as_bytes());
    if !head { let _ = stream.write_all(contents); }
}

fn serve(mut stream: TcpStream, root: &Path) {
    let _ = stream.set_read_timeout(Some(Duration::from_secs(4)));
    let _ = stream.set_write_timeout(Some(Duration::from_secs(15)));
    let mut buf = [0u8; 8192];
    let len = match stream.read(&mut buf) { Ok(n) => n, Err(_) => return };
    let line = match std::str::from_utf8(&buf[..len]).ok().and_then(|t| t.lines().next()) {
        Some(line) => line,
        None => return,
    };
    let mut parts = line.split_whitespace();
    let method = parts.next().unwrap_or("");
    let path = parts.next().unwrap_or("").split(['?', '#']).next().unwrap_or("");
    if !matches!(method, "GET" | "HEAD") {
        return response(&mut stream, "405 Method Not Allowed", "text/plain", b"GET/HEAD only", false);
    }
    let head = method == "HEAD";
    if path == "/healthz" { return response(&mut stream, "200 OK", "application/json", b"{\"ok\":true}", head); }
    let decoded = match decode_path(path) {
        Some(s) if s.starts_with('/') => s,
        _ => return response(&mut stream, "400 Bad Request", "text/plain", b"Bad path", head),
    };
    let relative = decoded.trim_start_matches('/');
    if relative.split('/').any(|part| part == ".." || part.contains('\\') || part.contains('\0')) {
        return response(&mut stream, "403 Forbidden", "text/plain", b"Forbidden", head);
    }
    let mut target = root.join(relative);
    if target.is_dir() { target.push("index.html"); }
    let target = match fs::canonicalize(&target) {
        Ok(path) if path.starts_with(root) && path.is_file() => path,
        _ => return response(&mut stream, "404 Not Found", "text/plain", b"Not found", head),
    };
    match fs::read(&target) {
        Ok(contents) => response(&mut stream, "200 OK", mime(&target), &contents, head),
        Err(_) => response(&mut stream, "500 Internal Server Error", "text/plain", b"Cannot read file", head),
    }
}

fn main() -> std::io::Result<()> {
    let path = env::args().nth(1).unwrap_or_else(|| ".".to_owned());
    let root: PathBuf = fs::canonicalize(&path)?;
    let bind = env::var("VS_MODEL_BIND").unwrap_or_else(|_| "127.0.0.1:3070".into());
    let listener = TcpListener::bind(&bind)?;
    // Both the standalone Blockbench directory and the full VSMedia root work.
    let in_vsm = root.join("modules/vspack/vs-model-studio/dist/bundle.js").is_file();
    let app_name = if in_vsm { "VSMedia Studio" } else { "VS Model Studio" };
    println!("{app_name} (servidor Rust): http://{bind}/ · {}", root.display());
    if !in_vsm && !root.join("dist/bundle.js").is_file() {
        eprintln!("Aviso: no se encontró dist/bundle.js. Ejecutá ./start.sh para compilar.");
    }
    for stream in listener.incoming() {
        match stream {
            Ok(stream) => {
                let root = root.clone();
                std::thread::spawn(move || serve(stream, &root));
            }
            Err(err) => eprintln!("Connection error: {err}"),
        }
    }
    Ok(())
}
