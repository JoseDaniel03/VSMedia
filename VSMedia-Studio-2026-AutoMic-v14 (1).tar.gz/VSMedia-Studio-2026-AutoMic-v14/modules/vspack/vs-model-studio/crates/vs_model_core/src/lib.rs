//! VS Model Core — Rust geometry and .bbmodel analysis for web and native hosts.
//! Preserves the original Blockbench JSON format without rewriting its codecs.
//! Licensing: GPL-3.0-or-later.
use serde::{Deserialize, Serialize};
use serde_json::Value;

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Bounds {
    pub min: [f64; 3],
    pub max: [f64; 3],
}
impl Bounds {
    fn extend(&mut self, p: [f64; 3]) {
        for (axis, value) in p.into_iter().enumerate() {
            self.min[axis] = self.min[axis].min(value);
            self.max[axis] = self.max[axis].max(value);
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ModelStats {
    pub format: String,
    pub name: Option<String>,
    pub elements: usize,
    pub cubes: usize,
    pub meshes: usize,
    pub vertices: usize,
    pub estimated_triangles: usize,
    pub textures: usize,
    pub groups: usize,
    pub animations: usize,
    pub bounds: Option<Bounds>,
}

fn vec3(v: &Value) -> Option<[f64; 3]> {
    let array = v.as_array()?;
    if array.len() < 3 { return None; }
    let result = [array[0].as_f64()?, array[1].as_f64()?, array[2].as_f64()?];
    result.into_iter().all(f64::is_finite).then_some(result)
}

fn add_point(bounds: &mut Option<Bounds>, point: [f64; 3]) {
    if let Some(bounds) = bounds.as_mut() {
        bounds.extend(point);
    } else {
        *bounds = Some(Bounds { min: point, max: point });
    }
}

/// Validate and inspect Blockbench JSON. Does not modify or drop unknown fields.
/// Geometry statistics are estimates: visibility/material/transform not baked.
pub fn analyze_bbmodel(json: &str) -> Result<ModelStats, String> {
    const LIMIT: usize = 64 * 1024 * 1024;
    if json.len() > LIMIT { return Err(".bbmodel exceeds 64 MiB".into()); }
    let model: Value = serde_json::from_str(json).map_err(|e| e.to_string())?;
    let meta = model.get("meta").and_then(Value::as_object)
        .ok_or("Invalid .bbmodel: missing meta object")?;
    let format = meta.get("model_format").and_then(Value::as_str)
        .unwrap_or("free").to_string();
    let elements = model.get("elements").and_then(Value::as_array);
    let mut result = ModelStats {
        format,
        name: model.get("name").and_then(Value::as_str).map(str::to_string),
        elements: elements.map_or(0, Vec::len),
        cubes: 0,
        meshes: 0,
        vertices: 0,
        estimated_triangles: 0,
        textures: model.get("textures").and_then(Value::as_array).map_or(0, Vec::len),
        groups: model.get("groups").and_then(Value::as_array).map_or(0, Vec::len),
        animations: model.get("animations").and_then(Value::as_array).map_or(0, Vec::len),
        bounds: None,
    };
    for element in elements.into_iter().flatten() {
        match element.get("type").and_then(Value::as_str).unwrap_or("cube") {
            "cube" => {
                result.cubes += 1;
                if let (Some(from), Some(to)) = (element.get("from").and_then(vec3), element.get("to").and_then(vec3)) {
                    add_point(&mut result.bounds, from);
                    add_point(&mut result.bounds, to);
                    result.vertices += 8;
                }
                // Each visible quad is two triangles; missing faces assumed whole cube.
                let face_count = element.get("faces").and_then(Value::as_object)
                    .map(|f| f.values().filter(|face| !face.is_null()).count()).unwrap_or(6);
                result.estimated_triangles += face_count * 2;
            }
            "mesh" => {
                result.meshes += 1;
                if let Some(vertices) = element.get("vertices").and_then(Value::as_object) {
                    result.vertices += vertices.len();
                    for point in vertices.values().filter_map(vec3) {
                        add_point(&mut result.bounds, point);
                    }
                }
                if let Some(faces) = element.get("faces").and_then(Value::as_object) {
                    for face in faces.values() {
                        let n = face.get("vertices").and_then(Value::as_array).map_or(0, Vec::len);
                        result.estimated_triangles += n.saturating_sub(2);
                    }
                }
            }
            _ => {}
        }
    }
    Ok(result)
}

/// Multiply xyz positions by a 4×4 column-major matrix (Three.js convention).
/// Returns errors rather than emitting NaN/Inf and corrupting editor state.
pub fn transform_positions(positions: &[f32], m: &[f32]) -> Result<Vec<f32>, String> {
    if m.len() != 16 || positions.len() % 3 != 0 {
        return Err("Expected a 4x4 matrix and packed xyz positions".into());
    }
    if !m.iter().chain(positions).all(|f| f.is_finite()) {
        return Err("Geometry contains non-finite numbers".into());
    }
    let mut transformed = Vec::with_capacity(positions.len());
    for p in positions.chunks_exact(3) {
        let (x, y, z) = (p[0], p[1], p[2]);
        let w = m[3] * x + m[7] * y + m[11] * z + m[15];
        if w.abs() < 1e-7 { return Err("Invalid perspective division".into()); }
        let values = [
            (m[0] * x + m[4] * y + m[8] * z + m[12]) / w,
            (m[1] * x + m[5] * y + m[9] * z + m[13]) / w,
            (m[2] * x + m[6] * y + m[10] * z + m[14]) / w,
        ];
        if !values.into_iter().all(f32::is_finite) { return Err("Transform overflow".into()); }
        transformed.extend_from_slice(&values);
    }
    Ok(transformed)
}

/// Convert pixel UV pairs into texture-space coordinates.
pub fn normalize_uv(uv: &[f32], width: f32, height: f32) -> Result<Vec<f32>, String> {
    if uv.len() % 2 != 0 || !width.is_finite() || !height.is_finite() || width <= 0.0 || height <= 0.0
        || !uv.iter().all(|f| f.is_finite()) {
        return Err("Invalid UV pairs or texture dimensions".into());
    }
    Ok(uv.chunks_exact(2).flat_map(|pair| [pair[0] / width, pair[1] / height]).collect())
}

/// Compact geometry quality/performance summary. These values are geometric
/// estimates, not a promise of GPU triangle counts after modifiers/materials.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GeometryPerformance {
    pub cube_count: usize,
    pub mesh_count: usize,
    pub zero_volume_cubes: usize,
    pub invalid_vertices: usize,
    pub zero_area_faces: usize,
    pub estimated_cube_volume: f64,
    pub estimated_cube_surface: f64,
}

/// Bounded single-pass scan. Cube rotations are intentionally NOT baked;
/// callers receive axis-aligned local-space statistics.
pub fn geometry_performance(json: &str) -> Result<GeometryPerformance, String> {
    if json.len() > 64 * 1024 * 1024 { return Err("Model exceeds 64 MiB".into()); }
    let parsed: Value = serde_json::from_str(json).map_err(|e| e.to_string())?;
    let entries = parsed.get("elements").and_then(Value::as_array)
        .ok_or("Model has no elements array")?;
    let mut stats = GeometryPerformance {
        cube_count: 0, mesh_count: 0, zero_volume_cubes: 0,
        invalid_vertices: 0, zero_area_faces: 0,
        estimated_cube_volume: 0.0, estimated_cube_surface: 0.0,
    };
    for item in entries {
        if item.get("type").and_then(Value::as_str) == Some("mesh") {
            stats.mesh_count += 1;
            if let Some(vertices) = item.get("vertices").and_then(Value::as_object) {
                stats.invalid_vertices += vertices.values().filter(|point| point.as_array().is_some() && vec3(point).is_none()).count();
            }
            if let Some(faces) = item.get("faces").and_then(Value::as_object) {
                stats.zero_area_faces += faces.values().filter(|face| {
                    face.get("vertices").and_then(Value::as_array).map_or(true, |v| v.len() < 3)
                }).count();
            }
        } else if item.get("type").and_then(Value::as_str).unwrap_or("cube") == "cube" {
            stats.cube_count += 1;
            if let (Some(a), Some(b)) = (item.get("from").and_then(vec3), item.get("to").and_then(vec3)) {
                let w=(a[0]-b[0]).abs();let h=(a[1]-b[1]).abs();let d=(a[2]-b[2]).abs();
                if w < 1e-7 || h < 1e-7 || d < 1e-7 { stats.zero_volume_cubes += 1; }
                stats.estimated_cube_volume += w*h*d;
                stats.estimated_cube_surface += 2.0*(w*h + w*d + h*d);
            } else { stats.invalid_vertices += 1; }
        }
    }
    if !stats.estimated_cube_volume.is_finite() || !stats.estimated_cube_surface.is_finite() {
        return Err("Geometry dimensions overflow".into());
    }
    Ok(stats)
}

#[cfg(feature = "wasm")]
mod wasm {
    use super::*;
    use wasm_bindgen::prelude::*;

    #[wasm_bindgen(js_name = analyzeBBModel)]
    pub fn wasm_analyze_bbmodel(json: &str) -> Result<JsValue, JsValue> {
        let result = analyze_bbmodel(json).map_err(|e| JsValue::from_str(&e))?;
        serde_wasm_bindgen::to_value(&result).map_err(|e| JsValue::from_str(&e.to_string()))
    }
    #[wasm_bindgen(js_name = geometryPerformance)]
    pub fn wasm_geometry_performance(json: &str) -> Result<JsValue, JsValue> {
        let result=geometry_performance(json).map_err(|e| JsValue::from_str(&e))?;
        serde_wasm_bindgen::to_value(&result).map_err(|e| JsValue::from_str(&e.to_string()))
    }
    #[wasm_bindgen(js_name = transformPositions)]
    pub fn wasm_transform_positions(positions: &[f32], matrix: &[f32]) -> Result<Vec<f32>, JsValue> {
        transform_positions(positions, matrix).map_err(|e| JsValue::from_str(&e))
    }
    #[wasm_bindgen(js_name = normalizeUV)]
    pub fn wasm_normalize_uv(uv: &[f32], width: f32, height: f32) -> Result<Vec<f32>, JsValue> {
        normalize_uv(uv, width, height).map_err(|e| JsValue::from_str(&e))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn quality_metrics() {
        let json=r#"{"elements":[{"type":"cube","from":[0,0,0],"to":[2,3,4]},{"type":"cube","from":[1,2,3],"to":[1,2,3]},{"type":"mesh","vertices":{"bad":[1,null,3]},"faces":{"empty":{"vertices":["a","b"]}}}]}"#;
        let stats=geometry_performance(json).unwrap();
        assert_eq!(stats.cube_count,2);
        assert_eq!(stats.mesh_count,1);
        assert_eq!(stats.zero_volume_cubes,1);
        assert_eq!(stats.invalid_vertices,1);
        assert_eq!(stats.zero_area_faces,1);
        assert_eq!(stats.estimated_cube_volume,24.0);
        assert_eq!(stats.estimated_cube_surface,52.0);
    }
    #[test]
    fn invalid_meta() {
        assert!(analyze_bbmodel("{}").is_err());
        assert!(analyze_bbmodel("not json").is_err());
    }
    #[test]
    fn counts_cubes_meshes_and_bounds() {
        let value = r#"{"meta":{"model_format":"free"},"elements":[{"type":"cube","from":[5,-1,2],"to":[1,3,6]},{"type":"mesh","vertices":{"a":[-4,0,0],"b":[8,1,1],"c":[1,2,3]},"faces":{"one":{"vertices":["a","b","c"]}}}],"textures":[{}],"animations":[{}]}"#;
        let stats = analyze_bbmodel(value).unwrap();
        assert_eq!((stats.cubes, stats.meshes, stats.textures, stats.animations), (1, 1, 1, 1));
        assert_eq!(stats.vertices, 11);
        assert_eq!(stats.estimated_triangles, 13);
        assert_eq!(stats.bounds.unwrap(), Bounds { min: [-4.0, -1.0, 0.0], max: [8.0, 3.0, 6.0] });
    }
    #[test]
    fn transform_and_uv() {
        let mut matrix = [0.0; 16];
        for i in 0..4 { matrix[i*5] = 1.0; }
        matrix[12] = 2.0;
        assert_eq!(transform_positions(&[1., 2., 3.], &matrix).unwrap(), [3., 2., 3.]);
        assert_eq!(normalize_uv(&[8., 16.], 16., 32.).unwrap(), [0.5, 0.5]);
        assert!(normalize_uv(&[1.], 16., 16.).is_err());
    }
}
