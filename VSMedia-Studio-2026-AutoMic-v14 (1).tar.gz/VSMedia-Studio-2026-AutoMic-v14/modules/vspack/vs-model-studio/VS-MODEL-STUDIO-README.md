# VS Model Studio v0.2 — Component de Blockbench 5.2.2, Rust + WASM

Este paquete transforma el código fuente de Blockbench recibido en un **editor integrable mediante un Web Component**, manteniendo sus pantallas, menús, funcionalidades y motor 3D original. Incluye API de comunicación segura entre la página contenedora y el editor, demo, ejemplos para React y Vue, biblioteca Rust para geometría y servidor HTTP Rust de desarrollo.


## Edición v0.2 — web más limpia y bilingüe

- **Solo español e inglés** en la demo y en el selector interno de Blockbench. Se eliminaron los otros JSON de idioma y sus imports. Español por defecto en la demo.
- **Carrusel de inicio desactivado en modo embebido**, sin publicidad de redes, anuncios externos, noticias de actualización ni configuración inicial invasiva. Los formatos de creación originales siguen accesibles.
- **Interfaz contenedora simplificada**: nuevo modelo, abrir `.bbmodel`, exportar, deshacer/rehacer y selector ES/EN.
- **Logo de llave inglesa dorado** (`#c8a96c`) en el contenedor y en la cabecera del editor embebido. Otros sitios pueden cambiarlo con `accent="#hexhex"` o `editor.accent = '#hexhex'`.
- Los cambios visuales del editor original se aplican **solo cuando está integrado** con `vs_embed=1`. No se han ocultado los controles 3D, de UV, pintura, texturas ni animación.

**Abrir la demo:** `./VER-DEMO.sh` y entrar en `http://127.0.0.1:3070/demo/`. Si el navegador no abre automáticamente, pegar la URL manualmente. La primera ejecución requiere Node/npm y conexión a internet para compilar `dist/bundle.js` porque los fuentes originales no incluían el bundle. El servidor Rust tiene alternativa Python.

**Uso en una web propia:**

```html
<script type="module" src="/vs-model-studio/embed/component.js"></script>
<vs-model-studio editor-url="/vs-model-studio/index.html" language="es" accent="#c8a96c"
                 style="display:block;width:100%;height:80vh"></vs-model-studio>
```

Cambiar de idioma **recarga el editor**, así que la demo avisa para evitar perder cambios no guardados. Los cambios de color también recargan la instancia; es mejor configurarlo al montar el componente.

## Estructura

- `index.html`, `js/`, `css/`, `assets/`, `lib/`, ... — fuentes originales de Blockbench (licencia GPL-3.0 o posterior).
- `embed/component.js` — `<vs-model-studio>`: API de integración para cualquier framework.
- `embed/bridge.js` — puente de comandos y eventos dentro de la app de Blockbench.
- `embed/component.d.ts` — tipos para TypeScript.
- `embed/rust-engine.js` — cliente de funciones WASM opcionales.
- `crates/vs_model_core/` — núcleo Rust para inspección de `.bbmodel`, matriz 4×4 y UV, exportable a WASM.
- `crates/vs_model_server/` — servidor HTTP de desarrollo **100 % Rust y sin dependencias externas**.
- `demo/` — interfaz sencilla para probar el componente integrado con la UI completa del editor.
- `examples/` — módulos para integrar en Vue o React.
- `tests/` — pruebas Node para API y seguridad de mensajes.

## Inicio en CachyOS / Linux

```bash
./scripts/start.sh
```

Entrar en **http://127.0.0.1:3070/demo/**. Si falta el bundle web de Blockbench, el script instala dependencias y lo compila automáticamente (requiere internet); si hay `rustc`, utiliza el servidor Rust, y si no, Python como alternativa. El ZIP original **no incluía** `dist/bundle.js`.

**Opcional Rust WebAssembly:** instalar Rust, target `wasm32-unknown-unknown`, `wasm-pack`, ejecutar `./scripts/build.sh` y usar `await editor.analyzeModelRust()` desde el contenedor. Estas funciones no se encuentran compiladas dentro del ZIP entregado.

## Resultado / limitaciones

La reutilización de la interfaz y del engine del Blockbench original está implementada con iframe + API de eventos y comandos; la biblioteca Rust, el servidor, la demo y los ejemplos tienen sus fuentes completos. **No se incluye un bundle JS ni WASM precompilado**: faltan las dependencias npm en este entorno sin acceso al registro, y no hay compilador Rust instalado para verificar la compilación. Las pruebas Node del puente/componentes están pasadas, pero la prueba visual completa depende de compilar la aplicación original.

Una migración **1:1 completa** del renderer y la UI de Blockbench a Rust no está hecha; sería un proyecto de portabilidad de gran escala. Esta arquitectura preserva la interfaz real y hace posible portar módulos intensivos a Rust progresivamente sin romper formatos ni herramientas.

Licencia de distribución: **GPL-3.0-or-later**, respetando la autoría del proyecto original. Ver `LICENSE.MD` y `embed/USAGE.md`.
