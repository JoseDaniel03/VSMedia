# Vista previa de VS Model Studio en CachyOS / Linux

Esta demo presenta el componente **real** `<vs-model-studio>` integrado en una página contenedora. Dentro se muestra el editor original de Blockbench; la barra externa corresponde a la API del componente.

## Iniciar

1. Descomprimir el ZIP.
2. Abrir una terminal dentro de la carpeta `blockbench-master`.
3. Ejecutar: `./VER-DEMO.sh`
4. El navegador debe abrirse automáticamente en **http://localhost:3070/demo/**. También podés abrir esa URL manualmente.

La primera ejecución **requiere acceso a internet** para descargar paquetes y generar `dist/bundle.js` desde el código fuente. El servidor intenta usar Rust si está instalado y, en caso contrario, Python 3. Node.js y npm (Node >=20) son necesarios para compilar la primera vez.

En CachyOS, para instalar requisitos:

```bash
sudo pacman -S --needed nodejs npm python
```

La demo permite crear un proyecto, abrir `.bbmodel`, exportar y usar deshacer/rehacer. El resto de herramientas de modelado siguen en la UI original del editor embebido.

**Si aparece «Editor did not become ready»**: comprobar que `dist/bundle.js` se creó y revisar los errores de la terminal. Si npm falla por conectividad o dependencias, no está disponible el editor completo hasta que termine la compilación.

No hay un enlace público a esta adaptación: corre en tu equipo. La web oficial https://web.blockbench.net/ sirve para conocer la interfaz *original*, pero no es nuestra demo embebida.
