/* Minimal non-caching service worker for standalone Blockbench.
 * The embedded VSPack editor deliberately does not register a worker.
 * Keeping this file prevents a 404 / installation failure when opening
 * the original Blockbench page outside the VSPack component.
 */
self.addEventListener('install', () => {self.skipWaiting();});
self.addEventListener('activate', event => {event.waitUntil(self.clients.claim());});
