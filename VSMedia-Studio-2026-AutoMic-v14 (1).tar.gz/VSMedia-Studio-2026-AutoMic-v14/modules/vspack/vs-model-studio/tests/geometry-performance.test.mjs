import test from 'node:test';
import assert from 'node:assert/strict';
import {geometryPerformance} from '../embed/geometry-performance.js';
import {analyzeGeometry} from '../embed/geometry-runner.js';
const model={name:'Prueba',meta:{model_format:'free'},elements:[
 {type:'cube',from:[0,0,0],to:[2,3,4]},
 {type:'cube',from:[1,2,3],to:[1,2,3]},
 {type:'mesh',vertices:{bad:[1,null,3]},faces:{empty:{vertices:['a','b']}}}
],textures:[]};
test('cube stats, surface and degenerate geometry match Rust expected values',()=>{
 const stats=geometryPerformance(model);
 assert.deepEqual(stats,{cubeCount:2,meshCount:1,zeroVolumeCubes:1,invalidVertices:1,
  zeroAreaFaces:1,estimatedCubeVolume:24,estimatedCubeSurface:52});
});
test('analysis uses fallback when Worker is unavailable, leaving the original model intact',async()=>{
 const original=JSON.stringify(model);
 const report=await analyzeGeometry(model);
 assert.equal(report.engine,'javascript');
 assert.equal(report.performance.zeroVolumeCubes,1);
 assert.equal(report.elements,3);
 assert.equal(JSON.stringify(model),original);
});
test('reject nonfinite dimensions before entering Rust or renderer',()=>{
 assert.throws(()=>geometryPerformance({elements:[{type:'cube',from:[0,0,0],to:[1e250,1e250,1e250]}]}),/overflow/);
});
test('large 20000-cube stress test stays deterministic',()=>{
 const input={elements:Array.from({length:20000},(_,i)=>({type:'cube',from:[i,0,0],to:[i+1,1,1]}))};
 const stats=geometryPerformance(input);
 assert.equal(stats.estimatedCubeVolume,20000);
 assert.equal(stats.estimatedCubeSurface,120000);
});
