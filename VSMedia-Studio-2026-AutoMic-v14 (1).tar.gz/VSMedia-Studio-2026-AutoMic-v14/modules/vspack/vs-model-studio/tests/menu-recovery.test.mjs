import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const source=fs.readFileSync(new URL('../embed/menu-repair.js',import.meta.url),'utf8');
function setup(){
  const listeners={};
  const li={isConnected:true,classList:{contains:()=>false},contains:child=>child===li,hasAttribute:()=>false,setAttribute(){},getBoundingClientRect:()=>({width:90})};
  const menu={label:li,node:{isConnected:false,style:{},getBoundingClientRect:()=>({width:120})},open(){this.node.isConnected=true;this.opens=(this.opens||0)+1;},hide(){this.node.isConnected=false;this.closes=(this.closes||0)+1;}};
  const bar={
    contains:el=>el===li,
    addEventListener:(type,fn)=>{listeners[type]=fn;},
    querySelectorAll:()=>[li]
  };
  const fakeDoc={getElementById:id=>id==='menu_bar'?bar:null,querySelectorAll:()=>[],addEventListener(){}};
  const window={parent:{},Blockbench:{MenuBar:{menus:{file:menu}}}};
  const environment={window,document:fakeDoc,location:{search:'?vs_embed=1'},
    URLSearchParams,Element:class{},MutationObserver:class{observe(){}},WeakMap,Set,
    requestAnimationFrame:fn=>fn(),getComputedStyle:node=>({display:node.isConnected?'block':'none'}),console};
  vm.runInNewContext(source,environment);
  const evt=type=>({target:{closest:()=>li},key:'Enter',preventDefault(){},stopPropagation(){}});
  return {listeners,menu,evt,li};
}
test('recover broken native menu click by matching BarMenu.label DOM element',()=>{
  const {listeners,menu,evt}=setup();
  listeners.pointerdown(evt());listeners.click(evt());
  assert.equal(menu.opens,1);
});
test('never double-open an already opened native menu',()=>{
  const {listeners,menu,evt}=setup();
  menu.node.isConnected=true;
  listeners.pointerdown(evt());listeners.click(evt());
  assert.equal(menu.opens||0,0);
});
test('keyboard opens menu from registry and then closes it',()=>{
  const {listeners,menu,evt}=setup();
  listeners.keydown(evt());assert.equal(menu.opens,1);
  listeners.keydown(evt());assert.equal(menu.closes,1);
});
