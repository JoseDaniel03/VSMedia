import test from 'node:test';
import assert from 'node:assert/strict';

const listeners = new Map();
const elements = new Map();
const posted = [];
class MockElement {
  constructor() { this.attrs = new Map(); }
  setAttribute(name, value) { this.attrs.set(name, value); }
  removeAttribute(name) { this.attrs.delete(name); }
  getAttribute(name) { return this.attrs.get(name) || null; }
  attachShadow() {
    this.shadowRoot = { append() {}, querySelector() { return { textContent: '' }; } };
    return this.shadowRoot;
  }
  dispatchEvent() {}
}
class MockNode {
  constructor(type) {
    this.type = type;
    this.listeners = new Map();
    if (type === 'iframe') this.contentWindow = { postMessage(value, origin) { posted.push({ value, origin }); } };
  }
  addEventListener(name, cb) { this.listeners.set(name, cb); }
  setAttribute(name, value) { this[name] = value; }
}
globalThis.HTMLElement = MockElement;
globalThis.location = { origin: 'https://vsmedia.example' };
globalThis.document = { baseURI: 'https://vsmedia.example/studio/', createElement: type => new MockNode(type) };
globalThis.window = {
  addEventListener(name, cb) { listeners.set(name, cb); },
  removeEventListener(name) { listeners.delete(name); }
};
globalThis.customElements = { get: name => elements.get(name), define: (name, type) => elements.set(name, type) };
globalThis.CustomEvent = class { constructor(type, options) { this.type = type; this.detail = options.detail; } };
const { VSModelStudio } = await import('../embed/component.js');

test('custom element mounts original editor URL and origin handshake', async () => {
  const editor = new VSModelStudio();
  editor.setAttribute('editor-url', 'https://editor.example/index.html');
  editor.connectedCallback();
  const url = new URL(editor.frame.src);
  assert.equal(url.origin, 'https://editor.example');
  assert.equal(url.searchParams.get('vs_embed'), '1');
  assert.equal(url.searchParams.get('vs_parent_origin'), location.origin);
  assert.equal(url.searchParams.get('vs_lang'), 'en'); // Non-Spanish browser fallback
  assert.equal(url.searchParams.get('vs_accent'), '#c8a96c');
  editor.frame.listeners.get('load')();
  assert.equal(posted.at(-1).value.type, 'hello');
  assert.equal(posted.at(-1).origin, url.origin);
  listeners.get('message')({ source: editor.frame.contentWindow, origin: 'https://evil.example', data: {protocol:'vs-model-studio/v1',type:'ready'} });
  assert.equal(editor.ready, false);
  listeners.get('message')({ source: editor.frame.contentWindow, origin: url.origin, data: {protocol:'vs-model-studio/v1',type:'ready',info: {editorVersion:'5.2.2'}} });
  assert.equal((await editor.whenReady).editorVersion, '5.2.2');
  const future = editor.newProject('free');
  await Promise.resolve();
  const req = posted.at(-1).value;
  assert.equal(req.command, 'new');
  assert.equal(req.payload.format, 'free');
  listeners.get('message')({source:editor.frame.contentWindow,origin:url.origin,data:{protocol:'vs-model-studio/v1',type:'response', id:req.id,ok:true,result:{hasProject:true}}});
  assert.deepEqual(await future, {hasProject:true});
  editor.disconnectedCallback();
});


test('language and brand color are sanitized when mounting the editor', () => {
  const editor = new VSModelStudio();
  editor.setAttribute('editor-url', 'https://editor.example/index.html');
  editor.setAttribute('language', 'es');
  editor.setAttribute('accent', '#8abf43');
  editor.connectedCallback();
  let url = new URL(editor.frame.src);
  assert.equal(url.searchParams.get('vs_lang'), 'es');
  assert.equal(url.searchParams.get('vs_accent'), '#8abf43');
  editor.setAttribute('accent', 'red; background:url(x)');
  editor.attributeChangedCallback('accent', '#8abf43', 'red; background:url(x)');
  url = new URL(editor.frame.src);
  assert.equal(url.searchParams.get('vs_accent'), '#c8a96c');
  editor.disconnectedCallback();
});

test('embedded source has exactly two locales and suppresses startup promotions', async () => {
  const {readFile, readdir} = await import('node:fs/promises');
  const {join} = await import('node:path');
  const dir = new URL('../', import.meta.url);
  const locales = await readdir(new URL('lang/', dir));
  assert.deepEqual(locales.filter(name => name.endsWith('.json')).sort(), ['en.json', 'es.json']);
  const start = await readFile(new URL('js/interface/start_screen.ts',dir), 'utf8');
  assert.match(start, /show_splash_screen: !vsEmbeddedStudio/);
  assert.match(start, /vsEmbeddedStudio \? Promise\.resolve\(null\)/);
  assert.match(start, /if \(vsEmbeddedStudio\) return/);
});
