import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const source = fs.readFileSync(new URL('../embed/bridge.js', import.meta.url), 'utf8');
function scenario() {
  const sent = [];
  const handlers = new Map();
  const documentHandlers = new Map();
  const origins = { parent: 'https://vsmedia.example', editor: 'https://editor.example' };
  let activeProject = null;
  const parent = { postMessage(message, origin) { sent.push({ message, origin }); } };
  const window = {
    parent,
    addEventListener(name, cb) { handlers.set(name, cb); },
    Blockbench: {
      version: '5.2.2', setup_successful: true,
      get Project() { return activeProject; },
      on() {},
    },
    Formats: { free: {}, java_block: {} },
    Codecs: { java_block: {
      load(model, file) { activeProject = { name: file.name, format: { id:'java_block' }, saved: false, elements: model.elements || [], textures: [], animations: [], uuid:'java' }; },
      compile() { return JSON.stringify({ parent:'minecraft:block/cube_all', textures:{all:'minecraft:block/stone'} }); }
    }, project: {
      load(model, file) { activeProject = {
        name: file.name,
        format: { id: model.meta.model_format },
        elements: model.elements || [], textures: model.textures || [], animations: [], uuid: 'fake', saved: false,
      }; },
      compile(options) {
        const value = { meta: { model_format: 'free' }, elements: [{type:'cube'}] };
        return options.raw ? value : JSON.stringify(value);
      }
    } },
    newProject(format) { activeProject = { name: 'new', format: {id: format}, elements: [], textures: [] }; },
    Undo: { undo() {}, redo() {} },
    focus() {}
  };
  const sandbox = {
    window,
    location: { search: '?vs_embed=1&vs_parent_origin=https%3A%2F%2Fvsmedia.example', origin: origins.editor },
    URL, URLSearchParams, setTimeout() {}, document: { getElementById() { return { focus() {} }; }, addEventListener(name, cb) {documentHandlers.set(name,cb);} }
  };
  vm.runInNewContext(source, sandbox);
  const send = (type, data = {}, origin = origins.parent, source = parent) => {
    return handlers.get('message')({ origin, source, data: { protocol: 'vs-model-studio/v1', type, ...data } });
  };
  return { sent, send, origins, parent, documentHandlers,window };
}

test('only designated parent origin is permitted', async () => {
  const s = scenario();
  await s.send('hello', {}, 'https://evil.example');
  assert.equal(s.sent.length, 0);
  await s.send('hello', {}, s.origins.parent, {});
  assert.equal(s.sent.length, 0);
  await s.send('hello');
  assert.equal(s.sent[0].message.type, 'ready');
  assert.equal(s.sent[0].origin, s.origins.parent);
});

test('opens and snapshots native Blockbench project', async () => {
  const s = scenario();
  await s.send('hello');
  await s.send('request', { id: 1, command: 'open', payload: { model: JSON.stringify({meta: {model_format: 'free'}, elements: [{type:'cube'}]}), name: 'foo.bbmodel' } });
  assert.equal(s.sent.at(-1).message.ok, true);
  assert.equal(s.sent.at(-1).message.result.name, 'foo.bbmodel');
  await s.send('request', { id: 2, command: 'snapshot' });
  assert.equal(s.sent.at(-1).message.result.elements[0].type, 'cube');
});

test('rejects unsupported commands, malformed model and origin forgery', async () => {
  const s = scenario();
  await s.send('hello');
  await s.send('request', { id: 1, command: 'open', payload: { model: '{}' } });
  assert.equal(s.sent.at(-1).message.ok, false);
  await s.send('request', { id: 2, command: '__proto__' });
  assert.equal(s.sent.at(-1).message.ok, false);
  const count = s.sent.length;
  await s.send('request', { id: 3, command: 'info' }, 'https://evil.example');
  assert.equal(s.sent.length, count);
});

test('imports Minecraft Java JSON with correct codec and exports it without .bbmodel wrapping', async () => {
  const s = scenario();
  await s.send('hello');
  await s.send('request', {id:1, command:'open', payload:{name:'stone.json', model:JSON.stringify({parent:'minecraft:block/cube_all',textures:{all:'minecraft:block/stone'}})}});
  assert.equal(s.sent.at(-1).message.ok, true);
  assert.equal(s.sent.at(-1).message.result.format, 'java_block');
  await s.send('request', {id:2, command:'export', payload:{format:'java_block'}});
  assert.equal(JSON.parse(s.sent.at(-1).message.result).parent, 'minecraft:block/cube_all');
});

test('save acknowledgement clears dirty flag in original editor', async () => {
  const s = scenario();
  await s.send('hello');
  await s.send('request', { id:1, command:'open', payload:{name:'test.bbmodel',model:JSON.stringify({meta:{model_format:'free'},elements:[]})}});
  assert.equal(s.sent.at(-1).message.result.saved, false);
  await s.send('request', {id:2,command:'mark_saved'});
  assert.equal(s.sent.at(-1).message.result.saved, true);
});

test('Ctrl+S in embedded editor asks the VSPack host to save', async () => {
  const s = scenario();
  await s.send('hello');
  await s.send('request',{id:1,command:'open',payload:{name:'test.bbmodel',model:JSON.stringify({meta:{model_format:'free'}})}});
  let prevented = false, stopped = false;
  s.documentHandlers.get('keydown')({key:'s',ctrlKey:true,metaKey:false,altKey:false,shiftKey:false,repeat:false,preventDefault(){prevented=true;},stopImmediatePropagation(){stopped=true;}});
  assert.equal(prevented, true);
  assert.equal(stopped, true);
  assert.equal(s.sent.at(-1).message.name, 'save_shortcut');
});

test('exports local PNG textures without filesystem access', async () => {
  const s=scenario();
  await s.send('hello');
  await s.send('request',{id:1,command:'open',payload:{name:'test.bbmodel',model:JSON.stringify({meta:{model_format:'free'},elements:[]})}});
  const p=s.window.Blockbench.Project;
  p.textures=[{name:'stone.png',getDataURL(){return 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAB';}}];
  await s.send('request',{id:2,command:'export_textures'});
  assert.equal(s.sent.at(-1).message.ok,true);
  assert.equal(s.sent.at(-1).message.result[0].name,'stone.png');
  assert.match(s.sent.at(-1).message.result[0].dataUrl,/^data:image\/png;base64,/);
});

test('native project events include edit notifications for up-to-date dirty state', async()=>{
  const s=scenario();
  await s.send('hello');
  assert.equal(s.window.Blockbench.setup_successful,true);
  const bridge=fs.readFileSync(new URL('../embed/bridge.js',import.meta.url),'utf8');
  for(const event of ['finished_edit','undo','redo','edit_texture'])assert.ok(bridge.includes(`'${event}'`));
});
