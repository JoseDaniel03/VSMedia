(()=>{'use strict';
const KEY='vsmedia-pack-layout-2026';
window.addEventListener('DOMContentLoaded',()=>{
 const side=document.querySelector('.sidebar');if(!side)return;
 const b=document.createElement('button');b.type='button';b.className='vs-pack-layout';
 const sync=()=>{const compact=document.body.classList.contains('vs-pack-compact');b.textContent=compact?'▦ Vista cómoda':'▥ Vista compacta';b.setAttribute('aria-pressed',String(compact));};
 try{document.body.classList.toggle('vs-pack-compact',localStorage.getItem(KEY)==='compact');}catch{}
 sync();side.insertBefore(b,side.querySelector('.sidebar-bottom'));
 b.addEventListener('click',()=>{document.body.classList.toggle('vs-pack-compact');sync();try{localStorage.setItem(KEY,document.body.classList.contains('vs-pack-compact')?'compact':'normal');}catch{}window.dispatchEvent(new Event('resize'));});
});
})();
