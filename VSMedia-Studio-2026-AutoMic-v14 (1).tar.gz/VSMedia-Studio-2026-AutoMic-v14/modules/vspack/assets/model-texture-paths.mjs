/** Path helpers for exporting PNGs from embedded Blockbench into VSPack. */
export function validateTexturePath(path) {
 return typeof path==='string' && /^assets\/[a-z0-9_.-]+\/textures\/(?:[a-z0-9_.-]+\/)*[a-z0-9_.-]+\.png$/.test(path)
   && !path.split('/').includes('..');
}
export function suggestTexturePath(modelPath,name='texture.png',packName='virgoland'){
 const ns=/^assets\/([a-z0-9_.-]+)\//.exec(modelPath||'')?.[1]
   ||String(packName).toLowerCase().replace(/[^a-z0-9_.-]+/g,'_')||'virgoland';
 const part=String(name||'texture.png').toLowerCase().replace(/\.[^.]*$/,'').replace(/[^a-z0-9_.-]+/g,'_')||'texture';
 return `assets/${ns}/textures/${part}.png`;
}
