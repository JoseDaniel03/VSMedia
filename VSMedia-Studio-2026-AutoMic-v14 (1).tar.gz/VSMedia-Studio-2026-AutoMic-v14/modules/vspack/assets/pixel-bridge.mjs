import '../pixel-studio/web/vs-pixel-studio.mjs';
import {encodeAsepriteCompressed} from '../pixel-studio/web/ase-format.mjs';

/** Editor incorporado en el workspace de VSPack. No usa ventana modal, iframe ni navegación externa. */
export async function mountPixelStudio({mount,file,name,path,packName,savePNG,saveASE}) {
  if (!mount?.isConnected) throw Error('El área de trabajo ya no está disponible.');
  const host=document.createElement('section');
  host.className='vspixel-integrated';
  host.setAttribute('aria-label','Editor de píxeles de '+name);
  const toolbar=document.createElement('div');
  toolbar.className='vspixel-integrated-actions';
  const location=document.createElement('div');
  location.className='vspixel-document';
  const title=document.createElement('strong');title.textContent=name;
  const detail=document.createElement('small');detail.textContent=packName+'  /  '+path;
  location.append(title,detail);
  const actions=document.createElement('div');actions.className='vspixel-toolbar-actions';
  const status=document.createElement('span');status.className='vspixel-inline-status';status.textContent='Cargando editor…';
  const button=(text,kind)=>{const b=document.createElement('button');b.type='button';b.className='vspixel-host-button '+kind;b.textContent=text;return b;};
  const save=button('Guardar PNG','primary');
  const saveAs=button('Guardar como…','secondary');
  const project=button('Guardar .aseprite','secondary');
  actions.append(status,save,saveAs,project);
  toolbar.append(location,actions);
  const workspace=document.createElement('div');workspace.className='vspixel-editor-viewport';
  const editor=document.createElement('vs-pixel-studio');
  editor.setAttribute('width','32');editor.setAttribute('height','32');editor.setAttribute('embedded','');
  workspace.append(editor);host.append(toolbar,workspace);mount.replaceChildren(host);
  // No propagar archivos arrastrados al importador global de ZIP.
  ['dragenter','dragover','dragleave','drop'].forEach(eventName=>host.addEventListener(eventName,e=>e.stopPropagation()));
  let dirty=false,busy=false,disposed=false;
  const setStatus=s=>{if(!disposed)status.textContent=s;};
  const onChange=()=>{dirty=true;setStatus('● Sin guardar');};
  editor.addEventListener('vs-pixel-change',onChange);
  const shortcuts=e=>{
    if ((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='s') {
      e.preventDefault();e.stopPropagation();save.click();
    }
  };
  host.addEventListener('keydown',shortcuts,true);
  // Unificar el menú Archivo del editor: no descargar al equipo cuando el usuario pulsa Guardar.
  const nativeSave=e=>{
    const action=e.composedPath().find(node=>node?.dataset?.act==='export'||node?.dataset?.act==='exportase');
    if(!action)return;
    e.preventDefault();e.stopPropagation();
    if(action.dataset.act==='export')save.click();else project.click();
  };
  host.addEventListener('click',nativeSave,true);
  function dispose(){if(disposed)return;disposed=true;editor.removeEventListener('vs-pixel-change',onChange);host.removeEventListener('keydown',shortcuts,true);host.removeEventListener('click',nativeSave,true);host.remove();}
  const controller={get dirty(){return dirty;},get busy(){return busy;},dispose,setStatus,editor};
  const hasProjectStructure=()=>{
    const project=editor.getProject();
    return (project.frames?.length||0)>1 || (project.layers?.length||0)>1;
  };
  const write=async (label,work,{flatten=false,switchActive=false}={})=>{
    if(disposed||busy)return;
    busy=true;[save,saveAs,project].forEach(b=>b.disabled=true);
    setStatus('Guardando '+label+'…');
    try{
      const result=await work();
      if(result!==false){
        if(switchActive&&typeof result==='string'){
          path=result;name=result.split('/').pop();
          title.textContent=name;detail.textContent=packName+'  /  '+path;
        }
        // PNG is a flattened raster. It cannot preserve editable layers/frames.
        if(flatten&&hasProjectStructure()){
          dirty=true;
          setStatus('PNG exportado · guardá .aseprite para conservar capas y animación');
        }else{
          dirty=false;setStatus('✓ '+label+' guardado en el pack');
        }
      }else setStatus('Sin cambios guardados');
    }catch(error){setStatus('Error: '+(error?.message||error));}
    finally{busy=false;[save,saveAs,project].forEach(b=>b.disabled=false);}
  };
  async function makePNG(pathOverride){
    if(hasProjectStructure() && !confirm('PNG aplana las capas y guarda solo el fotograma visible. Guardá un .aseprite para conservar el proyecto editable. ¿Exportar PNG igualmente?'))return false;
    const blob=await editor.toPNGBlob();if(!blob)throw Error('No se pudo generar PNG');
    return savePNG(blob,pathOverride);
  }
  save.addEventListener('click',()=>write('PNG',()=>makePNG(),{flatten:true}));
  saveAs.addEventListener('click',()=>{
    const proposal=path.replace(/\.[^./]+$/,'.png');
    const next=prompt('Ruta de la nueva textura dentro del pack:',proposal);
    if(next===null)return;
    const trimmed=next.trim();if(!trimmed){setStatus('Ingresá una ruta válida');return;}
    void write('PNG',()=>makePNG(trimmed),{flatten:true,switchActive:true});
  });
  project.addEventListener('click',()=>write('Aseprite',async()=>{
    const bytes=await encodeAsepriteCompressed(editor.getProject());
    return saveASE(new Uint8Array(bytes));
  }));
  try{
    // El Web Component emite ready al completar el connectedCallback asíncrono.
    if(!editor.engine){
      await Promise.race([
        new Promise(resolve=>editor.addEventListener('vs-pixel-ready',resolve,{once:true})),
        new Promise((_,reject)=>setTimeout(()=>reject(Error('VS Pixel Studio no pudo iniciarse.')),15000))
      ]);
    }
    if(!mount.isConnected||disposed){dispose();return controller;}
    await editor.openFile(file);
    if(!mount.isConnected||disposed){dispose();return controller;}
    dirty=false;
    setStatus('Listo · '+editor.engine.width+'×'+editor.engine.height+' · '+(editor.engine.kind==='wasm'?'Rust/WASM':'JS'));
    editor.shadowRoot?.querySelector('.studio')?.focus();
    return controller;
  }catch(error){dispose();throw error;}
}
