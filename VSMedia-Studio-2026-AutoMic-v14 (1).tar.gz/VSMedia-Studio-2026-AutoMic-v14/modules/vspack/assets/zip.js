/* VSPack ZIP reader/writer. No third-party scripts. Supports ZIP32 STORE/DEFLATE imports and STORE exports.
   Limits are enforced before extraction, path normalization rejects traversal, CRC32 checked. */
(function(){'use strict';
 const dec=new TextDecoder('utf-8',{fatal:true}),enc=new TextEncoder();
 const table=new Uint32Array(256);for(let i=0;i<256;i++){let c=i;for(let j=0;j<8;j++)c=c&1?0xedb88320^(c>>>1):c>>>1;table[i]=c>>>0;}
 function crc32(bytes){let c=0xffffffff;for(const b of bytes)c=table[(c^b)&255]^(c>>>8);return (c^0xffffffff)>>>0;}
 function cleanPath(s){if(typeof s!=='string'||!s||s.startsWith('/')||s.includes('\\')||s.includes('\0')||/^[a-zA-Z]:/.test(s))throw Error('Ruta insegura: '+s);const seg=s.split('/');if(seg.some(p=>p==='..'||p==='.'||p===''))throw Error('Ruta inválida: '+s);return s;}
 async function read(file,opts={}){const data=new Uint8Array(await file.arrayBuffer());const view=new DataView(data.buffer);const maxEntries=opts.maxEntries||1500,maxBytes=opts.maxBytes||128*1024*1024,maxSingle=opts.maxSingle||32*1024*1024;
  let eocd=-1;for(let p=data.length-22;p>=Math.max(0,data.length-65557);p--){if(view.getUint32(p,true)===0x06054b50){eocd=p;break;}}
  if(eocd<0)throw Error('No es un ZIP válido');const count=view.getUint16(eocd+10,true),size=view.getUint32(eocd+12,true),start=view.getUint32(eocd+16,true);
  if(count===0xffff||start===0xffffffff)throw Error('ZIP64 no admitido en esta versión');if(count>maxEntries)throw Error('Límite de '+maxEntries+' archivos por importación');if(start+size>data.length)throw Error('Directorio central fuera del archivo');
  const entries=[];let p=start,total=0;for(let i=0;i<count;i++){
    if(p+46>data.length||view.getUint32(p,true)!==0x02014b50)throw Error('Directorio ZIP dañado');
    const flags=view.getUint16(p+8,true),method=view.getUint16(p+10,true),crc=view.getUint32(p+16,true),comp=view.getUint32(p+20,true),plain=view.getUint32(p+24,true),nlen=view.getUint16(p+28,true),extra=view.getUint16(p+30,true),comment=view.getUint16(p+32,true),offset=view.getUint32(p+42,true),extattr=view.getUint32(p+38,true),name=dec.decode(data.slice(p+46,p+46+nlen));p+=46+nlen+extra+comment;
    if(name.endsWith('/'))continue;if(flags&1)throw Error('No se permiten ZIP cifrados');if(method!==0&&method!==8)throw Error('Compresión ZIP no soportada: '+method);
    // Reject UNIX symbolic links, to avoid creating confusing imported paths.
    if(((extattr>>>16)&0xf000)===0xa000)throw Error('Enlaces simbólicos no admitidos');
    cleanPath(name);total+=plain;if(plain>maxSingle||total>maxBytes)throw Error('El ZIP supera los límites de importación');if(comp>0&&plain/comp>250)throw Error('Relación de compresión excesiva');
    entries.push({name,method,crc,comp,plain,offset});
  }
  const out=[];for(const e of entries){const h=e.offset;if(h+30>data.length||view.getUint32(h,true)!==0x04034b50)throw Error('Archivo ZIP corrupto');const n=view.getUint16(h+26,true),ex=view.getUint16(h+28,true),begin=h+30+n+ex;if(begin+e.comp>data.length)throw Error('Datos fuera del ZIP');const raw=data.slice(begin,begin+e.comp);let bytes;
    if(e.method===0)bytes=raw;else{if(typeof DecompressionStream==='undefined')throw Error('El navegador no admite descompresión ZIP. Probá Chromium actualizado.');const ds=new DecompressionStream('deflate-raw');const streamed=new Blob([raw]).stream().pipeThrough(ds);bytes=new Uint8Array(await new Response(streamed).arrayBuffer());}
    if(bytes.length!==e.plain||crc32(bytes)!==e.crc)throw Error('Archivo corrupto o CRC inválido: '+e.name);out.push({path:e.name,bytes});
  }return out;
 }
 function concat(chunks){const size=chunks.reduce((n,v)=>n+v.length,0);const buffer=new Uint8Array(size);let offset=0;for(const c of chunks){buffer.set(c,offset);offset+=c.length;}return buffer;}
 function writer(){const out=[],cent=[];let pos=0;return{add(path,bytes){cleanPath(path);if(!(bytes instanceof Uint8Array))bytes=new Uint8Array(bytes);const name=enc.encode(path);if(name.length>65535||bytes.length>0xffffffff)throw Error('Archivo ZIP demasiado grande');const header=new Uint8Array(30+name.length),v=new DataView(header.buffer),crc=crc32(bytes);v.setUint32(0,0x04034b50,true);v.setUint16(4,20,true);v.setUint16(6,0x800,true);v.setUint32(14,crc,true);v.setUint32(18,bytes.length,true);v.setUint32(22,bytes.length,true);v.setUint16(26,name.length,true);header.set(name,30);const dir=new Uint8Array(46+name.length),d=new DataView(dir.buffer);d.setUint32(0,0x02014b50,true);d.setUint16(4,20,true);d.setUint16(6,20,true);d.setUint16(8,0x800,true);d.setUint32(16,crc,true);d.setUint32(20,bytes.length,true);d.setUint32(24,bytes.length,true);d.setUint16(28,name.length,true);d.setUint32(42,pos,true);dir.set(name,46);cent.push(dir);out.push(header,bytes);pos+=header.length+bytes.length;},finish(){if(cent.length>65535)throw Error('Demasiados archivos');const cd=concat(cent),e=new Uint8Array(22),v=new DataView(e.buffer);v.setUint32(0,0x06054b50,true);v.setUint16(8,cent.length,true);v.setUint16(10,cent.length,true);v.setUint32(12,cd.length,true);v.setUint32(16,pos,true);return new Blob([...out,cd,e],{type:'application/zip'});}};}
 // Optional v11 export: lossless DEFLATE only for text-like pack entries.
 // Keep PNG, OGG, JPG, WebP, GIF and binary models byte-identical and stored:
 // recompressing existing compressed formats wastes time with little benefit.
 function optimizedWriter(){
  const out=[],cent=[],names=new Set();let pos=0;
  const textExt=/\.(?:json|mcmeta|txt|lang|properties|mcfunction|yml|yaml|xml|css|js|md|svg|glsl|fsh|vsh|json5)$/i;
  return{
   async add(path,bytes){
    cleanPath(path);if(names.has(path))throw Error('Ruta repetida en ZIP: '+path);names.add(path);
    if(!(bytes instanceof Uint8Array))bytes=new Uint8Array(bytes);
    if(bytes.length>0xffffffff)throw Error('Entrada ZIP demasiado grande');
    const name=enc.encode(path);if(name.length>65535)throw Error('Nombre de archivo ZIP demasiado largo');
    let payload=bytes,method=0;
    if(bytes.length>=256&&textExt.test(path)&&typeof CompressionStream!=='undefined'){
     try{
      const compressor=new CompressionStream('deflate-raw');
      const stream=new Blob([bytes]).stream().pipeThrough(compressor);
      const candidate=new Uint8Array(await new Response(stream).arrayBuffer());
      if(candidate.length+32<bytes.length){payload=candidate;method=8;}
     }catch(_){/* Some browsers cannot compress deflate-raw; STORE stays valid. */}
    }
    if(pos+30+name.length+payload.length>0xffffffff)throw Error('El ZIP supera el límite ZIP32');
    const header=new Uint8Array(30+name.length),v=new DataView(header.buffer),crc=crc32(bytes);
    v.setUint32(0,0x04034b50,true);v.setUint16(4,20,true);v.setUint16(6,0x800,true);
    v.setUint16(8,method,true);v.setUint32(14,crc,true);
    v.setUint32(18,payload.length,true);v.setUint32(22,bytes.length,true);v.setUint16(26,name.length,true);header.set(name,30);
    const dir=new Uint8Array(46+name.length),d=new DataView(dir.buffer);
    d.setUint32(0,0x02014b50,true);d.setUint16(4,20,true);d.setUint16(6,20,true);
    d.setUint16(8,0x800,true);d.setUint16(10,method,true);d.setUint32(16,crc,true);
    d.setUint32(20,payload.length,true);d.setUint32(24,bytes.length,true);
    d.setUint16(28,name.length,true);d.setUint32(42,pos,true);dir.set(name,46);
    out.push(header,payload);cent.push(dir);pos+=header.length+payload.length;
   },
   finish(){if(cent.length>65535)throw Error('Demasiados archivos ZIP');const cd=concat(cent);
    if(pos+cd.length+22>0xffffffff)throw Error('El ZIP supera ZIP32');
    const e=new Uint8Array(22),v=new DataView(e.buffer);v.setUint32(0,0x06054b50,true);
    v.setUint16(8,cent.length,true);v.setUint16(10,cent.length,true);
    v.setUint32(12,cd.length,true);v.setUint32(16,pos,true);
    return new Blob([...out,cd,e],{type:'application/zip'});
   }
  };
 }
 window.VSZip={read,writer,optimizedWriter,cleanPath,crc32};
})();
