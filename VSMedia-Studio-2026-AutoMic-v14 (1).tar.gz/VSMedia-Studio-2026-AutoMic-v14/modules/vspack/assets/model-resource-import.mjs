/**
 * Resource-pack JSON -> Blockbench document bridge.
 * Reads assets that are already stored by VSPack. No network, no AI, no
 * changes to the source pack until the user explicitly saves.
 * GPL-3.0-or-later integration around the original Blockbench codec.
 */
const MODEL_RE = /^assets\/([a-z0-9_.-]+)\/models\/(.+)\.json$/;
const ITEM_RE = /^assets\/([a-z0-9_.-]+)\/items\/(.+)\.json$/;
const BLOCKSTATE_RE = /^assets\/([a-z0-9_.-]+)\/blockstates\/(.+)\.json$/;
const VALID_ID = /^[a-z0-9_.-]+(?::[a-z0-9_./-]+)?$/;
const DECODER = new TextDecoder('utf-8', {fatal:true});
const ENCODER = new TextEncoder();
const LIMITS={maxResourceBytes:24*1024*1024,maxTextBytes:2*1024*1024,maxParents:24,maxTextures:128};
const FACES=['north','south','east','west','up','down'];
const cubeFaces=(links)=>Object.fromEntries(FACES.map(f=>[f,{texture:'#'+(links[f]||'all'),cullface:f}]));
const VANILLA_MODELS = Object.freeze({
 'minecraft:block/cube_all':{elements:[{from:[0,0,0],to:[16,16,16],faces:cubeFaces({})}]},
 'minecraft:block/cube':{elements:[{from:[0,0,0],to:[16,16,16],faces:cubeFaces(Object.fromEntries(FACES.map(f=>[f,f])))}]},
 'minecraft:block/cube_bottom_top':{elements:[{from:[0,0,0],to:[16,16,16],faces:cubeFaces({north:'side',south:'side',east:'side',west:'side',up:'top',down:'bottom'})}]},
 'minecraft:block/cube_column':{elements:[{from:[0,0,0],to:[16,16,16],faces:cubeFaces({north:'side',south:'side',east:'side',west:'side',up:'end',down:'end'})}]},
 'minecraft:block/cross':{elements:[
  {from:[0,0,8],to:[16,16,8],rotation:{origin:[8,8,8],axis:'y',angle:45,rescale:true},faces:{north:{texture:'#cross'},south:{texture:'#cross'}}},
  {from:[8,0,0],to:[8,16,16],rotation:{origin:[8,8,8],axis:'y',angle:45,rescale:true},faces:{east:{texture:'#cross'},west:{texture:'#cross'}}}
 ]}
});
function canonical(id,defaultNs='minecraft') {
 if(typeof id!=='string'||!VALID_ID.test(id)||id.includes('..')||id.startsWith('/')||id.endsWith('/'))
  throw Error('Referencia inválida en el JSON: '+String(id).slice(0,150));
 return id.includes(':')?id:`${defaultNs}:${id}`;
}
function pathFor(kind, identifier,defaultNs) {
 const [ns,id]=canonical(identifier,defaultNs).split(':');
 if(!id||id.split('/').some(s=>!s||s==='.'||s==='..')) throw Error('Ruta de recurso inválida');
 return `assets/${ns}/${kind}/${id}.${kind==='textures'?'png':'json'}`;
}
function isBuiltIn(id) {return /^(?:minecraft:)?(?:builtin|item\/(?:generated|handheld|handheld_rod|template_.*))\b/.test(id);}
function safeObject(value,context){if(!value||typeof value!=='object'||Array.isArray(value))throw Error('JSON inválido en '+context);return value;}
function textFromBytes(bytes,path){if(!(bytes instanceof Uint8Array))bytes=new Uint8Array(bytes);if(bytes.byteLength>LIMITS.maxTextBytes)throw Error('JSON demasiado grande: '+path);return DECODER.decode(bytes);}
function directItemModel(root){
 if(!root.model||typeof root.model!=='object')throw Error('El ítem no contiene un selector model válido.');
 const m=root.model;
 if(m.type==='minecraft:model'||m.type==='model')return m.model;
 throw Error('Este ítem usa '+(m.type||'un selector condicional')+'. Seleccioná el modelo específico dentro de assets/*/models; no se puede suponer cuál de sus variantes se activa.');
}
function directBlockstateModel(root){
 const variants=root.variants;
 if(variants&&typeof variants==='object'){
  const values=Object.values(variants);if(values.length!==1)throw Error('El blockstate tiene varias variantes. Abrí el JSON del modelo específico para editar sin seleccionar una variante equivocada.');
  const v=values[0];if(Array.isArray(v))throw Error('El blockstate elige modelos ponderados. Seleccioná el modelo correspondiente.');
  return v?.model;
 }
 throw Error('Este blockstate usa multipart o variantes complejas; elegí un modelo dentro de assets/*/models.');
}
const makeVirtualText=object=>JSON.stringify(object);
async function fetchBytes(file,readBytes){let data=await readBytes(file);if(!(data instanceof Uint8Array))data=new Uint8Array(data);return data;}
function makeUri(bytes){ // bounded PNG to data URL, consumed by Blockbench's externalDataLoader
 let result='';for(let i=0;i<bytes.length;i+=8192)result+=String.fromCharCode(...bytes.subarray(i,i+8192));
 return 'data:image/png;base64,'+btoa(result);
}
/**
 * @param {object} opts {path,files,readBytes}
 * @returns {Promise<{path,text,originalPath,resources,warnings,dependencies,sourceId}>}
 */
export async function prepareMinecraftModel({path,files,readBytes}) {
 if(typeof path!=='string'||!Array.isArray(files)||typeof readBytes!=='function')throw TypeError('Argumentos inválidos');
 const lookup=new Map(files.map(f=>[f.path,f]));
 const notices=[];const dependencies=[];const resources=Object.create(null);
 async function loadJSON(p){const file=lookup.get(p);if(!file)return null;const data=await fetchBytes(file,readBytes);const text=textFromBytes(data,p);const parsed=safeObject(JSON.parse(text),p);resources[p]=text;dependencies.push(p);return {file,parsed,text};}
 const initial=await loadJSON(path);if(!initial)throw Error('Modelo no encontrado en el pack: '+path);
 let modelPath=path;
 let model=initial.parsed;
 const originalPath=path;
 if(ITEM_RE.test(path)) {
  const ns=ITEM_RE.exec(path)[1];
  modelPath=pathFor('models',directItemModel(model),ns);
  const entry=await loadJSON(modelPath);if(!entry)throw Error('El ítem referencia un modelo que falta: '+modelPath);
  model=entry.parsed;
 }else if(BLOCKSTATE_RE.test(path)){
  const ns=BLOCKSTATE_RE.exec(path)[1];
  modelPath=pathFor('models',directBlockstateModel(model),ns);
  const entry=await loadJSON(modelPath);if(!entry)throw Error('El bloque referencia un modelo que falta: '+modelPath);
  model=entry.parsed;
 }
 const match=MODEL_RE.exec(modelPath);
 if(!match)throw Error('Elegí un JSON de assets/<namespace>/models/ o una definición de ítem/bloque simple.');
 const currentNs=match[1];
 const visited=new Set([modelPath]);
 const lineage=[model];
 let child=model,level=0;
 while(typeof child.parent==='string'&&level++<LIMITS.maxParents){
  const id=canonical(child.parent,'minecraft');
  const parentPath=pathFor('models',id,'minecraft');
  if(visited.has(parentPath))throw Error('Referencia circular de modelos padre: '+parentPath);
  visited.add(parentPath);
  const loaded=await loadJSON(parentPath);
  if(loaded){lineage.push(loaded.parsed);child=loaded.parsed;continue;}
  if(VANILLA_MODELS[id]){
   resources[parentPath]=makeVirtualText(VANILLA_MODELS[id]);lineage.push(VANILLA_MODELS[id]);
   notices.push('Se utilizó la geometría vanilla '+id+' para la vista previa.');
  }else if(!isBuiltIn(id))notices.push('Falta el modelo padre '+parentPath+'. El resultado puede no tener geometría completa.');
  break;
 }
 if(level>LIMITS.maxParents)throw Error('Demasiados niveles de modelos padre (>24)');
 const textures=Object.assign(Object.create(null),...lineage.slice().reverse().map(layer=>layer.textures||{}));
 const texturePaths=new Set();
 for(const [key,definition] of Object.entries(textures)){
  if(key==='particle')continue;
  let value=definition;const seen=new Set([key]);
  for(let depth=0;depth<32;depth++){
   if(value&&typeof value==='object')value=value.sprite;
   if(typeof value!=='string')break;
   if(!value.startsWith('#'))break;
   const next=value.slice(1);
   if(seen.has(next)){notices.push('Referencia circular de textura #'+next);value=null;break;}
   seen.add(next);value=textures[next];
  }
  if(typeof value!=='string'||value.startsWith('#'))continue;
  if(value.startsWith('data:image/'))continue;
  try{texturePaths.add(pathFor('textures',value,'minecraft'));}catch{notices.push('Textura inválida en '+key);}
 }
 const selected=[...texturePaths].slice(0,LIMITS.maxTextures);
 if(texturePaths.size>LIMITS.maxTextures)notices.push('Se limitaron las texturas cargadas a 128.');
 let total=0;
 for(const texturePath of selected){
  const file=lookup.get(texturePath);
  if(!file){notices.push('Textura no incluida en pack: '+texturePath);continue;}
  const bytes=await fetchBytes(file,readBytes);
  total+=bytes.length;
  if(total>LIMITS.maxResourceBytes){notices.push('Texturas adicionales omitidas (límite 24 MiB).');break;}
  if(bytes.length<8||![137,80,78,71,13,10,26,10].every((x,i)=>bytes[i]===x)){
   notices.push('PNG inválido: '+texturePath);continue;
  }
  resources[texturePath]=makeUri(bytes);dependencies.push(texturePath);
 }
 return {path:modelPath, originalPath, text:resources[modelPath], sourceId:lookup.get(modelPath)?.id||null,
  resources,warnings:notices,dependencies};
}
export const RESOURCE_IMPORT_LIMITS=Object.freeze(LIMITS);
export const resourceModelPath=(kind,id,ns='minecraft')=>pathFor(kind,id,ns);
export const vanillaModelIds=()=>Object.keys(VANILLA_MODELS);
