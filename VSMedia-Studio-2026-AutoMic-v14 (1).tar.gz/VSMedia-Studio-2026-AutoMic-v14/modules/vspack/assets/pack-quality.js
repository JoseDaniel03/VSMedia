/* VSPack static quality inspection. No I/O or network. */
(function(scope){'use strict';
 const pngSig=[137,80,78,71,13,10,26,10];
 function checkPath(path){
  const issues=[];if(typeof path!=='string')return [{level:'error',title:'Ruta inválida'}];
  if(path.length>240)issues.push({level:'error',title:'Ruta demasiado larga',detail:'Límite de 240 caracteres para exportación segura.'});
  if(path.startsWith('/')||path.includes('\\')||path.split('/').some(x=>x==='..'||x==='.'||x===''))issues.push({level:'error',title:'Ruta insegura'});
  if(/^assets\//.test(path)){
   const parts=path.split('/'),ns=parts[1];if(!/^[a-z0-9_.-]+$/.test(ns||''))issues.push({level:'error',title:'Namespace inválido',detail:'Usá minúsculas, números, punto, guion o guion bajo.'});
   if(parts.slice(2).some(seg=>!/^[a-z0-9_.-]+$/.test(seg)))issues.push({level:'warning',title:'Ruta de recurso no estándar',detail:'Minecraft suele exigir rutas en minúsculas.'});
  }
  return issues;
 }
 function checkCaseCollisions(files){
  const seen=new Map(),issues=[];
  for(const file of files){const path=typeof file==='string'?file:file.path;const key=path.toLowerCase();if(seen.has(key)&&seen.get(key)!==path)issues.push({level:'error',title:'Colisión por mayúsculas',path,detail:`«${path}» y «${seen.get(key)}» compiten en sistemas de archivos distintos.`});else if(!seen.has(key))seen.set(key,path);}
  return issues;
 }
 function pngInfo(bytes){
  if(!(bytes instanceof Uint8Array)||bytes.length<24||pngSig.some((x,i)=>bytes[i]!==x))return {valid:false,issue:'Cabecera PNG inválida'};
  if(String.fromCharCode(...bytes.slice(12,16))!=='IHDR')return {valid:false,issue:'Falta bloque IHDR'};
  const v=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),width=v.getUint32(16),height=v.getUint32(20);
  if(!width||!height||width>32768||height>32768)return {valid:false,issue:'Dimensiones PNG inválidas'};
  return {valid:true,width,height,warnings:width>8192||height>8192?['Textura excesivamente grande']:[]};
 }
 /** Shared, conservative structural checks for the export and diagnostics screens.
   * Versions are NOT guessed: Minecraft compatibility still depends on the target game.
   */
 function checkPackMeta(pack){
  const issues=[];
  if(!pack || typeof pack!=='object' || Array.isArray(pack))return [{level:'error',title:'pack.mcmeta inválido',detail:'Se espera un objeto JSON con pack.'}];
  const meta=pack.pack;
  if(!meta || typeof meta!=='object' || Array.isArray(meta))return [{level:'error',title:'Manifiesto incompleto',detail:'Falta el objeto pack.'}];
  const description=meta.description;
  if(!(typeof description==='string'&&description.trim() || description&&typeof description==='object'&&!Array.isArray(description) || Array.isArray(description)&&description.length))
   issues.push({level:'error',title:'Descripción ausente',detail:'pack.description debe ser texto o un componente de texto válido.'});
  const format=meta.pack_format;
  const classic=Number.isInteger(format)&&format>0;
  const newRange=Number.isInteger(meta.min_format)&&meta.min_format>0&&Number.isInteger(meta.max_format)&&meta.max_format>=meta.min_format;
  const supported=Number.isInteger(meta.supported_formats)&&meta.supported_formats>0 ||
   Array.isArray(meta.supported_formats)&&meta.supported_formats.length>0&&meta.supported_formats.every(x=>Number.isInteger(x)&&x>0);
  if(!classic&&!newRange&&!supported)issues.push({level:'error',title:'Formato de pack ausente',detail:'Indicá pack_format o un rango de formatos reconocido.'});
  if(typeof format!=='undefined'&&!classic)issues.push({level:'error',title:'pack_format inválido',detail:'pack_format debe ser un entero positivo.'});
  if(('min_format' in meta || 'max_format' in meta)&&!newRange)issues.push({level:'error',title:'Rango de formato inválido',detail:'min_format y max_format deben ser enteros positivos ordenados.'});
  return issues;
 }
 function inspectEntries(entries,{maxIssues=160}={}){
  const issues=[];
  const push=(issue,path)=>{if(issues.length<maxIssues)issues.push({...issue,path:issue.path||path,detail:issue.detail||''});};
  for(const issue of checkCaseCollisions(entries))push(issue,issue.path||'');
  const seen=new Set();
  for(const entry of entries){
   const path=entry.path;
   if(seen.has(path))push({level:'error',title:'Ruta duplicada',detail:'Hay más de un archivo para la misma ruta.'},path);
   seen.add(path);
   for(const issue of checkPath(path))push(issue,path);
   const bytes=entry.bytes;
   if(!(bytes instanceof Uint8Array)){
    push({level:'error',title:'Archivo ausente',detail:'No fue posible leer los bytes del recurso.'},path);continue;
   }
   if(/\.png$/i.test(path)){
    const png=pngInfo(bytes);
    if(!png.valid)push({level:'error',title:'PNG inválido',detail:png.issue},path);
    else for(const msg of png.warnings)push({level:'warning',title:msg,detail:`${png.width} × ${png.height} px`},path);
   }
   if(/\.(?:json|mcmeta|bbmodel)$/i.test(path)){
    try{
     const value=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));
     if(value===null||typeof value!=='object'||Array.isArray(value))throw Error('Se espera un objeto JSON.');
     if(path==='pack.mcmeta')for(const issue of checkPackMeta(value))push(issue,path);
    }catch(e){push({level:'error',title:'JSON inválido',detail:e.message},path);}
   }
  }
  return issues;
 }
 scope.VSPackQuality={checkPath,checkCaseCollisions,pngInfo,checkPackMeta,inspectEntries};
 if(typeof module!=='undefined'&&module.exports)module.exports=scope.VSPackQuality;
})(typeof window!=='undefined'?window:globalThis);
