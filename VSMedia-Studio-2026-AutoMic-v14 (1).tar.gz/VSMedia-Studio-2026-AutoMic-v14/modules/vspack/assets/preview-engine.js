/* VSPack 1.8 — vistas reales de recursos: canvas, píxel exacto y miniaturas bajo demanda. */
(() => {
  'use strict';
  const IMAGE = /\.(png|jpe?g|gif|webp)$/i;
  const CLAMP = (v, low, high) => Math.max(low, Math.min(high, v));
  const mime = path => ({png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',gif:'image/gif',webp:'image/webp'})[String(path).split('.').pop().toLowerCase()] || 'application/octet-stream';
  const gcd = (a,b) => b ? gcd(b,a%b) : a;
  let generation=0, observer=null, alive=new Map(), urls=new Map(), queue=new Set(), batchPending=false;
  let fileLookup=new Map(), readBatch=null;
  const activeViewers=new Set();
  function reset() {
    generation++;
    observer?.disconnect();observer=null;
    queue.clear();batchPending=false;
    for(const view of activeViewers)view.dispose();
    activeViewers.clear();
    for(const u of urls.values())URL.revokeObjectURL(u);
    urls.clear();alive.clear();fileLookup.clear();readBatch=null;
  }
  function isImage(file){return file && IMAGE.test(file.path||'');}
  function markInvalid(slot, detail='No se pudo decodificar la imagen') {
    if(!slot?.isConnected)return;
    slot.classList.add('preview-error');slot.title=detail;
    const l=document.createElement('span');l.className='preview-error-text';l.textContent='Imagen no disponible';
    slot.replaceChildren(l);
  }
  function enqueue(id){queue.add(id);if(!batchPending){batchPending=true;queueMicrotask(flush);}}
  async function flush(){
    batchPending=false;
    const epoch=generation;
    const ids=[...queue].slice(0,40);ids.forEach(id=>queue.delete(id));
    if(queue.size){batchPending=true;queueMicrotask(flush);}
    if(!ids.length||!readBatch)return;
    let data;
    try{data=await readBatch(ids);}catch(e){if(epoch===generation)ids.forEach(id=>(alive.get(id)||[]).forEach(slot=>markInvalid(slot,e.message)));return;}
    if(epoch!==generation)return;
    for(let i=0;i<ids.length;i++){
      const id=ids[i],file=fileLookup.get(id),slots=alive.get(id)||[];
      if(!file||!data?.[i]){slots.forEach(slot=>markInvalid(slot,'No hay bytes guardados'));continue;}
      let url=urls.get(id);
      if(!url){url=URL.createObjectURL(new Blob([data[i]],{type:mime(file.path)}));urls.set(id,url);}
      for(const slot of slots){
        if(!slot.isConnected)continue;
        const img=document.createElement('img');
        img.className='resource-thumbnail';img.alt='Miniatura real de '+file.path.split('/').pop();
        img.loading='lazy';img.decoding='async';img.src=url;
        img.addEventListener('error',()=>markInvalid(slot,'Formato de imagen inválido'),{once:true});
        img.addEventListener('load',()=>{
          if(!slot.isConnected)return;
          slot.dataset.dimensions=`${img.naturalWidth} × ${img.naturalHeight}`;
          slot.title=`${file.path}\n${img.naturalWidth} × ${img.naturalHeight} px`;
        },{once:true});
        const typeTag=slot.querySelector('.type-tag');
        slot.replaceChildren(img);
        if(typeTag)slot.append(typeTag);
      }
    }
  }
  function tiles(files,getFilesBatch){
    const nodes=[...document.querySelectorAll('[data-preview-id], [data-manager-image]')];
    if(!nodes.length)return;
    fileLookup=new Map(files.filter(isImage).map(f=>[f.id,f]));readBatch=getFilesBatch;
    alive=new Map();
    for(const slot of nodes){
      const id=slot.dataset.previewId||slot.dataset.managerImage;
      if(!fileLookup.has(id))continue;
      if(!alive.has(id))alive.set(id,[]);
      alive.get(id).push(slot);
    }
    if('IntersectionObserver' in window){
      observer=new IntersectionObserver(changes=>{
        for(const entry of changes){if(!entry.isIntersecting)continue;observer?.unobserve(entry.target);const id=entry.target.dataset.previewId||entry.target.dataset.managerImage;if(id)enqueue(id);}
      },{rootMargin:'220px 0px',threshold:0.01});
      for(const slots of alive.values())for(const slot of slots)observer.observe(slot);
    }else for(const id of alive.keys())enqueue(id);
  }
  async function imageOf(bytes, path){
    const blob=new Blob([bytes],{type:mime(path)});
    if(typeof createImageBitmap==='function'){
      try{return {drawable:await createImageBitmap(blob),close(){this.drawable.close?.();}};}catch(e){/* Fallback image decoding. */}
    }
    const uri=URL.createObjectURL(blob);
    const image=new Image();
    try{
      image.src=uri;
      await new Promise((resolve,reject)=>{image.onload=resolve;image.onerror=()=>reject(Error('La imagen no se pudo decodificar'));});
      return {drawable:image,close(){URL.revokeObjectURL(uri);}};
    }catch(e){URL.revokeObjectURL(uri);throw e;}
  }
  async function open(slot,bytes,file){
    if(!slot?.isConnected||!isImage(file))return;
    const epoch=generation;
    let source;
    try{source=await imageOf(bytes,file.path);}catch(e){if(epoch===generation)markInvalid(slot,e.message);return;}
    if(epoch!==generation||!slot.isConnected){source.close();return;}
    const w=source.drawable.width||source.drawable.naturalWidth;
    const h=source.drawable.height||source.drawable.naturalHeight;
    if(!w||!h){source.close();markInvalid(slot);return;}
    const root=document.createElement('div');root.className='resource-viewer';root.tabIndex=0;root.setAttribute('aria-label','Visor de '+file.path);
    const bar=document.createElement('div');bar.className='resource-viewer-bar';
    bar.innerHTML='<div class="viewer-tools"><button type="button" data-v="fit" title="Ajustar al espacio">Ajustar</button><button type="button" data-v="actual" title="Un píxel de imagen por píxel CSS">1:1</button><button type="button" data-v="minus" title="Alejar">−</button><output data-v="scale" aria-live="off">100%</output><button type="button" data-v="plus" title="Acercar">+</button></div><div class="viewer-tools"><button type="button" data-v="grid" aria-pressed="false" title="Cuadrícula de píxeles">Cuadrícula</button><button type="button" data-v="background" title="Cambiar transparencia">Fondo</button><button type="button" data-v="fullscreen" title="Ampliar visor">⛶</button></div>';
    const viewport=document.createElement('div');viewport.className='resource-viewer-stage bg-checker';
    viewport.innerHTML='<canvas class="resource-viewer-canvas" aria-label="Vista ampliable de la imagen"></canvas>';
    const canvas=viewport.querySelector('canvas');
    const bottom=document.createElement('div');bottom.className='resource-viewer-meta';
    const aspect=gcd(w,h);
    bottom.innerHTML=`<span>${w} × ${h} px</span><span>${w/aspect}:${h/aspect}</span><span>${file.path.split('.').pop().toUpperCase()}</span><span class="viewer-probe" aria-live="polite">Arrastrá para mover · rueda para zoom</span>`;
    const frameCount=(w>0&&h>w&&h%w===0&&h/w<=64&&file.path.includes('/textures/')&&!file.path.includes('/textures/gui/')&&!file.path.includes('/textures/font/'))?h/w:1;
    if(frameCount>1){
      const strip=document.createElement('div');strip.className='viewer-tools viewer-frames';
      strip.innerHTML=`<button data-v="frame" type="button" title="Mostrar un cuadro de la tira">Ver fotograma</button><button data-v="prev" type="button" title="Fotograma anterior">‹</button><output data-v="frame-count">Tira completa</output><button data-v="next" type="button" title="Siguiente fotograma">›</button>`;
      bar.append(strip);
      const hint=document.createElement('span');hint.textContent=`Tira vertical: ${frameCount} cuadros posibles`;bottom.prepend(hint);
    }
    root.append(bar,viewport,bottom);slot.replaceChildren(root);
    let zoom=1,panX=0,panY=0,showGrid=false,shade=0,drag=null,disposed=false,fitReady=false,frame=0,frameMode=false,frameIndex=0;
    const visibleH=()=>frameMode?w:h;
    const frameOffset=()=>frameMode?frameIndex*w:0;
    const abort=new AbortController();
    const c=canvas.getContext('2d',{alpha:true});
    if(!c){source.close();markInvalid(slot,'Canvas 2D no disponible');return;}
    const output=bar.querySelector('[data-v="scale"]');
    const clampZoom=v=>CLAMP(v,1/4096,128);
    function measure(){return {width:Math.max(20,viewport.clientWidth),height:Math.max(20,viewport.clientHeight)};}
    function displayScale(){const p=zoom*100;output.value=(p>=10?String(Math.round(p)):p>=1?p.toFixed(1):p.toFixed(2))+'%';}
    function fit(){const size=measure();zoom=clampZoom(Math.min((size.width-36)/w,(size.height-36)/visibleH(),32));panX=(size.width-w*zoom)/2;panY=(size.height-visibleH()*zoom)/2;fitReady=true;draw();}
    function draw(){
      if(disposed)return;
      const size=measure(),dpr=Math.min(window.devicePixelRatio||1,2);
      const dw=Math.max(1,Math.round(size.width*dpr)),dh=Math.max(1,Math.round(size.height*dpr));
      if(canvas.width!==dw||canvas.height!==dh){canvas.width=dw;canvas.height=dh;canvas.style.width=size.width+'px';canvas.style.height=size.height+'px';}
      c.setTransform(dpr,0,0,dpr,0,0);c.clearRect(0,0,size.width,size.height);
      c.imageSmoothingEnabled=false;
      c.drawImage(source.drawable,0,frameOffset(),w,visibleH(),panX,panY,w*zoom,visibleH()*zoom);
      if(showGrid&&zoom>=9&&w+visibleH()<=3000){
        c.beginPath();c.strokeStyle='rgba(230,213,173,.28)';c.lineWidth=1;
        const minX=Math.max(0,Math.floor(-panX/zoom)),maxX=Math.min(w,Math.ceil((size.width-panX)/zoom));
        const minY=Math.max(0,Math.floor(-panY/zoom)),maxY=Math.min(visibleH(),Math.ceil((size.height-panY)/zoom));
        for(let x=minX;x<=maxX;x++){let xx=Math.round(panX+x*zoom)+0.5;c.moveTo(xx,Math.max(0,panY));c.lineTo(xx,Math.min(size.height,panY+visibleH()*zoom));}
        for(let y=minY;y<=maxY;y++){let yy=Math.round(panY+y*zoom)+0.5;c.moveTo(Math.max(0,panX),yy);c.lineTo(Math.min(size.width,panX+w*zoom),yy);}
        c.stroke();
      }
      displayScale();
    }
    function schedule(){if(frame)return;frame=requestAnimationFrame(()=>{frame=0;draw();});}
    function zoomAt(factor,cx,cy){const next=clampZoom(zoom*factor);if(next===zoom)return;const x=(cx-panX)/zoom,y=(cy-panY)/zoom;zoom=next;panX=cx-x*zoom;panY=cy-y*zoom;schedule();}
    const point=e=>{const rect=viewport.getBoundingClientRect();return {x:e.clientX-rect.left,y:e.clientY-rect.top};};
    function sample(x,y){
      const sx=Math.floor((x-panX)/zoom),sy=Math.floor((y-panY)/zoom);
      if(sx<0||sy<0||sx>=w||sy>=visibleH())return;
      const sampleCanvas=document.createElement('canvas');sampleCanvas.width=sampleCanvas.height=1;
      const sc=sampleCanvas.getContext('2d',{willReadFrequently:true});
      try{sc.drawImage(source.drawable,sx,sy+frameOffset(),1,1,0,0,1,1);const v=sc.getImageData(0,0,1,1).data;
        const code='#'+[...v].map(t=>t.toString(16).padStart(2,'0')).join('').toUpperCase();
        bottom.querySelector('.viewer-probe').textContent=`(${sx}, ${sy}) · ${code}`;
      }catch(e){bottom.querySelector('.viewer-probe').textContent=`(${sx}, ${sy}) · color no disponible`;}
    }
    viewport.addEventListener('wheel',e=>{e.preventDefault();const p=point(e);zoomAt(Math.exp(-CLAMP(e.deltaY,-180,180)*0.002),p.x,p.y);},{passive:false,signal:abort.signal});
    viewport.addEventListener('pointerdown',e=>{if(e.button!==0&&e.button!==1)return;e.preventDefault();const p=point(e);drag={id:e.pointerId,x:p.x,y:p.y,startX:p.x,startY:p.y,px:panX,py:panY};viewport.setPointerCapture(e.pointerId);},{signal:abort.signal});
    viewport.addEventListener('pointermove',e=>{if(!drag||drag.id!==e.pointerId)return;const p=point(e);panX=drag.px+(p.x-drag.x);panY=drag.py+(p.y-drag.y);schedule();},{signal:abort.signal});
    viewport.addEventListener('pointerup',e=>{if(!drag||drag.id!==e.pointerId)return;const p=point(e);if(Math.hypot(p.x-drag.startX,p.y-drag.startY)<5)sample(p.x,p.y);drag=null;},{signal:abort.signal});
    viewport.addEventListener('pointercancel',()=>{drag=null;},{signal:abort.signal});
    bar.addEventListener('click',async e=>{
      const key=e.target.closest('button[data-v]')?.dataset.v;if(!key)return;
      const {width,height}=measure();
      if(key==='fit')fit();else if(key==='actual'){const factor=1/zoom;zoomAt(factor,width/2,height/2);}
      else if(key==='plus')zoomAt(1.45,width/2,height/2);else if(key==='minus')zoomAt(1/1.45,width/2,height/2);
      else if(key==='grid'){showGrid=!showGrid;bar.querySelector('[data-v="grid"]').setAttribute('aria-pressed',String(showGrid));schedule();}
      else if(key==='background'){shade=(shade+1)%3;viewport.classList.toggle('bg-checker',shade===0);viewport.classList.toggle('bg-black',shade===1);viewport.classList.toggle('bg-sand',shade===2);}
      else if(key==='frame'&&frameCount>1){frameMode=!frameMode;bar.querySelector('[data-v="frame"]').textContent=frameMode?'Ver tira':'Ver fotograma';bar.querySelector('[data-v="frame-count"]').textContent=frameMode?`${frameIndex+1} / ${frameCount}`:'Tira completa';fit();}
      else if((key==='prev'||key==='next')&&frameCount>1){frameMode=true;frameIndex=(frameIndex+(key==='next'?1:-1)+frameCount)%frameCount;bar.querySelector('[data-v="frame"]').textContent='Ver tira';bar.querySelector('[data-v="frame-count"]').textContent=`${frameIndex+1} / ${frameCount}`;fit();}
      else if(key==='fullscreen'){try{if(document.fullscreenElement===root)await document.exitFullscreen();else await root.requestFullscreen();}catch(e){root.classList.toggle('preview-expanded');}setTimeout(fit,60);}
    },{signal:abort.signal});
    const ro=typeof ResizeObserver!=='undefined'?new ResizeObserver(()=>{if(disposed)return;if(!fitReady)fit();else schedule();}):null;
    ro?.observe(viewport);
    requestAnimationFrame(()=>{if(!disposed&&root.isConnected)fit();});
    const viewer={dispose(){if(disposed)return;disposed=true;ro?.disconnect();abort.abort();if(frame)cancelAnimationFrame(frame);source.close();activeViewers.delete(viewer);}};
    activeViewers.add(viewer);
    return viewer;
  }
  window.VSPreview={reset,tiles,open,isImage};
})();
