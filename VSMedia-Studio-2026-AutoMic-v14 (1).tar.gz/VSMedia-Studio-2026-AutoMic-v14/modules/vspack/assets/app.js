/* VSPack Foundry v3.0 — biblioteca, edición y publicación en un mismo ecosistema. */
(()=>{'use strict';
const $=(s,root=document)=>root.querySelector(s), $$=(s,root=document)=>[...root.querySelectorAll(s)];
const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uuid=()=>globalThis.crypto?.randomUUID?.() || `vp-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
const now=()=>new Date().toISOString();
const fmtSize=n=>n<1024?`${n} B`:n<1048576?`${(n/1024).toFixed(1)} KB`:`${(n/1048576).toFixed(2)} MB`;
const typeOf=path=>{const p=path.toLowerCase(),e=p.split('.').pop();if(p.includes('/textures/gui/')||p.includes('/gui/'))return 'interfaz';if(['png','jpg','jpeg','webp','gif'].includes(e))return 'textura';if(['ogg','mp3','wav','flac'].includes(e))return 'sonido';if(p.includes('/models/')||['bbmodel','obj','gltf','glb'].includes(e))return 'modelo';if(p.includes('/font/')||['ttf','otf'].includes(e))return 'fuente';if(p.includes('/shaders/'))return 'shader';if(['json','mcmeta','yml','yaml','properties','txt','mcfunction','lang'].includes(e))return 'configuración';return 'otro';};
const kindTitle={textura:'Texturas',sonido:'Sonidos',modelo:'Modelos',fuente:'Fuentes',shader:'Shaders',interfaz:'Interfaces',configuración:'Configuración',otro:'Otros'};
const iconPaths={library:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',editor:'<path d="m15 5 4 4M4 20l4-.8L20 7.3 16.7 4 4.8 15.9 4 20Z"/>',composer:'<path d="m12 3 9 5-9 5-9-5 9-5ZM3 12l9 5 9-5M3 16l9 5 9-5"/>',publisher:'<path d="M12 16V3m0 0 5 5m-5-5L7 8M5 16v3a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-3"/>',plus:'<path d="M12 5v14M5 12h14"/>',upload:'<path d="m12 16 0-13m0 0-5 5m5-5 5 5M4 17v3h16v-3"/>',package:'<path d="m12 2 9 5-9 5-9-5 9-5ZM3 7v10l9 5 9-5V7M12 12v10"/>',image:'<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8" cy="8" r="1"/><path d="m21 15-5-5L5 21"/>',sound:'<path d="M10 5 6 9H3v6h3l4 4V5ZM15 9a5 5 0 0 1 0 6M18 6a9 9 0 0 1 0 12"/>',file:'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6ZM14 2v6h6"/>',folder:'<path d="M3 7a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z"/>',search:'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',check:'<path d="m5 12 4 4L19 6"/>',warning:'<path d="M12 3 2 21h20L12 3Zm0 7v4m0 4h.01"/>',trash:'<path d="M4 7h16M10 11v6m4-6v6M6 7l1 14h10l1-14M9 7V4h6v3"/>',download:'<path d="M12 3v13m0 0 5-5m-5 5-5-5M5 19v2h14v-2"/>',layers:'<path d="m12 3 9 5-9 5-9-5 9-5ZM3 12l9 5 9-5M3 16l9 5 9-5"/>',eye:'<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',star:'<path d="m12 2 3 7 7 .8-5.3 5 1.6 7.2L12 18l-6.3 4 1.6-7.2-5.3-5L9 9l3-7Z"/>',refresh:'<path d="M20 7V3h-4M4 17v4h4M20 3a9 9 0 0 0-16 5M4 21a9 9 0 0 0 16-5"/>',chevron:'<path d="m9 18 6-6-6-6"/>',grip:'<path d="M9 5h.01M15 5h.01M9 12h.01M15 12h.01M9 19h.01M15 19h.01" stroke-width="3"/>',settings:'<circle cx="12" cy="12" r="3"/><path d="M12 2v3m0 14v3M2 12h3m14 0h3M5 5l2 2m10 10 2 2M5 19l2-2M17 7l2-2"/>'};
iconPaths.managers='<path d="M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z"/>';
function ic(name,size=17){return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${iconPaths[name]||iconPaths.file}</svg>`;}
const navs=[['library','Biblioteca'],['managers','Gestores'],['editor','Editor'],['composer','Compositor'],['publisher','Publicador']];
const fresh=()=>({packs:[],selectedPackId:null,selectedAssetId:null,view:'library',resolutions:{},packFormat:'',savedAt:null});
let state=fresh(),filter={query:'',kind:'todos',favorites:false,display:'grid',pack:'todos'},previewUrl=null,dbConn=null,editorDirty=false,report=null,working=false,uploadFolder='';
const getPack=id=>state.packs.find(p=>p.id===id),selectedPack=()=>getPack(state.selectedPackId),assets=()=>state.packs.flatMap(p=>p.files.map(f=>({...f,packId:p.id,packName:p.name})));
function toast(msg,error=false){const el=document.createElement('div');el.className='toast'+(error?' error':'');el.textContent=msg;$('#toast-root').append(el);setTimeout(()=>el.remove(),4800);}
function db(){if(dbConn)return Promise.resolve(dbConn);return new Promise((yes,no)=>{const req=indexedDB.open('vspack-local-v1',1);req.onupgradeneeded=()=>{let d=req.result;if(!d.objectStoreNames.contains('meta'))d.createObjectStore('meta');if(!d.objectStoreNames.contains('files'))d.createObjectStore('files');};req.onsuccess=()=>{dbConn=req.result;yes(dbConn);};req.onerror=()=>no(req.error);});}
async function metaRead(){let d=await db();return new Promise((yes,no)=>{let r=d.transaction('meta','readonly').objectStore('meta').get('state');r.onsuccess=()=>yes(r.result||null);r.onerror=()=>no(r.error);});}
async function storeState(){state.savedAt=now();report=null;diagReport=null;compositionCache=null;let d=await db();let serialized=structuredClone(state);return new Promise((yes,no)=>{let t=d.transaction('meta','readwrite');t.objectStore('meta').put(serialized,'state');t.oncomplete=yes;t.onerror=()=>no(t.error);});}
async function putFile(id,bytes){const d=await db();return new Promise((yes,no)=>{let t=d.transaction('files','readwrite');t.objectStore('files').put(bytes,id);t.oncomplete=yes;t.onerror=()=>no(t.error);});}
async function getFile(id){const d=await db();return new Promise((yes,no)=>{let r=d.transaction('files','readonly').objectStore('files').get(id);r.onsuccess=()=>yes(r.result||null);r.onerror=()=>no(r.error);});}
/** Atomic IndexedDB writes, avoiding one transaction per asset. */
async function putFilesBatch(items){
 if(!items.length)return;
 const d=await db();
 return new Promise((resolve,reject)=>{
  const tx=d.transaction('files','readwrite'),store=tx.objectStore('files');
  for(const item of items)store.put(item.bytes,item.id);
  tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||Error('Escritura cancelada'));
 });
}
/** Read all files from one stable read transaction, preserving order. */
async function getFilesBatch(ids){
 if(!ids.length)return [];
 const d=await db();
 return new Promise((resolve,reject)=>{
  const tx=d.transaction('files','readonly'),store=tx.objectStore('files');
  const out=new Array(ids.length);
  ids.forEach((id,i)=>{const req=store.get(id);req.onsuccess=()=>{out[i]=req.result||null;};});
  tx.oncomplete=()=>resolve(out);tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||Error('Lectura cancelada'));
 });
}
async function deleteFilesBatch(ids){
 if(!ids.length)return;
 const d=await db();
 return new Promise((resolve,reject)=>{
  const tx=d.transaction('files','readwrite'),store=tx.objectStore('files');
  for(const id of ids)store.delete(id);
  tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||Error('Borrado cancelado'));
 });
}
async function delFile(id){let d=await db();return new Promise((yes,no)=>{let t=d.transaction('files','readwrite');t.objectStore('files').delete(id);t.oncomplete=yes;t.onerror=()=>no(t.error);});}
function download(blob,name){const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),15000);}
function fileName(path){return path.split('/').pop();}
function normalize(path){return window.VSZip.cleanPath(path.trim());}
function rootPath(path){return path.replace(/^\/+/, '');}
function selectedAsset(){return assets().find(a=>a.id===state.selectedAssetId)||null;}
function titleNav(){return navs.find(n=>n[0]===state.view)?.[1]||'Biblioteca';}
function setView(v){if(!navs.some(n=>n[0]===v))return;if(!confirmUnsaved())return;if(managerTab==='pixel'){managerTab=pixelReturnTab;pixelSource=null;}if(managerTab==='model-studio'){managerTab=modelReturnTab;modelSource=null;}state.view=v;editorDirty=false;managerDirty=false;render();}
function confirmUnsaved(){if(modelSession?.busy){toast('Terminá la operación del modelo antes de salir.',true);return false;}return (!editorDirty && !managerDirty && !pixelSession?.dirty && !modelSession?.dirty) || confirm('Tenés cambios sin guardar. ¿Descartarlos?');}
function cleanPreviews(){if(previewUrl){URL.revokeObjectURL(previewUrl);previewUrl=null;}}
async function refreshState(){await storeState();render();}
function busy(on){working=on;document.body.classList.toggle('is-busy',on);}
function formatDate(s){return new Date(s).toLocaleDateString('es-AR',{day:'2-digit',month:'short',year:'numeric'});}
function renderSidebar(){const nav=$('#main-nav');nav.innerHTML=navs.map(([id,label])=>`<button class="nav-btn ${state.view===id?'active':''}" data-act="nav" data-v="${id}">${ic(id)} <span>${label}</span></button>`).join('');$('#sidebar-packs').innerHTML=state.packs.length?state.packs.map(p=>`<button class="side-pack ${state.selectedPackId===p.id?'on':''}" data-act="choose-pack" data-id="${p.id}"><span class="tiny-swatch"></span><span class="sp-name">${escape(p.name)}</span><span class="sp-count">${p.files.length}</span></button>`).join(''):`<div class="side-empty">Todavía no hay packs.</div>`;$('#breadcrumb').innerHTML=`VSPack <span class="chev">/</span> <strong>${titleNav()}</strong>`;}
function header(eyebrow,name,sub,tools=''){return `<section class="page-head"><div><div class="section-eyebrow">${eyebrow}</div><h1 class="page-title">${name}</h1><p class="subtitle">${sub}</p></div><div class="page-tools">${tools}</div></section>`;}
function btn(txt,act,style='secondary',extra=''){return `<button class="button ${style} compact" data-act="${act}" ${extra}>${txt}</button>`;}
function empty(icon,title,desc,action='',compact=false){return `<div class="empty ${compact?'empty-compact':''}"><div class="empty-icon">${ic(icon,25)}</div><h3>${title}</h3><p>${desc}</p>${action?`<div class="actions">${action}</div>`:''}</div>`;}
function thumb(a){const image=VSPreview.isImage(a);return `<div class="thumb" ${image?`data-preview-id="${a.id}"`:''}>${ic(a.kind==='sonido'?'sound':a.kind==='textura'||a.kind==='interfaz'?'image':a.kind==='modelo'?'package':'file',31)}<span class="type-tag">${escape(kindTitle[a.kind]||'Archivo')}</span></div>`;}
function assetCard(a){return `<div class="asset-card ${state.selectedAssetId===a.id?'selected':''}" role="button" tabindex="0" data-act="select-file" data-id="${a.id}">${thumb(a)}<div class="card-line"><span class="card-title" title="${escape(a.path)}">${escape(fileName(a.path))}</span><button data-act="fav" data-id="${a.id}" class="fav-btn ${a.favorite?'on':''}" title="Favorito">${a.favorite?'★':'☆'}</button></div><span class="card-sub">${escape(a.packName)} · ${fmtSize(a.size)}</span></div>`;}
function inspector(a){if(!a)return `<div class="pane"><div class="pane-heading"><strong>Inspector</strong></div>${empty('eye','Seleccioná un recurso','Verás la vista previa y sus propiedades.', '',true)}</div>`;return `<div class="pane"><div class="pane-heading"><strong>Inspector</strong><small>${escape(kindTitle[a.kind])}</small></div><div class="inspector"><div class="preview-box" id="inspect-preview">${ic(a.kind==='sonido'?'sound':a.kind==='textura'?'image':'file',45)}</div><h3 class="inspect-title">${escape(fileName(a.path))}</h3><div class="inspect-path">${escape(a.path)}</div><div class="divider"></div><div class="meta-row"><span>Pack</span><strong>${escape(a.packName)}</strong></div><div class="meta-row"><span>Tipo</span><strong>${escape(kindTitle[a.kind])}</strong></div><div class="meta-row"><span>Tamaño</span><strong>${fmtSize(a.size)}</strong></div><div class="meta-row"><span>Modificado</span><strong>${formatDate(a.modifiedAt)}</strong></div><div class="meta-row"><span>Etiquetas</span><strong>${escape(a.tags?.join(', ')||'Sin etiquetas')}</strong></div><div class="inspector-actions">${a.kind==='modelo'?btn('VS Model Studio','open-model','primary'):/\.(png|ase|aseprite|webp|jpe?g)$/i.test(a.path)?btn('VS Pixel Studio','open-pixel','primary'):btn('Abrir editor','edit-file','primary')}${btn('Descargar','download-file','secondary')}</div></div></div>`;}
function libPage(){let a=assets().filter(x=>(filter.pack==='todos'||x.packId===filter.pack)&&(filter.kind==='todos'||x.kind===filter.kind)&&(!filter.favorites||x.favorite)&&(`${x.path} ${x.packName} ${(x.tags||[]).join(' ')}`.toLowerCase().includes(filter.query.toLowerCase())));const all=assets();const p=selectedPack();const tools=btn(`${ic('folder')} Nueva carpeta`,'new-folder')+btn(`${ic('upload')} Añadir archivos`,'import-files')+(p?btn('Editar pack','edit-pack'):'');return `${header('ARCHIVO / 01','Biblioteca de recursos','Una biblioteca local. Tus packs, assets y colecciones, sin elementos de demostración.',tools)}
<div class="metric-strip"><div class="metric"><span class="metric-icon">${ic('package')}</span><div><strong>${state.packs.length}</strong><small>Packs locales</small></div></div><div class="metric"><span class="metric-icon">${ic('image')}</span><div><strong>${all.length}</strong><small>Archivos importados</small></div></div><div class="metric"><span class="metric-icon">${ic('layers')}</span><div><strong>${computeConflicts().length}</strong><small>Rutas compartidas</small></div></div><div class="metric"><span class="metric-icon">${ic('star')}</span><div><strong>${all.filter(x=>x.favorite).length}</strong><small>Favoritos</small></div></div></div>
${state.packs.length===0?`<div class="hero"><div class="hero-inner"><div class="section-eyebrow">BIENVENIDO AL ESTUDIO</div><h2>Un lugar para todos tus recursos.</h2><p>Importá tus propios Resource Packs ZIP o creá un pack vacío. No agregamos contenido de ejemplo.</p>${btn('Crear mi primer pack','create-pack','primary')} ${btn('Importar ZIP','import-zip')}</div><div class="hero-art" aria-hidden="true"><i></i><i></i><i></i></div></div>`:''}
<div class="section-head"><h3>Mis packs</h3><small>${state.packs.length} disponibles</small></div><div class="pack-list">${state.packs.map(p=>`<button class="pack-card ${p.id===state.selectedPackId?'active':''}" data-act="choose-pack" data-id="${p.id}"><div class="pack-cover">${ic('package',22)}</div><div><strong>${escape(p.name)}</strong><small>${p.files.length} archivos · v${escape(p.version||'1.0')}</small></div></button>`).join('')||`<div class="info-text">Todavía no creaste packs.</div>`}</div>
<div class="section-head"><h3>Recursos</h3><small>${a.length} encontrados</small></div>
<div class="toolbar"><label class="search-field">${ic('search')}<input id="library-search" placeholder="Buscar archivo, ruta, etiqueta..." value="${escape(filter.query)}" aria-label="Buscar recursos" /></label>
<select class="select" id="library-pack" aria-label="Filtrar por pack"><option value="todos">Todos los packs</option>${state.packs.map(p=>`<option value="${p.id}" ${filter.pack===p.id?'selected':''}>${escape(p.name)}</option>`).join('')}</select>
<select class="select" id="library-kind" aria-label="Filtrar tipo"><option value="todos">Todos los tipos</option>${Object.entries(kindTitle).map(([id,n])=>`<option value="${id}" ${filter.kind===id?'selected':''}>${n}</option>`).join('')}</select>
<button class="pill ${filter.favorites?'active':''}" data-act="filter-favs">${ic('star',13)} Favoritos</button><span class="toolbar-spacer"></span><button class="pill ${filter.display==='grid'?'active':''}" data-act="display-grid">Cuadrícula</button><button class="pill ${filter.display==='list'?'active':''}" data-act="display-list">Lista</button></div>
<div class="workspace"><section class="pane"><div class="pane-heading"><strong>Archivos ${p?`· ${escape(p.name)}`:''}</strong><small>${a.length} elementos</small></div>${a.length?filter.display==='grid'?`<div class="asset-grid">${a.map(assetCard).join('')}</div>`:`<table class="list-table"><thead><tr><th>Recurso</th><th>Tipo</th><th>Pack</th><th>Tamaño</th></tr></thead><tbody>${a.map(x=>`<tr class="${x.id===state.selectedAssetId?'selected':''}" data-act="select-file" data-id="${x.id}"><td><div class="list-name">${ic('file')} ${escape(x.path)}</div></td><td>${escape(kindTitle[x.kind])}</td><td>${escape(x.packName)}</td><td>${fmtSize(x.size)}</td></tr>`).join('')}</tbody></table>`:empty('folder','No hay recursos en esta vista',state.packs.length?'Añadí archivos o modificá los filtros.':'Creá o importá un pack para empezar.',btn('Importar ZIP','import-zip','primary'))}</section>${inspector(selectedAsset())}</div>`;}
function editorPage(){let a=selectedAsset();let p=selectedPack();const files=p?.files||[];const tool=btn(`${ic('upload')} Importar archivos`,'import-files')+btn(`${ic('folder')} Carpeta`,'new-folder');return `${header('TALLER / 02','Taller de recursos', 'Vista previa y edición local. Los modelos 3D se abren en VS Model Studio.',tool)}
<div class="toolbar"><select id="editor-pack" class="select"><option value="">Elegir pack</option>${state.packs.map(x=>`<option value="${x.id}" ${x.id===state.selectedPackId?'selected':''}>${escape(x.name)}</option>`).join('')}</select><span class="statusline">${files.length} archivos · ${p?.folders?.length||0} carpetas virtuales</span></div>
<div class="editor-grid"><section class="pane"><div class="pane-heading"><strong>Explorador</strong><small>${files.length} archivos</small></div><div class="editor-tree">${(p?.folders||[]).map(f=>`<button class="tree-item" title="${escape(f)}" data-act="browse-folder" data-path="${escape(f)}">${ic('folder')}<span class="ellipsis">${escape(f)}/</span></button>`).join('')}${files.map(f=>`<button class="tree-item ${f.id===state.selectedAssetId?'active':''}" data-act="select-editor-file" data-id="${f.id}" title="${escape(f.path)}">${ic(f.kind==='textura'?'image':f.kind==='sonido'?'sound':'file')}<span class="ellipsis">${escape(f.path)}</span></button>`).join('')||`<div class="side-empty">Pack vacío.</div>`}</div></section>
<section class="pane editor-canvas"><div class="editor-toolbar"><div><div class="kicker">VISTA PREVIA</div><strong>${escape(a?.path||'Sin archivo seleccionado')}</strong></div><div class="page-tools">${a?( /\.(png|ase|aseprite|webp|jpe?g)$/i.test(a.path)?btn('VS Pixel Studio','open-pixel','primary'):a?.kind==='modelo'?btn('VS Model Studio','open-model','primary'):'' )+btn(`${ic('download')} Descargar`,'download-file')+btn('Guardar texto','save-text','primary',!textEditable(a)?'disabled title="Solo archivos de texto"':''):''}</div></div><div class="editor-view" id="editor-preview">${a?`${ic(a.kind==='sonido'?'sound':a.kind==='textura'?'image':'file',38)}<span class="info-text">Cargando recurso...</span>`:empty('file','Elegí un archivo','Seleccioná un archivo de la izquierda o importá contenido al pack.')}</div></section>
<section class="pane"><div class="pane-heading"><strong>Propiedades</strong></div>${a?`<div class="property-pane"><div class="field"><label for="property-path">Ruta dentro del pack</label><input id="property-path" value="${escape(a.path)}"/></div><div class="field"><label for="property-tags">Etiquetas (separadas por comas)</label><input id="property-tags" value="${escape((a.tags||[]).join(', '))}"/></div><div class="field"><label>Clasificación</label><div class="detail-badge">${escape(kindTitle[a.kind])}</div></div><div class="meta-row"><span>Archivo</span><strong>${fmtSize(a.size)}</strong></div><div class="meta-row"><span>Pack</span><strong>${escape(a.packName)}</strong></div><div class="inspector-actions">${btn('Guardar propiedades','save-properties','primary')}${btn('Duplicar','duplicate-file')}</div><div class="divider"></div>${btn('Eliminar archivo','delete-file','warn')}</div>`:empty('settings','Sin selección','Elegí un recurso para modificar su ruta, etiquetas y contenido.', '',true)}</section></div>`;}
function orderedPacks(){return [...state.packs].sort((a,b)=>a.order-b.order);}
// Build a single index per update: O(total files) instead of rescanning packs for every path.
let compositionCache=null;
function compositionIndex(){
 if(compositionCache)return compositionCache;
 const byPath=new Map(),selection=new Map(),conflicts=[];
 for(const pack of orderedPacks()){
  if(pack.enabled===false)continue;
  for(const file of pack.files){
   let candidates=byPath.get(file.path);
   if(!candidates){candidates=[];byPath.set(file.path,candidates);}
   candidates.push({pack,file});
  }
 }
 for(const [path,candidates] of byPath){
  if(candidates.length>1)conflicts.push({path,candidates});
  selection.set(path,candidates.find(x=>x.pack.id===state.resolutions[path])||candidates[0]);
 }
 return compositionCache={byPath,selection,conflicts};
}
function computeConflicts(){return compositionIndex().conflicts;}
function candidate(path){return compositionIndex().selection.get(path)||null;}
function composed(){return [...compositionIndex().selection.values()].sort((a,b)=>a.file.path.localeCompare(b.file.path));}
function composerPage(){const ordered=orderedPacks(),conflicts=computeConflicts(),combined=composed();return `${header('COMPOSICIÓN / 03','Mesa de capas','Combiná packs, organizá prioridades y resolvé rutas en conflicto.')}
<div class="composer-grid"><section class="pane"><div class="pane-heading"><strong>Capas y prioridades</strong><small>Arriba = mayor prioridad</small></div><div class="layer-pane">${ordered.map((p,i)=>`<div class="layer-card"><span class="layer-grip" title="Usá las flechas para cambiar la prioridad">${ic('layers')}</span><label title="Activar o desactivar pack"><input type="checkbox" data-toggle-pack="${p.id}" ${p.enabled!==false?'checked':''}/></label><div class="layer-info"><strong>${escape(p.name)}</strong><small>${p.files.length} recursos · prioridad ${i+1}</small></div><div class="layer-actions"><button class="tiny-btn" data-act="layer-up" data-id="${p.id}" ${i===0?'disabled':''} title="Subir prioridad">↑</button><button class="tiny-btn" data-act="layer-down" data-id="${p.id}" ${i===ordered.length-1?'disabled':''} title="Bajar prioridad">↓</button></div></div>`).join('')||empty('package','Sin capas','Importá o creá un pack desde la Biblioteca.',btn('Crear pack','create-pack','primary'),true)}<div class="hint-box">Podés activar o desactivar packs y cambiar su orden. Ningún archivo original se modifica.</div></div></section>
<section class="pane"><div class="pane-heading"><strong>Resultado de la composición</strong><small>${combined.length} rutas únicas</small></div>${combined.length?`<div class="composition-visual"><div class="layer-stack" aria-hidden="true"><div></div><div></div><div></div></div><h3>Tu Resource Pack combinado</h3><p>Se incluyen ${combined.length} rutas únicas de ${ordered.filter(p=>p.enabled!==false).length} packs activos.</p><div class="publish-summary"><div class="sum-box"><small>Rutas finales</small><strong>${combined.length}</strong></div><div class="sum-box"><small>Conflictos</small><strong>${conflicts.length}</strong></div></div>${btn('Validar y publicar','go-publisher','primary')}</div><div class="pane-heading"><strong>Archivos resultantes</strong><small>Se muestran los primeros 30</small></div><div class="stack-pad"><table class="list-table"><tbody>${combined.slice(0,30).map(c=>`<tr><td class="break-all">${escape(c.file.path)}</td><td>${escape(c.pack.name)}</td></tr>`).join('')}</tbody></table></div>`:empty('layers','Esperando Resource Packs','Seleccioná o importá al menos un pack con archivos para componer.')}</section>
<section class="pane"><div class="pane-heading"><strong>Conflictos de rutas</strong><small>${conflicts.length} encontrados</small></div><div class="conflicts">${conflicts.length?conflicts.map(c=>`<div class="conflict-item"><strong>${escape(c.path)}</strong><small>${c.candidates.length} versiones disponibles</small><select data-conflict="${escape(c.path)}" class="conflict-choice" aria-label="Elegir archivo para ${escape(c.path)}">${c.candidates.map((x,i)=>`<option value="${x.pack.id}" ${candidate(c.path)?.pack.id===x.pack.id?'selected':''}>${escape(x.pack.name)} ${i===0?'(prioridad)':''}</option>`).join('')}</select></div>`).join(''):`${empty('check','Sin conflictos','Las rutas de los packs activos no se solapan.', '',true)}`}</div></section></div>`;}
function publisherPage(){let pack=selectedPack(),compo=composed(),valid=report;return `${header('EXPORTACIÓN / 04','Preparar publicación','Validá y exportá tus packs en ZIP, sin modificar el servidor.')}
<div class="stepper">${['Validar','Resolver','Construir','Exportar'].map((x,i)=>`<div class="step ${i===0?'current':''}"><span class="step-num">${i+1}</span><strong>${x}</strong></div>`).join('')}</div><div class="publication-grid"><section class="pane publication-card"><div class="section-eyebrow">RESULTADO</div><h2 class="page-title" style="font-size:27px">Validación del Resource Pack</h2><p class="subtitle">El pack se construye localmente; no se guardará una versión en Minecraft hasta integrarlo con el servidor.</p>
<div class="field" style="margin-top:20px"><label for="publish-target">Origen para exportación</label><select id="publish-target"><option value="composed" ${publishTarget==='composed'?'selected':''}>Composición completa</option>${state.packs.map(p=>`<option value="${p.id}" ${publishTarget===p.id?'selected':''}>Solo ${escape(p.name)}</option>`).join('')}</select></div>
<div class="field"><label for="pack-format">pack_format (ingresá el número compatible con tu Minecraft)</label><input id="pack-format" type="number" min="1" max="999999" placeholder="No establecido" value="${escape(state.packFormat||'')}"/><small>Si el ZIP ya incluye pack.mcmeta, se mantiene. Si falta, indicá pack_format para generarlo correctamente.</small></div>
<div class="divider"></div>${valid?valid.items.map(x=>`<div class="valid-line ${x.level==='error'?'fail':x.level==='warning'?'warn':'ok'}">${ic(x.level==='ok'?'check':'warning')}<div><strong>${escape(x.title)}</strong><small>${escape(x.path?x.path+' · ':'')}${escape(x.detail)}</small></div></div>`).join(''):`<div class="hint-box">Seleccioná «Analizar recursos» para comprobar metadatos, archivos y conflictos. No se muestra un resultado de validación ficticio.</div>`}
<div class="publication-actions" style="margin-top:22px">${btn('Analizar','validate','secondary')}${btn('Exportar ZIP','export-publish','primary')}</div></section>
<section class="pane publication-card"><div class="section-eyebrow">PANORAMA</div><h2 class="page-title" style="font-size:27px">Versión de salida</h2><div class="publish-summary"><div class="sum-box"><small>Archivos</small><strong>${publishTarget==='composed'?compo.length:(getPack(publishTarget)?.files?.length||0)}</strong></div><div class="sum-box"><small>Conflictos detectados</small><strong>${publishTarget==='composed'?computeConflicts().length:0}</strong></div></div><div class="meta-row"><span>Destino</span><strong>Archivo ZIP local</strong></div><div class="meta-row"><span>Servidor</span><strong>No conectado</strong></div><div class="meta-row"><span>API VSRender</span><strong>Contrato futuro</strong></div><div class="divider"></div><div class="section-eyebrow">PUBLICACIÓN SEGURA</div><p class="info-text">No se sobrescribe ningún recurso del plugin. El ZIP se descarga a tu equipo y puede revisarse antes de una importación manual.</p>${pack?`<div class="hint-box">Pack activo: <strong>${escape(pack.name)}</strong>. Los metadatos se conservan localmente en este navegador.</div>`:''}</section></div>`;}
let publishTarget='composed';
let renderedView=null;
let searchTimer=0;
function render(){
 compositionCache=null;
 if(searchTimer){clearTimeout(searchTimer);searchTimer=0;}
 if(pixelSession){pixelSession.dispose();pixelSession=null;}
 if(modelSession){modelSession.dispose();modelSession=null;}
 const pixelActive=state.view==='managers'&&managerTab==='pixel';
 const modelActive=state.view==='managers'&&managerTab==='model-studio';
 document.body.classList.toggle('model-workspace-active',modelActive);
 document.body.classList.toggle('pixel-workspace-active',pixelActive);
 const keepPosition=renderedView===state.view;
 const oldScroll=window.scrollY;
 VSPreview.reset();cleanPreviews();releaseManagerURLs();renderSidebar();
 $('#main-content').innerHTML=state.view==='library'?libPage():state.view==='managers'?managerPage():state.view==='editor'?editorPage():state.view==='composer'?composerPage():publisherPage();
 renderedView=state.view;
 if(keepPosition)window.scrollTo(0,oldScroll);else window.scrollTo(0,0);
 VSPreview.tiles(assets(),getFilesBatch);
 hydratePreviews();hydrateManagers();
 notifyHost('change');
}
function textEditable(a){return ['json','mcmeta','txt','lang','yml','yaml','properties','mcfunction','fsh','vsh','glsl','mcshader'].includes(a.path.split('.').pop().toLowerCase());}
async function hydratePreviews(){
 const a=selectedAsset();if(!a)return;
 const place=state.view==='editor'?$('#editor-preview'):$('#inspect-preview');if(!place)return;
 const key=a.id,bytes=await getFile(key);
 if(!place.isConnected||selectedAsset()?.id!==key)return;
 if(!bytes){place.textContent='Archivo no disponible en almacenamiento local';return;}
 if(VSPreview.isImage(a)){await VSPreview.open(place,bytes,a);return;}
 if(a.kind==='sonido'){
  previewUrl=URL.createObjectURL(new Blob([bytes],{type:guessMime(a.path)}));
  place.innerHTML=`<audio controls preload="metadata" src="${previewUrl}"></audio>`;return;
 }
 if(state.view==='editor'&&textEditable(a)){
  place.innerHTML='<textarea id="text-source" spellcheck="false" aria-label="Contenido del archivo" placeholder="Contenido de texto..."></textarea>';
  $('#text-source').value=new TextDecoder('utf-8').decode(bytes);
  $('#text-source').addEventListener('input',()=>editorDirty=true);return;
 }
 place.innerHTML=`<div class="empty empty-compact">${ic('file',32)}<h3>Vista previa no disponible</h3><p>Podés descargar este archivo o inspeccionarlo con un gestor especializado.</p></div>`;
}
function guessMime(p){const ext=p.split('.').pop().toLowerCase();return ({png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',gif:'image/gif',webp:'image/webp',ogg:'audio/ogg',mp3:'audio/mpeg',wav:'audio/wav',flac:'audio/flac',json:'application/json',mcmeta:'application/json'})[ext]||'application/octet-stream';}
function modal(title,desc,fields,onSubmit,danger=false){const root=$('#dialog-root');root.innerHTML=`<div class="dialog-backdrop"><div class="dialog" role="dialog" aria-modal="true" aria-labelledby="dialog-title"><button class="dialog-close" type="button" aria-label="Cerrar" data-close>×</button><h2 id="dialog-title">${escape(title)}</h2><p>${escape(desc)}</p><form id="modal-form">${fields}<div class="form-actions"><button class="button secondary" type="button" data-close>Cancelar</button><button class="button ${danger?'warn':'primary'}" type="submit">${danger?'Confirmar':'Aceptar'}</button></div></form></div></div>`;const form=$('#modal-form');root.onclick=ev=>{if(ev.target.matches('[data-close], .dialog-backdrop')){root.innerHTML='';root.onclick=null;}};form.addEventListener('submit',async ev=>{ev.preventDefault();let b=$('button[type=submit]',form);b.disabled=true;try{const result=await onSubmit(new FormData(form));if(result!==false){root.innerHTML='';root.onclick=null;render();}}catch(e){toast(e.message||String(e),true);}finally{b.disabled=false;}});setTimeout(()=>form.querySelector('input,select,textarea')?.focus(),15);}
function field(name,label,value='',type='text',required=true){return `<div class="field"><label for="field-${name}">${label}</label><input id="field-${name}" name="${name}" type="${type}" value="${escape(value)}" ${required?'required':''} ${name==='name'?'maxlength="96"':''}/></div>`;}
function createPack(){modal('Nuevo Resource Pack','Creá un pack vacío. Podrás importar archivos, generar carpetas y exportarlo después.',field('name','Nombre del pack')+field('version','Versión','1.0.0')+`<div class="field"><label for="desc">Descripción</label><textarea name="description" id="desc" rows="3" placeholder="Opcional"></textarea></div>`,async d=>{let name=String(d.get('name')||'').trim();if(!name)throw Error('Ingresá un nombre');let p={id:uuid(),name,version:String(d.get('version')||'1.0.0'),description:String(d.get('description')||''),createdAt:now(),order:state.packs.length,enabled:true,folders:[],files:[]};state.packs.push(p);state.selectedPackId=p.id;filter.pack='todos';await refreshState();toast('Pack creado');});}
function editPack(){const p=selectedPack();if(!p)return;modal('Editar pack','Cambiá la información de tu pack local.',field('name','Nombre',p.name)+field('version','Versión',p.version)+`<div class="field"><label for="pack-desc">Descripción</label><textarea id="pack-desc" name="description" rows="3">${escape(p.description||'')}</textarea></div><div class="divider"></div><button type="button" class="button warn" data-act="delete-pack" data-id="${p.id}">Eliminar pack</button>`,async d=>{p.name=String(d.get('name')).trim();if(!p.name)throw Error('El nombre no puede estar vacío');p.version=String(d.get('version')).trim();p.description=String(d.get('description')||'');await refreshState();toast('Pack actualizado');});}
function deletePack(id){const p=getPack(id);if(!p)return;$('#dialog-root').innerHTML='';modal('Eliminar pack completo',`Se eliminarán ${p.files.length} archivos de ${p.name} en este navegador. Exportá un ZIP antes de continuar si querés conservarlo.`, `<div class="hint-box">No afecta los archivos originales ni ningún servidor.</div>`,async()=>{await deleteFilesBatch(p.files.map(f=>f.id));state.packs=state.packs.filter(x=>x.id!==id);state.packs.forEach((x,i)=>x.order=i);state.selectedPackId=state.packs[0]?.id||null;state.selectedAssetId=null;if(filter.pack===id)filter.pack='todos';await refreshState();toast('Pack eliminado');},true);}
function choosePack(id){const p=getPack(id);if(!p)return;state.selectedPackId=id;if(!p.files.some(f=>f.id===state.selectedAssetId))state.selectedAssetId=p.files[0]?.id||null;filter.pack=id;storeState().then(render);}
function safeFolder(path){let normalized=normalize(path.replace(/\/+$/,''));if(normalized.length>220)throw Error('Ruta demasiado larga');return normalized;}
function createFolder(){if(!selectedPack())return toast('Primero creá o seleccioná un pack',true);modal('Nueva carpeta','Podés crear subcarpetas escribiendo una ruta con /.',field('name','Ruta de carpeta (por ejemplo assets/virgoland/textures)'),async d=>{let p=selectedPack(),path=safeFolder(String(d.get('name')));if(!p.folders)p.folders=[];if(p.folders.includes(path))throw Error('Esa carpeta ya existe');p.folders.push(path);await refreshState();toast('Carpeta creada');});}
function importZIP(){if(working)return;$('#zip-upload').click();}
function importFiles(){if(!selectedPack()){toast('Primero elegí o creá un pack',true);return;}if(state.view!=='managers'||managerTab!=='files')uploadFolder='';$('#asset-upload').click();}
function uniquePath(p,path){let base=path,idx=2;while(p.files.some(f=>f.path===path)){const i=base.lastIndexOf('.');path=(i>0?base.slice(0,i):base)+`_${idx++}`+(i>0?base.slice(i):'');}return path;}
function createAsset(p,path,bytes){return {id:uuid(),path,kind:typeOf(path),size:bytes.length,tags:[],favorite:false,modifiedAt:now()};}
async function doImportZip(files){if(!files.length)return;busy(true);let count=0;try{for(const file of files){if(file.size>80*1024*1024)throw Error('ZIP comprimido demasiado grande (límite: 80 MB)');const entries=await VSZip.read(file,{maxEntries:1500,maxBytes:128*1024*1024,maxSingle:32*1024*1024});if(!entries.length)throw Error('ZIP vacío');if(entries.some(e=>e.path===WORKSPACE_BACKUP_PATH))throw Error('Este ZIP es una copia completa. Usá Gestores → Packs → Restaurar copia.');let names=entries.map(x=>x.path),prefix='';const hasRoot=names.some(n=>n==='pack.mcmeta'||n.startsWith('assets/'));if(!hasRoot){const dir=names[0].split('/')[0]+'/';if(names.every(n=>n.startsWith(dir)))prefix=dir;}
const p={id:uuid(),name:file.name.replace(/\.zip$/i,''),version:'1.0.0',description:'',createdAt:now(),order:state.packs.length,enabled:true,folders:[],files:[]};const used=new Set(),batch=[];
for(const e of entries){let path=e.path.slice(prefix.length);if(!path||path.includes('__MACOSX/')||path.split('/').some(s=>s.startsWith('.DS_Store')))continue;path=normalize(path);if(used.has(path))throw Error('Rutas duplicadas en ZIP: '+path);used.add(path);let a=createAsset(p,path,e.bytes);batch.push({id:a.id,bytes:e.bytes});p.files.push(a);}
await putFilesBatch(batch);state.packs.push(p);state.selectedPackId=p.id;state.selectedAssetId=p.files[0]?.id||null;count++;await storeState();}filter.pack='todos';toast(`${count} pack(s) importado(s) correctamente`);}catch(e){toast(e.message||String(e),true);}finally{busy(false);render();}}
async function doImportAssets(files){const p=selectedPack();if(!p)return;const destination=uploadFolder;uploadFolder='';busy(true);try{const batch=[],newAssets=[],seen=new Set(p.files.map(f=>f.path));
for(const file of files){
 if(file.size>32*1024*1024)throw Error(`Archivo demasiado grande: ${file.name} (máximo 32 MB)`);
 const base=normalize(destination+rootPath(file.webkitRelativePath||file.name));
 let path=base,suffix=2;const dot=base.lastIndexOf('.');
 while(seen.has(path))path=(dot>0?base.slice(0,dot):base)+`_${suffix++}`+(dot>0?base.slice(dot):'');
 seen.add(path);
 const bytes=new Uint8Array(await file.arrayBuffer()),asset=createAsset(p,path,bytes);
 batch.push({id:asset.id,bytes});newAssets.push(asset);
}
await putFilesBatch(batch);p.files.push(...newAssets);
if(newAssets.length)state.selectedAssetId=newAssets.at(-1).id;
await storeState();toast(`${newAssets.length} archivo(s) agregados`);}catch(e){toast(e.message||String(e),true);}finally{busy(false);render();}}
async function exportFile(){let a=selectedAsset();if(!a)return;const bytes=await getFile(a.id);if(bytes)download(new Blob([bytes],{type:guessMime(a.path)}),fileName(a.path));}
async function saveProperties(){let a=selectedAsset();if(!a)return;let pack=getPack(a.packId);try{const path=normalize($('#property-path').value);if(pack.files.some(f=>f.id!==a.id&&f.path===path))throw Error('Ya existe un archivo con esa ruta');let f=pack.files.find(x=>x.id===a.id);f.path=path;f.kind=typeOf(path);f.tags=($('#property-tags')?.value||'').split(',').map(x=>x.trim()).filter(Boolean).slice(0,20);f.modifiedAt=now();await refreshState();toast('Propiedades actualizadas');}catch(e){toast(e.message,true);}}
async function saveText(){let a=selectedAsset();if(!a||!textEditable(a))return;let area=$('#text-source');if(!area)return;try{let text=area.value;if(/\.(json|mcmeta)$/i.test(a.path))JSON.parse(text);let b=new TextEncoder().encode(text);await putFile(a.id,b);let f=getPack(a.packId).files.find(f=>f.id===a.id);f.size=b.length;f.modifiedAt=now();editorDirty=false;await storeState();toast('Contenido guardado');}catch(e){toast(`No se pudo guardar: ${e.message}`,true);}}
function askDelete(){const a=selectedAsset();if(!a)return;modal('Eliminar recurso',`Se eliminará ${a.path} de la biblioteca local.`, `<div class="hint-box">Esta acción no modifica los archivos originales de tu computadora.</div>`,async()=>{let p=getPack(a.packId);p.files=p.files.filter(f=>f.id!==a.id);await delFile(a.id);state.selectedAssetId=p.files[0]?.id||null;await refreshState();toast('Archivo eliminado');},true);}
/** Una única implementación de duplicado para Biblioteca y Gestor de Archivos. */
async function duplicateAssetFile(pack,file){
 if(!pack||!file)throw Error('Elegí un recurso para duplicar.');
 const bytes=await getFile(file.id);
 if(!(bytes instanceof Uint8Array))throw Error('No se encontró el archivo de origen.');
 const copy={...file,id:uuid(),path:uniquePath(pack,file.path),modifiedAt:now(),tags:[...(file.tags||[])]};
 await putFile(copy.id,bytes);pack.files.push(copy);
 return copy;
}
async function duplicate(){
 const selected=selectedAsset();if(!selected)return;
 try{const copy=await duplicateAssetFile(getPack(selected.packId),selected);state.selectedAssetId=copy.id;await refreshState();toast('Recurso duplicado');}
 catch(error){toast(error.message,true);}
}
async function toggleFav(id){let a=assets().find(x=>x.id===id);if(!a)return;let f=getPack(a.packId).files.find(x=>x.id===id);f.favorite=!f.favorite;await refreshState();}
async function changePriority(id,up){let ordered=orderedPacks(),i=ordered.findIndex(x=>x.id===id),j=i+(up?-1:1);if(j<0||j>=ordered.length)return;[ordered[i],ordered[j]]=[ordered[j],ordered[i]];ordered.forEach((p,n)=>p.order=n);await refreshState();}
function entriesForTarget(){return publishTarget==='composed'?composed():((getPack(publishTarget)?.files||[]).map(f=>({pack:getPack(publishTarget),file:f})));}
async function buildEntries(){
 const selected=entriesForTarget();
 const bytes=await getFilesBatch(selected.map(x=>x.file.id));
 return selected.map((x,i)=>{
  if(!bytes[i])throw Error('No se encuentra '+x.file.path+' en el almacenamiento local');
  return {path:x.file.path,bytes:bytes[i]};
 });
}
function generatedMeta(){const fmt=parseInt(state.packFormat,10);if(!Number.isInteger(fmt)||fmt<=0)throw Error('Falta pack.mcmeta. Ingresá un pack_format válido para generar uno.');const desc=publishTarget==='composed'?'VSPack — Composición local':getPack(publishTarget)?.description||getPack(publishTarget)?.name||'VSPack';return new TextEncoder().encode(JSON.stringify({pack:{pack_format:fmt,description:desc}},null,2));}
async function validate(){
 const entries=await buildEntries(),issues=[],add=(level,title,detail,path='')=>issues.push({level,title,detail,path});
 if(!entries.length)add('error','Sin archivos','Seleccioná un pack que contenga recursos.');
 else add('ok','Archivos accesibles',`${entries.length} archivos locales disponibles.`);
 if(publishTarget==='composed')add('ok','Prioridades aplicadas',`${computeConflicts().length} rutas compartidas resueltas mediante prioridad o selección explícita.`);
 issues.push(...VSPackQuality.inspectEntries(entries));
 const mcmeta=entries.find(e=>e.path==='pack.mcmeta');
 if(!mcmeta){try{generatedMeta();add('ok','pack.mcmeta generado',`Se generará con pack_format ${state.packFormat}. Verificá que corresponda a tu Minecraft.`);}
   catch(error){add('error','Falta pack.mcmeta',error.message);}}
 // Un formato válido no garantiza que todos los modelos, shaders o referencias sean compatibles.
 const errors=issues.filter(x=>x.level==='error').length;
 if(!errors)add('ok','Validación estructural finalizada','Se verificaron rutas, colisiones, PNG, JSON y metadatos. No sustituye una prueba dentro del juego.');
 report={items:issues,errors,warnings:issues.filter(x=>x.level==='warning').length,at:now()};
 render();return report;
}
async function exportPack(){if(working)return;busy(true);try{const r=await validate();if(r.errors){toast('Revisá los errores antes de exportar',true);return;}const entries=await buildEntries();if(!entries.some(x=>x.path==='pack.mcmeta'))entries.push({path:'pack.mcmeta',bytes:generatedMeta()});const w=VSZip.optimizedWriter();for(const e of entries)await w.add(e.path,e.bytes);const name=publishTarget==='composed'?'VSPack-composicion':getPack(publishTarget)?.name||'VSPack';download(w.finish(),name.replace(/[^a-z\d._-]+/gi,'-')+'.zip');toast('ZIP exportado localmente');}catch(e){toast('No se pudo exportar: '+e.message,true);}finally{busy(false);}}

/* Portable VSPack library backup. Unlike a Minecraft pack ZIP, this preserves
 * packs, ordering, favorites, tags and raw assets in one user-owned ZIP. */
const WORKSPACE_BACKUP_PATH='__vspack_workspace__/manifest.json';
const WORKSPACE_BACKUP_SCHEMA='vspack-workspace-v1';
const WORKSPACE_BACKUP_LIMIT=128*1024*1024;
async function exportWorkspaceBackup(){
 if(working)return;
 busy(true);
 try{
  const packs=orderedPacks();
  const totalFiles=packs.reduce((n,p)=>n+p.files.length,0);
  if(packs.length>100||totalFiles>4000)throw Error('El respaldo admite hasta 100 packs y 4000 archivos.');
  const totalBytes=packs.reduce((n,p)=>n+p.files.reduce((a,f)=>a+f.size,0),0);
  if(totalBytes>WORKSPACE_BACKUP_LIMIT)throw Error('La biblioteca supera 128 MiB. Exportá los packs individuales antes de continuar.');
  const files=packs.flatMap(p=>p.files);
  const contents=await getFilesBatch(files.map(f=>f.id));
  const writer=VSZip.optimizedWriter();let ix=0;
  const metadataPacks=[];
  for(let pi=0;pi<packs.length;pi++){
   const pack=packs[pi];
   metadataPacks.push({id:pack.id,name:pack.name,version:pack.version,description:pack.description,
    order:pack.order,enabled:pack.enabled,folders:pack.folders||[],
    files:pack.files.map((file,fi)=>({...file,backupPath:`data/${pi}/${fi}.bin`}))});
   for(let fi=0;fi<pack.files.length;fi++){
    const data=contents[ix++];
    if(!(data instanceof Uint8Array))throw Error('Faltan bytes del archivo '+pack.files[fi].path);
    await writer.add(`data/${pi}/${fi}.bin`,data);
   }
  }
  await writer.add(WORKSPACE_BACKUP_PATH,new TextEncoder().encode(JSON.stringify({
   schema:WORKSPACE_BACKUP_SCHEMA,createdAt:now(),packFormat:state.packFormat||'',
   resolutions:state.resolutions||{},packs:metadataPacks
  })));
  download(writer.finish(),`VSPack-biblioteca-${new Date().toISOString().slice(0,10)}.zip`);
  toast(`Copia exportada: ${packs.length} packs · ${totalFiles} archivos`);
 }catch(error){toast('No se pudo crear el respaldo: '+error.message,true);}finally{busy(false);}
}
function validateBackupPackage(entries){
 const map=new Map(entries.map(e=>[e.path,e.bytes]));
 const manifest=map.get(WORKSPACE_BACKUP_PATH);
 if(!manifest||manifest.length>8*1024*1024)throw Error('La copia no tiene un manifiesto VSPack válido.');
 let data;
 try{data=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(manifest));}
 catch{throw Error('El manifiesto de respaldo no es JSON válido.');}
 if(data?.schema!==WORKSPACE_BACKUP_SCHEMA||!Array.isArray(data.packs)||data.packs.length>100)
  throw Error('El archivo no es una copia compatible de la biblioteca.');
 const usedIds=new Set(),newPacks=[],batch=[];
 let files=0,total=0;
 for(const saved of data.packs){
  if(typeof saved.name!=='string'||!saved.name.trim()||saved.name.length>96||!Array.isArray(saved.files))
   throw Error('Metadatos de pack inválidos.');
  const packId=uuid();const seenPaths=new Set();const restoredFiles=[];
  for(const entry of saved.files){
   if(++files>4000||typeof entry.path!=='string'||typeof entry.backupPath!=='string')throw Error('Cantidad o nombre de archivos inválido.');
   if(VSZip.cleanPath(entry.path)!==entry.path||VSPackQuality.checkPath(entry.path).some(x=>x.level==='error'))
    throw Error('El respaldo contiene una ruta insegura: '+entry.path);
   if(seenPaths.has(entry.path))throw Error('Ruta duplicada en la copia: '+entry.path);
   seenPaths.add(entry.path);
   if(!/^data\/\d+\/\d+\.bin$/.test(entry.backupPath)||usedIds.has(entry.backupPath))
    throw Error('Referencia de archivo inválida en el respaldo.');
   usedIds.add(entry.backupPath);
   const bytes=map.get(entry.backupPath);
   if(!(bytes instanceof Uint8Array)||bytes.length>32*1024*1024||(total+=bytes.length)>WORKSPACE_BACKUP_LIMIT)
    throw Error('Falta un archivo o la copia supera los límites permitidos.');
   const id=uuid();
   batch.push({id,bytes});
   restoredFiles.push({id,path:entry.path,kind:typeOf(entry.path),size:bytes.length,
    tags:Array.isArray(entry.tags)?entry.tags.filter(x=>typeof x==='string').slice(0,20):[],
    favorite:entry.favorite===true,modifiedAt:typeof entry.modifiedAt==='string'?entry.modifiedAt:now()});
  }
  newPacks.push({id:packId,oldId:saved.id,name:saved.name,version:String(saved.version||'1.0.0').slice(0,48),
   description:String(saved.description||'').slice(0,2048),createdAt:now(),
   order:state.packs.length+newPacks.length,enabled:saved.enabled!==false,
   folders:Array.isArray(saved.folders)?saved.folders.filter(path=>typeof path==='string'&&path.length<=240&&
    !VSPackQuality.checkPath(path).some(x=>x.level==='error')).slice(0,200):[],files:restoredFiles});
 }
 return {data,newPacks,batch};
}
async function importWorkspaceBackup(file){
 if(!file||working)return;
 if(file.size>140*1024*1024)throw Error('El ZIP supera los 140 MiB permitidos.');
 busy(true);
 try{
  const entries=await VSZip.read(file,{maxEntries:4001,maxBytes:WORKSPACE_BACKUP_LIMIT+8*1024*1024,maxSingle:32*1024*1024});
  const {data,newPacks,batch}=validateBackupPackage(entries);
  if(!newPacks.length)throw Error('La copia está vacía.');
  if(!confirm(`Se añadirán ${newPacks.length} packs (${batch.length} archivos) a tu biblioteca actual, sin borrar los existentes. ¿Restaurar?`))return;
  await putFilesBatch(batch);
  const oldPacks=state.packs,oldResolutions=state.resolutions;
  const remap=new Map(newPacks.map(p=>[p.oldId,p.id]));
  const nextResolutions={...state.resolutions};
  for(const [path,oldId] of Object.entries(data.resolutions||{})){
   if(remap.has(oldId)&&!(path in nextResolutions))nextResolutions[path]=remap.get(oldId);
  }
  state.packs=[...oldPacks,...newPacks.map(({oldId,...p})=>p)];
  state.resolutions=nextResolutions;
  if(!state.selectedPackId)state.selectedPackId=newPacks[0].id;
  try{await storeState();}catch(error){state.packs=oldPacks;state.resolutions=oldResolutions;await deleteFilesBatch(batch.map(file=>file.id));throw error;}
  toast(`Copia restaurada: ${newPacks.length} packs y ${batch.length} archivos.`);render();
 }finally{busy(false);}
}
function help(){modal('VSPack — Guía rápida','Todo funciona localmente, sin servidores externos.',`<div class="info-text" style="line-height:1.85"><strong>Biblioteca:</strong> creá packs o importá ZIP; filtrá, clasificá y descargá recursos.<br><strong>Editor:</strong> previsualizá imágenes y archivos. Modificá JSON, YAML y archivos de texto.<br><strong>Gestores:</strong> editá PNG y sprites con VS Pixel Studio, editá modelos con VS Model Studio, revisá HUD y diagnosticá problemas. Los sonidos se conservan sin editar.<br><strong>Compositor:</strong> activá packs, ordenalos por prioridad y elegí ganadores de conflictos.<br><strong>Publicador:</strong> validá el ZIP y exportá la composición o un pack individual.<br><br><strong>Persistencia:</strong> la biblioteca se guarda en IndexedDB. Antes de borrar datos o cambiar de navegador, usá «Gestores → Packs → Copia completa» y «Restaurar copia». El ZIP de Minecraft no conserva favoritos, carpetas virtuales o etiquetas.</div>`,async()=>{});}
/* Fase 1: cinco gestores. Estado compartido con biblioteca IndexedDB y exportador. */
let managerTab='packs', managerScopeId='', managerFolder='', managerSearch='', managerSelectedId=null, managerDirty=false;
let managerURLs=[], modelAngle=35,diagReport=null,diagBusy=false;
let pixelSession=null,pixelSource=null,pixelReturnView='managers',pixelReturnTab='textures',pixelLoadToken=0;
let modelSession=null,modelSource=null,modelReturnView='managers',modelReturnTab='models',modelLoadToken=0;
const manageTabs=[['packs','Packs','package'],['files','Archivos','folder'],['textures','Texturas','image'],['models','Modelos','layers'],['items','Ítems / Bloques','file'],['interfaces','Interfaces / HUD','eye'],['diagnostics','Diagnóstico','check']];
const managerPack=()=>getPack(managerScopeId)||selectedPack()||state.packs[0]||null;
function releaseManagerURLs(){managerURLs.forEach(u=>URL.revokeObjectURL(u));managerURLs=[];}
function managedImage(a){return `<div class="manager-img" ${VSPreview.isImage(a)?`data-manager-image="${a.id}"`:''}>${ic('image',30)}</div>`;}
function managerPage(){if(managerTab==='pixel')return pixelPage();if(managerTab==='model-studio')return modelStudioPage();const p=managerPack();return `${header('FORJA / GESTORES','Centro de gestores','Herramientas para packs, archivos, texturas, modelos, ítems, interfaces y diagnóstico, sin duplicar el gestor de audio.')}
  <div class="manager-tabs" role="tablist" aria-label="Gestores">${manageTabs.map(([id,name,icon])=>`<button role="tab" aria-selected="${id===managerTab}" class="manager-tab ${id===managerTab?'selected':''}" data-act="m-tab" data-v="${id}">${ic(icon,17)} ${name}</button>`).join('')}</div>
  <div class="manager-scope"><div class="manager-scope-title"><span class="kicker">ESPACIO ACTIVO</span><strong>${p?escape(p.name):'Ningún pack seleccionado'}</strong></div><label>Pack <select class="select" id="manager-pack" aria-label="Pack en los gestores"><option value="">Seleccionar pack</option>${state.packs.map(x=>`<option value="${x.id}" ${x.id===p?.id?'selected':''}>${escape(x.name)}</option>`).join('')}</select></label><span class="statusline">${p?p.files.length+' archivos • '+(p.folders||[]).length+' carpetas':'Creá o importá tu primer pack'}</span></div>
  ${managerTab==='packs'?managerPacks():managerTab==='files'?managerFiles():managerTab==='textures'?managerTextures():managerTab==='models'?managerModels():managerTab==='items'?managerItems():managerTab==='interfaces'?managerInterfaces():managerDiagnostics()}`;}
function managerPacks(){const ordered=orderedPacks();return `<div class="manager-section-heading"><div><h2>Gestor de Resource Packs</h2><p>Administrá los packs completos y su contenido local, sin afectar tu servidor.</p></div><div class="actions">${btn('Copia completa','backup-export')}${btn('Restaurar copia','backup-import')}</div></div>
  ${!ordered.length?empty('package','Tu biblioteca está vacía','Importá un ZIP o creá un pack para comenzar.',btn('Importar ZIP','import-zip','primary')+btn('Crear pack','create-pack')):`<div class="manager-packs">${ordered.map(p=>`<article class="manager-pack-card ${managerPack()?.id===p.id?'is-selected':''}"><div class="manager-pack-symbol">${ic('package',28)}</div><div class="manager-pack-info"><div class="section-eyebrow">RESOURCE PACK</div><h3>${escape(p.name)}</h3><p>${escape(p.description||'Sin descripción')}</p><div class="manager-tags"><span>v${escape(p.version||'1.0.0')}</span><span>${p.files.length} archivos</span><span>${fmtSize(p.files.reduce((n,f)=>n+f.size,0))}</span></div></div><div class="manager-actions"><button class="button ${managerPack()?.id===p.id?'secondary':'primary'}" data-act="m-pick" data-id="${p.id}">${managerPack()?.id===p.id?'Seleccionado':'Abrir pack'}</button><button class="button secondary" data-act="m-copy-pack" data-id="${p.id}">Duplicar</button><button class="button secondary" data-act="m-export-pack" data-id="${p.id}">Exportar ZIP</button></div></article>`).join('')}</div>`}`;}
function foldersOf(p){const found=new Set(p?.folders||[]);for(const f of p?.files||[]){const bits=f.path.split('/');for(let i=1;i<bits.length;i++)found.add(bits.slice(0,i).join('/'));}return [...found].sort((a,b)=>a.localeCompare(b));}
function managerFiles(){const p=managerPack();if(!p)return empty('folder','Seleccioná un pack','Los archivos y subcarpetas aparecerán aquí.',btn('Crear pack','create-pack','primary'));const folders=foldersOf(p);const prefix=managerFolder?managerFolder+'/':'';const direct=folders.filter(f=>f.startsWith(prefix)&&f.slice(prefix.length)&&!f.slice(prefix.length).includes('/'));
const matching=p.files.filter(f=>f.path.startsWith(prefix)&&!f.path.slice(prefix.length).includes('/')&&f.path.toLowerCase().includes(managerSearch.toLowerCase()));let a=p.files.find(f=>f.id===managerSelectedId);
return `<div class="manager-section-heading"><div><h2>Explorador de archivos</h2><p>Carpetas virtuales, subcarpetas, renombrado y movimiento de recursos.</p></div><div class="actions">${btn('Nueva carpeta','m-new-folder')}${btn('Importar aquí','m-import-folder','primary')}</div></div>
  <div class="manager-file-layout"><section class="pane file-tree-panel"><div class="pane-heading"><strong>Carpetas</strong><small>${folders.length}</small></div><div class="manager-folder-tree"><button class="manager-folder-item ${!managerFolder?'current':''}" data-act="m-open-folder" data-path="">${ic('package',15)} Raíz del pack</button>${folders.map(f=>`<button class="manager-folder-item ${managerFolder===f?'current':''}" style="padding-left:${11+Math.min(6,f.split('/').length-1)*14}px" data-act="m-open-folder" data-path="${escape(f)}">${ic('folder',14)} <span>${escape(fileName(f))}</span></button>`).join('')}</div></section>
  <section class="pane file-data-panel"><div class="pane-heading"><div class="manager-breadcrumb"><button data-act="m-open-folder" data-path="">${escape(p.name)}</button>${managerFolder.split('/').filter(Boolean).map((seg,i,ar)=>`<span>/</span><button data-act="m-open-folder" data-path="${escape(ar.slice(0,i+1).join('/'))}">${escape(seg)}</button>`).join('')}</div><small>${direct.length} carpetas · ${matching.length} archivos</small></div><div class="toolbar manager-toolbar"><label class="search-field">${ic('search')}<input id="manager-file-search" placeholder="Buscar en carpeta..." value="${escape(managerSearch)}"/></label>${managerFolder?btn('Renombrar carpeta','m-rename-folder')+btn('Eliminar carpeta','m-delete-folder','warn'):''}</div>
  <div class="manager-file-items">${direct.map(f=>`<button class="manager-file-row" data-act="m-open-folder" data-path="${escape(f)}">${ic('folder',20)}<strong>${escape(fileName(f))}</strong><span>Carpeta</span>${ic('chevron',15)}</button>`).join('')}${matching.map(f=>`<button class="manager-file-row ${managerSelectedId===f.id?'chosen':''}" data-act="m-select" data-id="${f.id}">${ic('file',18)}<strong>${escape(fileName(f.path))}</strong><span>${fmtSize(f.size)} · ${escape(kindTitle[f.kind]||'Archivo')}</span>${ic('chevron',15)}</button>`).join('')||(!direct.length?`<div class="manager-placeholder">Esta carpeta no contiene archivos.</div>`:'')}</div></section>
  <aside class="pane file-property-panel"><div class="pane-heading"><strong>Archivo seleccionado</strong></div>${a?`<div class="manager-property"><h3>${escape(fileName(a.path))}</h3><p class="codepath">${escape(a.path)}</p><div class="meta-row"><span>Tipo</span><strong>${escape(kindTitle[a.kind]||'Archivo')}</strong></div><div class="meta-row"><span>Tamaño</span><strong>${fmtSize(a.size)}</strong></div><div class="manager-actions vertical">${btn('Mover / renombrar','m-move-file','primary')}${/\.(png|ase|aseprite|webp|jpe?g)$/i.test(a.path)?btn('VS Pixel Studio','m-open-pixel','primary'):''}${a.kind==='modelo'?btn('VS Model Studio','m-open-model','primary'):btn('Abrir editor','m-open-editor')}${btn('Duplicar','m-duplicate')}${btn('Descargar','m-download')}${btn('Eliminar','m-remove','warn')}</div></div>`:empty('file','Elegí un archivo','Podés moverlo, renombrarlo o descargarlo.', '',true)}</aside></div>`;}
function managerTextures(){
 const p=managerPack();if(!p)return empty('image','No hay packs','Importá un Resource Pack o creá uno nuevo.',btn('Importar ZIP','import-zip','primary'));
 const files=p.files.filter(f=>/\.(png|ase|aseprite)$/i.test(f.path));
 const shown=files.filter(f=>f.path.toLowerCase().includes(managerSearch.toLowerCase()));
 const chosen=files.find(f=>f.id===managerSelectedId);
 return `<div class="manager-section-heading"><div><h2>Texturas & Pixel Studio</h2><p>Edición real de sprites, paletas, capas, animaciones y archivos Aseprite. Todos los cambios se guardan en tu biblioteca.</p></div><div class="actions">${btn('Nueva textura','m-new-pixel')}${btn('Importar imágenes','import-files')}</div></div>
 <div class="manager-texture-layout"><section class="pane"><div class="pane-heading"><strong>Imágenes y sprites</strong><small>${files.length}</small></div><div class="toolbar manager-toolbar"><label class="search-field">${ic('search')}<input id="manager-texture-search" placeholder="Buscar PNG, Aseprite…" value="${escape(managerSearch)}"/></label></div><div class="manager-tile-grid">${shown.map(f=>`<button class="manager-tile ${chosen?.id===f.id?'selected':''}" data-act="m-select-texture" data-id="${f.id}">${/\.png$/i.test(f.path)?managedImage(f):`<div class="manager-img">${ic('layers',36)}</div>`}<strong>${escape(fileName(f.path))}</strong><small>${escape(f.path)}</small></button>`).join('')||empty('image','Sin imágenes','Importá una textura o un sprite de tu pack.', '',true)}</div></section>
 <section class="pane texture-workarea"><div class="pane-heading"><strong>${chosen?escape(fileName(chosen.path)):'VS Pixel Studio'}</strong><small>${chosen?'Recurso seleccionado':'Sin selección'}</small></div>${chosen?`<div class="pixel-landing"><div class="pixel-landing-preview" id="pixel-landing-preview">${ic('image',48)}</div><div class="pixel-landing-info"><span class="kicker">EDITOR DE PIXEL ART</span><h3>Trabajá directamente sobre tu recurso</h3><p>Abre el editor original que compartiste, con timeline, capas, paletas, importación ASE y filtros. Guardá PNG o el proyecto animado en este pack.</p><div class="manager-actions">${btn('Abrir VS Pixel Studio','m-open-pixel','primary')}${btn('Descargar original','m-download')}</div><small>${escape(chosen.path)}</small></div></div>`:empty('image','Seleccioná una textura','Elegí un PNG o .aseprite para editarlo aquí, sin salir de VSPack.', '',true)}</section></div>`;
}
function managerModels(){const p=managerPack();if(!p)return empty('layers','No hay modelos','Importá un pack con modelos JSON o Blockbench.',btn('Importar ZIP','import-zip','primary'));let models=p.files.filter(f=>/\.bbmodel$/i.test(f.path)||(/\.json$/i.test(f.path)&&/\/(?:models|items|blockstates)\//.test(f.path)));const shown=models.filter(f=>f.path.toLowerCase().includes(managerSearch.toLowerCase()));const a=models.find(f=>f.id===managerSelectedId);return `<div class="manager-section-heading"><div><h2>Gestor de modelos</h2><p>Abrí modelos JSON de Minecraft, resolvé padres y texturas PNG, o editá un proyecto .bbmodel.</p></div><div class="actions">${btn('Abrir Blockbench','m-open-original','primary')}${btn('Nuevo archivo .bbmodel','m-new-model')}${btn('Importar modelos','import-files')}</div></div><div class="manager-model-layout"><section class="pane"><div class="pane-heading"><strong>Modelos del pack</strong><small>${models.length}</small></div><div class="toolbar manager-toolbar"><label class="search-field">${ic('search')}<input id="manager-model-search" placeholder="Buscar modelo..." value="${escape(managerSearch)}"/></label></div><div class="manager-list">${shown.map(f=>`<button class="manager-model-row ${a?.id===f.id?'chosen':''}" data-act="m-select-model" data-id="${f.id}">${ic('layers',18)}<div><strong>${escape(fileName(f.path))}</strong><small>${escape(f.path)}</small></div>${ic('chevron',14)}</button>`).join('')||empty('package','Sin modelos','Agregá un JSON en assets/<namespace>/models/ o un .bbmodel.', '',true)}</div></section><section class="pane model-view-panel"><div class="pane-heading"><strong>${a?escape(fileName(a.path)):'Visor geométrico'}</strong><small>Vista conceptual · no render Minecraft</small></div>${a?`<div class="model-stage"><canvas id="model-canvas" width="640" height="360" aria-label="Vista geométrica del modelo"></canvas></div><div class="model-controls"><button class="button secondary" data-act="m-rotate" data-dir="-1">↶ Girar</button><button class="button secondary" data-act="m-rotate" data-dir="1">Girar ↷</button>${btn('Abrir VS Model Studio','m-open-model','primary')}${btn('Editar JSON','m-open-editor')}</div><div id="model-details" class="model-details"><p class="info-text">Analizando el archivo…</p></div>`:empty('layers','Seleccioná un modelo','Mostraremos la geometría si existe, sus propiedades y referencias de texturas.', '',true)}</section></div>`;}
function getItems(p){return (p?.files||[]).filter(f=>/\.json$/i.test(f.path)&&(/\/models\/(item|block)\//.test(f.path)||/\/items\//.test(f.path)||/\/blockstates\//.test(f.path)));}
function managerItems(){const p=managerPack();if(!p)return empty('package','Seleccioná un pack','Creá o importá un pack antes de construir definiciones.',btn('Crear pack','create-pack','primary'));let files=getItems(p),shown=files.filter(f=>f.path.toLowerCase().includes(managerSearch.toLowerCase()));const a=files.find(f=>f.id===managerSelectedId);return `<div class="manager-section-heading"><div><h2>Ítems y bloques</h2><p>Administrá modelos, definiciones y estados existentes. Podés abrir las referencias sencillas como modelos 3D; las variantes complejas requieren elegir un modelo concreto.</p></div><div class="actions">${btn('Crear ítem','m-new-item','primary')}${btn('Crear modelo de bloque','m-new-block')}</div></div>
 <div class="manager-item-layout"><section class="pane"><div class="pane-heading"><strong>Definiciones encontradas</strong><small>${files.length}</small></div><div class="toolbar manager-toolbar"><label class="search-field">${ic('search')}<input id="manager-item-search" placeholder="Buscar ítems o bloques..." value="${escape(managerSearch)}"/></label></div><div class="manager-list">${shown.map(f=>`<button class="manager-model-row ${managerSelectedId===f.id?'chosen':''}" data-act="m-select-item" data-id="${f.id}">${ic('package',17)}<div><strong>${escape(fileName(f.path))}</strong><small>${escape(f.path)}</small></div></button>`).join('')||empty('folder','Sin definiciones','Creá un modelo o importá un pack para comenzar.', '',true)}</div></section><section class="pane"><div class="pane-heading"><strong>${a?escape(a.path):'Inspector de recursos'}</strong><small>Referencias y modelos</small></div>${a?`<div id="item-details" class="model-details"><p class="info-text">Leyendo datos…</p></div><div class="manager-item-actions">${/\/(?:items|blockstates|models)\//.test(a.path)?btn('Ver modelo 3D','m-open-model','primary'):''}${btn('Editar JSON','m-open-editor','secondary')}${btn('Duplicar','m-duplicate')}${btn('Eliminar','m-remove','warn')}</div>`:empty('file','Seleccioná una definición','Podrás inspeccionar referencias y editar el JSON original.', '',true)}</section></div>`;}

/* Phase 2: gestores especializados. Todo es local y reutiliza el almacenamiento existente. */
const soundFiles=p=>(p?.files||[]).filter(f=>/\.(ogg|wav|mp3|flac)$/i.test(f.path));
const guiFiles=p=>(p?.files||[]).filter(f=>/\.(png|jpe?g|gif|webp)$/i.test(f.path)&&/(\/textures\/(gui|font)\/|\/gui\/|\/textures\/particle\/|pack\.png$)/i.test(f.path));
function managerSounds(){const p=managerPack();if(!p)return empty('sound','Sin packs','Importá archivos OGG o creá un pack.',btn('Importar ZIP','import-zip','primary'));
const tracks=soundFiles(p),listed=tracks.filter(x=>x.path.toLowerCase().includes(managerSearch.toLowerCase()));
const chosen=tracks.find(x=>x.id===managerSelectedId);const configs=p.files.filter(x=>/(^|\/)sounds\.json$/i.test(x.path));
return `<div class="manager-section-heading"><div><h2>Laboratorio de sonidos</h2><p>Escuchá los archivos importados y creá eventos de sounds.json; editá las variantes desde el JSON.</p></div><div class="actions">${btn('Importar audio','m-import-audio')}${btn('Nuevo evento','m-new-sound-event','primary')}</div></div>
<div class="manager-special-grid"><section class="pane"><div class="pane-heading"><strong>Archivos de audio</strong><small>${tracks.length}</small></div><div class="toolbar manager-toolbar"><label class="search-field">${ic('search')}<input id="manager-sounds-search" placeholder="Buscar sonidos..." value="${escape(managerSearch)}"/></label></div><div class="manager-list">${listed.map(f=>`<button class="manager-model-row ${chosen?.id===f.id?'chosen':''}" data-act="m-select-sound" data-id="${f.id}">${ic('sound')}<div><strong>${escape(fileName(f.path))}</strong><small>${escape(f.path)} · ${fmtSize(f.size)}</small></div></button>`).join('')||empty('sound','Sin audios','Importá .ogg, .wav o .mp3; OGG es el formato habitual para Minecraft.',btn('Importar audio','m-import-audio'),true)}</div></section>
<section class="pane"><div class="pane-heading"><strong>${chosen?'Escuchar recurso':'Reproductor'}</strong><small>Vista local</small></div>${chosen?`<div class="audio-panel"><div class="audio-cover">${ic('sound',54)}</div><div class="section-eyebrow">ARCHIVO ORIGINAL</div><h3>${escape(fileName(chosen.path))}</h3><p class="codepath">${escape(chosen.path)}</p><div id="sound-player-slot" class="sound-player-slot"></div><div class="manager-actions">${btn('Descargar audio','m-download','secondary')}${btn('Abrir recurso','m-open-editor','secondary')}</div></div>`:empty('sound','Elegí un sonido','Podrás reproducirlo sin alterar los bytes originales.', '',true)}<div class="pane-heading"><strong>Eventos sounds.json</strong><small>${configs.length}</small></div><div class="manager-list">${configs.map(f=>`<button class="manager-model-row" data-act="m-open-sounds-config" data-id="${f.id}">${ic('file',18)}<div><strong>${escape(f.path)}</strong><small>Editar definición de sonidos</small></div></button>`).join('')||`<p class="info-text">Aún no existe un sounds.json en el pack. Crealo desde «Nuevo evento».</p>`}</div></section></div>`;}
function managerInterfaces(){const p=managerPack();if(!p)return empty('eye','Sin packs','Importá un pack con texturas de GUI.',btn('Importar ZIP','import-zip','primary'));
const all=guiFiles(p),list=all.filter(x=>x.path.toLowerCase().includes(managerSearch.toLowerCase()));const chosen=all.find(x=>x.id===managerSelectedId);
return `<div class="manager-section-heading"><div><h2>Interfaces y HUD</h2><p>Inspeccioná iconos, atlas y texturas reales. Vista en píxeles reales y fondo ajedrezado.</p></div>${btn('Importar imagen','m-import-ui','primary')}</div>
<div class="manager-special-grid"><section class="pane"><div class="pane-heading"><strong>Recursos de interfaz</strong><small>${all.length}</small></div><div class="toolbar manager-toolbar"><label class="search-field">${ic('search')}<input id="manager-ui-search" placeholder="Buscar GUI, HUD, fuente..." value="${escape(managerSearch)}"/></label></div><div class="manager-tile-grid">${list.map(f=>`<button class="manager-tile ${chosen?.id===f.id?'selected':''}" data-act="m-select-ui" data-id="${f.id}">${managedImage(f)}<strong>${escape(fileName(f.path))}</strong><small>${escape(f.path)}</small></button>`).join('')||empty('image','Sin imágenes de GUI','Se detectan texturas dentro de textures/gui, font y particle; también pack.png.', '',true)}</div></section>
<section class="pane"><div class="pane-heading"><strong>${chosen?escape(fileName(chosen.path)):'Vista de interfaz'}</strong><small>Imagen original · sin simulación de HUD</small></div>${chosen?`<div class="gui-inspector"><div class="gui-preview" id="ui-preview">${ic('image',46)}</div><div class="gui-properties" id="ui-info">Leyendo dimensiones…</div><div class="codepath">${escape(chosen.path)}</div><div class="manager-actions">${/\.png$/i.test(chosen.path)?btn('Editar en VS Pixel Studio','m-open-pixel','primary'):''}${btn('Descargar','m-download')}</div><div class="hint-box">No se genera una interfaz de Minecraft ficticia: se muestra exactamente la textura importada.</div></div>`:empty('image','Seleccioná una textura','La vista previa respetará proporciones, transparencia y tamaño.', '',true)}</section></div>`;}
function managerDiagnostics(){const p=managerPack();const r=diagReport?.packId===p?.id?diagReport:null;
return `<div class="manager-section-heading"><div><h2>Diagnóstico de recursos</h2><p>Revisión local de rutas, archivos JSON, imágenes PNG y dependencias de modelos y sonidos.</p></div><div class="actions">${btn('Analizar pack','m-run-diagnostics','primary')}${r?btn('Descargar informe','m-download-diagnostics'):''}</div></div>
${!p?empty('check','No hay pack seleccionado','Importá un pack para analizar su contenido.',btn('Importar ZIP','import-zip','primary')):`<div class="diagnostic-shell"><section class="pane"><div class="pane-heading"><strong>Estado de revisión</strong><small>${escape(p.name)}</small></div><div class="diagnostic-summary">${r?`<div class="diag-stat"><strong>${r.checked}</strong><span>Archivos revisados</span></div><div class="diag-stat"><strong>${r.issues.filter(x=>x.level==='error').length}</strong><span>Errores</span></div><div class="diag-stat"><strong>${r.issues.filter(x=>x.level==='warning').length}</strong><span>Advertencias</span></div>`:`<div class="diag-blank">Presioná «Analizar pack» para ejecutar las comprobaciones reales sobre tus archivos.</div>`}</div>${r?`<div class="diagnostic-date">Analizado: ${formatDate(r.at)} · No comprueba compatibilidad exacta con todas las versiones de Minecraft.</div>`:''}</section><section class="pane"><div class="pane-heading"><strong>Hallazgos</strong><small>${r?r.issues.length:'Sin ejecutar'}</small></div><div class="diagnostic-results">${!r?empty('check','Análisis pendiente','Los resultados se generarán cuando ejecutes la revisión.', '',true):r.issues.length?r.issues.map(issue=>`<div class="diagnostic-issue ${issue.level}"><span>${ic(issue.level==='error'?'warning':'eye',19)}</span><div><strong>${escape(issue.title)}</strong><p>${escape(issue.detail)}</p>${issue.path?`<code>${escape(issue.path)}</code>`:''}</div></div>`).join(''):`<div class="diagnostic-clear">${ic('check',23)} No se encontraron problemas en las comprobaciones disponibles.</div>`}</div></section></div>`}`;}
function specialImport(kind){const p=managerPack();if(!p)return toast('Seleccioná un pack',true);
const base=/^assets\/([^/]+)\//.exec(managerSelected()?.path||'')?.[1]||'virgoland';
modal(kind==='sounds'?'Importar sonidos':'Importar texturas de GUI','Elegí el namespace de Minecraft. Los archivos se guardarán dentro de assets/<namespace>/textures/gui o sounds.',field('namespace','Namespace',base),async data=>{const ns=String(data.get('namespace')||'').trim().toLowerCase();if(!/^[a-z0-9_.-]+$/.test(ns))throw Error('Namespace inválido');state.selectedPackId=p.id;uploadFolder=`assets/${ns}/${kind==='sounds'?'sounds':'textures/gui'}/`;setTimeout(()=>$('#asset-upload').click(),0);});}
async function newSoundEvent(){const p=managerPack();if(!p)return toast('Seleccioná un pack',true);const sounds=soundFiles(p).filter(f=>/^assets\/[^/]+\/sounds\/.+\.ogg$/i.test(f.path));
if(!sounds.length)return toast('Importá primero un OGG dentro de assets/<namespace>/sounds/',true);
const opts=sounds.map(f=>`<option value="${escape(f.path)}">${escape(f.path)}</option>`).join('');
modal('Nuevo evento de sonido','Agrega o actualiza un evento en assets/<namespace>/sounds.json. No altera los audios.',field('namespace','Namespace',sounds[0].path.split('/')[1])+field('event','Nombre del evento (ej: ambiente.cueva)')+`<div class="field"><label>Sonido disponible</label><select name="soundPath" class="select" required>${opts}</select></div><label class="checkbox-row"><input name="stream" type="checkbox"/> Streaming (útil para audios largos)</label>`,async d=>{
const ns=String(d.get('namespace')||'').trim().toLowerCase(),event=String(d.get('event')||'').trim().toLowerCase(),soundPath=String(d.get('soundPath'));
if(!/^[a-z0-9_.-]+$/.test(ns)||!/^[a-z0-9_.-]+$/.test(event))throw Error('Namespace y evento solo admiten minúsculas, números, puntos, guiones y _');
const m=soundPath.match(/^assets\/([^/]+)\/sounds\/(.+)\.ogg$/i);
if(!m||m[1]!==ns)throw Error('El sonido debe estar en assets/'+ns+'/sounds/. Elegí su namespace correctamente.');
const loc=`assets/${ns}/sounds.json`,original=p.files.find(f=>f.path===loc);let obj={};if(original){const bytes=await getFile(original.id);try{obj=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));}catch{throw Error('El sounds.json existente es inválido; corregilo antes de agregar eventos.');}if(!obj||typeof obj!=='object'||Array.isArray(obj))throw Error('La raíz de sounds.json debe ser un objeto');}
if(obj[event]&&!confirm('Ese evento ya existe. ¿Reemplazar la definición completa del evento?'))return false;
const name=ns+':'+m[2];obj[event]={sounds:[{name,stream:d.has('stream')}]};const bytes=new TextEncoder().encode(JSON.stringify(obj,null,2));
if(original){await putFile(original.id,bytes);original.size=bytes.length;original.modifiedAt=now();}else{const f=createAsset(p,loc,bytes);await putFile(f.id,bytes);p.files.push(f);}
managerSearch='';await storeState();toast('Evento de sonido guardado');});}
async function hydrateSoundManager(){const a=managerSelected(),slot=$('#sound-player-slot');if(!a||!slot)return;const bytes=await getFile(a.id);if(!slot.isConnected)return;if(!bytes){slot.textContent='No se encuentra el audio local';return;}const url=URL.createObjectURL(new Blob([bytes],{type:guessMime(a.path)}));managerURLs.push(url);const audio=document.createElement('audio');audio.controls=true;audio.preload='metadata';audio.src=url;audio.setAttribute('aria-label','Reproducción de '+fileName(a.path));slot.replaceChildren(audio);}
/** Hydrate a gallery in one IndexedDB transaction instead of a transaction per thumbnail. */
async function hydrateImageTiles(pack){
 // Las miniaturas ya las administra VSPreview.tiles desde render(): carga diferida y lectura por lotes.
}
async function hydrateInterfaceManager(){
 const chosen=managerSelected(),spot=$('#ui-preview');if(!chosen||!spot||!VSPreview.isImage(chosen))return;
 const b=await getFile(chosen.id);
 if(!b||!spot.isConnected||managerSelected()?.id!==chosen.id)return;
 const info=$('#ui-info');
 await VSPreview.open(spot,b,chosen);
 // Dimensiones exactas en el visor; acá conservamos además los metadatos del archivo.
 if(info?.isConnected)info.textContent=`${chosen.path.split('.').pop().toUpperCase()} · ${fmtSize(chosen.size)} · Zoom, cuadrícula y transparencia disponibles`;
}
async function runDiagnostics(){
 const p=managerPack();if(!p||diagBusy)return;
 diagBusy=true;
 try{
  const files=p.files,bytes=await getFilesBatch(files.map(f=>f.id));
  const entries=files.map((f,i)=>({path:f.path,bytes:bytes[i]}));
  const issues=VSPackQuality.inspectEntries(entries,{maxIssues:300});
  const paths=new Set(files.map(f=>f.path));
  const push=(level,title,detail,path)=>issues.push({level,title,detail,path});
  if(!paths.has('pack.mcmeta'))push('warning','Sin pack.mcmeta','Se generará al exportar si configurás el formato compatible con Minecraft.','pack.mcmeta');
  // Model and sound reference checks complement the shared structural checks.
  for(let i=0;i<files.length;i++){
   const file=files[i],data=bytes[i];
   if(!(data instanceof Uint8Array)||!/\.(?:json|mcmeta|bbmodel)$/i.test(file.path))continue;
   let obj;
   try{obj=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(data));}catch{continue;}
   if(!obj||typeof obj!=='object'||Array.isArray(obj))continue;
   if(/\/sounds\.json$/i.test(file.path)){
    const ns=file.path.split('/')[1];
    for(const [event,record] of Object.entries(obj)){
     for(const entry of (Array.isArray(record?.sounds)?record.sounds:[])){
      const sound=typeof entry==='string'?entry:entry?.name;
      if(typeof sound!=='string')continue;
      const [soundNs,loc]=sound.includes(':')?sound.split(':',2):[ns,sound];
      if(!soundNs||!loc||loc.includes('..'))continue;
      if(soundNs!=='minecraft'&&!paths.has(`assets/${soundNs}/sounds/${loc}.ogg`))
       push('warning','Audio referenciado ausente',`Evento ${event} → ${sound}.`,file.path);
     }
    }
   }
   if(/\/models\/.*\.json$/i.test(file.path)){
    const ns=file.path.split('/')[1];
    for(const value of Object.values(obj.textures||{})){
     if(typeof value!=='string'||value.startsWith('#'))continue;
     const [textureNs,loc]=value.includes(':')?value.split(':',2):[ns,value];
     if(textureNs!=='minecraft'&&!paths.has(`assets/${textureNs}/textures/${loc}.png`))
      push('warning','Textura no encontrada',`Referencia del modelo: ${value}`,file.path);
    }
    const parent=obj.parent;
    if(typeof parent==='string'&&parent&&!parent.startsWith('builtin/')&&!parent.startsWith('minecraft:')){
     const [parentNs,loc]=parent.includes(':')?parent.split(':',2):[ns,parent];
     if(parentNs!=='minecraft'&&!paths.has(`assets/${parentNs}/models/${loc}.json`))
      push('warning','Modelo padre ausente',`Parent ${parent}`,file.path);
    }
   }
  }
  diagReport={packId:p.id,checked:files.length,issues,at:now()};render();
  toast(`Diagnóstico: ${issues.filter(x=>x.level==='error').length} errores, ${issues.filter(x=>x.level==='warning').length} advertencias`);
 }catch(e){toast('Error en diagnóstico: '+e.message,true);}finally{diagBusy=false;}
}
function downloadDiagnostics(){if(!diagReport)return;const name=(managerPack()?.name||'pack').replace(/[^a-z\d._-]+/gi,'-');download(new Blob([JSON.stringify({tool:'VSPack Foundry',version:'3.0',...diagReport},null,2)],{type:'application/json'}),name+'-diagnostico.json');}
async function hydrateManagers(){
 if(state.view!=='managers')return;
 if(managerTab==='pixel'){void hydratePixelWorkspace();return;}
 if(managerTab==='model-studio'){void hydrateModelWorkspace();return;}
 if(managerTab==='textures'&&managerSelectedId){
  const f=managerSelected(),preview=$('#pixel-landing-preview');
  if(f&&preview&&VSPreview.isImage(f)){
   const b=await getFile(f.id);
   if(b&&preview.isConnected&&managerSelected()?.id===f.id)await VSPreview.open(preview,b,f);
  }
 }
 if(managerTab==='models'&&managerSelectedId)await inspectModel();
 if(managerTab==='items'&&managerSelectedId)await inspectItem();
 if(managerTab==='interfaces')await hydrateInterfaceManager();
}
async function chooseManagerFile(id,tab){if(!confirmUnsaved())return;managerDirty=false;managerSelectedId=id;managerTab=tab;render();}
async function copyPack(id){
 const src=getPack(id);if(!src)return;
 busy(true);
 try{
  const contents=await getFilesBatch(src.files.map(f=>f.id));
  const cp={...src,id:uuid(),name:src.name+' — copia',order:state.packs.length,createdAt:now(),folders:[...(src.folders||[])],files:[]};
  const batch=src.files.map((file,i)=>{
   const bytes=contents[i];if(!(bytes instanceof Uint8Array))throw Error('No se encontró el archivo '+file.path);
   const copy={...file,id:uuid(),tags:[...(file.tags||[])]};cp.files.push(copy);return {id:copy.id,bytes};
  });
  await putFilesBatch(batch);
  state.packs.push(cp);state.selectedPackId=cp.id;managerScopeId=cp.id;
  await refreshState();toast('Pack duplicado');
 }catch(e){toast(e.message,true);}finally{busy(false);}
}
async function exportOnePack(id){
 const pack=getPack(id);if(!pack)return;
 busy(true);
 try{
  const contents=await getFilesBatch(pack.files.map(f=>f.id));
  const writer=VSZip.optimizedWriter();
  for(let i=0;i<pack.files.length;i++){
   const file=pack.files[i],bytes=contents[i];
   if(!(bytes instanceof Uint8Array))throw Error('Falta '+file.path);
   await writer.add(file.path,bytes);
  }
  download(writer.finish(),(pack.name.replace(/[^a-z\d._-]+/gi,'-')||'resource-pack')+'.zip');toast('Pack exportado');
 }catch(e){toast(e.message,true);}finally{busy(false);}
}
function folderModal(){const p=managerPack();if(!p)return toast('Seleccioná un pack',true);modal('Crear carpeta','Podés organizar recursos en subcarpetas. No se modifica tu disco hasta exportar.',field('name','Ruta de la carpeta',managerFolder?managerFolder+'/':''),async d=>{const path=safeFolder(String(d.get('name')));if(foldersOf(p).includes(path))throw Error('Esa carpeta ya existe');p.folders.push(path);managerFolder=path;await refreshState();});}
function changeFolderName(remove=false){const p=managerPack(),old=managerFolder;if(!p||!old)return;const children=p.files.filter(f=>f.path.startsWith(old+'/'));if(remove){modal('Eliminar carpeta',`Se quitará ${old} del explorador.`, `<div class="hint-box">${children.length} archivo(s) se moverán a la raíz del pack. Ninguno se eliminará.</div>`,async()=>{for(const f of children){let basename=f.path.slice(old.length+1);let dest=uniquePath(p,basename);f.path=dest;f.kind=typeOf(dest);}p.folders=p.folders.filter(s=>s!==old&&!s.startsWith(old+'/'));managerFolder='';await refreshState();},true);return;}
modal('Renombrar carpeta','La ruta de sus recursos se actualizará sin modificar los bytes originales.',field('name','Ruta nueva',old),async d=>{let neu=safeFolder(String(d.get('name')));if(neu===old)return;let files=p.files.filter(f=>f.path.startsWith(old+'/'));let newPaths=files.map(f=>neu+f.path.slice(old.length));if(new Set(newPaths).size!==newPaths.length||newPaths.some(x=>p.files.some(f=>!files.includes(f)&&f.path===x)))throw Error('El destino colisiona con archivos existentes');files.forEach((f,i)=>{f.path=newPaths[i];f.kind=typeOf(f.path);});p.folders=p.folders.map(f=>f===old?neu:f.startsWith(old+'/')?neu+f.slice(old.length):f);if(!p.folders.includes(neu))p.folders.push(neu);managerFolder=neu;await refreshState();});}
function moveManagerFile(){const p=managerPack(),f=p?.files.find(x=>x.id===managerSelectedId);if(!f)return;modal('Mover o renombrar archivo','La nueva ruta debe ser relativa y permanecer dentro del Resource Pack.',field('name','Nueva ruta',f.path),async d=>{const path=normalize(String(d.get('name')));if(p.files.some(a=>a.id!==f.id&&a.path===path))throw Error('Ya existe un archivo con esa ruta');f.path=path;f.kind=typeOf(path);f.modifiedAt=now();managerFolder=path.split('/').slice(0,-1).join('/');await refreshState();toast('Archivo movido');});}
function managerSelected(){return managerPack()?.files.find(f=>f.id===managerSelectedId)||null;}
function useManagerEditor(){const f=managerSelected();if(!f)return;state.selectedPackId=managerPack().id;state.selectedAssetId=f.id;setView('editor');}
async function managerRemove(){const f=managerSelected(),p=managerPack();if(!f||!p)return;modal('Eliminar archivo',`Se eliminará ${f.path} de la biblioteca local.`, '<div class="hint-box">Esta operación no modifica ningún plugin ni archivos de tu computadora.</div>',async()=>{p.files=p.files.filter(x=>x.id!==f.id);await delFile(f.id);managerSelectedId=null;await refreshState();},true);}
async function managerDuplicate(){
 const file=managerSelected(),pack=managerPack();if(!file||!pack)return;
 try{const copy=await duplicateAssetFile(pack,file);managerSelectedId=copy.id;await refreshState();toast('Copia creada');}
 catch(error){toast(error.message,true);}
}
async function managerDownload(){const f=managerSelected();if(!f)return;let b=await getFile(f.id);if(b)download(new Blob([b],{type:guessMime(f.path)}),fileName(f.path));}
/* El editor de píxeles legado fue retirado: VS Pixel Studio es el único motor de edición. */
function coords(v,angle){const a=angle*Math.PI/180;const x=v[0]-8,y=v[1]-8,z=v[2]-8;const rx=x*Math.cos(a)+z*Math.sin(a),rz=-x*Math.sin(a)+z*Math.cos(a);return [rx-rz*.48,(y*-1)+rz*.42+rx*.12];}
function drawModel(elements){const c=$('#model-canvas');if(!c)return;const ctx=c.getContext('2d');ctx.clearRect(0,0,c.width,c.height);ctx.fillStyle='#23241f';ctx.fillRect(0,0,c.width,c.height);if(!elements.length){ctx.fillStyle='#b9aa8e';ctx.font='17px sans-serif';ctx.textAlign='center';ctx.fillText('No hay geometría local para mostrar',c.width/2,c.height/2);return;}
const faces=[];for(const e of elements.slice(0,100)){const min=e.from,max=e.to;if(!Array.isArray(min)||!Array.isArray(max)||min.length!==3||max.length!==3)continue;const verts=[[min[0],min[1],min[2]],[max[0],min[1],min[2]],[max[0],max[1],min[2]],[min[0],max[1],min[2]],[min[0],min[1],max[2]],[max[0],min[1],max[2]],[max[0],max[1],max[2]],[min[0],max[1],max[2]]];for(const [inds,col] of [[[0,1,2,3],'#a88757'],[[4,5,6,7],'#74644b'],[[3,2,6,7],'#d0b17b'],[[1,5,6,2],'#8d7755'],[[0,4,7,3],'#ad9367'],[[0,1,5,4],'#645744']]){const v=inds.map(i=>verts[i]);const pts=v.map(v=>coords(v,modelAngle));faces.push({pts,col,depth:v.reduce((acc,q)=>acc+q[2],0)/4});}}
const all=faces.flatMap(f=>f.pts),mag=Math.max(12,...all.map(p=>Math.max(Math.abs(p[0]),Math.abs(p[1])))),scale=Math.min(240/mag,18);faces.sort((a,b)=>a.depth-b.depth);ctx.save();ctx.translate(c.width/2,c.height/2);ctx.scale(scale,scale);for(const f of faces){ctx.beginPath();f.pts.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));ctx.closePath();ctx.fillStyle=f.col;ctx.fill();ctx.strokeStyle='#171813';ctx.lineWidth=.9/scale;ctx.stroke();}ctx.restore();}
async function inspectModel(){const a=managerSelected(),p=managerPack();if(!a||!p)return;const detail=$('#model-details');try{const b=await getFile(a.id);const json=JSON.parse(new TextDecoder().decode(b));const elements=Array.isArray(json.elements)?json.elements.filter(e=>e&&Array.isArray(e.from)&&Array.isArray(e.to)):[];drawModel(elements);const tex=Object.values(json.textures||{}).filter(x=>typeof x==='string');const refs=tex.map(t=>{if(t.startsWith('#'))return {path:t,status:'alias'};const parts=t.includes(':')?t.split(':'):['minecraft',t];const target=`assets/${parts[0]}/textures/${parts.slice(1).join(':')}.png`;return {path:target,status:p.files.some(f=>f.path===target)?'presente':parts[0]==='minecraft'?'externo':'ausente'};});const others=Array.isArray(json.outliner)?json.outliner.length:0;detail.innerHTML=`<div class="meta-row"><span>Formato</span><strong>${/\.bbmodel$/.test(a.path)?'Blockbench (.bbmodel)':'Modelo JSON'}</strong></div><div class="meta-row"><span>Padre</span><strong>${escape(json.parent||'No declarado')}</strong></div><div class="meta-row"><span>Elementos geométricos</span><strong>${elements.length}</strong></div>${others?`<div class="meta-row"><span>Outliner</span><strong>${others} nodos</strong></div>`:''}<h3>Texturas referenciadas</h3>${refs.length?refs.map(x=>`<div class="ref-line"><span class="dot ${x.status}"></span><code>${escape(x.path)}</code><span>${x.status}</span></div>`).join(''):'<p class="info-text">Sin referencias en textures.</p>'}<p class="manager-tip">El visor representa cubos locales sin texturizado, rigs ni animación. La interpretación completa de .bbmodel requiere el motor de VSRender.</p>`;}catch(e){drawModel([]);detail.innerHTML=`<p class="warning-line">No se pudo leer el modelo: ${escape(e.message)}</p>`;}}
async function inspectItem(){const a=managerSelected(),p=managerPack(),place=$('#item-details');if(!a||!place)return;try{const b=await getFile(a.id);const obj=JSON.parse(new TextDecoder().decode(b));const lines=[];const walk=(v)=>{if(!v||typeof v!=='object')return;if(typeof v.model==='string')lines.push(v.model);if(typeof v.parent==='string')lines.push(v.parent);if(v.textures)Object.values(v.textures).filter(x=>typeof x==='string').forEach(x=>lines.push(x));Object.values(v).forEach(x=>{if(typeof x==='object')walk(x);});};walk(obj);const unique=[...new Set(lines)].slice(0,35);let ns=a.path.match(/^assets\/([^/]+)\//)?.[1]||'minecraft';place.innerHTML=`<div class="manager-property"><div class="meta-row"><span>Clase</span><strong>${a.path.includes('/blockstates/')?'Estado de bloque':a.path.includes('/items/')?'Definición de ítem':a.path.includes('/models/block/')?'Modelo de bloque':'Modelo de ítem'}</strong></div><div class="meta-row"><span>Namespace</span><strong>${escape(ns)}</strong></div><div class="meta-row"><span>Tamaño</span><strong>${fmtSize(a.size)}</strong></div><h3>Dependencias declaradas</h3>${unique.length?unique.map(value=>`<div class="ref-line"><code>${escape(value)}</code></div>`).join(''):'<p class="info-text">No hay referencias explícitas.</p>'}<div class="divider"></div><div class="hint-box">Las definiciones son archivos visuales. Registrar ítems o bloques nuevos requiere un datapack o plugin aparte.</div></div>`;}catch(e){place.textContent='JSON inválido: '+e.message;}}
function newVisualAsset(kind){const p=managerPack();if(!p)return toast('Seleccioná un pack',true);modal(kind==='item'?'Crear ítem visual':'Crear modelo de bloque','Se crearán archivos JSON dentro del pack actual. No se registra contenido nuevo en Minecraft.',field('namespace','Namespace','virgoland')+field('name','ID del recurso')+field('texture','Textura (namespace:ruta)',`virgoland:${kind==='item'?'item':'block'}/`),async d=>{const ns=String(d.get('namespace')).toLowerCase().trim(),id=String(d.get('name')).toLowerCase().trim(),tex=String(d.get('texture')).toLowerCase().trim();if(!/^[a-z0-9_.-]+$/.test(ns)||!/^[a-z0-9_.-]+$/.test(id))throw Error('Namespace e ID: solo minúsculas, números, _ . -');if(tex&&!/^[a-z0-9_.-]+:[a-z0-9_./-]+$/.test(tex))throw Error('Ruta de textura inválida (ej: virgoland:item/objeto)');const path=`assets/${ns}/models/${kind==='item'?'item':'block'}/${id}.json`;const itemDef=`assets/${ns}/items/${id}.json`;const paths=kind==='item'?[path,itemDef]:[path];if(paths.some(path=>p.files.some(f=>f.path===path)))throw Error('Ya existe esa definición');const model=kind==='item'?{parent:'minecraft:item/generated',textures:{layer0:tex||`${ns}:item/${id}`}}:{parent:'minecraft:block/cube_all',textures:{all:tex||`${ns}:block/${id}`}};const list=[{path,bytes:new TextEncoder().encode(JSON.stringify(model,null,2))}];if(kind==='item')list.push({path:itemDef,bytes:new TextEncoder().encode(JSON.stringify({model:{type:'minecraft:model',model:`${ns}:item/${id}`}},null,2))});for(const ent of list){const f=createAsset(p,ent.path,ent.bytes);await putFile(f.id,ent.bytes);p.files.push(f);managerSelectedId=f.id;}await storeState();render();toast(`${kind==='item'?'Ítem visual':'Modelo de bloque'} creado`);});}

/** Crea un PNG real vacío, utilizable en Minecraft; no genera contenido de demostración. */
function newPixelTexture(){
 const p=managerPack();if(!p)return toast('Seleccioná un pack',true);
 modal('Nueva textura PNG','Elegí la ruta dentro del pack y las dimensiones del lienzo transparente.',
  field('path','Ruta PNG','assets/virgoland/textures/item/nueva_textura.png')+
  field('width','Ancho (píxeles)','32','number')+
  field('height','Alto (píxeles)','32','number'),
  async data=>{
   const path=normalize(String(data.get('path')||'')),w=Number(data.get('width')),h=Number(data.get('height'));
   if(!/\.png$/i.test(path)||!/^[a-z0-9_.\/-]+$/.test(path))throw Error('Ingresá una ruta PNG válida y relativa.');
   if(!Number.isInteger(w)||!Number.isInteger(h)||w<1||h<1||w>512||h>512)throw Error('La versión del editor admite entre 1 y 512 píxeles por lado.');
   if(p.files.some(f=>f.path===path))throw Error('Ya existe un recurso con esa ruta.');
   const c=document.createElement('canvas');c.width=w;c.height=h;
   const blob=await new Promise(resolve=>c.toBlob(resolve,'image/png'));
   if(!blob)throw Error('No se pudo generar la textura PNG.');
   const bytes=new Uint8Array(await blob.arrayBuffer()),f=createAsset(p,path,bytes);
   await putFile(f.id,bytes);p.files.push(f);managerSelectedId=f.id;state.selectedAssetId=f.id;
   await storeState();toast('Textura creada: '+path);
   queueMicrotask(()=>openPixelFile(f.id).catch(e=>toast(e.message,true)));
  }
 );
}
/** Componente editor en la misma superficie de VSPack: no overlay ni iframe. */
function pixelPage(){
 const source=pixelSource;
 return `<section class="pixel-workspace" aria-label="Editor integrado de texturas"><div class="pixel-workspace-head"><div class="pixel-breadcrumb">Gestores / ${pixelReturnTab==='interfaces'?'Interfaces y HUD':'Texturas'} / <strong>${escape(source?.path||'Editor')}</strong></div><div class="pixel-heading-actions">${btn('← Volver a '+(pixelReturnView==='managers'?(pixelReturnTab==='interfaces'?'HUD':'Texturas'):pixelReturnView==='editor'?'Editor':'Biblioteca'),'m-pixel-back','secondary')}</div></div><div id="pixel-studio-slot"><div class="pixel-module-loading">Iniciando editor dentro de VSPack…</div></div></section>`;
}
async function hydratePixelWorkspace(){
 const source=pixelSource,slot=$('#pixel-studio-slot');if(!source||!slot)return;
 const load=++pixelLoadToken;
 try{
  const {mountPixelStudio}=await import(new URL('./assets/pixel-bridge.mjs',document.baseURI).href);
  if(!slot.isConnected||managerTab!=='pixel'||load!==pixelLoadToken)return;
  const onSave=async(blobOrBytes,format,overridePath)=>{
   if(!state.packs.some(p=>p.id===source.packId))throw Error('Este pack ya no existe.');
   const p=getPack(source.packId);
   const ext=format==='aseprite'?'aseprite':'png';
   const destination=overridePath?normalize(overridePath):source.path.replace(/\.[^.\/]+$/,'.'+ext);
   if(!destination.toLowerCase().endsWith('.'+ext))throw Error('El archivo debe terminar en .'+ext);
   const data=blobOrBytes instanceof Uint8Array?blobOrBytes:new Uint8Array(await blobOrBytes.arrayBuffer());
   let asset=p.files.find(f=>f.path===destination);
   if(asset&&asset.id!==source.fileId&&!confirm('Ya existe '+destination+'. ¿Reemplazarlo?'))return false;
   if(!asset){asset=createAsset(p,destination,data);p.files.push(asset);}
   await putFile(asset.id,data);
   asset.size=data.byteLength;asset.kind=typeOf(destination);asset.modifiedAt=now();
   state.selectedAssetId=asset.id;managerSelectedId=asset.id;
   await storeState();
   // Guardar como PNG convierte la nueva ruta en el documento activo.
   if(format==='png'&&overridePath){source.fileId=asset.id;source.path=destination;source.bytes=data;}
   // No reconstruir el DOM: hacerlo destruiría el canvas y todas las capas del usuario.
   renderSidebar();
   toast('Guardado en el pack: '+destination);
   return destination;
  };
  const session=await mountPixelStudio({
   mount:slot,
   file:new File([source.bytes],fileName(source.path),{type:guessMime(source.path)}),
   name:fileName(source.path),path:source.path,packName:source.packName,
   savePNG:(blob,path)=>onSave(blob,'png',path),
   saveASE:bytes=>onSave(bytes,'aseprite')
  });
  if(managerTab==='pixel'&&slot.isConnected&&load===pixelLoadToken)pixelSession=session;
  else session.dispose();
 }catch(error){if(slot.isConnected){slot.innerHTML=`<div class="pixel-module-loading"><strong>No se pudo iniciar VS Pixel Studio.</strong><p>${escape(error.message||String(error))}</p>${btn('Volver','m-pixel-back')}</div>`;}toast(error.message||String(error),true);}
}
async function openPixelFile(fileId=managerSelectedId){
 if(managerTab==='pixel')return;
 const p=state.packs.find(pack=>pack.files.some(f=>f.id===fileId));
 const f=p?.files.find(x=>x.id===fileId);
 if(!p||!f)throw Error('Seleccioná una imagen de un pack.');
 if(!/\.(png|ase|aseprite|webp|jpe?g|bmp)$/i.test(f.path))throw Error('VS Pixel Studio admite PNG, imágenes y proyectos .aseprite.');
 const bytes=await getFile(f.id);if(!bytes)throw Error('No se encontró el archivo en IndexedDB.');
 if(!confirmUnsaved())return;
 pixelReturnView=state.view;
 pixelReturnTab=state.view==='managers'?managerTab:'textures';
 pixelSource={fileId:f.id,packId:p.id,packName:p.name,path:f.path,bytes};
 state.view='managers';managerTab='pixel';managerScopeId=p.id;state.selectedPackId=p.id;
 managerSelectedId=f.id;managerDirty=false;editorDirty=false;
 render();
}
function pixelBack(){
 if(pixelSession?.busy){toast('Guardado en curso',true);return;}
 if(!confirmUnsaved())return;
 pixelLoadToken++;
 pixelSource=null;managerTab=pixelReturnTab;
 state.view=pixelReturnView;
 managerDirty=false;editorDirty=false;
 render();
}

/** VS Model Studio comparte el mismo espacio de trabajo y el almacenamiento IndexedDB. */
function modelStudioPage(){
 const src=modelSource;
 return `<section class="model-workspace" aria-label="VS Model Studio integrado"><div class="model-workspace-head"><div class="model-title"><strong>VS Model Studio</strong><span>${escape(src?.path||'Nuevo modelo')}</span></div><div class="model-actions"><output id="model-studio-status" role="status" aria-live="polite">Iniciando editor…</output>${btn('Guardar en pack','m-model-save','primary','disabled')}${btn('Exportar archivo','m-model-export','secondary','disabled')}${btn('Diagnóstico','m-model-diagnose','secondary','disabled')}${btn('Guardar PNG','m-model-textures','secondary','disabled')}${btn('Editar textura en Pixel','m-model-pixel','secondary','disabled')}${btn('← Volver','m-model-back')}</div></div><div id="model-studio-slot"><div class="pixel-module-loading">Abriendo Blockbench original…</div></div></section>`;
}
async function hydrateModelWorkspace(){
 const src=modelSource,slot=$('#model-studio-slot');if(!src||!slot)return;
 const current=++modelLoadToken;
 try{
  const appScript=document.querySelector('script[src$="assets/app.js"]')?.src || new URL('assets/app.js',document.baseURI).href;
  const {mountModelStudio}=await import(new URL('model-native.mjs',appScript).href);
  if(!slot.isConnected||managerTab!=='model-studio'||current!==modelLoadToken)return;
  const save=async (blob, modelInfo={})=>{
   const pack=getPack(src.packId);if(!pack)throw Error('El pack fue eliminado.');
   let asset=src.fileId?pack.files.find(f=>f.id===src.fileId):null;
   const data=new Uint8Array(await blob.arrayBuffer());
   if(!asset){
    const suggested='blueprint/'+((modelInfo.name||'nuevo_modelo').toLowerCase().replace(/[^a-z0-9_.-]+/g,'_')||'modelo')+'.bbmodel';
    const requested=prompt('Guardar proyecto Blockbench en el pack:',suggested);
    if(requested===null)throw Error('Guardado cancelado.');
    const path=normalize(String(requested));
    if(!/^[a-z0-9_.\/-]+\.bbmodel$/.test(path)||path.includes('..')||path.startsWith('/'))throw Error('Ruta .bbmodel inválida.');
    if(pack.files.some(f=>f.path===path))throw Error('Ya existe ese modelo en el pack.');
    asset=createAsset(pack,path,data);pack.files.push(asset);
    src.fileId=asset.id;src.path=path;src.text=new TextDecoder().decode(data);
   }
   await putFile(asset.id,data);asset.size=data.byteLength;asset.modifiedAt=now();
   // Keep the original model in sync when the native Blockbench view is remounted.
   src.bytes=data;src.text=new TextDecoder().decode(data);
   await storeState();renderSidebar();toast('Modelo guardado en el pack: '+src.path);
   return true;
  };
  const saveTexture=async (bytes, name)=>{
   if(!(bytes instanceof Uint8Array)||bytes.length<24||bytes.length>16*1024*1024||
      ![137,80,78,71,13,10,26,10].every((b,i)=>bytes[i]===b))throw Error('Se requiere un PNG válido de hasta 16 MB.');
   const {suggestTexturePath,validateTexturePath}=await import(new URL('./assets/model-texture-paths.mjs',document.baseURI).href);
   const pack=getPack(src.packId);if(!pack)throw Error('El pack de origen ya no existe.');
   const proposed=suggestTexturePath(src.path,name,pack.name);
   const input=prompt('Ruta de la textura PNG dentro del pack:',proposed);
   if(input===null)return false;
   const path=input.trim().toLowerCase();
   if(!validateTexturePath(path))throw Error('Ruta inválida: usá assets/<namespace>/textures/.../*.png sin .. ni rutas absolutas.');
   let asset=pack.files.find(f=>f.path===path);
   if(asset&&!confirm('Ya existe '+path+'. ¿Querés sobrescribir la textura?'))return false;
   const created=!asset;
   if(!asset){asset=createAsset(pack,path,bytes);pack.files.push(asset);}
   try{
    await putFile(asset.id,bytes);
    asset.size=bytes.byteLength;asset.modifiedAt=now();asset.kind=typeOf(path);
    await storeState();renderSidebar();toast('Textura guardada: '+path);
    return path;
   }catch(error){if(created)pack.files=pack.files.filter(f=>f.id!==asset.id);throw error;}
  };
  const saveTextureProject=async (bytes,name)=>{
   if(!(bytes instanceof Uint8Array)||bytes.length===0||bytes.length>32*1024*1024)
     throw Error('El proyecto Aseprite está vacío o supera 32 MB.');
   const {suggestTexturePath}=await import(new URL('./assets/model-texture-paths.mjs',document.baseURI).href);
   const {textureProjectPath}=await import(new URL('./assets/model-pixel-sync.mjs',document.baseURI).href);
   const pack=getPack(src.packId);if(!pack)throw Error('El pack de origen ya no existe.');
   const proposed=textureProjectPath(suggestTexturePath(src.path,name,pack.name));
   const input=prompt('Guardar proyecto editable .aseprite en el pack:',proposed);
   if(input===null)return false;
   const path=input.trim().toLowerCase();
   if(!/^assets\/[a-z0-9_.-]+\/textures\/(?:[a-z0-9_.-]+\/)*[a-z0-9_.-]+\.aseprite$/.test(path))
     throw Error('Ruta inválida para el proyecto .aseprite.');
   let asset=pack.files.find(f=>f.path===path);
   if(asset&&!confirm('Ya existe '+path+'. ¿Sobrescribir proyecto?'))return false;
   const created=!asset;if(created){asset=createAsset(pack,path,bytes);pack.files.push(asset);}
   try{await putFile(asset.id,bytes);asset.size=bytes.length;asset.modifiedAt=now();
    await storeState();renderSidebar();toast('Proyecto .aseprite guardado: '+path);return true;
   }catch(error){if(created)pack.files=pack.files.filter(f=>f.id!==asset.id);throw error;}
  };
  const session=await mountModelStudio({mount:slot,source:src,save,saveTexture,saveTextureProject,download});
  if(managerTab==='model-studio'&&slot.isConnected&&current===modelLoadToken)modelSession=session;
  else session.dispose();
 }catch(e){if(slot.isConnected)slot.innerHTML=`<div class="pixel-module-loading"><strong>Error al abrir VS Model Studio</strong><p>${escape(e.message||String(e))}</p>${btn('Reintentar','m-model-retry','primary')}${btn('Volver','m-model-back')}</div>`;toast(e.message||String(e),true);}
}
async function openModelTextureInPixel(){
 if(!modelSession||!modelSource)return toast('Abrí un modelo primero.',true);
 if(modelSession.busy)return;
 try{
  // Persist Blockbench first: switching workspaces disposes its iframe/editor state.
  if(modelSession.dirty||!modelSource.fileId){
   if(!confirm('Antes de abrir VS Pixel Studio hay que guardar el modelo 3D en tu pack para no perder cambios. ¿Guardar ahora?'))return;
   await modelSession.save();
   if(!modelSource.fileId)throw Error('Guardá el modelo antes de editar su textura.');
  }
  const path=await modelSession.openTextureInPixel();
  if(!path)return;
  const pack=getPack(modelSource.packId),texture=pack?.files.find(f=>f.path===path);
  if(!texture)throw Error('La textura no se encontró en el pack tras guardarla.');
  await openPixelFile(texture.id);
 }catch(error){toast('No se pudo abrir Pixel Studio: '+error.message,true);}
}
async function openModelFile(fileId=managerSelectedId){
 const p=state.packs.find(pack=>pack.files.some(f=>f.id===fileId));
 const f=p?.files.find(x=>x.id===fileId);
 if(!p||!f)throw Error('Seleccioná un modelo de un pack.');
 if(!/\.(bbmodel|json)$/i.test(f.path))throw Error('VS Model Studio admite .bbmodel y JSON de modelos Minecraft.');
 const bytes=await getFile(f.id);if(!bytes)throw Error('No se encontró el archivo en la biblioteca.');
 if(!confirmUnsaved())return;
 let prepared=null;
 if(/\.json$/i.test(f.path)){
  const {prepareMinecraftModel}=await import(new URL('./assets/model-resource-import.mjs',document.baseURI).href);
  prepared=await prepareMinecraftModel({path:f.path,files:p.files,readBytes:asset=>getFile(asset.id)});
 }
 modelReturnView=state.view;modelReturnTab=state.view==='managers'?managerTab:'models';
 modelSource={fileId:prepared?.sourceId||f.id,packId:p.id,packName:p.name,
  path:prepared?.path||f.path,originPath:prepared?.originalPath||f.path,
  bytes:prepared?null:bytes,text:prepared?.text||new TextDecoder().decode(bytes),
  resources:prepared?.resources||null,importWarnings:prepared?.warnings||[]};
 state.view='managers';managerTab='model-studio';managerScopeId=p.id;state.selectedPackId=p.id;
 managerSelectedId=f.id;managerDirty=false;editorDirty=false;
 render();
}
function modelBack(){
 if(modelSession?.busy)return toast('Guardado en curso',true);
 if(!confirmUnsaved())return;
 modelLoadToken++;modelSource=null;managerTab=modelReturnTab;state.view=modelReturnView;
 managerDirty=false;editorDirty=false;render();
}
function openOriginalBlockbench(){
 const p=managerPack();if(!p)return toast('Seleccioná un pack primero.',true);
 if(!confirmUnsaved())return;
 modelReturnView=state.view;modelReturnTab=managerTab;
 modelSource={fileId:null,packId:p.id,packName:p.name,path:null,bytes:null,text:null};
 state.view='managers';managerTab='model-studio';managerScopeId=p.id;state.selectedPackId=p.id;
 managerDirty=false;editorDirty=false;
 render();
}
function newModelFile(){
 const p=managerPack();if(!p)return toast('Creá o seleccioná primero un pack.',true);
 modal('Crear modelo 3D','Creá un modelo local dentro del pack y abrilo en VS Model Studio.',field('path','Ruta del archivo','blueprint/native/mi_modelo.bbmodel'),async data=>{
  const path=normalize(String(data.get('path')||''));
  if(!/\.(bbmodel|json)$/i.test(path)||!/^[a-z0-9_.\/-]+$/.test(path))throw Error('Ruta relativa válida .bbmodel o .json.');
  if(p.files.some(f=>f.path===path))throw Error('Ya existe ese archivo.');
  const json=/\.bbmodel$/i.test(path)?{
   meta:{format_version:'5.0',model_format:'free',box_uv:false},name:fileName(path).replace(/\.bbmodel$/i,''),resolution:{width:16,height:16},elements:[],textures:[],groups:[],outliner:[],animations:[]
  }:{parent:'minecraft:block/cube_all',textures:{all:'minecraft:block/stone'}};
  const bytes=new TextEncoder().encode(JSON.stringify(json,null,2)),asset=createAsset(p,path,bytes);
  await putFile(asset.id,bytes);p.files.push(asset);managerSelectedId=asset.id;state.selectedAssetId=asset.id;
  await storeState();toast('Modelo creado: '+path);queueMicrotask(()=>openModelFile(asset.id).catch(e=>toast(e.message,true)));
 });
}
function managerAction(act,el){switch(act){case 'm-model-back':modelBack();break;case 'm-model-retry':render();break;case 'm-model-save':modelSession?.save().catch(e=>toast(e.message,true));break;case 'm-model-export':modelSession?.export().catch(e=>toast(e.message,true));break;case 'm-model-textures':modelSession?.saveTextures().catch(e=>toast(e.message,true));break;case 'm-model-pixel':void openModelTextureInPixel();break;case 'm-model-diagnose':modelSession?.diagnose().then(report=>{const lines=[`Modelo: ${report.name}`,`Formato: ${report.format}`,`Elementos: ${report.elements} (${report.cubes} cubos, ${report.meshes} mallas)`,`Triángulos estimados: ${report.estimatedTriangles}`,`Texturas: ${report.textures}`,`Motor: ${report.engine || "JavaScript"}`,`Cubos sin volumen: ${report.performance?.zeroVolumeCubes ?? 0}`,`Caras degeneradas: ${report.performance?.zeroAreaFaces ?? 0}`,`Volumen local estimado: ${(report.performance?.estimatedCubeVolume ?? 0).toFixed(2)}`,`Límites: ${report.bounds?report.bounds.min.map((x,i)=>x.toFixed(2)+' → '+report.bounds.max[i].toFixed(2)).join(' / '):'Sin geometría'}`,...report.issues.map(i=>`${i.level==='error'?'ERROR':i.level==='warning'?'Aviso':'Info'}: ${i.what}`)];alert(lines.join('\n'));}).catch(e=>toast(e.message,true));break;case 'm-open-model':openModelFile().catch(e=>toast(e.message,true));break;case 'm-open-original':openOriginalBlockbench();break;case 'm-new-model':newModelFile();break;case 'm-pixel-back':pixelBack();break;case 'm-tab':if(!confirmUnsaved())return;managerDirty=false;managerSearch='';managerSelectedId=null;managerTab=el.dataset.v;render();break;
case 'm-pick':managerScopeId=el.dataset.id;state.selectedPackId=el.dataset.id;managerFolder='';managerSelectedId=null;storeState().then(render);break;
case 'm-copy-pack':copyPack(el.dataset.id);break;case 'm-export-pack':exportOnePack(el.dataset.id);break;
case 'm-open-pixel':openPixelFile().catch(e=>toast(e.message,true));break;case 'm-new-pixel':newPixelTexture();break;case 'm-new-folder':folderModal();break;case 'm-import-folder':uploadFolder=managerFolder?managerFolder+'/':'';state.selectedPackId=managerPack()?.id;importFiles();break;case 'm-open-folder':managerFolder=el.dataset.path||'';managerSearch='';managerSelectedId=null;render();break;case 'm-rename-folder':changeFolderName();break;case 'm-delete-folder':changeFolderName(true);break;
case 'm-select':managerSelectedId=el.dataset.id;render();break;case 'm-move-file':moveManagerFile();break;case 'm-open-editor':useManagerEditor();break;case 'm-duplicate':managerDuplicate();break;case 'm-download':managerDownload();break;case 'm-remove':managerRemove();break;
case 'm-select-texture':chooseManagerFile(el.dataset.id,'textures');break;case 'm-select-model':chooseManagerFile(el.dataset.id,'models');break;case 'm-select-item':chooseManagerFile(el.dataset.id,'items');break;

case 'm-rotate':modelAngle=(modelAngle+(Number(el.dataset.dir)||1)*22.5+360)%360;inspectModel();break;
case 'm-new-item':newVisualAsset('item');break;case 'm-new-block':newVisualAsset('block');break;case 'm-select-sound':chooseManagerFile(el.dataset.id,'sounds');break;case 'm-select-ui':chooseManagerFile(el.dataset.id,'interfaces');break;case 'm-edit-ui':openPixelFile().catch(e=>toast(e.message,true));break;case 'm-open-sounds-config':{const p=managerPack();state.selectedPackId=p.id;state.selectedAssetId=el.dataset.id;setView('editor');break;}case 'm-import-audio':specialImport('sounds');break;case 'm-import-ui':specialImport('gui');break;case 'm-new-sound-event':newSoundEvent();break;case 'm-run-diagnostics':runDiagnostics();break;case 'm-download-diagnostics':downloadDiagnostics();break;default:return false;}return true;}

function command(action,element){if(action.startsWith("m-")&&managerAction(action,element))return;switch(action){case 'nav':setView(element.dataset.v);break;case 'choose-pack':if(confirmUnsaved()){editorDirty=false;choosePack(element.dataset.id);}break;case 'create-pack':createPack();break;case 'backup-export':void exportWorkspaceBackup();break;case 'backup-import':$('#workspace-backup-upload').click();break;case 'new-folder':createFolder();break;case 'edit-pack':editPack();break;case 'delete-pack':deletePack(element.dataset.id);break;case 'import-zip':importZIP();break;case 'import-files':importFiles();break;case 'select-file':if(confirmUnsaved()){editorDirty=false;state.selectedAssetId=element.dataset.id;render();}break;case 'select-editor-file':if(confirmUnsaved()){editorDirty=false;state.selectedAssetId=element.dataset.id;render();}break;case 'open-pixel':openPixelFile(state.selectedAssetId).catch(e=>toast(e.message,true));break;case 'open-model':openModelFile(state.selectedAssetId).catch(e=>toast(e.message,true));break;case 'edit-file':setView('editor');break;case 'download-file':exportFile();break;case 'save-properties':saveProperties();break;case 'save-text':saveText();break;case 'duplicate-file':duplicate();break;case 'delete-file':askDelete();break;case 'fav':toggleFav(element.dataset.id);break;case 'browse-folder':if(confirmUnsaved()){editorDirty=false;filter.query=element.dataset.path;filter.pack=state.selectedPackId;setView('library');}break;case 'display-grid':filter.display='grid';render();break;case 'display-list':filter.display='list';render();break;case 'filter-favs':filter.favorites=!filter.favorites;render();break;case 'layer-up':changePriority(element.dataset.id,true);break;case 'layer-down':changePriority(element.dataset.id,false);break;case 'go-publisher':setView('publisher');break;case 'validate':validate().catch(e=>toast(e.message,true));break;case 'export-composed':publishTarget='composed';setView('publisher');break;case 'export-publish':exportPack();break;default:break;}}
function bind(){document.addEventListener('click',ev=>{const actionable=ev.target.closest('[data-act]');if(actionable){ev.preventDefault();if(working)return;const isFav=actionable.dataset.act==='fav';if(isFav)ev.stopPropagation();command(actionable.dataset.act,actionable);}});
$('#top-create').addEventListener('click',createPack);$('#add-pack-side').addEventListener('click',createPack);$('#top-import').addEventListener('click',importZIP);$('#import-pack-side').addEventListener('click',importZIP);$('#quick-guide').addEventListener('click',help);
$('#workspace-backup-upload').addEventListener('change',async ev=>{const file=ev.target.files?.[0];ev.target.value='';if(file)try{await importWorkspaceBackup(file);}catch(e){toast('No se pudo restaurar: '+e.message,true);}});
$('#zip-upload').addEventListener('change',async ev=>{const chosen=[...ev.target.files];ev.target.value='';await doImportZip(chosen);});$('#asset-upload').addEventListener('change',async ev=>{const chosen=[...ev.target.files];ev.target.value='';await doImportAssets(chosen);});
document.addEventListener('change',async ev=>{const t=ev.target;switch(t.id){case 'library-kind':filter.kind=t.value;render();break;case 'library-pack':filter.pack=t.value;render();break;case 'editor-pack':choosePack(t.value);render();break;case 'manager-pack':if(confirmUnsaved()){managerScopeId=t.value;state.selectedPackId=t.value;managerSelectedId=null;managerFolder='';managerDirty=false;storeState().then(render);}break;case 'publish-target':publishTarget=t.value;report=null;render();break;case 'pack-format':state.packFormat=t.value;await storeState();break;default:if(t.hasAttribute('data-toggle-pack')){const p=getPack(t.dataset.togglePack);if(p){p.enabled=t.checked;await refreshState();}}else if(t.hasAttribute('data-conflict')){state.resolutions[t.dataset.conflict]=t.value;await refreshState();}}});
document.addEventListener('input',ev=>{

 const id=ev.target.id;
 if(['manager-file-search','manager-texture-search','manager-model-search','manager-item-search','manager-sounds-search','manager-ui-search','library-search'].includes(id)){
  const input=ev.target,cursor=input.selectionStart;
  if(id==='library-search')filter.query=input.value;else managerSearch=input.value;
  clearTimeout(searchTimer);
  searchTimer=setTimeout(()=>{
   searchTimer=0;
   if(!input.isConnected)return;
   render();
   const next=document.getElementById(id);
   if(next){next.focus();next.setSelectionRange(cursor,cursor);}
  },90);
 }
});
document.addEventListener('keydown',ev=>{if(ev.key==='Escape')$('#dialog-root').innerHTML='';if((ev.ctrlKey||ev.metaKey)&&ev.key.toLowerCase()==='s'&&state.view==='editor'&&editorDirty){ev.preventDefault();saveText();}if(ev.target.matches('.asset-card')&&(ev.key==='Enter'||ev.key===' ')){ev.preventDefault();ev.target.click();}});
let dragCount=0;window.addEventListener('dragenter',ev=>{if([...ev.dataTransfer.types].includes('Files')){dragCount++;if(!$('#drag-help')){const o=document.createElement('div');o.id='drag-help';o.className='drop-overlay';o.textContent='Soltá tus Resource Packs ZIP aquí';document.body.append(o);}}});window.addEventListener('dragleave',()=>{dragCount=Math.max(0,dragCount-1);if(!dragCount)$('#drag-help')?.remove();});window.addEventListener('dragover',ev=>{if([...ev.dataTransfer.types].includes('Files'))ev.preventDefault();});window.addEventListener('drop',async ev=>{ev.preventDefault();dragCount=0;$('#drag-help')?.remove();const files=[...ev.dataTransfer.files];const zips=files.filter(f=>/\.zip$/i.test(f.name));if(zips.length)await doImportZip(zips);else if(files.length)await doImportAssets(files);});}
/* VSMedia host interface — same-origin only. The host receives metadata, never the bytes
   of local files. Keep this adapter isolated from the rendering/editor engines. */
const hostViews=new Set(['library','managers','editor','composer','publisher']);
const hostManagerTabs=new Set(manageTabs.map(([id])=>id));
function hostSnapshot(){return {
  schema:'vspack-host-v1', version:'3.0.0', view:state.view,
  manager:state.view==='managers'?(hostManagerTabs.has(managerTab)?managerTab:'editor'):null,
  activePackId:state.selectedPackId||null,
  packs:state.packs.map(p=>({id:p.id,name:p.name,count:p.files.length,enabled:p.enabled!==false})),
  selectedAssetId:state.selectedAssetId||null
};}
function notifyHost(kind){
  const data=hostSnapshot();
  window.dispatchEvent(new CustomEvent('vspack:'+kind,{detail:data}));
  // Cross-origin parents are deliberately excluded: IndexedDB is origin-scoped.
  if(window.parent!==window){try{if(window.parent.location.origin===window.location.origin)
    window.parent.postMessage({source:'vspack',type:kind,...data},window.location.origin);
  }catch{/* different origins require explicit migration; do not leak metadata */}}
}
function hostNavigate(view,manager){
  if(!hostViews.has(view))throw Error('Vista de VSPack no disponible');
  if(manager!==undefined&&manager!==null&&!hostManagerTabs.has(manager))throw Error('Gestor no disponible');
  if(!confirmUnsaved())return false;
  if(managerTab==='pixel'){pixelSource=null;managerTab=pixelReturnTab;}
  if(managerTab==='model-studio'){modelSource=null;managerTab=modelReturnTab;}
  state.view=view;
  if(view==='managers'&&manager)managerTab=manager;
  editorDirty=false;managerDirty=false;render();return true;
}
function hostOpenPack(id){
  if(!getPack(id))throw Error('El pack no existe');
  if(!confirmUnsaved())return false;
  choosePack(id);return true;
}
async function hostOpenAsset({packId,path,editor='auto'}){
  if(!packId||typeof path!=='string')throw Error('Indicá packId y path');
  const p=getPack(packId),file=p?.files.find(f=>f.path===path);
  if(!file)throw Error('Recurso no encontrado dentro del pack');
  if(!confirmUnsaved())return false;
  if(editor==='auto')editor=/\.(bbmodel)$/i.test(path)||path.includes('/models/')?'model':/\.(png|aseprite|ase|webp|jpe?g)$/i.test(path)?'pixel':'text';
  if(!['model','pixel','text'].includes(editor))throw Error('Editor inválido');
  if(editor==='model')await openModelFile(file.id);
  else if(editor==='pixel')await openPixelFile(file.id);
  else{state.selectedPackId=p.id;state.selectedAssetId=file.id;state.view='editor';render();}
  return true;
}
/** VSMedia audio editor -> VSPack browser-only handoff. */
async function hostImportSound({packId,namespace,eventName,bytes,stream=false,subtitle=''}){
 if(!(bytes instanceof Uint8Array) || bytes.length<80 || bytes.length>32*1048576 ||
    String.fromCharCode(...bytes.subarray(0,4))!=='OggS' ||
    !new TextDecoder('ascii').decode(bytes.subarray(0,200)).includes('vorbis'))
   throw Error('Se requiere un OGG/Vorbis real (máximo 32 MiB).');
 if(!/^[a-z0-9_.-]{1,40}$/.test(namespace) ||
    !/^[a-z0-9_.-]+(?:\/[a-z0-9_.-]+)*$/.test(eventName) ||
    eventName.length>120 || eventName.split('/').includes('..'))
   throw Error('Namespace o identificador de sonido inválido.');
 if(editorDirty||managerDirty||modelSession?.dirty)throw Error('Guardá primero tus cambios en VS Pack.');
 let p=(packId&&getPack(packId))||selectedPack()||state.packs[0];
 if(!p){p={id:uuid(),name:'VSMedia Sonidos',version:'1.0.0',description:'Sonidos exportados desde VSMedia',createdAt:now(),order:state.packs.length,enabled:true,folders:[],files:[]};state.packs.push(p);}
 const folder=`assets/${namespace}/sounds/`,jsonPath=`assets/${namespace}/sounds.json`;
 // Existing sound events are extended with a variant; no unrelated event is overwritten.
 let stem=eventName,suffix=2,path=folder+stem+'.ogg';
 while(p.files.some(a=>a.path===path))path=folder+stem+'_'+suffix+++'.ogg';
 const identifier=path.slice(folder.length,-4);
 let old=p.files.find(a=>a.path===jsonPath),meta={};
 if(old){const content=await getFile(old.id);if(!content)throw Error('No se pudo leer sounds.json actual');
   meta=JSON.parse(new TextDecoder().decode(content));
   if(!meta||typeof meta!=='object'||Array.isArray(meta))throw Error('sounds.json no es un objeto');
 }
 const item=meta[eventName];
 if(item!==undefined && (!item||typeof item!=='object'||Array.isArray(item)||!Array.isArray(item.sounds)))
   throw Error('El evento existente necesita una lista sounds válida.');
 const entry={name:`${namespace}:${identifier}`,stream:!!stream};
 const variants=item?[...item.sounds]:[];
 if(!variants.some(x=>(typeof x==='string'?x:x?.name)===entry.name))variants.push(entry);
 meta[eventName]={...(item||{}),sounds:variants};
 if(subtitle && !item?.subtitle)meta[eventName].subtitle=String(subtitle).slice(0,160);
 const jsonBytes=new TextEncoder().encode(JSON.stringify(meta,null,2)+'\n');
 const soundAsset=createAsset(p,path,bytes),jsonAsset=old||createAsset(p,jsonPath,jsonBytes);
 await putFilesBatch([{id:soundAsset.id,bytes},{id:jsonAsset.id,bytes:jsonBytes}]);
 p.files.push(soundAsset);
 if(!old)p.files.push(jsonAsset);else{old.size=jsonBytes.length;old.modifiedAt=now();}
 state.selectedPackId=p.id;state.selectedAssetId=soundAsset.id;
 await storeState();render();notifyHost('change');
 return {packId:p.id,packName:p.name,path,eventId:`${namespace}:${eventName}`,size:bytes.length};
}
window.VSPackHost=Object.freeze({
  version:'3.0.0',snapshot:hostSnapshot,navigate:hostNavigate,
  selectPack:hostOpenPack,openAsset:hostOpenAsset,importSound:hostImportSound
});
window.addEventListener('message',async ev=>{
  if(ev.source!==window.parent||ev.origin!==window.location.origin)return;
  const msg=ev.data;
  if(!msg||msg.source!=='vsmedia'||typeof msg.type!=='string')return;
  let result=null,error=null;
  try{
    if(msg.type==='GET_STATE')result=hostSnapshot();
    else if(msg.type==='NAVIGATE')result=hostNavigate(msg.view,msg.manager);
    else if(msg.type==='SELECT_PACK')result=hostOpenPack(msg.packId);
    else if(msg.type==='OPEN_ASSET')result=await hostOpenAsset({packId:msg.packId,path:msg.path,editor:msg.editor});
    else if(msg.type==='IMPORT_SOUND')result=await hostImportSound(msg);
    else throw Error('Acción no disponible');
  }catch(e){error=String(e.message||e);}
  ev.source.postMessage({source:'vspack',type:'RESPONSE',requestId:msg.requestId??null,result,error},ev.origin);
});
async function init(){bind();try{let saved=await metaRead();if(saved&&Array.isArray(saved.packs)){state={...fresh(),...saved};state.packs.forEach((p,i)=>{p.folders||=[];p.files||=[];p.order??=i;p.enabled??=true;});}}catch(e){toast('El navegador no permite guardar datos: '+e.message,true);}
  const query=new URLSearchParams(window.location.search);
  if(query.get('embed')==='1')document.body.classList.add('vspack-embed');
  const initialView=query.get('view');if(hostViews.has(initialView))state.view=initialView;
  const initialManager=query.get('manager');if(state.view==='managers'&&hostManagerTabs.has(initialManager))managerTab=initialManager;
  render();notifyHost('ready');
}
// Retain editor event handlers inside this module's lexical scope. The old
// listeners lived after the IIFE and threw `managerTab is not defined`.
window.addEventListener('vspack:model-return',()=>{if(managerTab==='model-studio')modelBack();});
window.addEventListener('beforeunload',event=>{if(modelSession?.dirty){event.preventDefault();event.returnValue='';}});
init().catch(e=>{console.error('No se pudo iniciar VSPack:',e);toast('Error inicializando biblioteca local: '+e.message,true);});
})();
