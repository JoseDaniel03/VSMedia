/** An editable Aseprite project alongside a saved PNG texture. */
export function textureProjectPath(path){
 if(typeof path!=='string'||!path.endsWith('.png'))throw Error('Se requiere ruta PNG');
 return path.slice(0,-4)+'.aseprite';
}
