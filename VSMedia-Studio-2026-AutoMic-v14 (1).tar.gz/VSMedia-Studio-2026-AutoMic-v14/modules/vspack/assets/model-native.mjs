/**
 * VS Model Studio in VSPack.
 *
 * Embed the unmodified Blockbench document as an internal UI component.
 * Running its bundle against transplanted DOM nodes and a temporary <base>
 * corrupts CSS, relative URLs, Vue panels and Three.js canvases.
 * The same-origin component provides a small, origin-checked bridge to the
 * original Blockbench codecs. No source code or visual UI is cloned here.
 *
 * Upstream Blockbench: GPL-3.0-or-later; see ../vs-model-studio/LICENSE.MD.
 */
import '../vs-model-studio/embed/component.js';

const root = new URL('../vs-model-studio/', import.meta.url);
const MAX_MODEL_BYTES = 64 * 1024 * 1024;
const message = (value) => value?.message || String(value);

async function verifyBundle() {
  const url = new URL('dist/bundle.js', root);
  let response;
  try {
    response = await fetch(url, {method:'HEAD', cache:'no-store'});
    if(response.status===405 || response.status===501){
      response = await fetch(url,{method:'GET',headers:{Range:'bytes=0-7'},cache:'no-store'});
      if(response.body)await response.body.cancel();
    }
  } catch {
    throw Error('No se pudo acceder al editor local. Iniciá VSMedia con ./start.sh.');
  }
  if (!response.ok || /text\/html/i.test(response.headers.get('content-type') || '')) {
    throw Error('Blockbench compilado no encontrado: falta modules/vspack/vs-model-studio/dist/bundle.js. Copiá el bundle que ya compilaste o ejecutá build-blockbench-once.sh una sola vez.');
  }
}

function validateSource(source) {
  if (!source?.text && !source?.bytes) return null;
  const text = typeof source.text === 'string' ? source.text : new TextDecoder().decode(source.bytes);
  if (!text.trim() || text.length > MAX_MODEL_BYTES) throw Error('Archivo de modelo vacío o superior a 64 MiB.');
  let parsed;
  try {parsed = JSON.parse(text);} catch {throw Error('El modelo no contiene JSON válido.');}
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw Error('Modelo JSON inválido.');
  if (/\.bbmodel$/i.test(source.path || '') && (!parsed.meta || typeof parsed.meta !== 'object')) {
    throw Error('El archivo .bbmodel no tiene metadatos de Blockbench.');
  }
  return text;
}

export async function mountModelStudio({mount, source, save, saveTexture, download}) {
  if (!mount?.isConnected) throw Error('No se encontró el panel de VS Model Studio.');
  // Detect missing compiled sources before creating a blank 3D editor.
  await verifyBundle();
  if (!mount.isConnected) throw Error('El panel ya fue cerrado.');

  const contents = validateSource(source);
  const el = document.createElement('vs-model-studio');
  el.className = 'vs-model-embedded';
  el.setAttribute('editor-url', new URL('index.html', root).href);
  el.setAttribute('language', 'es');
  el.setAttribute('accent', '#c8a96c');
  el.setAttribute('aria-label', 'Editor completo Blockbench integrado en VSPack');

  let closed = false;
  let busy = false;
  let changed = false;
  let details = {name:'Modelo', saved:true};
  let probe = null;
  const headStatus = document.querySelector('#model-studio-status');
  const saveButton = document.querySelector('[data-act="m-model-save"]');
  const exportButton = document.querySelector('[data-act="m-model-export"]');
  const diagnoseButton = document.querySelector('[data-act="m-model-diagnose"]');
  const textureButton = document.querySelector('[data-act="m-model-textures"]');
  const pixelButton = document.querySelector('[data-act="m-model-pixel"]');
  const updateStatus = (text, invalid=false) => {
    if (headStatus?.isConnected) {
      headStatus.textContent = text;
      headStatus.classList.toggle('error', invalid);
    }
  };
  const updateButtons = () => {
    for (const button of [saveButton, exportButton, diagnoseButton, textureButton, pixelButton]) {
      if (button?.isConnected) button.disabled = busy || closed || !el.ready;
    }
  };
  const syncInfo = async () => {
    if (closed || !el.ready || busy || !el.getClientRects().length) return;
    try {
      const next = await el.getInfo();
      if (closed) return;
      details = next;
      changed = Boolean(next.hasProject && next.saved === false);
    } catch { /* transient render/codec state; keep last known state */ }
  };
  const onChange = event => {
    if (closed) return;
    details = event.detail?.payload || details;
    changed = Boolean(details.hasProject && details.saved === false);
    if(!busy)updateStatus(changed?'● Modelo con cambios sin guardar':'Modelo sincronizado · guardado');
  };
  const onVisible = () => {if(!document.hidden)void syncInfo();};
  const onError = event => updateStatus('Blockbench: ' + message(event.detail), true);
  const onHostEvent = event => {
    if (event.detail?.name === 'save_shortcut' && !busy && !closed) {
      void savePack().catch(error => updateStatus('Error: ' + message(error), true));
    }
  };
  el.addEventListener('vs-project-changed', onChange);
  el.addEventListener('vs-event', onHostEvent);
  el.addEventListener('vs-error', onError);
  mount.replaceChildren(el);
  updateStatus('Iniciando Blockbench…');

  try {
    await el.whenReady;
    if (closed || !el.isConnected) return {dispose(){},get dirty(){return false},get busy(){return false}};
    if (contents) {
      await el.openModel(contents, source.path || 'modelo.bbmodel', source.resources || null);
      await el.markSaved();
    }
    details = await el.getInfo();
    changed = Boolean(details.hasProject && details.saved === false && contents);
    const hints=source?.importWarnings||[];
    updateStatus(contents
      ? 'Modelo abierto · Blockbench '+(details.editorVersion||'original')+(hints.length ? ` · ${hints.length} advertencia(s) de recursos` : '')
      : 'Editor listo · elegí formato o abrí un modelo');
    if(hints.length){
      const notice=document.createElement('div');
      notice.className='model-import-notice';
      notice.title=hints.join('\n');
      notice.textContent='⚠ '+hints.slice(0,2).join(' · ');
      const parent=mount.closest('.model-workspace-head');
      parent?.append(notice);
    }
    updateButtons();
    probe = setInterval(()=>{if(!document.hidden)void syncInfo();}, 3000);
    document.addEventListener('visibilitychange', onVisible);
  } catch (error) {
    document.removeEventListener('visibilitychange',onVisible);
    el.remove();
    updateStatus('No se pudo iniciar Blockbench: ' + message(error), true);
    throw error;
  }

  const run = async (action, operation) => {
    if (closed || busy) return;
    busy = true; updateButtons(); updateStatus(action + '…');
    try {return await operation();}
    catch (error) { updateStatus('Error: ' + message(error), true); throw error; }
    finally {busy = false; updateButtons();}
  };
  const savePack = () => run('Guardando modelo en el pack', async () => {
    const info = await el.getInfo();
    if (!info?.hasProject) throw Error('Abrí o creá un modelo antes de guardarlo.');
    const format = /\.json$/i.test(source?.path || '') ? 'java_block' : 'project';
    const text = await el.exportModel(format);
    const blob = new Blob([text], {type:'application/json'});
    await save(blob, info);
    await el.markSaved();
    details = await el.getInfo(); changed = false;
    updateStatus('Guardado en el Resource Pack');
    return true;
  });
  const persistTexture=async item=>{
    if(!saveTexture)throw Error('El pack no admite guardar texturas.');
    if(!item?.dataUrl?.startsWith('data:image/png;base64,'))throw Error('Textura PNG inválida.');
    const binary=atob(item.dataUrl.slice('data:image/png;base64,'.length));
    const bytes=new Uint8Array(binary.length);
    for(let i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i);
    return saveTexture(bytes,item.name);
  };
  const saveTextures = () => run('Guardando texturas PNG', async () => {
    const items=await el.exportTextures();
    if(!items.length)throw Error('No hay texturas PNG exportables en el modelo');
    let saved=0;
    for(const item of items)if(await persistTexture(item))saved++;
    updateStatus(`${saved} de ${items.length} texturas guardadas en el pack`);
    return saved;
  });
  const openTextureInPixel = () => run('Preparando textura para VS Pixel Studio', async () => {
    const items=await el.exportTextures();
    if(!items.length)throw Error('Este modelo no tiene texturas PNG para editar.');
    let index=0;
    if(items.length>1){
      const choice=prompt('Elegí el número de textura que querés editar en Pixel Studio:\n'+items.map((item,i)=>`${i+1}. ${item.name}`).join('\n'),'1');
      if(choice===null)return null;
      index=Number(choice)-1;
      if(!Number.isInteger(index)||index<0||index>=items.length)throw Error('Número de textura inválido.');
    }
    const path=await persistTexture(items[index]);
    if(!path)return null;
    updateStatus('Textura guardada para editar: '+path);
    return path;
  });
  const diagnose = () => run('Revisando geometría', async () => {
    const report=await el.diagnose();
    const count=report.issues.filter(i=>i.level==='error').length;
    updateStatus(`${report.elements} elementos · ${report.estimatedTriangles} triángulos aprox. · ${report.issues.length} avisos`, count>0);
    return report;
  });
  const exportLocal = () => run('Exportando archivo', async () => {
    const info = await el.getInfo();
    if (!info?.hasProject) throw Error('Primero abrí o creá un modelo.');
    const format = /\.json$/i.test(source?.path || '') ? 'java_block' : 'project';
    const text = await el.exportModel(format);
    const name = (source?.path?.split('/').pop() || info.name || 'modelo.bbmodel').replace(/[\\/]/g,'_');
    // Reuse VSPack's local download helper rather than an external server.
    download(new Blob([text], {type:'application/json'}), /\.(json|bbmodel)$/i.test(name) ? name : name + '.bbmodel');
    updateStatus('Modelo exportado al equipo');
    return true;
  });
  return {
    save: savePack,
    export: exportLocal,
    diagnose,
    saveTextures,
    openTextureInPixel,
    get info(){return details;},
    get busy(){return busy;},
    get dirty(){return !closed && changed;},
    dispose(){
      if (closed) return;
      closed = true;
      clearInterval(probe);
      document.removeEventListener('visibilitychange',onVisible);
      el.removeEventListener('vs-project-changed', onChange);
      el.removeEventListener('vs-event', onHostEvent);
      el.removeEventListener('vs-error', onError);
      el.remove();
      updateButtons();
    }
  };
}
