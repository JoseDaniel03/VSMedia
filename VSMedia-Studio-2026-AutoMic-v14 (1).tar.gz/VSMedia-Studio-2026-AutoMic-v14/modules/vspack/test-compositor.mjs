import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
// Test the production code, not a copy of the algorithm.
const source=readFileSync(new URL('./assets/app.js',import.meta.url),'utf8');
const start=source.indexOf('// Build a single index per update:');
const end=source.indexOf('function composerPage()',start);
assert(start>=0&&end>start);
const section=source.slice(start,end);
const packs=Array.from({length:7},(_,i)=>({id:'p'+i,order:i,enabled:i!==4,files:Array.from({length:400},(_,j)=>({id:`f${i}-${j}`,path:`assets/minecraft/textures/block/${j%35?'unique'+i+'-'+j:'shared'+j%23}.png`}))}));
const state={packs,resolutions:{'assets/minecraft/textures/block/shared0.png':'p2'}};
const ctx=vm.createContext({state,orderedPacks:()=>[...state.packs].sort((a,b)=>a.order-b.order)});
vm.runInContext(section+'; globalThis.api={candidate,composed,computeConflicts,clear:()=>{compositionCache=null}}',ctx);
const api=ctx.api;
const naive=()=>{
 const result=new Map();for(const p of packs.filter(p=>p.enabled).sort((a,b)=>a.order-b.order))for(const f of p.files){
  const old=result.get(f.path);if(!old)result.set(f.path,{pack:p,file:f});
  if(state.resolutions[f.path]===p.id)result.set(f.path,{pack:p,file:f});
 }return result;
};
const reference=naive(),optimized=api.composed();
assert.equal(optimized.length,reference.size);
for(const x of optimized)assert.equal(x.pack.id,reference.get(x.file.path).pack.id,x.file.path);
assert.equal(api.candidate('no-such-path'),null);
assert(api.computeConflicts().length>0);
// Cache invalidation simulates state persistence/update in application.
const sample=optimized.find(x=>x.file.path.includes('unique0-1'));
packs[0].enabled=false;api.clear();
assert.equal(api.candidate(sample.file.path),null);
console.log(`Composición: OK (${packs.length} packs, ${packs.reduce((n,p)=>n+p.files.length,0)} entradas, ${optimized.length} rutas únicas)`);
