import assert from 'node:assert/strict';
import {PixelEngine} from './pixel-studio/web/fallback.mjs';
import {viewportMetrics,pixelAtClient,brushFootprint} from './pixel-studio/web/viewport.mjs';

for(const zoom of [.125,.5,1,2,3.5,6,9.25,12,24,64]){
 const g=viewportMetrics(zoom,3);
 assert.equal(g.checkerTile,zoom*4);
 assert.equal(g.pixel,zoom);
 assert.equal(g.gridVisible,zoom>=5);
 const rect={left:142.3,top:48.2,width:32*zoom,height:32*zoom};
 for(const [x,y] of [[0,0],[12,19],[31,31]]){
  const pt=pixelAtClient(rect.left+(x+.5)*zoom,rect.top+(y+.5)*zoom,rect,32,32);
  assert.equal(pt.x,x);assert.equal(pt.y,y);assert(pt.inside);
 }
 assert.equal(pixelAtClient(rect.left-1,rect.top,rect,32,32).inside,false);
}
assert.deepEqual(brushFootprint(10,12,4),{x:9,y:11,width:4,height:4});
assert.deepEqual(brushFootprint(10,12,3),{x:9,y:11,width:3,height:3});
const e=new PixelEngine(4,4);
const red=0xff0000ff,blue=0xffff0000;
e.transaction(()=>e.pixel(0,0,red));
e.renameLayer(0,'Base');e.addLayer();e.renameLayer(1,'Encima');e.transaction(()=>e.pixel(1,1,blue));
e.addFrame();e.transaction(()=>e.pixel(2,2,red));
assert.equal(e.frameCount,2);assert.equal(e.layerCount,2);
assert.equal(e.getCelPixels(0,0)[0],255);
const topFrame1=e.getCelPixels(1,1).slice();
const priorName=e.layers[1].name;
e.duplicateLayer(1);assert.equal(e.layerCount,3);assert.equal(e.activeLayer,2);
assert.equal(e.getCelPixels(1,2)[(2*4+2)*4],255);
assert.equal(e.getCelPixels(0,2)[(1*4+1)*4+2],255);
assert.equal(e.layers[2].name,priorName+' copia');
e.moveLayer(2,0);assert.equal(e.activeLayer,0);assert.equal(e.layers[0].name,'Encima copia');
assert.deepEqual(e.getCelPixels(1,0),topFrame1);
e.setLayerOpacity(0,127);assert.equal(e.layers[0].opacity,127);
e.setLayerBlend(0,1);assert.equal(e.layers[0].blend,1);
assert.equal(e.undo(),true);assert.equal(e.layers[0].blend,0);
assert.equal(e.redo(),true);assert.equal(e.layers[0].blend,1);
e.deleteLayer(0);assert.equal(e.layerCount,2);assert.equal(e.layers[0].name,'Base');
assert.equal(e.getCelPixels(0,0)[0],255);
const locks=new PixelEngine(2,2);
locks.transaction(()=>{locks.layers[0].locked=true;});
locks.addLayer();locks.moveLayer(0,1);
assert.equal(locks.layers[1].locked,true);
assert.equal(locks.undo(),true);
assert.equal(locks.layers[0].locked,true);
assert.equal(locks.redo(),true);
assert.equal(locks.layers[1].locked,true);
console.log('Pixel viewport + layer state tests passed');
