# Entrega VSPack Foundry v2.1

## Incluido en este ZIP
- Web VSPack (Biblioteca, Gestores, Editor, Compositor, Publicador) con Pixel Studio integrado y tema grafito/dorado.
- Puente de Blockbench para `.bbmodel` y modelos JSON Minecraft, guardado directo a pack, análisis, atlas.
- Instalador local del editor Blockbench oficial 5.2.2 usando el archivo `blockbench-master.zip` que facilitó el usuario.
- API de integración `?embed=1` para la web VSMedia; rutas y bases de datos conservadas.
- Código y pruebas del componente VS Model Studio y Pixel Studio.

## No incluido / pendiente
- **No viene `dist/bundle.js` de Blockbench ya compilado.** Se necesita ejecutar `./instalar-blockbench.sh /ruta/al/blockbench-master.zip` en CachyOS con Node 22+, npm y conexión a Internet para las dependencias.
- No se ejecutó la compilación de Blockbench aquí por no tener acceso al registro npm; por tanto no debe considerarse validada la interfaz Blockbench completa en navegador.
- La compatibilidad de modelos Minecraft con referencias externas a otras texturas requiere pruebas de proyecto.
- No incluye VSAudio, VSRadio, VSMix, plugins ni modificaciones a GitHub.

## Pruebas verificadas
- 52 pruebas Node de Model Studio superadas.
- Suite local de Pixel Studio superada.
- Tests de compositor y comunicación host superados.
- Sintaxis de JavaScript y shell correctas.
- Chromium no permitió navegación a localhost desde el entorno de pruebas: verificación visual final en CachyOS pendiente.
