# VSPack Foundry v2.1 — Blockbench original integrado

Se usa la **aplicación web original Blockbench 5.2.2**, ejecutada *dentro* del área central de **Gestores → Modelos**, en un iframe local del **mismo origen**, con puente de mensajes validado por sesión y origen. No es un enlace a otra web. Se conserva el editor local si el motor web no está instalado o falla su compilación.

## Instalación en CachyOS

El ZIP de Blockbench **que proporcionaste** es el código fuente completo pero **no contiene `dist/bundle.js`**. Por ello se necesita compilar su versión web una sola vez. El proyecto entregado ya incluye el instalador y el puente; para finalizar la instalación local ejecutá:

```bash
cd VSPack-Foundry-Web-v2.1
./instalar-blockbench.sh /ruta/al/blockbench-master.zip
./start.sh
```

Abrí `http://127.0.0.1:3060`, entrá en **Gestores → Modelos**, importá un pack o creá un modelo y abrilo. El instalador usa Node.js >=22, npm y Python 3. **La primera compilación necesita conexión a Internet para descargar dependencias npm.** Se usa `npm ci` con `package-lock.json`, nunca una copia remota de Blockbench.

El instalador comprueba rutas del ZIP, licencia y versión antes de extraer; compila en una carpeta provisional y únicamente reemplaza la versión instalada si `dist/bundle.js` se generó correctamente. Los cambios de dependencias solo afectan la carpeta de Blockbench dentro de VSPack.

## Qué integra

- Interfaz original de Blockbench con cubos, mallas, UV, animaciones, texturas y formatos admitidos por la aplicación original.
- `.bbmodel` y JSON de modelos Java en el flujo principal (algunos modelos Java con referencias externas pueden requerir texturas externas que el iframe no conoce).
- Apertura desde la biblioteca local IndexedDB de VSPack, sin volver a importar el mismo archivo.
- Botón **Guardar en pack**: exporta el modelo abierto desde Blockbench y actualiza la entrada del pack existente.
- **Volver al editor local** sincroniza primero el contenido actual de Blockbench para evitar perder trabajo.
- **Descargar modelo**, analizar geometría y atlas desde VSPack.
- Modo embebible para VSMedia heredado de VSPack 2.0.

Las acciones nativas de Blockbench de **guardar a archivo** guardan/exportan fuera de VSPack. Para persistir en su biblioteca local, usá el botón superior de VSPack **Guardar en pack**.

## Seguridad, derechos y limitaciones verificadas

- Blockbench 5.2.2 usa licencia **GPL-3.0-or-later**. Conservá `LICENSE.MD`, el código fuente y sus avisos al redistribuir la versión compilada o modificada. Este instalador parte del ZIP fuente proporcionado y deja las fuentes intactas junto a la compilación.
- VS Pixel Studio y el resto de VSPack no fueron sustituidos. No incluye un gestor de audio.
- Este paquete **no contiene el bundle compilado de Blockbench**. En el entorno donde se preparó no había acceso al registro npm. Por ello el flujo completo no está validado hasta que el instalador compile en CachyOS. Sí puede comprobarse la sintaxis del puente y sus pruebas locales.
- No se modifica GitHub, VSRender ni VSEngine.

## Estructura tras instalar

```text
model-studio/
├── component/                         # adaptador de Web Component y puente
├── scripts/make-embed.mjs             # genera entrada sin modificar el HTML original
└── vendor/blockbench/
    ├── index.html                     # Blockbench original
    ├── vs-embed.html                  # entrada embebible de VSPack
    ├── dist/bundle.js                 # compilación web realizada por el instalador
    ├── css/, assets/, lang/, font/…   # recursos originales en el equipo local
    ├── package.json, package-lock.json
    ├── js/                            # código fuente GPL conservado
    └── LICENSE.MD                     # licencia original
```
