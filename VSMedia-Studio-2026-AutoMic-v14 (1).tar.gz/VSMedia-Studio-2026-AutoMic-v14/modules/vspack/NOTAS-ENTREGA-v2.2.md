# VSPack Foundry 2.2 — Estabilidad e intercambio de texturas

## Cambios comprobables

- `VSModelStudio.dirty` se obtiene de un evento explícito del puente de Blockbench, no de leer las variables del iframe (fiabilidad con aislamiento de contexto).
- El puente notifica cambios de `Project.saved` y estado de proyecto cada 800 ms solo mientras el editor está activo, y al completar comandos.
- El editor geométrico y Blockbench ahora incluyen un inspector compartido de **Texturas del modelo**. Puede previsualizar PNG incrustados en `.bbmodel`, o extraer texturas de Blockbench instalado, y guardarlos directamente en la biblioteca del mismo pack.
- Antes de sobrescribir rutas existentes, se pide confirmación; las rutas de salida se validan como `assets/<namespace>/textures/.../*.png` y no se permiten rutas absolutas ni recorridos `..`.
- Evita salir de Model Studio durante una operación de guardado y transfiere el estado local al cambiar de modo.
- El código del editor de textura VS Pixel Studio, compositor, ZIP y biblioteca de la v2.1 se conserva.

## Probá la integración

1. `./start.sh` y abrí `http://127.0.0.1:3060`.
2. Creá/importá un pack, abrí un `.bbmodel` desde **Gestores → Modelos**.
3. Tocá **Texturas del modelo** y seleccioná una textura PNG incrustada.
4. Revisá la vista previa y tocá **Guardar PNG en pack** para copiarla al espacio del pack.
5. Volvé a **Gestores → Texturas** y abrí ese PNG en VS Pixel Studio, sin importar otra vez el archivo.
6. Si instalaste Blockbench, modificá geometría o UV y probá guardar con el botón superior **Guardar en pack**. Cambiá de vista sin guardar y verificá el aviso.

## Instalación opcional de la interfaz original de Blockbench

El paquete **NO contiene el bundle de Blockbench**, porque necesita instalar sus dependencias npm con acceso a Internet. Se conserva el instalador de v2.1 y su puente original; ejecutá:

```bash
./instalar-blockbench.sh /ruta/al/blockbench-master.zip
./start.sh
```

El instalador trabaja dentro de `model-studio/vendor/blockbench/` y no modifica GitHub ni plugins.

## Alcance de validación

Los tests de sintaxis, motor de modelos, texturas y rutas se pueden correr con `node --test model-studio/tests/*.test.mjs tests/*.test.mjs` y el compositor con `node test-compositor.mjs`. La interfaz **original Blockbench** necesita compilación y prueba manual real en CachyOS. Los recursos se guardan localmente mediante IndexedDB del navegador; se recomienda exportar ZIP antes de cambios importantes de versión.
