# VSPack Foundry v2.0 — Validación de entrega

## Controles ejecutados

- `node --check assets/app.js` — **OK**
- `node --check assets/zip.js` — **OK**
- `node --check assets/preview-engine.js` — **OK**
- `node --check assets/model-bridge.mjs` — **OK**
- `node tests/test-host-integration.mjs` — **OK**
- `node test-viewport.mjs` — **OK**
- `node test-compositor.mjs` — **OK** (2.800 entradas)
- `cd pixel-studio && npm test` — **OK** (suites del editor suministrado)
- `cd model-studio && npm test` — **OK, 52/52 tests** (incluyendo UV/atlas)

## No verificado en este entorno

- La apertura visual end-to-end en Chromium: el entorno de ejecución rechaza la navegación local con `ERR_BLOCKED_BY_ADMINISTRATOR`, incluso con rutas de red interceptadas.
- La persistencia de IndexedDB tras cerrar el navegador en la PC de destino.
- La instalación web completa de Blockbench (no está incluida en el ZIP original suministrado).
- La compilación Rust/WASM; solo se conservan las fuentes experimentales.

## Recomendación para aceptación en VSMedia

1. Iniciar `./start.sh` (puerto 3060 local).
2. Importar un ZIP real; comprobar Biblioteca y selección de packs.
3. Editar y guardar un PNG en VS Pixel Studio; exportar el ZIP.
4. Abrir y guardar `.bbmodel` en VS Model Studio; verificar el ZIP.
5. Abrir `/index.html?embed=1&view=managers&manager=textures` y revisar que no aparezcan el logo ni la barra global duplicados.
6. Montar el iframe bajo el mismo origen de VSMedia y probar `GET_STATE`, `NAVIGATE`, `OPEN_ASSET` y `RESPONSE`.

No se modificó GitHub, VSMedia, VSRender ni VSEngine. No hay servidor remoto, backend, publicación de plugins ni importación automática al servidor Minecraft.
