/** Pure RGBA transformations, safe to use in browser and Node. No hidden dependencies. */
function check(data,w,h){if(!Number.isInteger(w)||!Number.isInteger(h)||w<1||h<1||data.length!==w*h*4)throw Error('Dimensiones RGBA inválidas');}
const mod=(v,m)=>(v%m+m)%m;
export function offsetTile(data,w,h,dx,dy){
 check(data,w,h);dx=Math.trunc(dx);dy=Math.trunc(dy);
 if(!Number.isFinite(dx)||!Number.isFinite(dy))throw Error('Desplazamiento inválido');
 const out=new Uint8ClampedArray(data.length);
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){
  const from=(y*w+x)*4,to=(mod(y+dy,h)*w+mod(x+dx,w))*4;
  out.set(data.subarray(from,from+4),to);
 }
 return out;
}
export function alphaThreshold(data,w,h,threshold=128){
 check(data,w,h);const out=new Uint8ClampedArray(data),limit=Math.min(255,Math.max(0,Math.round(threshold)));
 for(let i=3;i<out.length;i+=4)out[i]=out[i]>=limit?255:0;
 return out;
}
export function clearTransparentRGB(data,w,h){
 check(data,w,h);const out=new Uint8ClampedArray(data);
 for(let i=0;i<out.length;i+=4)if(!out[i+3])out.fill(0,i,i+3);
 return out;
}
export function eraseIsolated(data,w,h,diagonals=false){
 check(data,w,h);const out=new Uint8ClampedArray(data);
 const neighbors=diagonals?[[-1,0],[1,0],[0,-1],[0,1],[-1,-1],[-1,1],[1,-1],[1,1]]:[[-1,0],[1,0],[0,-1],[0,1]];
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){
  const n=(y*w+x)*4;if(!data[n+3])continue;
  if(!neighbors.some(([dx,dy])=>x+dx>=0&&x+dx<w&&y+dy>=0&&y+dy<h&&data[((y+dy)*w+x+dx)*4+3]>0))out.fill(0,n,n+4);
 }
 return out;
}
export function innerOutline(data,w,h,hex='#000000'){
 check(data,w,h);if(!/^#[a-f\d]{6}$/i.test(hex))throw Error('Color de contorno inválido');
 const out=new Uint8ClampedArray(data),rgb=[1,3,5].map(n=>parseInt(hex.slice(n,n+2),16));
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){
  const n=(y*w+x)*4;if(!data[n+3])continue;
  if(x===0||y===0||x===w-1||y===h-1||[[-1,0],[1,0],[0,-1],[0,1]].some(([dx,dy])=>data[((y+dy)*w+x+dx)*4+3]===0)){out.set(rgb,n);}
 }
 return out;
}
export function spriteStatistics(data,w,h){
 check(data,w,h);let visible=0,transparent=0,partial=0,colors=new Set(),minX=w,minY=h,maxX=-1,maxY=-1;
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){
  const n=(y*w+x)*4,a=data[n+3];if(!a){transparent++;continue;}visible++;if(a!==255)partial++;
  if(colors.size<=4096)colors.add(`${data[n]},${data[n+1]},${data[n+2]},${a}`);
  minX=Math.min(minX,x);minY=Math.min(minY,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y);
 }
 return {width:w,height:h,visible,transparent,partial,colors:Math.min(colors.size,4096),colorsOverLimit:colors.size>4096,bounds:visible?[minX,minY,maxX,maxY]:null};
}
