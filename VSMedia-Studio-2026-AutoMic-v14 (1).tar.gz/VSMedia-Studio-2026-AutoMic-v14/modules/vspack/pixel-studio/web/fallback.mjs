// Independent reference engine. Used when the Rust/WASM build is not yet installed.
const copy = a => new Uint8ClampedArray(a);
export class PixelEngine {
  constructor(width = 32, height = 32) {
    this.width = width; this.height = height; this.kind = 'js';
    this.layers = [{name:'Capa 1', visible:true,opacity:255,blend:0,kind:0}];
    this.frames = [{duration:120,cels:[new Uint8ClampedArray(width*height*4)],links:[null]}];
    this.activeLayer = 0; this.activeFrame = 0;
    this.history=[]; this.future=[]; this.pending=null;
  }
  get layerCount(){return this.layers.length;}
  get frameCount(){return this.frames.length;}
  get duration(){return this.frames[this.activeFrame].duration;}
  set duration(value){this.frames[this.activeFrame].duration=Math.max(20,Math.min(2000,Math.round(value)));}
  snapshot(){return {layers:this.layers.map(l=>({...l})), frames:this.frames.map(f=>({duration:f.duration,cels:f.cels.map(copy),links:[...(f.links||f.cels.map(()=>null))]})),activeLayer:this.activeLayer,activeFrame:this.activeFrame};}
  restore(s){this.layers=s.layers;this.frames=s.frames;this.activeLayer=s.activeLayer;this.activeFrame=s.activeFrame;}
  begin(){if(!this.pending)this.pending=this.snapshot();}
  end(){if(this.pending){
    // Keep undo history within a hard memory budget: many 512×512 cels can
    // otherwise consume gigabytes in a long texture-editing session.
    const cost=s=>s.frames.reduce((sum,f)=>sum+f.cels.reduce((n,p)=>n+p.byteLength,0),0);
    const budget=96*1024*1024;
    const snapshot=this.pending;
    if(cost(snapshot)<=budget){
      this.history.push(snapshot);
      let total=0;for(const entry of this.history)total+=cost(entry);
      while(this.history.length>50||total>budget){total-=cost(this.history.shift());}
    }
    this.future=[];this.pending=null;
  }}
  transaction(fn){this.begin();fn();this.end();}
  undo(){if(this.pending)this.end();const s=this.history.pop();if(!s)return false;this.future.push(this.snapshot());this.restore(s);return true;}
  redo(){const s=this.future.pop();if(!s)return false;this.history.push(this.snapshot());this.restore(s);return true;}
  selectLayer(i){if(i>=0&&i<this.layerCount)this.activeLayer=i;}
  selectFrame(i){if(i>=0&&i<this.frameCount)this.activeFrame=i;}
  addLayer(){if(this.layerCount>=128)throw Error('Límite de 128 capas');this.transaction(()=>{const n=this.layerCount;this.layers.push({name:`Capa ${n+1}`,visible:true,opacity:255,blend:0,kind:0});for(const f of this.frames){f.cels.push(new Uint8ClampedArray(this.width*this.height*4));f.links.push(null);}this.activeLayer=n;});}
  addFrame(){if(this.frameCount>=512)throw Error('Límite de 512 fotogramas');this.transaction(()=>{
    const previous=this.activeFrame,old=this.frames[previous];
    for(let f=previous+1;f<this.frameCount;f++)for(let l=0;l<this.layerCount;l++){
      const target=this.frames[f].links[l];if(target!==null&&target>previous)this.frames[f].links[l]++;
    }
    this.frames.splice(previous+1,0,{duration:old.duration,cels:old.cels.map((_,i)=>this.getCelPixels(previous,i)),links:old.cels.map(()=>null)});
    this.activeFrame++;
  });}
  renameLayer(i,name){
    if(i<0||i>=this.layerCount)throw new RangeError('Capa inválida');
    const value=String(name).trim().slice(0,96);
    if(!value)throw new Error('El nombre no puede estar vacío');
    this.transaction(()=>{this.layers[i].name=value;});
  }
  setLayerOpacity(i,opacity){
    if(i<0||i>=this.layerCount||!Number.isFinite(opacity))throw new RangeError('Opacidad inválida');
    this.transaction(()=>{this.layers[i].opacity=Math.round(Math.max(0,Math.min(255,opacity)));});
  }
  setLayerBlend(i,blend){
    if(i<0||i>=this.layerCount||![0,1,2,3,4,5,10,11,16,17,18].includes(blend))throw new RangeError('Modo de fusión inválido');
    this.transaction(()=>{this.layers[i].blend=blend;});
  }
  /** Reorder full multi-frame layer data atomically: cel links point to frames, not layer indexes. */
  moveLayer(from,to){
    if(!Number.isInteger(from)||!Number.isInteger(to)||from<0||to<0||from>=this.layerCount||to>=this.layerCount)throw new RangeError('Capa inválida');
    if(from===to)return;
    this.transaction(()=>{
      this.layers.splice(to,0,this.layers.splice(from,1)[0]);
      for(const frame of this.frames){
        frame.cels.splice(to,0,frame.cels.splice(from,1)[0]);
        frame.links.splice(to,0,frame.links.splice(from,1)[0]);
      }
      const active=this.activeLayer;
      this.activeLayer=active===from?to:(from<active&&active<=to?active-1:(to<=active&&active<from?active+1:active));
    });
  }
  duplicateLayer(i=this.activeLayer){
    if(!Number.isInteger(i)||i<0||i>=this.layerCount)throw new RangeError('Capa inválida');
    if(this.layerCount>=128)throw new Error('Límite de 128 capas');
    this.transaction(()=>{
      const originals=this.frames.map((_,f)=>this.getCelPixels(f,i));
      this.layers.splice(i+1,0,{...this.layers[i],name:this.layers[i].name+' copia'});
      for(let f=0;f<this.frameCount;f++){
        this.frames[f].cels.splice(i+1,0,originals[f]);
        this.frames[f].links.splice(i+1,0,null);
      }
      this.activeLayer=i+1;
    });
  }
  toggleLayer(i){if(i<0||i>=this.layerCount)return;this.transaction(()=>{this.layers[i].visible=!this.layers[i].visible;});}
  deleteLayer(i){if(this.layerCount<=1)return;this.transaction(()=>{this.layers.splice(i,1);for(const f of this.frames){f.cels.splice(i,1);f.links.splice(i,1);}this.activeLayer=Math.min(this.activeLayer,this.layerCount-1);});}
  deleteFrame(i){if(this.frameCount<=1||i<0||i>=this.frameCount)return;this.transaction(()=>{
    // Avoid dangling linked-cel pointers; detach only links targeting the removed frame.
    for(let f=i+1;f<this.frameCount;f++)for(let l=0;l<this.layerCount;l++){
      const target=this.frames[f].links[l];
      if(target===i){this.frames[f].cels[l]=this.getCelPixels(f,l);this.frames[f].links[l]=null;}
      else if(target!==null&&target>i)this.frames[f].links[l]--;
    }
    this.frames.splice(i,1);this.activeFrame=Math.min(this.activeFrame,this.frameCount-1);
  });}
  getCelLink(frame=this.activeFrame,layer=this.activeLayer){
    this.validateCel(frame,layer);
    return this.frames[frame].links?.[layer]??null;
  }
  validateCel(frame,layer){if(!Number.isInteger(frame)||frame<0||frame>=this.frameCount||!Number.isInteger(layer)||layer<0||layer>=this.layerCount)throw new RangeError('Cel inexistente');}
  resolveCel(frame=this.activeFrame,layer=this.activeLayer){
    this.validateCel(frame,layer);
    // Every link must target an earlier frame, so cycles and forward pointers are rejected.
    for(let steps=0;steps<this.frameCount;steps++){
      const target=this.frames[frame].links?.[layer];
      if(target===null||target===undefined)return this.frames[frame].cels[layer];
      if(!Number.isInteger(target)||target<0||target>=frame)throw new Error('Vínculo de cel inválido');
      frame=target;
    }
    throw new Error('Ciclo de cels enlazados');
  }
  getCelPixels(frame=this.activeFrame,layer=this.activeLayer){return copy(this.resolveCel(frame,layer));}
  get cel(){return this.resolveCel();}
  linkCel(frame,layer,sourceFrame){
    this.validateCel(frame,layer);
    if(!Number.isInteger(sourceFrame)||sourceFrame<0||sourceFrame>=frame)throw new RangeError('El origen debe ser un fotograma anterior');
    this.transaction(()=>{this.frames[frame].links[layer]=sourceFrame;});
  }
  unlinkCel(frame=this.activeFrame,layer=this.activeLayer){
    this.validateCel(frame,layer);
    if(this.getCelLink(frame,layer)===null)return;
    this.transaction(()=>{this.frames[frame].cels[layer]=this.getCelPixels(frame,layer);this.frames[frame].links[layer]=null;});
  }
  addLinkedFrame(){
    if(this.frameCount>=512)throw Error('Límite de 512 fotogramas');
    this.transaction(()=>{
      const previous=this.activeFrame;
      // Inserting in the middle shifts all existing link targets after that position.
      for(let f=previous+1;f<this.frameCount;f++)for(let l=0;l<this.layerCount;l++){
        const target=this.frames[f].links[l];if(target!==null&&target>previous)this.frames[f].links[l]++;
      }
      const old=this.frames[previous];
      this.frames.splice(previous+1,0,{duration:old.duration,cels:old.cels.map(()=>new Uint8ClampedArray(this.width*this.height*4)),links:old.cels.map(()=>previous)});
      this.activeFrame=previous+1;
    });
  }
  pixel(x,y,rgba){x|=0;y|=0;if(x<0||y<0||x>=this.width||y>=this.height)return;const n=(y*this.width+x)*4;const p=this.cel;p[n]=rgba&255;p[n+1]=(rgba>>>8)&255;p[n+2]=(rgba>>>16)&255;p[n+3]=(rgba>>>24)&255;}
  line(x0,y0,x1,y1,rgba){x0|=0;y0|=0;x1|=0;y1|=0;const dx=Math.abs(x1-x0), sx=x0<x1?1:-1,dy=-Math.abs(y1-y0),sy=y0<y1?1:-1;let err=dx+dy;while(true){this.pixel(x0,y0,rgba);if(x0===x1&&y0===y1)break;const e2=err*2;if(e2>=dy){err+=dy;x0+=sx;}if(e2<=dx){err+=dx;y0+=sy;}}}
  rect(x0,y0,x1,y1,rgba){const a=Math.min(x0,x1),b=Math.max(x0,x1),c=Math.min(y0,y1),d=Math.max(y0,y1);this.line(a,c,b,c,rgba);this.line(a,d,b,d,rgba);this.line(a,c,a,d,rgba);this.line(b,c,b,d,rgba);}
  fill(x,y,rgba){
    x|=0;y|=0;
    const w=this.width,h=this.height;
    if(x<0||y<0||x>=w||y>=h)return;
    const p=this.cel,start=y*w+x,off=start*4;
    const r=p[off],g=p[off+1],b=p[off+2],a=p[off+3];
    const rr=rgba&255,gg=(rgba>>>8)&255,bb=(rgba>>>16)&255,aa=rgba>>>24;
    if(r===rr&&g===gg&&b===bb&&a===aa)return;
    const seen=new Uint8Array(w*h),queue=new Int32Array(w*h);
    let head=0,tail=1;queue[0]=start;seen[start]=1;
    while(head<tail){
      const index=queue[head++],i=index*4;
      if(p[i]!==r||p[i+1]!==g||p[i+2]!==b||p[i+3]!==a)continue;
      p[i]=rr;p[i+1]=gg;p[i+2]=bb;p[i+3]=aa;
      const xx=index%w,yy=(index/w)|0;
      // Mark when enqueued, ensuring at most four tests per pixel and no duplicate queue entries.
      const enqueue=n=>{if(!seen[n]){seen[n]=1;queue[tail++]=n;}};
      if(xx>0)enqueue(index-1);if(xx+1<w)enqueue(index+1);
      if(yy>0)enqueue(index-w);if(yy+1<h)enqueue(index+w);
    }
  }
  setCelPixels(data){if(data.length!==this.width*this.height*4)throw new Error('Tamaño RGBA inválido');this.transaction(()=>this.cel.set(data));}
  render(frame=this.activeFrame,destination=null){
    const n=this.width*this.height*4;
    const out=destination?.length===n?destination:new Uint8ClampedArray(n);
    if(destination)out.fill(0);
    for(let l=0;l<this.layerCount;l++){
      const layer=this.layers[l];if(!layer.visible)continue;
      const src=this.resolveCel(frame,l),layerAlpha=(layer.opacity??255)/255,blend=layer.blend??0;
      for(let i=0;i<out.length;i+=4){
        const sa=src[i+3]/255*layerAlpha;if(sa===0)continue;
        const da=out[i+3]/255,oa=sa+da*(1-sa);if(oa===0)continue;
        for(let c=0;c<3;c++){
          const s=src[i+c]/255,d=out[i+c]/255;
          let b=s;
          switch(blend){
            case 1:b=s*d;break; // Multiply
            case 2:b=s+d-s*d;break; // Screen
            case 3:b=d<=.5?2*s*d:1-2*(1-s)*(1-d);break; // Overlay
            case 4:b=Math.min(s,d);break;
            case 5:b=Math.max(s,d);break;
            case 10:b=Math.abs(d-s);break;
            case 11:b=d+s-2*d*s;break;
            case 16:b=Math.min(1,d+s);break;
            case 17:b=Math.max(0,d-s);break;
            case 18:b=s===0?1:Math.min(1,d/s);break;
            default:b=s;
          }
          const premult=s*sa*(1-da)+d*da*(1-sa)+b*sa*da;
          out[i+c]=Math.round(Math.min(255,Math.max(0,premult/oa*255)));
        }
        out[i+3]=Math.round(oa*255);
      }
    }
    return out;
  }
}
