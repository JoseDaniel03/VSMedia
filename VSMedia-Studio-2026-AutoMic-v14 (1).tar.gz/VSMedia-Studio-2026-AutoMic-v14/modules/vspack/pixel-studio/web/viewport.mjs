/** Pure viewport maths. Zoom is CSS pixels per source pixel. */
export const ZOOM_STEPS = Object.freeze([0.0625,0.125,0.25,0.5,0.75,1,1.5,2,3,4,6,8,12,16,24,32,48,64]);
export const clampZoom = value => Math.min(64,Math.max(0.0625,Number.isFinite(value)?value:1));
export function stepZoom(current,direction){
  const x=clampZoom(current),eps=1e-7;
  if(direction>0)return ZOOM_STEPS.find(v=>v>x+eps)??ZOOM_STEPS.at(-1);
  return ZOOM_STEPS.findLast(v=>v<x-eps)??ZOOM_STEPS[0];
}
export function fitZoom(viewWidth,viewHeight,docWidth,docHeight,padding=48){
  if(![viewWidth,viewHeight,docWidth,docHeight].every(v=>Number.isFinite(v)&&v>0))return 1;
  return clampZoom(Math.min((viewWidth-padding)/docWidth,(viewHeight-padding)/docHeight));
}
export function zoomText(value){const percent=value*100;return (percent>=10?Math.round(percent):Number(percent.toFixed(2)))+'%';}
export function sourcePoint(pointer,canvasRect,zoom,docWidth,docHeight){
  return {x:Math.max(0,Math.min(docWidth,(pointer.x-canvasRect.left)/zoom)),y:Math.max(0,Math.min(docHeight,(pointer.y-canvasRect.top)/zoom))};
}
export function anchorScrollDelta(pointer,newCanvasRect,point,newZoom){
  return {x:newCanvasRect.left+point.x*newZoom-pointer.x,y:newCanvasRect.top+point.y*newZoom-pointer.y};
}

/** All viewport decorations are defined in the SAME source-pixel space.
 * CSS scaling, scroll and browser zoom may move the canvas on screen; the grid
 * and the brush are always positioned relative to the canvas origin. */
export function viewportMetrics(zoom,brush=1){
  const z=clampZoom(zoom),b=Math.max(1,Math.min(16,Math.round(brush)||1));
  return {pixel:z,checkerCell:2*z,checkerTile:4*z,gridVisible:z>=5,brushSize:b};
}
export function pixelAtClient(clientX,clientY,rect,w,h){
  const px=(clientX-rect.left)/rect.width*w,py=(clientY-rect.top)/rect.height*h;
  return {x:Math.floor(px),y:Math.floor(py),inside:rect.width>0&&rect.height>0&&px>=0&&py>=0&&px<w&&py<h};
}
export function brushFootprint(x,y,brush=1){
  const b=Math.max(1,Math.min(16,Math.round(brush)||1));
  const off=Math.floor((b-1)/2);
  return {x:x-off,y:y-off,width:b,height:b};
}
