// Independent pixel operations for VS Pixel Studio, shared by UI and Node tests.
// All transformations preserve RGBA channels and never interpolate colors.
const clamp = (n, min=0, max=255) => Math.min(max,Math.max(min,Math.round(n)));
const clone = pixels => new Uint8ClampedArray(pixels);
export function imageTransform(pixels,w,h,operation) {
  if(pixels.length!==w*h*4)throw new Error('Tamaño de imagen incorrecto');
  const rotate = operation==='rotate-cw'||operation==='rotate-ccw';
  const outW=rotate?h:w,outH=rotate?w:h,out=new Uint8ClampedArray(outW*outH*4);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){
    let xx=x,yy=y;
    if(operation==='flip-h')xx=w-1-x;
    else if(operation==='flip-v')yy=h-1-y;
    else if(operation==='rotate-cw'){xx=h-1-y;yy=x;}
    else if(operation==='rotate-ccw'){xx=y;yy=w-1-x;}
    else if(operation==='rotate-180'){xx=w-1-x;yy=h-1-y;}
    else if(operation!=='identity')throw new Error('Transformación desconocida: '+operation);
    out.set(pixels.subarray((y*w+x)*4,(y*w+x+1)*4),(yy*outW+xx)*4);
  }
  return {pixels:out,width:outW,height:outH};
}
export function resizeImage(pixels,w,h,newW,newH,{scale=false,anchor='center'}={}){
  if(newW<1||newH<1||!Number.isInteger(newW)||!Number.isInteger(newH))throw new Error('Dimensión inválida');
  const result=new Uint8ClampedArray(newW*newH*4);
  let xOff=0,yOff=0;
  if(!scale){xOff=anchor==='top-left'?0:Math.floor((newW-w)/2);yOff=anchor==='top-left'?0:Math.floor((newH-h)/2);}
  for(let y=0;y<newH;y++)for(let x=0;x<newW;x++){
    const sx=scale?Math.min(w-1,Math.floor(x*w/newW)):x-xOff;
    const sy=scale?Math.min(h-1,Math.floor(y*h/newH)):y-yOff;
    if(sx<0||sy<0||sx>=w||sy>=h)continue;
    result.set(pixels.subarray((sy*w+sx)*4,(sy*w+sx+1)*4),(y*newW+x)*4);
  }
  return result;
}
export function cropImage(pixels,w,h,x0,y0,x1,y1){
  const left=Math.max(0,Math.min(w-1,Math.min(x0,x1))),top=Math.max(0,Math.min(h-1,Math.min(y0,y1)));
  const right=Math.max(left,Math.min(w-1,Math.max(x0,x1))),bottom=Math.max(top,Math.min(h-1,Math.max(y0,y1)));
  const nw=right-left+1,nh=bottom-top+1,result=new Uint8ClampedArray(nw*nh*4);
  for(let y=0;y<nh;y++)result.set(pixels.subarray(((top+y)*w+left)*4,((top+y)*w+left+nw)*4),y*nw*4);
  return {pixels:result,width:nw,height:nh};
}
export function filterImage(data,w,h,kind,options={}) {
  if(data.length!==w*h*4)throw new Error('RGBA inválido');
  const out=clone(data),delta=Number(options.amount??30),opacityPreserved=true;
  const region=options.region??[0,0,w-1,h-1];
  const [left,top,right,bottom]=region;
  const matches=(x,y)=>x>=left&&x<=right&&y>=top&&y<=bottom;
  if(kind==='outline'){
    const r=Array.isArray(options.color)?options.color:[0,0,0,255];
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){
      const i=(y*w+x)*4;if(data[i+3]!==0||!matches(x,y))continue;
      if([[x-1,y],[x+1,y],[x,y-1],[x,y+1]].some(([a,b])=>a>=0&&b>=0&&a<w&&b<h&&data[(b*w+a)*4+3]!==0))out.set(r,i);
    }
    return out;
  }
  if(kind==='blur'){
    const radius=Math.min(3,Math.max(1,Math.round(delta)));
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){
      if(!matches(x,y))continue;
      const sums=[0,0,0,0];let n=0;
      for(let dy=-radius;dy<=radius;dy++)for(let dx=-radius;dx<=radius;dx++){
        const xx=x+dx,yy=y+dy;if(xx<0||xx>=w||yy<0||yy>=h)continue;
        const i=(yy*w+xx)*4;for(let c=0;c<4;c++)sums[c]+=data[i+c];n++;
      }
      const p=(y*w+x)*4;for(let c=0;c<4;c++)out[p+c]=clamp(sums[c]/n);
    }
    return out;
  }
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){
    if(!matches(x,y))continue;
    const i=(y*w+x)*4;
    if(!data[i+3])continue;
    let r=data[i],g=data[i+1],b=data[i+2];
    if(kind==='grayscale'){const l=Math.round(0.2126*r+0.7152*g+0.0722*b);r=g=b=l;}
    else if(kind==='invert'){r=255-r;g=255-g;b=255-b;}
    else if(kind==='brightness'){r=clamp(r+delta);g=clamp(g+delta);b=clamp(b+delta);}
    else if(kind==='contrast'){const t=(259*(delta+255))/(255*(259-delta));r=clamp(t*(r-128)+128);g=clamp(t*(g-128)+128);b=clamp(t*(b-128)+128);}
    else if(kind==='threshold'){const lum=.2126*r+.7152*g+.0722*b;r=g=b=lum>=delta?255:0;}
    else if(kind==='hue'){
      const angle=delta*Math.PI/180,c=Math.cos(angle),s=Math.sin(angle);
      const nr=(.213+c*.787-s*.213)*r+(.715-c*.715-s*.715)*g+(.072-c*.072+s*.928)*b;
      const ng=(.213-c*.213+s*.143)*r+(.715+c*.285+s*.14)*g+(.072-c*.072-s*.283)*b;
      const nb=(.213-c*.213-s*.787)*r+(.715-c*.715+s*.715)*g+(.072+c*.928+s*.072)*b;
      r=clamp(nr);g=clamp(ng);b=clamp(nb);
    }else throw new Error('Filtro desconocido: '+kind);
    out[i]=r;out[i+1]=g;out[i+2]=b;
  }
  return out;
}
export function transformedProject(doc,operation){
  const {width,height}=doc;
  const dimensions=imageTransform(new Uint8ClampedArray(width*height*4),width,height,operation);
  return {...doc,width:dimensions.width,height:dimensions.height,frames:doc.frames.map(f=>({...f,cels:f.cels.map(c=>imageTransform(c,width,height,operation).pixels)}))};
}
export function resizedProject(doc,newW,newH,options={}){
  return {...doc,width:newW,height:newH,frames:doc.frames.map(f=>({...f,cels:f.cels.map(c=>resizeImage(c,doc.width,doc.height,newW,newH,options))}))};
}
export function croppedProject(doc,x0,y0,x1,y1){
  const bounds=cropImage(new Uint8ClampedArray(doc.width*doc.height*4),doc.width,doc.height,x0,y0,x1,y1);
  return {...doc,width:bounds.width,height:bounds.height,frames:doc.frames.map(f=>({...f,cels:f.cels.map(c=>cropImage(c,doc.width,doc.height,x0,y0,x1,y1).pixels)}))};
}
export function replaceColor(data,from,to,{tolerance=0,region=null,width=0}={}){
  const out=clone(data);let count=0;
  for(let i=0;i<data.length;i+=4){
    const k=i/4,x=width?k%width:0,y=width?Math.floor(k/width):0;
    if(region&&(!width||x<region[0]||x>region[2]||y<region[1]||y>region[3]))continue;
    if(Math.max(...from.map((c,j)=>Math.abs(c-data[i+j])))<=tolerance){out.set(to,i);count++;}
  }
  return {pixels:out,count};
}
