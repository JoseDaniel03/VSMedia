import {createEngine} from './wasm.mjs';
import {offsetTile,alphaThreshold,clearTransparentRGB,eraseIsolated,innerOutline,spriteStatistics} from './pixel-power.mjs';
import {reducePalette,posterizeRGBA,paletteFromPixels,alphaContentBounds} from './color-math.mjs';
import {loadKernels} from './rust-kernels.mjs';
import {skin} from './skin-atlas.mjs';
import {parseAseprite,encodeAsepriteCompressed} from './ase-format.mjs';
import {transformedProject,resizedProject,croppedProject,filterImage,replaceColor} from './edit-ops.mjs';
import {parsePalette,encodeGPL,rgbToHex} from './palette.mjs';
import {AnimationCursor,tagsAfterFrameInsert,tagsAfterFrameDelete} from './animation.mjs';
import {ZOOM_STEPS,clampZoom,stepZoom,fitZoom,zoomText,sourcePoint,anchorScrollDelta,viewportMetrics,pixelAtClient,brushFootprint} from './viewport.mjs';

const PALETTE=['#000000','#222034','#45283c','#663931','#8f563b','#df7126','#d9a066','#eec39a','#fbf236','#99e550','#6abe30','#37946e','#4b692f','#524b24','#323c39','#3f3f74','#306082','#5b6ee1','#639bff','#5fcde4','#cbdbfc','#ffffff','#9badb7','#847e87','#696a6a','#595652','#76428a','#ac3232','#d95763','#d77bba','#8f974a','#e8d9a3'];
const TOOLS=[
 ['marquee','tool_rectangular_marquee','Selección rectangular (M)','M'],
 ['ellipse-marquee','tool_elliptical_marquee','Selección elíptica (Shift+M)',''],
 ['wand','tool_magic_wand','Varita mágica (W)','W'],
 ['pencil','tool_pencil','Lápiz (B)','B'],
 ['eraser','tool_eraser','Borrador (E)','E'],
 ['pick','tool_eyedropper','Cuentagotas (I)','I'],
 ['fill','tool_paint_bucket','Balde (G)','G'],
 ['gradient','tool_gradient','Degradado (D)','D'],
 ['spray','tool_spray','Aerógrafo (S)','S'],
 ['line','tool_line','Línea (L)','L'],
 ['rect','tool_rectangle','Rectángulo (U)','U'],
 ['filledrect','tool_filled_rectangle','Rectángulo relleno (Shift+U)',''],
 ['ellipse','tool_ellipse','Elipse (O)','O'],
 ['filledellipse','tool_filled_ellipse','Elipse rellena (Shift+O)',''],
 ['hand','tool_hand','Desplazar (H)','H'],
 ['zoom','tool_zoom','Zoom (Z)','Z'],
];
const MENUS={
 'Archivo':[['Nuevo…','new','Ctrl+N'],['Abrir imagen o proyecto…','import','Ctrl+O'],['Importar paleta…','loadpalette',''],['Exportar paleta GPL','exportpalette',''],['Guardar PNG','export','Ctrl+S'],['Guardar Aseprite (.aseprite)','exportase',''],['Exportar sprite sheet','sheet',''],['Guardar proyecto VS (.json)','exportjson','']],
 'Editar':[['Deshacer','undo','Ctrl+Z'],['Rehacer','redo','Ctrl+Y'],['Copiar','copy','Ctrl+C'],['Cortar','cut','Ctrl+X'],['Pegar','paste','Ctrl+V'],['Borrar selección','deletepixels','Supr'],['Reemplazar color…','replacecolor','']],
 'Sprite':[['Propiedades…','properties',''],['Cambiar tamaño del sprite…','scale',''],['Cambiar tamaño del lienzo…','resizecanvas',''],['Recortar según selección','crop',''],['Voltear horizontal','flip-h',''],['Voltear vertical','flip-v',''],['Rotar 90° horario','rotate-cw',''],['Rotar 90° antihorario','rotate-ccw',''],['Rotar 180°','rotate-180',''],['Restablecer zoom','resetzoom','']],
 'Capa':[['Nueva capa','addlayer','Shift+Ctrl+N'],['Duplicar capa','duplicatelayer',''],['Subir capa','layerup',''],['Bajar capa','layerdown',''],['Renombrar capa','renamelayer',''],['Ocultar/mostrar capa','togglelayer',''],['Eliminar capa','deletelayer',''],['Opacidad de la capa…','layeropacity',''],['Modo de fusión…','layerblend',''],['Filtros › Escala de grises','grayscale',''],['Filtros › Invertir','invert',''],['Filtros › Brillo…','brightness',''],['Filtros › Contraste…','contrast',''],['Filtros › Matiz…','hue',''],['Filtros › Umbral…','threshold',''],['Filtros › Desenfoque…','blur',''],['Filtros › Contorno','outline','']],
 'Pixel Art':[['Reducir paleta (k-means)…','quantize',''],['Tramado Floyd–Steinberg…','dither',''],['Posterizar colores…','posterize',''],['Extraer paleta del sprite…','extractpalette',''],['Recortar bordes transparentes','trimtransparent',''],['Desplazar textura repetida…','offsettile',''],['Umbral de transparencia…','alphathreshold',''],['Eliminar RGB invisible','cleanalpha',''],['Eliminar píxeles aislados','isolated',''],['Contorno interior…','inneroutline',''],['Vista previa repetible 3×3','tilepreview',''],['Estadísticas del sprite','pixelstats','']],
 'Fotograma':[['Duplicar fotograma','addframe','Alt+N'],['Duplicar fotograma vinculado','addlinkedframe',''],['Vincular cel al fotograma anterior','linkcel',''],['Desvincular cel','unlinkcel',''],['Eliminar fotograma','deleteframe',''],['Reproducir / Pausar','play','Enter'],['Crear etiqueta de animación…','addtag',''],['Elegir etiqueta…','selecttag',''],['Eliminar etiqueta…','deletetag','']],
 'Seleccionar':[['Seleccionar todo','selectall','Ctrl+A'],['Deseleccionar','deselect','Ctrl+D'],['Invertir selección','invertselection','Ctrl+Shift+I']],
 'Ver':[['Acercar','zoomin','+'],['Alejar','zoomout','-'],['Ajustar a ventana','fitzoom','F'],['Tamaño real 100%','actualzoom','0'],['Centrar lienzo','centerzoom',''],['Mostrar minimapa','navigator','N'],['Rueda: Zoom/Desplazar','wheelmode',''],['Mostrar rejilla','grid','#'],['Piel de cebolla','onion',''],['Simetría X','symx',''],['Simetría Y','symy','']],
 'Ayuda':[['Acerca de VS Pixel Studio','about',''],['Teclas rápidas','shortcuts','']]
};
const esc=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const rgbaFromHex=hex=>{const v=parseInt(hex.replace('#',''),16);return ((255<<24)|((v&255)<<16)|(v&0xff00)|((v>>>16)&255))>>>0;};
const hexFromRGBA=(data,n)=>'#'+[data[n],data[n+1],data[n+2]].map(x=>x.toString(16).padStart(2,'0')).join('');
const bounds=(a,b)=>[Math.min(a[0],b[0]),Math.min(a[1],b[1]),Math.max(a[0],b[0]),Math.max(a[1],b[1])];
function ico(id){const [x,y,w,h]=skin[id]||skin.tool_pencil;return `<span class="sprite" aria-hidden="true" style="width:${w*2}px;height:${h*2}px;background-position:-${x*2}px -${y*2}px"></span>`;}
function dl(blob,name){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
function pngBlob(data,w,h){const c=document.createElement('canvas');c.width=w;c.height=h;c.getContext('2d').putImageData(new ImageData(new Uint8ClampedArray(data),w,h),0,0);return new Promise(ok=>c.toBlob(ok,'image/png'));}
function el(id,root){return root.getElementById(id);}
const range=(n)=>Array.from({length:n},(_,i)=>i);

export class VSPixelStudio extends HTMLElement {
  constructor(){super();this.attachShadow({mode:'open'});this.engine=null;this.tool='pencil';this.color='#5b6ee1';this.bgColor='#ffffff';this.zoom=12;this.fitMode=true;this.wheelMode='zoom';this.navigatorVisible=true;this.spaceDown=false;this.navFrame=0;this.navImageDirty=true;this.strokeFrame=0;this.strokePreview=null;this.baseBuffer=null;this.onionBuffers=[];this.size=1;this.selection=null;this.selectionMask=null;this.symX=false;this.symY=false;this.clipboard=null;this.drawing=false;this.pointer=null;this.playing=null;this.grid=false;this.onion=false;this.locked=new Set();this.docName='Sprite-1';this.mouse={x:0,y:0};this.pan=null;this.activeMenu=null;this.preferredEngine='auto';this.projectMeta={tags:[],slices:[],palette:null};this.selectedTag=null;this.layerMeta=[];this.hover=null;this.hoverFrame=0;this.dirty=false;}
  async connectedCallback(){if(this.engine)return;
    this.shadowRoot.innerHTML=`<link rel="stylesheet" href="${new URL('./styles.css',import.meta.url)}">
      <section class="studio" tabindex="0" role="application" aria-label="Editor de sprites VS Pixel Studio">
      <div class="menu-bar"><div class="app-mark" title="VS Pixel Studio">VS</div>${Object.entries(MENUS).map(([title,items])=>`<div class="menu-holder"><button class="menu-trigger" type="button" data-menu="${title}" aria-haspopup="menu" aria-expanded="false">${title}</button><div class="popup" role="menu" data-popup="${title}" hidden>${items.map(([label,action,key])=>`<button role="menuitem" data-act="${action}"><span>${label}</span><small>${key}</small></button>`).join('')}</div></div>`).join('')}<span class="top-brand">VS PIXEL STUDIO</span></div>
      <div class="tabs"><div class="home-tab">${ico('tab_home_icon_normal')} Home</div><button class="document-tab">${esc(this.docName)}.aseprite <span class="mod-marker" id="modified">●</span></button><div class="tabs-fill"></div><button class="tiny" data-act="export" title="Guardar PNG">${ico('icon_save')}</button></div>
      <div class="context-bar"><button class="mini-tool" data-act="undo" title="Deshacer">↶</button><button class="mini-tool" data-act="redo" title="Rehacer">↷</button><span class="context-divider"></span><span class="context-icon" id="context-icon">${ico('tool_pencil')}</span><label> Tamaño <input id="brush-size" type="number" min="1" max="16" value="1"></label><span class="context-divider"></span><label class="checkline"><input id="perfect" type="checkbox" checked> Pixel-perfect</label><label class="checkline" title="Simetría horizontal"><input id="sym-x" type="checkbox"> X</label><label class="checkline" title="Simetría vertical"><input id="sym-y" type="checkbox"> Y</label><span class="context-spacer"></span><button class="mini-tool" data-act="grid" title="Rejilla">${ico('icon_grid')}</button><button class="mini-tool" data-act="onion" title="Piel de cebolla">${ico('timeline_onionskin')}</button><div class="zoom-controls" aria-label="Controles del zoom"><button class="mini-tool" data-act="zoomout" title="Alejar (−)">−</button><input id="zoom-range" type="range" min="0" max="${ZOOM_STEPS.length-1}" value="12" aria-label="Nivel de zoom"><output id="zoomlabel" class="zoom-badge" aria-live="off">1200%</output><button class="mini-tool" data-act="zoomin" title="Acercar (+)">+</button><button class="mini-tool" data-act="fitzoom" title="Ajustar lienzo al área visible (F)">Ajustar</button><button class="mini-tool" data-act="actualzoom" title="Zoom real al 100%">1:1</button><button class="mini-tool" data-act="centerzoom" title="Centrar lienzo">⌖</button><button class="mini-tool" data-act="navigator" title="Mostrar u ocultar navegador (N)">Mapa</button><button class="mini-tool" data-act="wheelmode" id="wheelmode" title="Alternar rueda entre zoom y desplazamiento">Rueda: zoom</button></div></div>
      <div class="main-area"><aside class="color-panel"><div class="palette-head"><button class="tiny" data-act="loadpalette" title="Importar paleta GPL/PAL">☷</button><span>Paleta</span><button class="tiny" data-act="swapcolors" title="Intercambiar colores">⇄</button></div><label class="palette-presets-label">PALETAS <select id="palette-profile" aria-label="Seleccionar paleta de colores"><option value="default">Aseprite / actual</option><option value="pico8">PICO-8</option><option value="dawn">DawnBringer 32</option><option value="grayscale">Escala de grises</option><option value="pastel">Pastel</option><option value="minecraft">Minecraft / tierra</option></select></label><div id="colors" class="palette"></div><div class="palette-separator"></div><div class="color-picker"><div class="picker-square" id="pick-square" tabindex="0" role="group" aria-label="Saturación y luminosidad. Usar flechas para ajustar, Mayús para cambios grandes"><div class="picker-indicator" id="picker-indicator" aria-hidden="true"></div></div><input id="hue" type="range" min="0" max="360" value="231" title="Tono" class="hue"><div class="fg-row"><button id="fg-color" class="fg-color" title="Color primario"></button><button id="bg-color" class="bg-color" data-act="swapcolors" title="Color secundario"></button><input id="hex" class="hex" aria-label="Color hexadecimal" value="#5b6ee1" maxlength="7"></div><div class="color-name">Índice: <span id="colorindex">17</span> · RGBA</div></div></aside>
      <div class="stage-shell"><section class="stage" id="stage" tabindex="0" aria-label="Lienzo"><div class="pan-surface" id="pan-surface"><div class="canvas-holder" id="holder"><div class="checker"><canvas class="draw" id="canvas" aria-label="Lienzo editable"></canvas><div class="pixel-hover" id="pixel-hover" hidden aria-hidden="true"></div></div></div></div></section><div class="navigator" id="navigator" aria-label="Minimapa del sprite"><div class="navigator-head"><span>MAPA DEL LIENZO</span><button type="button" data-act="navigator" title="Cerrar minimapa">×</button></div><div id="nav-preview" class="navigator-preview"><canvas id="nav-canvas"></canvas><div id="nav-viewport" class="nav-viewport"></div></div><small>Arrastrá para navegar</small></div></div>
      <aside class="tools" aria-label="Herramientas de Aseprite">${TOOLS.map(([id,sp,label])=>`<button data-tool="${id}" title="${label}" class="tool ${id==='pencil'?'active':''}">${ico(sp)}</button>`).join('')}<div class="tool-gap"></div><button class="tool" data-act="grid" title="Mostrar rejilla">${ico('icon_grid')}</button></aside></div>
      <div class="timeline" id="timeline"><div class="timeline-bar"><button class="time-button" data-act="firstframe" title="Primer fotograma">|◀</button><button class="time-button" data-act="prevframe" title="Anterior">◀</button><button class="time-button" data-act="play" id="playbtn" title="Reproducir">▶</button><button class="time-button" data-act="nextframe" title="Siguiente">▶|</button><button class="time-button" data-act="lastframe" title="Último">▶|</button><span class="separator"></span><button class="time-button" data-act="addframe" title="Duplicar fotograma">${ico('icon_add')}</button><button class="time-button" data-act="addlinkedframe" title="Duplicar fotograma enlazado">↗</button><button class="time-button" data-act="deleteframe" title="Eliminar fotograma">−</button><span class="separator"></span><button class="time-button" data-act="addlayer" title="Nueva capa">+ Capa</button><button class="time-button" data-act="deletelayer" title="Eliminar capa">− Capa</button><button class="time-button" data-act="duplicatelayer" title="Duplicar capa activa">⧉</button><button class="time-button" data-act="layerup" title="Subir capa">↑</button><button class="time-button" data-act="layerdown" title="Bajar capa">↓</button><span class="timeline-spacer"></span><span class="time-label">Duración</span><input id="duration" type="number" min="20" max="2000" value="120"> ms <button class="tiny" data-act="toggle-timeline" title="Ocultar o mostrar timeline">▾</button></div>
      <div class="timeline-content" id="timeline-content"><div class="layer-heading"><div class="layer-header"><span class="layer-heading-icon">${ico('timeline_open_eye_normal')}</span><span class="layer-heading-icon">${ico('timeline_open_padlock_normal')}</span><span class="layer-caption">Capas</span></div><div class="layer-properties"><label>Opacidad <output id="layer-opacity-label">100%</output><input id="layer-opacity" type="range" min="0" max="255" value="255" step="1" aria-label="Opacidad de capa"></label><label>Fusión<select id="layer-blend" aria-label="Modo de fusión"><option value="0">Normal</option><option value="1">Multiplicar</option><option value="2">Pantalla</option><option value="3">Superponer</option><option value="4">Oscurecer</option><option value="5">Aclarar</option><option value="10">Diferencia</option><option value="11">Exclusión</option><option value="16">Sumar</option><option value="17">Restar</option></select></label></div><div id="layer-list" class="layer-list"></div></div><div class="frame-scroller"><div id="frame-numbers" class="frame-numbers"></div><div id="frame-grid" class="frame-grid"></div></div></div></div>
      <footer class="status-bar"><span id="coords">Listo</span><span id="selectionlabel"></span><span class="status-spacer"></span><span id="mode">RGBA</span><span id="engine-type">Cargando…</span><span id="dimensions">32 × 32</span><span id="frame-info">Fotograma 1</span></footer>
      <input id="file" type="file" hidden accept=".png,.jpg,.jpeg,.webp,.bmp,.ase,.aseprite,.json,.gpl,.pal,image/*,application/json">
      <div class="toast" id="toast" role="status" hidden></div></section>`;
    this.$=id=>el(id,this.shadowRoot);
    this.canvas=this.$('canvas');this.ctx=this.canvas.getContext('2d',{alpha:true});
    const w=Number(this.getAttribute('width'))||32,h=Number(this.getAttribute('height'))||32;
    this.engine=await createEngine(Math.max(1,Math.min(512,w)),Math.max(1,Math.min(512,h)));
    this.$('engine-type').textContent=this.engine.kind==='wasm'?'Rust/WASM':'JS';
    this.shadowRoot.addEventListener('click',event=>{
      const menu=event.target.closest('[data-menu]');if(menu){this.toggleMenu(menu.dataset.menu);return;}
      const tool=event.target.closest('[data-tool]');if(tool){this.setTool(tool.dataset.tool);return;}
      const action=event.target.closest('[data-act]');if(action){this.closeMenu();void this.action(action.dataset.act);return;}
      if(!event.target.closest('.popup'))this.closeMenu();
    });
    this.$('colors').addEventListener('click',event=>{const sw=event.target.closest('[data-color]');if(sw)this.setColor(sw.dataset.color);});
    this.$('colors').addEventListener('dblclick',event=>{const sw=event.target.closest('[data-color]');if(!sw)return;const next=prompt('Color de la paleta:',sw.dataset.color);if(!next||!/^#[0-9a-f]{6}$/i.test(next))return;PALETTE[Number(sw.dataset.index)]=next.toLowerCase();this.projectMeta.palette=PALETTE.map(c=>[...c.slice(1).matchAll(/.{2}/g)].map(x=>parseInt(x[0],16)).concat(255));this.refreshColors();});
    this.$('layer-list').addEventListener('click',ev=>this.layerClick(ev));
    this.$('layer-list').addEventListener('dblclick',ev=>{const b=ev.target.closest('[data-layer]');if(b)this.renameLayer(Number(b.dataset.layer));});
    this.$('frame-grid').addEventListener('click',ev=>{const b=ev.target.closest('[data-cell]');if(b){
      this.stopPlay();const frame=Number(b.dataset.frame),layer=Number(b.dataset.layer);
      this.engine.selectLayer(layer);this.engine.selectFrame(frame);
      // Alt + click on a cel toggles a live link to its previous frame.
      if(ev.altKey){if(!this.engine.linkCel){this.notify('Los vínculos requieren el motor JS');return;}if((this.engine.getCelLink(frame,layer)??null)!==null)this.unlinkCel(frame,layer);else if(frame>0)this.linkCel(frame,layer,frame-1);else this.notify('El primer fotograma no puede enlazarse');return;}
      this.refresh();
    }});
    this.$('frame-numbers').addEventListener('click',ev=>{const b=ev.target.closest('[data-frame]');if(b){this.stopPlay();this.engine.selectFrame(Number(b.dataset.frame));this.refresh();}});
    this.$('brush-size').addEventListener('input',ev=>{this.size=Math.max(1,Math.min(16,Number(ev.target.value)||1));this.scheduleHover();});
    this.$('layer-opacity').addEventListener('input',ev=>{
      const value=Number(ev.target.value),e=this.engine;
      this.$('layer-opacity-label').textContent=Math.round(value/255*100)+'%';
      if(e.kind!=='js'||this.locked.has(e.activeLayer))return;
      e.begin();e.layers[e.activeLayer].opacity=value;
      this.$('layer-list').querySelector(`[data-layer="${e.activeLayer}"] .layer-alpha`)?.replaceChildren(document.createTextNode(Math.round(value/255*100)+'%'));
      this.redraw();
    });
    this.$('layer-opacity').addEventListener('change',()=>{
      const e=this.engine;if(e.kind!=='js')return;
      e.end();this.layerMeta[e.activeLayer]={...this.layerMeta[e.activeLayer],opacity:e.layers[e.activeLayer].opacity};this.changed();
    });
    this.$('layer-blend').addEventListener('change',ev=>{if(this.engine.kind!=='js')return;this.setLayerBlend(this.engine.activeLayer,Number(ev.target.value));});
    this.$('sym-x').addEventListener('change',ev=>this.symX=ev.target.checked);
    this.$('sym-y').addEventListener('change',ev=>this.symY=ev.target.checked);
    this.$('duration').addEventListener('change',ev=>{this.engine.transaction(()=>this.engine.duration=Math.max(20,Math.min(2000,Number(ev.target.value)||120)));this.changed();});
    this.$('hex').addEventListener('change',ev=>{if(/^#[0-9a-f]{6}$/i.test(ev.target.value))this.setColor(ev.target.value);else ev.target.value=this.color;});
    this.$('hue').addEventListener('input',ev=>{const {s,v}=this.hexToHsv(this.color);this.setColor(this.hsvToHex(Number(ev.target.value),s,v));});
    this.$('palette-profile').addEventListener('change',ev=>this.selectPalette(ev.target.value));
    const pickSquare=this.$('pick-square');
    const pickColor=ev=>{const r=pickSquare.getBoundingClientRect();if(!r.width||!r.height)return;const sat=Math.min(1,Math.max(0,(ev.clientX-r.left)/r.width)),val=1-Math.min(1,Math.max(0,(ev.clientY-r.top)/r.height));this.setColor(this.hsvToHex(Number(this.$('hue').value),sat,val));};
    pickSquare.addEventListener('pointerdown',ev=>{if(ev.button!==0)return;ev.preventDefault();pickSquare.setPointerCapture(ev.pointerId);pickColor(ev);});
    pickSquare.addEventListener('pointermove',ev=>{if(pickSquare.hasPointerCapture(ev.pointerId))pickColor(ev);});
    pickSquare.addEventListener('pointerup',ev=>{if(pickSquare.hasPointerCapture(ev.pointerId))pickSquare.releasePointerCapture(ev.pointerId);});
    pickSquare.addEventListener('pointercancel',ev=>{if(pickSquare.hasPointerCapture(ev.pointerId))pickSquare.releasePointerCapture(ev.pointerId);});
    pickSquare.addEventListener('keydown',ev=>{const delta=ev.shiftKey?.1:.01;let {h,s,v}=this.hexToHsv(this.color);if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(ev.key))return;
      ev.preventDefault();ev.stopPropagation();if(ev.key==='ArrowLeft')s=Math.max(0,s-delta);if(ev.key==='ArrowRight')s=Math.min(1,s+delta);if(ev.key==='ArrowUp')v=Math.min(1,v+delta);if(ev.key==='ArrowDown')v=Math.max(0,v-delta);
      this.setColor(this.hsvToHex(h,s,v));
    });
    this.shadowRoot.querySelector('.menu-bar').addEventListener('keydown',ev=>{
      const holder=ev.target.closest('.menu-holder');if(!holder)return;
      const holders=[...this.shadowRoot.querySelectorAll('.menu-holder')];const current=holders.indexOf(holder);const items=[...holder.querySelectorAll('[role="menuitem"]')];
      const opening=ev.target.matches('.menu-trigger');const fromMenu=ev.target.matches('[role="menuitem"]');if(!opening&&!fromMenu)return;
      if(ev.key==='Escape'){ev.preventDefault();ev.stopPropagation();this.closeMenu();holder.querySelector('.menu-trigger')?.focus();return;}
      if(ev.key==='ArrowRight'||ev.key==='ArrowLeft'){
       ev.preventDefault();ev.stopPropagation();const next=holders[(current+(ev.key==='ArrowRight'?1:-1)+holders.length)%holders.length];
       this.toggleMenu(next.querySelector('.menu-trigger').dataset.menu);next.querySelector('[role="menuitem"]')?.focus();return;
      }
      if(opening&&['ArrowDown','ArrowUp'].includes(ev.key)){
       ev.preventDefault();ev.stopPropagation();if(this.activeMenu!==holder.querySelector('.menu-trigger').dataset.menu)this.toggleMenu(holder.querySelector('.menu-trigger').dataset.menu);
       (ev.key==='ArrowUp'?items.at(-1):items[0])?.focus();return;
      }
      if(fromMenu&&['ArrowDown','ArrowUp','Home','End'].includes(ev.key)){
       ev.preventDefault();ev.stopPropagation();const idx=items.indexOf(ev.target);const next=ev.key==='Home'?0:ev.key==='End'?items.length-1:(idx+(ev.key==='ArrowDown'?1:-1)+items.length)%items.length;items[next]?.focus();
      }
    });
    this.$('file').addEventListener('change',async ev=>{const input=ev.currentTarget,file=input.files?.[0];if(file)try{await this.openFile(file);}catch(err){this.notify(err.message);}input.value='';});
    this.canvas.addEventListener('pointerdown',ev=>this.onDown(ev));
    this.canvas.addEventListener('pointermove',ev=>this.onMove(ev));
    this.canvas.addEventListener('pointerenter',ev=>{this.hover={x:ev.clientX,y:ev.clientY};this.scheduleHover();});
    this.canvas.addEventListener('pointerleave',()=>{if(!this.drawing)this.hideHover();});
    this.canvas.addEventListener('pointerup',ev=>this.onUp(ev));
    this.canvas.addEventListener('pointercancel',ev=>this.onUp(ev));
    this.$('stage').addEventListener('dragover',ev=>{ev.preventDefault();ev.dataTransfer.dropEffect='copy';});
    this.$('stage').addEventListener('drop',async ev=>{ev.preventDefault();const file=ev.dataTransfer.files?.[0];if(file)try{await this.openFile(file);}catch(error){this.notify(error.message);}});
    const stage=this.$('stage');
    stage.addEventListener('wheel',ev=>{
      // Shift + wheel: horizontal navigation; Alt + wheel: vertical navigation.
      if(ev.shiftKey){ev.preventDefault();stage.scrollLeft+=ev.deltaY||ev.deltaX;this.scheduleNavigator();return;}
      if(ev.altKey){ev.preventDefault();stage.scrollTop+=ev.deltaY;this.scheduleNavigator();return;}
      if(this.wheelMode==='pan'&&!ev.ctrlKey&&!ev.metaKey)return;
      ev.preventDefault();
      if(ev.deltaY!==0){const delta=ev.deltaY*(ev.deltaMode===1?16:ev.deltaMode===2?80:1);const ratio=Math.exp(-Math.max(-180,Math.min(180,delta))*0.0022);this.setZoom(this.zoom*ratio,{x:ev.clientX,y:ev.clientY});}
    },{passive:false});
    stage.addEventListener('scroll',()=>this.scheduleNavigator(),{passive:true});
    this.$('zoom-range').addEventListener('input',ev=>{
      this.setZoom(ZOOM_STEPS[Number(ev.target.value)]);
    });
    const nav=this.$('nav-preview');
    const jump=ev=>{
      if(ev.type==='pointerdown'&&ev.button!==0)return;
      const r=this.$('nav-canvas').getBoundingClientRect();
      if(!r.width||!r.height)return;
      const x=Math.min(1,Math.max(0,(ev.clientX-r.left)/r.width));
      const y=Math.min(1,Math.max(0,(ev.clientY-r.top)/r.height));
      this.panToSource(x*this.engine.width,y*this.engine.height);
    };
    nav.addEventListener('pointerdown',ev=>{ev.preventDefault();nav.setPointerCapture(ev.pointerId);jump(ev);});
    nav.addEventListener('pointermove',ev=>{if(nav.hasPointerCapture(ev.pointerId))jump(ev);});
    nav.addEventListener('pointerup',ev=>{if(nav.hasPointerCapture(ev.pointerId))nav.releasePointerCapture(ev.pointerId);});
    stage.addEventListener('pointerdown',ev=>{
      if(ev.target===this.canvas||!(ev.button===1||this.spaceDown))return;
      ev.preventDefault();stage.setPointerCapture(ev.pointerId);
      this.pan={x:ev.clientX,y:ev.clientY,left:stage.scrollLeft,top:stage.scrollTop,pointerId:ev.pointerId};
    });
    stage.addEventListener('pointermove',ev=>{
      if(this.pan&&this.pan.pointerId===ev.pointerId){stage.scrollLeft=this.pan.left-(ev.clientX-this.pan.x);stage.scrollTop=this.pan.top-(ev.clientY-this.pan.y);}
    });
    stage.addEventListener('pointerup',ev=>{if(this.pan?.pointerId===ev.pointerId)this.pan=null;});
    stage.addEventListener('pointercancel',ev=>{if(this.pan?.pointerId===ev.pointerId)this.pan=null;});
    this._onKeyUp=ev=>{if(ev.code==='Space'){this.spaceDown=false;this.canvas.style.cursor=this.tool==='hand'?'grab':this.tool==='zoom'?'zoom-in':'crosshair';}};
    this.shadowRoot.querySelector('.studio').addEventListener('keyup',this._onKeyUp);
    this._onBlur=()=>{this.spaceDown=false;};
    window.addEventListener('blur',this._onBlur);
    this._resizeObserver=new ResizeObserver(()=>{
      this.updateStageGutters();
      if(this.fitMode)this.fitCanvas();else this.scheduleNavigator();
    });
    this._resizeObserver.observe(stage);
    requestAnimationFrame(()=>{if(this.isConnected){this.updateStageGutters();this.fitCanvas();}});
    this.shadowRoot.querySelector('.studio').addEventListener('keydown',ev=>this.key(ev));
    this.refresh();this.dispatchEvent(new CustomEvent('vs-pixel-ready',{bubbles:true,composed:true,detail:{engine:this.engine.kind||'js'}}));
  }
  disconnectedCallback(){this.stopPlay();this._resizeObserver?.disconnect();this._resizeObserver=null;if(this.hoverFrame)cancelAnimationFrame(this.hoverFrame);this.hoverFrame=0;if(this.navFrame)cancelAnimationFrame(this.navFrame);this.navFrame=0;if(this.strokeFrame)cancelAnimationFrame(this.strokeFrame);this.strokeFrame=0;if(this._onBlur)window.removeEventListener('blur',this._onBlur);this.engine?.dispose?.();this.engine=null;}
  hsvToHex(h,s,v){const f=n=>{const k=(n+h/60)%6;return Math.round((v-v*s*Math.max(Math.min(k,4-k,1),0))*255).toString(16).padStart(2,'0');};return `#${f(5)}${f(3)}${f(1)}`;}
  toggleMenu(menu){this.activeMenu=this.activeMenu===menu?null:menu;this.shadowRoot.querySelectorAll('[data-popup]').forEach(p=>p.hidden=p.dataset.popup!==this.activeMenu);this.shadowRoot.querySelectorAll('[data-menu]').forEach(b=>{const opened=b.dataset.menu===this.activeMenu;b.classList.toggle('opened',opened);b.setAttribute('aria-expanded',String(opened));});}
  closeMenu(){this.activeMenu=null;this.shadowRoot.querySelectorAll('[data-popup]').forEach(p=>p.hidden=true);this.shadowRoot.querySelectorAll('[data-menu]').forEach(b=>{b.classList.remove('opened');b.setAttribute('aria-expanded','false');});}
  notify(msg){const t=this.$('toast');t.textContent=msg;t.hidden=false;clearTimeout(this.toastTimer);this.toastTimer=setTimeout(()=>t.hidden=true,2800);}
  setTool(id){this.tool=id;this.shadowRoot.querySelectorAll('[data-tool]').forEach(b=>b.classList.toggle('active',b.dataset.tool===id));const icon=TOOLS.find(t=>t[0]===id)?.[1];if(icon)this.$('context-icon').innerHTML=ico(icon);this.$('coords').textContent=`${TOOLS.find(t=>t[0]===id)?.[2]||id}`;this.$('canvas').style.cursor=id==='hand'?'grab':id==='zoom'?'zoom-in':'crosshair';this.scheduleHover();}
  hexToHsv(hex){const v=parseInt(String(hex).replace('#',''),16);if(!Number.isFinite(v))return {h:0,s:0,v:0};let r=((v>>16)&255)/255,g=((v>>8)&255)/255,b=(v&255)/255;const hi=Math.max(r,g,b),lo=Math.min(r,g,b),delta=hi-lo;let h=0;if(delta){if(hi===r)h=60*((g-b)/delta%6);else if(hi===g)h=60*((b-r)/delta+2);else h=60*((r-g)/delta+4);}return {h:(h+360)%360,s:hi===0?0:delta/hi,v:hi};}
  syncPicker(){const hsv=this.hexToHsv(this.color),square=this.$('pick-square'),mark=this.$('picker-indicator');if(!square||!mark)return;const remembered=Number(this.$('hue').value)||0;const hue=hsv.s<.001?remembered:hsv.h;square.style.setProperty('--hue',hue.toFixed(2));this.$('hue').value=String(Math.round(hue));mark.style.left=`${(hsv.s*100).toFixed(2)}%`;mark.style.top=`${((1-hsv.v)*100).toFixed(2)}%`;mark.title=`${this.color} · S ${Math.round(hsv.s*100)}% · V ${Math.round(hsv.v*100)}%`;square.setAttribute('aria-description',mark.title);}
  setColor(hex){this.color=hex.toLowerCase();this.$('hex').value=this.color;this.syncPicker();this.refreshColors();}
  selectPalette(profile){const palettes={
    pico8:['#000000','#1d2b53','#7e2553','#008751','#ab5236','#5f574f','#c2c3c7','#fff1e8','#ff004d','#ffa300','#ffec27','#00e436','#29adff','#83769c','#ff77a8','#ffccaa'],
    dawn:['#000000','#222034','#45283c','#663931','#8f563b','#df7126','#d9a066','#eec39a','#fbf236','#99e550','#6abe30','#37946e','#4b692f','#524b24','#323c39','#3f3f74','#306082','#5b6ee1','#639bff','#5fcde4','#cbdbfc','#ffffff','#9badb7','#847e87','#696a6a','#595652','#76428a','#ac3232','#d95763','#d77bba','#8f974a','#8a6f30'],
    grayscale:Array.from({length:24},(_,i)=>{const n=Math.round(i*255/23).toString(16).padStart(2,'0');return '#'+n+n+n;}),
    pastel:['#e7d2c2','#d9bdb8','#f2b6bb','#e8a8ac','#f7c8ab','#ffe0b6','#ffe9c2','#d8e5b0','#c0d6ad','#a6d9c8','#aedbe1','#b7d2f0','#bfc6ec','#d4c1eb','#eed2e5','#a598b5'],
    minecraft:['#ffffff','#d9d9d9','#a4a8a8','#55585a','#2b2927','#654321','#926d48','#b38b5b','#dbbd89','#4c792e','#71a24b','#a3c65d','#4d7967','#3886a0','#6fb5b8','#5672bb','#8254a8','#a34146','#d65d42','#eab855','#e5d7b0','#6d4b3b','#b2a59e','#cec3bb']};
    if(profile==='default'){this.$('palette-profile').value='default';return;}
    const data=palettes[profile];if(!data)return;PALETTE.splice(0,PALETTE.length,...data);this.projectMeta.palette=PALETTE.map(c=>[...c.slice(1).match(/.{2}/g).map(x=>parseInt(x,16)),255]);this.projectMeta.paletteName=profile;this.refreshColors();this.notify('Paleta seleccionada: '+profile);}

  refreshColors(){this.$('colors').innerHTML=PALETTE.map((c,i)=>`<button class="swatch ${c.toLowerCase()===this.color?'current':''}" style="background:${c}" data-color="${c}" data-index="${i}" title="${i}: ${c}"></button>`).join('');this.$('fg-color').style.background=this.color;this.$('bg-color').style.background=this.bgColor;this.$('colorindex').textContent=(()=>{const index=PALETTE.findIndex(c=>c.toLowerCase()===this.color);return index<0?'PERSONALIZADO':index;})();this.syncPicker();}
  getLayerName(i){return this.engine.layers[i]?.name||`Capa ${i+1}`;}
  setLayerName(i,name){if(this.engine.layerNames)this.engine.layerNames[i]=name;else this.engine.layers[i].name=name;}
  layerClick(event){
    const item=event.target.closest('[data-layer]');if(!item)return;
    const i=Number(item.dataset.layer),action=event.target.closest('[data-visible],[data-lock]');
    if(action?.hasAttribute('data-visible')){this.engine.toggleLayer(i);this.changed();return;}
    if(action?.hasAttribute('data-lock')){
      if(this.engine.kind==='js'){
        this.engine.transaction(()=>{this.engine.layers[i].locked=!this.engine.layers[i].locked;});
        this.locked=new Set(this.engine.layers.flatMap((l,n)=>l.locked?[n]:[]));
      }else this.locked.has(i)?this.locked.delete(i):this.locked.add(i);
      this.changed();return;
    }
    this.engine.selectLayer(i);this.refresh();
  }
  refreshLayers(){
    const e=this.engine,ids=range(e.layerCount).reverse();
    this.$('layer-list').innerHTML=ids.map(i=>{
      const l=e.layers[i],locked=this.locked.has(i),opacity=Math.round((l.opacity??255)/255*100);
      return `<div class="layer-row ${i===e.activeLayer?'selected':''} ${locked?'layer-locked':''} ${!l.visible?'layer-hidden':''}" data-layer="${i}"><button title="${l.visible?'Ocultar':'Mostrar'} capa" aria-pressed="${l.visible}" data-visible="${i}" class="eye">${ico(l.visible?'timeline_open_eye_normal':'timeline_closed_eye_normal')}</button><button title="${locked?'Desbloquear':'Bloquear'} capa" aria-pressed="${locked}" data-lock="${i}" class="lock">${ico(locked?'timeline_closed_padlock_normal':'timeline_open_padlock_normal')}</button><span class="layer-name" title="Doble clic para renombrar">${esc(l.name)}</span><small class="layer-alpha" title="Opacidad">${opacity}%</small></div>`;
    }).join('');
    const current=e.layers[e.activeLayer]||{};
    this.$('layer-opacity').value=String(current.opacity??255);
    this.$('layer-opacity-label').textContent=Math.round((current.opacity??255)/255*100)+'%';
    this.$('layer-blend').value=String(current.blend??0);
    for(const k of ['layer-opacity','layer-blend'])this.$(k).disabled=e.kind!=='js'||this.locked.has(e.activeLayer);
  }
  /** Keep lock flags and document metadata associated with the right layer after reordering. */
  reindexLayerState(indexFrom,indexTo,remove=false){
    const count=this.engine.layerCount,ids=Array.from({length:remove?count+1:count},(_,i)=>i);
    if(remove)ids.splice(indexFrom,1);else ids.splice(indexTo,0,ids.splice(indexFrom,1)[0]);
    const oldLocked=this.locked;this.locked=new Set(ids.flatMap((old,newIndex)=>oldLocked.has(old)?[newIndex]:[]));
    const previous=this.layerMeta.slice();this.layerMeta=ids.map(i=>previous[i]||{});
  }
  moveActiveLayer(direction){
    const e=this.engine,from=e.activeLayer,to=from+direction;
    if(to<0||to>=e.layerCount)return;
    if(typeof e.moveLayer!=='function'){this.notify('Reordenar requiere motor de capas compatible');return;}
    e.moveLayer(from,to);this.reindexLayerState(from,to);this.changed();
  }

  refreshFrames(){const e=this.engine,indices=range(e.frameCount),rowIds=range(e.layerCount).reverse();this.$('frame-numbers').innerHTML=indices.map(i=>{const tag=this.projectMeta.tags.find(t=>i>=t.from&&i<=t.to);return `<button data-frame="${i}" class="number-cell ${i===e.activeFrame?'current':''} ${tag?'tagged':''}" title="Fotograma ${i+1}${tag?` · ${esc(tag.name)}`:''}" style="${tag?`--tag-color:rgb(${(tag.color||[237,178,77]).map(n=>Math.max(0,Math.min(255,n|0))).join(',')})`:''}">${i+1}</button>`;}).join('');
    this.$('frame-grid').innerHTML=rowIds.map(l=>`<div class="cel-row">${indices.map(i=>{const linked=e.getCelLink?.(i,l);return `<button class="cel ${linked!==null&&linked!==undefined?'linked':''} ${i===e.activeFrame?'frame-active':''} ${l===e.activeLayer?'layer-active':''} ${(i===e.activeFrame&&l===e.activeLayer)?'selected':''}" data-cell data-layer="${l}" data-frame="${i}" title="${esc(this.getLayerName(l))}, frame ${i+1}${linked!==null&&linked!==undefined?` — enlazado al ${linked+1}`:''}. Alt+clic: alternar vínculo">${linked!==null&&linked!==undefined?'<span class="link-glyph">↗</span>':ico('timeline_keyframe_normal')}</button>`;}).join('')}</div>`).join('');}
  /** Reuse backing memory and avoid resetting the canvas (and its context state) on every stroke. */
  redraw(){const e=this.engine;if(!e)return;
    const w=e.width,h=e.height;
    if(this.canvas.width!==w||this.canvas.height!==h){
      this.canvas.width=w;this.canvas.height=h;this.baseBuffer=null;this.onionBuffers=[];
    }
    if(!this.baseBuffer||this.baseBuffer.width!==w||this.baseBuffer.height!==h){
      this.baseBuffer=this.ctx.createImageData(w,h);
    }
    // JS engine writes directly into existing ImageData: avoid a full RGBA
    // allocation and copy on every pointermove. WASM keeps legacy API.
    const base=e.render(e.activeFrame,this.baseBuffer.data);
    if(base!==this.baseBuffer.data)this.baseBuffer.data.set(base);
    this.ctx.putImageData(this.baseBuffer,0,0);
    if(this.onion&&e.frameCount>1){const f=e.activeFrame;if(f>0)this.drawOnion(f-1,0);if(f+1<e.frameCount)this.drawOnion(f+1,1);}
    if(this.selection)this.drawOutline(this.selection,'#ffffff');
    this.drawSymmetryGuides();
    this.scheduleNavigator(true);
  }
  /** Merge pointermove bursts: no more than one expensive composite per animation frame. */
  scheduleStrokeRedraw(preview=null){
    this.strokePreview=preview;
    if(this.strokeFrame)return;
    this.strokeFrame=requestAnimationFrame(()=>{
      this.strokeFrame=0;
      if(!this.engine||!this.isConnected)return;
      const pending=this.strokePreview;this.strokePreview=null;
      this.redraw();
      if(pending){if(pending.shape)this.previewShape(...pending.shape);else this.drawOutline(pending.rect,'#fff');}
    });
  }
  flushStrokeRedraw(){
    if(this.strokeFrame)cancelAnimationFrame(this.strokeFrame);
    this.strokeFrame=0;this.strokePreview=null;
    this.redraw();
  }
  hideHover(){this.hover=null;const indicator=this.$?.('pixel-hover');if(indicator)indicator.hidden=true;}
  scheduleHover(){
    if(this.hoverFrame||!this.engine||!this.isConnected)return;
    this.hoverFrame=requestAnimationFrame(()=>{this.hoverFrame=0;this.updateHover();});
  }
  updateHover(){
    const indicator=this.$('pixel-hover'),pos=this.hover;
    if(!pos||['hand','zoom'].includes(this.tool)){indicator.hidden=true;return;}
    const {x,y,inside}=pixelAtClient(pos.x,pos.y,this.canvas.getBoundingClientRect(),this.engine.width,this.engine.height);
    if(!inside){indicator.hidden=true;return;}
    const footprint=brushFootprint(x,y,['pencil','eraser','spray'].includes(this.tool)?this.size:1);
    indicator.hidden=false;
    indicator.style.width=`${footprint.width*this.zoom}px`;
    indicator.style.height=`${footprint.height*this.zoom}px`;
    indicator.style.transform=`translate3d(${footprint.x*this.zoom}px,${footprint.y*this.zoom}px,0)`;
    indicator.classList.toggle('eraser',this.tool==='eraser');
  }
  applyZoomStyle(){
    if(!this.engine)return;
    this.canvas.style.width=`${this.engine.width*this.zoom}px`;
    this.canvas.style.height=`${this.engine.height*this.zoom}px`;
    const geometry=viewportMetrics(this.zoom,this.size);
    this.$('holder').classList.toggle('show-grid',this.grid&&geometry.gridVisible);
    this.$('holder').style.setProperty('--pixel',`${geometry.pixel}px`);
    this.$('holder').style.setProperty('--checker-tile',`${geometry.checkerTile}px`);
    this.scheduleHover();
    this.$('zoomlabel').textContent=zoomText(this.zoom);
    const closest=ZOOM_STEPS.reduce((idx,val,i)=>Math.abs(val-this.zoom)<Math.abs(ZOOM_STEPS[idx]-this.zoom)?i:idx,0);
    this.$('zoom-range').value=String(closest);
    this.$('zoom-range').setAttribute('aria-valuetext',zoomText(this.zoom));
    this.scheduleNavigator();
  }
  drawOnion(frame,slot){
    let buffer=this.onionBuffers[slot];
    const w=this.engine.width,h=this.engine.height;
    if(!buffer||buffer.canvas.width!==w||buffer.canvas.height!==h){
      const canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;
      const ctx=canvas.getContext('2d');buffer={canvas,ctx,image:ctx.createImageData(w,h)};
      this.onionBuffers[slot]=buffer;
    }
    buffer.image.data.set(this.engine.render(frame));
    buffer.ctx.putImageData(buffer.image,0,0);
    this.ctx.save();this.ctx.globalAlpha=.20;this.ctx.drawImage(buffer.canvas,0,0);this.ctx.restore();
  }
  drawOutline(rect,color){const [x0,y0,x1,y1]=rect;this.ctx.save();this.ctx.strokeStyle=color;this.ctx.lineWidth=1;this.ctx.setLineDash([1,1]);this.ctx.strokeRect(x0+.5,y0+.5,x1-x0+1,y1-y0+1);this.ctx.restore();}
  drawSymmetryGuides(){if(!this.symX&&!this.symY)return;this.ctx.save();this.ctx.strokeStyle='rgba(255,195,55,.9)';this.ctx.lineWidth=1/Math.max(1,this.zoom);this.ctx.setLineDash([2,2]);this.ctx.beginPath();if(this.symX){this.ctx.moveTo(this.engine.width/2,0);this.ctx.lineTo(this.engine.width/2,this.engine.height);}if(this.symY){this.ctx.moveTo(0,this.engine.height/2);this.ctx.lineTo(this.engine.width,this.engine.height/2);}this.ctx.stroke();this.ctx.restore();}
  isSelected(x,y){if(x<0||y<0||x>=this.engine.width||y>=this.engine.height)return false;if(this.selectionMask)return !!this.selectionMask[y*this.engine.width+x];return !this.selection||(x>=this.selection[0]&&x<=this.selection[2]&&y>=this.selection[1]&&y<=this.selection[3]);}
  useMaskPixel(x,y,color){x|=0;y|=0;if(this.isSelected(x,y))this.engine.pixel(x,y,color);}
  paintPixel(x,y,color){this.useMaskPixel(x,y,color);if(this.symX)this.useMaskPixel(this.engine.width-1-x,y,color);if(this.symY)this.useMaskPixel(x,this.engine.height-1-y,color);if(this.symX&&this.symY)this.useMaskPixel(this.engine.width-1-x,this.engine.height-1-y,color);}
  paintLine(x0,y0,x1,y1,c){x0|=0;y0|=0;x1|=0;y1|=0;const dx=Math.abs(x1-x0),sx=x0<x1?1:-1,dy=-Math.abs(y1-y0),sy=y0<y1?1:-1;let err=dx+dy;while(true){this.paintPixel(x0,y0,c);if(x0===x1&&y0===y1)break;const t=2*err;if(t>=dy){err+=dy;x0+=sx;}if(t<=dx){err+=dx;y0+=sy;}}}
  paintFill(x,y,color){
    const e=this.engine,w=e.width,h=e.height;
    if(x<0||y<0||x>=w||y>=h||!this.isSelected(x,y))return;
    const p=e.getCelPixels(),start=y*w+x,pos=start*4;
    const r=p[pos],g=p[pos+1],b=p[pos+2],a=p[pos+3];
    if(r===(color&255)&&g===((color>>>8)&255)&&b===((color>>>16)&255)&&a===(color>>>24))return;
    const visited=new Uint8Array(w*h),queue=new Int32Array(w*h);
    let head=0,tail=1;queue[0]=start;visited[start]=1;
    while(head<tail){
      const k=queue[head++],off=k*4;
      if(p[off]!==r||p[off+1]!==g||p[off+2]!==b||p[off+3]!==a)continue;
      const yy=(k/w)|0,xx=k-yy*w;
      if(!this.isSelected(xx,yy))continue;
      this.useMaskPixel(xx,yy,color);
      const push=n=>{if(!visited[n]){visited[n]=1;queue[tail++]=n;}};
      if(xx>0)push(k-1);if(xx<w-1)push(k+1);
      if(yy>0)push(k-w);if(yy<h-1)push(k+w);
    }
  }
  setSelection(rect,shape='rect'){const e=this.engine;this.selection=rect;this.selectionMask=null;if(shape==='rect')return;const mask=new Uint8Array(e.width*e.height),[a,b,c,d]=rect,cx=(a+c+1)/2,cy=(b+d+1)/2,rx=Math.max(.5,(c-a+1)/2),ry=Math.max(.5,(d-b+1)/2);for(let y=Math.max(0,b);y<=Math.min(e.height-1,d);y++)for(let x=Math.max(0,a);x<=Math.min(e.width-1,c);x++)if(((x+.5-cx)/rx)**2+((y+.5-cy)/ry)**2<=1.00001)mask[y*e.width+x]=1;this.selectionMask=mask;}
  magicWand(x,y){const e=this.engine,w=e.width,h=e.height;if(x<0||y<0||x>=w||y>=h)return;const p=e.render(),start=(y*w+x)*4,target=p.slice(start,start+4);const seen=new Uint8Array(w*h),mask=new Uint8Array(w*h),stack=[y*w+x];let x0=w,y0=h,x1=0,y1=0;while(stack.length){const k=stack.pop();if(seen[k])continue;const xx=k%w,yy=Math.floor(k/w),off=k*4;seen[k]=1;if(target.some((n,i)=>p[off+i]!==n))continue;mask[k]=1;x0=Math.min(x0,xx);y0=Math.min(y0,yy);x1=Math.max(x1,xx);y1=Math.max(y1,yy);if(xx>0)stack.push(k-1);if(xx+1<w)stack.push(k+1);if(yy>0)stack.push(k-w);if(yy+1<h)stack.push(k+w);}this.selection=[x0,y0,x1,y1];this.selectionMask=mask;this.refresh();}
  paintGradient(a,b){const e=this.engine,x0=a[0],y0=a[1],dx=b[0]-x0,dy=b[1]-y0,denom=Math.max(1,dx*dx+dy*dy),fg=[...this.color.matchAll(/[0-9a-f]{2}/gi)].map(m=>parseInt(m[0],16)),bg=[...this.bgColor.matchAll(/[0-9a-f]{2}/gi)].map(m=>parseInt(m[0],16));for(let y=0;y<e.height;y++)for(let x=0;x<e.width;x++){if(!this.isSelected(x,y))continue;const t=Math.max(0,Math.min(1,((x-x0)*dx+(y-y0)*dy)/denom));const c=fg.map((v,k)=>Math.round(v*(1-t)+bg[k]*t));this.useMaskPixel(x,y,(0xff000000|c[2]<<16|c[1]<<8|c[0])>>>0);}}
  spray(x,y,color){const radius=Math.max(2,this.size*2);for(let i=0;i<Math.max(4,this.size*2);i++){const a=Math.random()*Math.PI*2,r=Math.sqrt(Math.random())*radius;this.paintPixel(Math.round(x+Math.cos(a)*r),Math.round(y+Math.sin(a)*r),color);}}
  refresh(){if(!this.engine)return;this.refreshColors();this.refreshLayers();this.refreshFrames();this.redraw();this.applyZoomStyle();this.$('dimensions').textContent=`${this.engine.width} × ${this.engine.height}`;this.$('frame-info').textContent=`Frame: ${this.engine.activeFrame+1}/${this.engine.frameCount}`;this.$('duration').value=this.engine.duration;this.$('selectionlabel').textContent=this.selection?'Selección activa':this.projectMeta.tags[this.selectedTag]?.name||'';this.$('engine-type').textContent=this.engine.kind==='wasm'?'Rust/WASM':'JS';}
  changed(){this.dirty=true;this.refresh();this.dispatchEvent(new CustomEvent('vs-pixel-change',{bubbles:true,composed:true,detail:{width:this.engine.width,height:this.engine.height,frame:this.engine.activeFrame,layers:this.engine.layerCount}}));}
  coords(ev){const r=pixelAtClient(ev.clientX,ev.clientY,this.canvas.getBoundingClientRect(),this.engine.width,this.engine.height);return [r.x,r.y];}
  stamp(x,y,color){const begin=Math.floor((this.size-1)/2);for(let oy=-begin;oy<this.size-begin;oy++)for(let ox=-begin;ox<this.size-begin;ox++)this.paintPixel(x+ox,y+oy,color);}
  pixelStroke(x,y,color){
    if(this.size===1&&this.$('perfect')?.checked&&this.strokePath?.length>=2){
      const [a,b]=this.strokePath.slice(-2);
      if(Math.abs(x-a[0])===1&&Math.abs(y-a[1])===1 &&
        ((a[0]===b[0]&&b[1]===y)||(a[1]===b[1]&&b[0]===x))){
          const n=(b[1]*this.engine.width+b[0])*4,p=this.strokeOriginal;
          if(p&&n>=0&&n+3<p.length)this.paintPixel(...b,((p[n+3]<<24)|(p[n+2]<<16)|(p[n+1]<<8)|p[n])>>>0);
        }
    }
    if(!this.strokePath)this.strokePath=[];
    this.strokePath.push([x,y]);this.stamp(x,y,color);
  }
  brushLine(ax,ay,bx,by,color){let x=ax,y=ay;const dx=Math.abs(bx-ax),dy=Math.abs(by-ay),sx=ax<bx?1:-1,sy=ay<by?1:-1;let err=dx-dy;while(true){if(!this.strokePath?.length||this.strokePath.at(-1)[0]!==x||this.strokePath.at(-1)[1]!==y)this.pixelStroke(x,y,color);if(x===bx&&y===by)break;const t=2*err;if(t>-dy){err-=dy;x+=sx;}if(t<dx){err+=dx;y+=sy;}}}
  onDown(ev){if(!this.engine||this.playing)return;if(ev.button!==0&&ev.button!==1)return;ev.preventDefault();this.shadowRoot.querySelector('.studio').focus();const [x,y]=this.coords(ev);this.mouse={x,y};this.start=[x,y];this.last=[x,y];this.pointer=ev.pointerId;this.drawing=true;this.canvas.setPointerCapture(ev.pointerId);
    if(this.tool==='hand'||this.spaceDown||ev.button===1){this.pan={x:ev.clientX,y:ev.clientY,left:this.$('stage').scrollLeft,top:this.$('stage').scrollTop,pointerId:ev.pointerId};return;}
    if(this.tool==='zoom'){this.zoomBy(ev.shiftKey?-1:1,{x:ev.clientX,y:ev.clientY});this.drawing=false;return;}
    if(this.tool==='pick'){this.pick(x,y);this.drawing=false;return;}
    if(this.tool==='marquee'||this.tool==='ellipse-marquee'){this.selection=null;this.selectionMask=null;this.redraw();return;}
    if(this.tool==='wand'){this.magicWand(x,y);this.drawing=false;return;}
    if(this.locked.has(this.engine.activeLayer)){this.notify('Esta capa está bloqueada');this.drawing=false;return;}
    this.engine.begin();const col=this.tool==='eraser'?0:rgbaFromHex(this.color);
    this.strokeOriginal=this.engine.getCelPixels(this.engine.activeFrame,this.engine.activeLayer);this.strokePath=[];
    if(this.tool==='pencil'||this.tool==='eraser')this.pixelStroke(x,y,col);
    if(this.tool==='fill')this.paintFill(x,y,col);
    if(this.tool==='spray')this.spray(x,y,col);
    this.redraw();
  }
  onMove(ev){if(!this.engine)return;const point=pixelAtClient(ev.clientX,ev.clientY,this.canvas.getBoundingClientRect(),this.engine.width,this.engine.height);const {x,y}=point;this.mouse={x,y};this.hover={x:ev.clientX,y:ev.clientY};this.scheduleHover();this.$('coords').textContent=point.inside?`${x}, ${y} px · ${this.tool}`:'Fuera del lienzo';if(!this.drawing||this.pointer!==ev.pointerId)return;
    if(this.pan){const stage=this.$('stage');stage.scrollLeft=this.pan.left-(ev.clientX-this.pan.x);stage.scrollTop=this.pan.top-(ev.clientY-this.pan.y);return;}
    if(this.tool==='pencil'||this.tool==='eraser'){this.brushLine(...this.last,x,y,this.tool==='eraser'?0:rgbaFromHex(this.color));this.last=[x,y];this.scheduleStrokeRedraw();}
    else if(this.tool==='spray'){this.spray(x,y,rgbaFromHex(this.color));this.scheduleStrokeRedraw();}
    else if(this.tool==='marquee'||this.tool==='ellipse-marquee'){this.scheduleStrokeRedraw({rect:bounds(this.start,[x,y])});}
    else if(['line','rect','filledrect','ellipse','filledellipse','gradient'].includes(this.tool)){this.scheduleStrokeRedraw({shape:[this.start,[x,y]]});}
  }
  previewShape(a,b){const [x0,y0,x1,y1]=bounds(a,b);this.ctx.save();this.ctx.strokeStyle=this.color;this.ctx.lineWidth=1;if(this.tool==='line'||this.tool==='gradient'){this.ctx.beginPath();this.ctx.moveTo(a[0]+.5,a[1]+.5);this.ctx.lineTo(b[0]+.5,b[1]+.5);this.ctx.stroke();}else if(this.tool.includes('rect')){if(this.tool==='filledrect'){this.ctx.globalAlpha=.3;this.ctx.fillStyle=this.color;this.ctx.fillRect(x0,y0,x1-x0+1,y1-y0+1);}this.ctx.strokeRect(x0+.5,y0+.5,x1-x0+1,y1-y0+1);}else{this.ctx.beginPath();this.ctx.ellipse((x0+x1+1)/2,(y0+y1+1)/2,Math.max(.5,(x1-x0+1)/2),Math.max(.5,(y1-y0+1)/2),0,0,Math.PI*2);this.ctx.stroke();}this.ctx.restore();}
  onUp(ev){if(!this.drawing||this.pointer!==ev.pointerId)return;const [x,y]=this.coords(ev);if(this.strokeFrame){cancelAnimationFrame(this.strokeFrame);this.strokeFrame=0;this.strokePreview=null;}this.drawing=false;this.pointer=null;if(this.pan){this.pan=null;this.scheduleHover();return;}if(this.tool==='marquee'||this.tool==='ellipse-marquee'){this.setSelection(bounds(this.start,[x,y]),this.tool==='ellipse-marquee'?'ellipse':'rect');this.refresh();return;}
    const c=rgbaFromHex(this.color),e=this.engine;
    if(this.tool==='line')this.paintLine(...this.start,x,y,c);
    if(this.tool==='gradient')this.paintGradient(this.start,[x,y]);
    if(this.tool==='rect'){const [a,b,z,t]=bounds(this.start,[x,y]);this.paintLine(a,b,z,b,c);this.paintLine(a,t,z,t,c);this.paintLine(a,b,a,t,c);this.paintLine(z,b,z,t,c);}
    if(this.tool==='filledrect'){const [ax,ay,bx,by]=bounds(this.start,[x,y]);for(let yy=ay;yy<=by;yy++)this.paintLine(ax,yy,bx,yy,c);}
    if(this.tool==='ellipse'||this.tool==='filledellipse')this.paintEllipse(this.start,[x,y],c,this.tool==='filledellipse');
    e.end();this.strokePath=null;this.strokeOriginal=null;this.changed();
  }
  paintEllipse(a,b,c,filled){const [x0,y0,x1,y1]=bounds(a,b),rx=(x1-x0+1)/2,ry=(y1-y0+1)/2,cx=x0+rx,cy=y0+ry;let prev=null;
    for(let y=y0;y<=y1;y++){let xs=[];for(let x=x0;x<=x1;x++){const nx=(x+.5-cx)/rx,ny=(y+.5-cy)/ry;if(nx*nx+ny*ny<=1.001)xs.push(x);}
      if(filled){if(xs.length)this.paintLine(xs[0],y,xs.at(-1),y,c);}else if(xs.length){this.paintPixel(xs[0],y,c);this.paintPixel(xs.at(-1),y,c);if(prev&&prev[0]!==xs[0])this.paintLine(prev[0],y-1,xs[0],y,c);if(prev&&prev[1]!==xs.at(-1))this.paintLine(prev[1],y-1,xs.at(-1),y,c);prev=[xs[0],xs.at(-1)];}
    }
  }
  pick(x,y){const e=this.engine;if(x<0||y<0||x>=e.width||y>=e.height)return;const p=e.render(),i=(y*e.width+x)*4;this.setColor(hexFromRGBA(p,i));}
  updateStageGutters(){const stage=this.$('stage');if(!stage)return;const surface=this.$('pan-surface');surface.style.setProperty('--gutter-x',stage.clientWidth/2+'px');surface.style.setProperty('--gutter-y',stage.clientHeight/2+'px');}
  viewportCenter(){const r=this.$('stage').getBoundingClientRect();return {x:r.left+r.width/2,y:r.top+r.height/2};}
  /** Keep the image pixel under the pointer stationary while zooming. */
  setZoom(value,anchor=null,preserveFit=false){
    if(!this.engine)return;
    const newZoom=clampZoom(value);
    if(!preserveFit)this.fitMode=false;
    if(Math.abs(newZoom-this.zoom)<0.000001){this.scheduleNavigator();return;}
    const stage=this.$('stage'),point=anchor||this.viewportCenter();
    const source=sourcePoint(point,this.canvas.getBoundingClientRect(),this.zoom,this.engine.width,this.engine.height);
    this.zoom=newZoom;this.applyZoomStyle();
    const delta=anchorScrollDelta(point,this.canvas.getBoundingClientRect(),source,newZoom);
    stage.scrollLeft+=delta.x;stage.scrollTop+=delta.y;
    this.scheduleNavigator();this.scheduleHover();
  }
  zoomBy(direction,anchor=null){this.setZoom(stepZoom(this.zoom,direction),anchor);}
  fitCanvas(){
    if(!this.engine)return;
    const stage=this.$('stage');if(!stage?.clientWidth||!stage?.clientHeight)return;
    this.fitMode=true;this.updateStageGutters();
    const z=fitZoom(stage.clientWidth,stage.clientHeight,this.engine.width,this.engine.height,54);
    this.setZoom(z,null,true);this.centerCanvas();
  }
  centerCanvas(){const stage=this.$('stage');if(!stage)return;
    const canvas=this.canvas.getBoundingClientRect(),stageRect=stage.getBoundingClientRect();
    stage.scrollLeft+=canvas.left+canvas.width/2-(stageRect.left+stageRect.width/2);
    stage.scrollTop+=canvas.top+canvas.height/2-(stageRect.top+stageRect.height/2);
    this.scheduleNavigator();
  }
  panToSource(x,y){const stage=this.$('stage'),canvas=this.canvas.getBoundingClientRect(),view=stage.getBoundingClientRect();
    stage.scrollLeft+=canvas.left+x*this.zoom-(view.left+view.width/2);
    stage.scrollTop+=canvas.top+y*this.zoom-(view.top+view.height/2);
    this.scheduleNavigator();
  }
  scheduleNavigator(imageChanged=false){if(imageChanged)this.navImageDirty=true;if(this.navFrame||!this.isConnected||!this.navigatorVisible)return;
    this.navFrame=requestAnimationFrame(()=>{this.navFrame=0;this.updateNavigator();});
  }
  updateNavigator(){if(!this.engine||!this.navigatorVisible)return;
    const canvas=this.$('nav-canvas'),e=this.engine;
    if(canvas.width!==e.width||canvas.height!==e.height){canvas.width=e.width;canvas.height=e.height;}
    const factor=Math.min(176/e.width,115/e.height);
    canvas.style.width=`${e.width*factor}px`;canvas.style.height=`${e.height*factor}px`;
    const ctx=canvas.getContext('2d');ctx.imageSmoothingEnabled=false;
    if(this.navImageDirty){ctx.clearRect(0,0,e.width,e.height);ctx.drawImage(this.canvas,0,0);this.navImageDirty=false;}
    const src=this.canvas.getBoundingClientRect(),view=this.$('stage').getBoundingClientRect();
    const left=Math.min(1,Math.max(0,(view.left-src.left)/src.width)),top=Math.min(1,Math.max(0,(view.top-src.top)/src.height));
    const right=Math.min(1,Math.max(0,(view.right-src.left)/src.width)),bottom=Math.min(1,Math.max(0,(view.bottom-src.top)/src.height));
    const marker=this.$('nav-viewport');
    marker.style.left=(left*100)+'%';marker.style.top=(top*100)+'%';
    marker.style.width=Math.max(0,(right-left)*100)+'%';marker.style.height=Math.max(0,(bottom-top)*100)+'%';
  }
  toggleNavigator(){this.navigatorVisible=!this.navigatorVisible;
    this.$('navigator').hidden=!this.navigatorVisible;
    if(this.navigatorVisible)this.scheduleNavigator();
  }
  key(ev){if(ev.target.closest('input,textarea,select')||ev.target.isContentEditable)return;const k=ev.key.toLowerCase(),mod=ev.ctrlKey||ev.metaKey;
    if(mod){const map={z:ev.shiftKey?'redo':'undo',y:'redo',n:'new',o:'import',s:'export',a:'selectall',d:'deselect',c:'copy',x:'cut',v:'paste'};if(map[k]){ev.preventDefault();void this.action(map[k]);return;}if(ev.shiftKey&&k==='n'){ev.preventDefault();void this.action('addlayer');return;}}
    if(ev.key==='Delete'||ev.key==='Backspace'){ev.preventDefault();void this.action('deletepixels');return;}
    if(ev.code==='Space'){ev.preventDefault();this.spaceDown=true;this.canvas.style.cursor='grab';return;}
    if(k==='f'){ev.preventDefault();this.fitCanvas();return;}
    if(k==='n'){ev.preventDefault();this.toggleNavigator();return;}
    if(k==='0'){ev.preventDefault();this.setZoom(1);return;}
    if(k==='escape'){this.selection=null;this.redraw();this.closeMenu();return;}
    if(k==='enter'){ev.preventDefault();void this.action('play');return;}
    if(k==='+'||k==='='){void this.action('zoomin');return;}if(k==='-'){void this.action('zoomout');return;}
    const shortcuts={b:'pencil',e:'eraser',g:'fill',d:'gradient',s:'spray',w:'wand',i:'pick',l:'line',u:ev.shiftKey?'filledrect':'rect',o:ev.shiftKey?'filledellipse':'ellipse',m:ev.shiftKey?'ellipse-marquee':'marquee',h:'hand',z:'zoom'};
    if(shortcuts[k]){ev.preventDefault();this.setTool(shortcuts[k]);}
  }
  async action(act){const e=this.engine;switch(act){
    case 'new':{if(this.dirty&&!confirm('Hay cambios sin guardar. ¿Crear otro sprite?'))return;const input=prompt('Nuevo sprite (ancho × alto):','32x32');if(!input)return;const m=input.match(/^(\d+)\s*[x×, ]\s*(\d+)$/i);if(!m){this.notify('Ejemplo de tamaño: 32x32');return;}await this.newDocument(Math.max(1,Math.min(512,+m[1])),Math.max(1,Math.min(512,+m[2])));return;}
    case 'import':if(this.dirty&&!confirm('Hay cambios sin guardar. ¿Abrir otro archivo?'))return;this.$('file').click();return;
    case 'loadpalette':this.$('file').click();return;
    case 'exportpalette':dl(new Blob([encodeGPL(this.getActivePalette(),this.docName)],{type:'text/plain'}),`${this.docName}.gpl`);return;
    case 'undo':e.undo();this.layerMeta=e.layers.map(l=>({...l}));if(e.kind==='js')this.locked=new Set(e.layers.flatMap((l,i)=>l.locked?[i]:[]));break;case 'redo':e.redo();this.layerMeta=e.layers.map(l=>({...l}));if(e.kind==='js')this.locked=new Set(e.layers.flatMap((l,i)=>l.locked?[i]:[]));break;
    case 'addlayer':e.addLayer();this.layerMeta.push({opacity:255,blend:0,kind:0});break;
    case 'layerup':this.moveActiveLayer(1);return;
    case 'layerdown':this.moveActiveLayer(-1);return;
    case 'deletelayer':if(e.layerCount>1&&confirm(`Eliminar ${this.getLayerName(e.activeLayer)}?`)){const at=e.activeLayer;e.deleteLayer(at);this.reindexLayerState(at,-1,true);}break;
    case 'duplicatelayer':{
      const old=e.activeLayer;if(typeof e.duplicateLayer==='function'){e.duplicateLayer(old);
        this.layerMeta.splice(old+1,0,{...this.layerMeta[old]});
        this.locked=new Set(e.layers.flatMap((l,i)=>l.locked?[i]:[]));
      }else {this.notify('Duplicar capas requiere el motor de capas compatible');return;}break;}
    case 'renamelayer':this.renameLayer(e.activeLayer);return;
    case 'togglelayer':e.toggleLayer(e.activeLayer);break;
    case 'addframe':{const after=e.activeFrame;e.addFrame();this.projectMeta.tags=tagsAfterFrameInsert(this.projectMeta.tags,after);break;}
    case 'addlinkedframe':this.addLinkedFrame();return;
    case 'linkcel':if(e.activeFrame>0)this.linkCel(e.activeFrame,e.activeLayer,e.activeFrame-1);else this.notify('El primer fotograma no puede enlazarse');return;
    case 'unlinkcel':this.unlinkCel(e.activeFrame,e.activeLayer);return;
    case 'deleteframe':if(e.frameCount>1){const at=e.activeFrame;e.deleteFrame?.(at);this.projectMeta.tags=tagsAfterFrameDelete(this.projectMeta.tags,at);}break;
    case 'firstframe':e.selectFrame(0);break;case 'lastframe':e.selectFrame(e.frameCount-1);break;
    case 'prevframe':e.selectFrame((e.activeFrame+e.frameCount-1)%e.frameCount);break;
    case 'nextframe':e.selectFrame((e.activeFrame+1)%e.frameCount);break;
    case 'play':this.playing?this.stopPlay():this.startPlay();return;
    case 'zoomin':this.zoomBy(1);return;case 'zoomout':this.zoomBy(-1);return;
    case 'fitzoom':this.fitCanvas();return;
    case 'actualzoom':this.setZoom(1);return;
    case 'centerzoom':this.centerCanvas();return;
    case 'navigator':this.toggleNavigator();return;
    case 'wheelmode':this.wheelMode=this.wheelMode==='zoom'?'pan':'zoom';this.$('wheelmode').textContent='Rueda: '+this.wheelMode;return;
    case 'resetzoom':this.fitCanvas();return;
    case 'grid':this.grid=!this.grid;this.redraw();return;
    case 'onion':this.onion=!this.onion;this.redraw();return;
    case 'export':await this.exportPNG();return;
    case 'sheet':await this.exportSpriteSheet();return;
    case 'exportase':await this.exportAseprite();return;
    case 'exportjson':await this.exportProject();return;
    case 'selectall':this.selection=[0,0,e.width-1,e.height-1];this.selectionMask=null;this.redraw();return;
    case 'deselect':this.selection=null;this.selectionMask=null;this.redraw();return;
    case 'invertselection':{const mask=new Uint8Array(e.width*e.height);for(let y=0;y<e.height;y++)for(let x=0;x<e.width;x++)mask[y*e.width+x]=Number(!this.isSelected(x,y));this.selectionMask=mask;this.selection=[0,0,e.width-1,e.height-1];this.redraw();return;}
    case 'symx':this.symX=!this.symX;this.$('sym-x').checked=this.symX;this.redraw();return;
    case 'symy':this.symY=!this.symY;this.$('sym-y').checked=this.symY;this.redraw();return;
    case 'copy':this.copySelection(false);return;
    case 'cut':this.copySelection(true);return;
    case 'paste':this.pasteSelection();return;
    case 'deletepixels':this.eraseSelection();return;
    case 'swapcolors':{const tmp=this.color;this.color=this.bgColor;this.bgColor=tmp;this.$('hex').value=this.color;break;}
    case 'toggle-timeline':this.$('timeline-content').classList.toggle('collapsed');return;
    case 'properties':alert(`Documento: ${this.docName}\nTamaño: ${e.width}×${e.height}\nRGBA / 32-bit\nCapas: ${e.layerCount}\nFotogramas: ${e.frameCount}`);return;
    case 'flip-h':case 'flip-v':case 'rotate-cw':case 'rotate-ccw':case 'rotate-180':await this.transformDocument(act);return;
    case 'scale':case 'resizecanvas':await this.resizeDialog(act==='scale');return;
    case 'crop':await this.cropSelection();return;
    case 'grayscale':case 'invert':case 'brightness':case 'contrast':case 'hue':case 'threshold':case 'blur':case 'outline':await this.filterDialog(act);return;
    case 'replacecolor':await this.replaceDialog();return;
    case 'quantize':case 'dither':case 'posterize':case 'extractpalette':await this.pixelColorAction(act);return;
    case 'trimtransparent':await this.trimTransparent();return;
    case 'offsettile':case 'alphathreshold':case 'cleanalpha':case 'isolated':case 'inneroutline':case 'tilepreview':case 'pixelstats':await this.pixelPowerAction(act);return;
    case 'layeropacity':this.editLayerOpacity();return;
    case 'layerblend':this.editLayerBlend();return;
    case 'addtag':this.addAnimationTag();return;
    case 'selecttag':this.selectAnimationTag();return;
    case 'deletetag':this.deleteAnimationTag();return;
    case 'about':alert('VS Pixel Studio — interfaz inspirada en Aseprite.\nTema e iconos Aseprite Default Dark: David Capello, Ilija Melentijevic, Nicolas Desilets · CC BY 4.0.\nMotor y web de implementación independiente.');return;
    case 'shortcuts':alert('B Lápiz · E Borrador · G Rellenar · I Cuentagotas · M Selección · L Línea · U Rectángulo · O Elipse · H Mano · Z Zoom\nCtrl+N Nuevo · Ctrl+O Abrir · Ctrl+S PNG · Ctrl+Z/Y Historia · Ctrl+C/X/V Selección · Ctrl+D Deseleccionar');return;
    default:return;
  }this.changed();}
  /** Extended, non-destructive pixel actions. All state changes use engine history. */
  async pixelPowerAction(act){
    const e=this.engine;
    if(act==='tilepreview'){
      const pixels=e.render(),w=e.width,h=e.height;
      const sheet=document.createElement('canvas');sheet.width=w*3;sheet.height=h*3;
      const ctx=sheet.getContext('2d');const single=document.createElement('canvas');single.width=w;single.height=h;
      single.getContext('2d').putImageData(new ImageData(new Uint8ClampedArray(pixels),w,h),0,0);
      ctx.imageSmoothingEnabled=false;for(let y=0;y<3;y++)for(let x=0;x<3;x++)ctx.drawImage(single,x*w,y*h);
      const dialog=document.createElement('div');dialog.className='tile-preview-pop';
      dialog.style.cssText='position:absolute;inset:6%;z-index:100;background:#182137f7;border:1px solid #7d8ea9;border-radius:10px;padding:16px;display:flex;flex-direction:column;gap:12px;align-items:center;justify-content:center';
      const caption=document.createElement('strong');caption.textContent='Vista repetible 3×3 — comprobá uniones y costuras';
      sheet.style.cssText='max-width:95%;max-height:80%;object-fit:contain;image-rendering:pixelated;background:#283248';
      const close=document.createElement('button');close.textContent='Cerrar vista';close.onclick=()=>dialog.remove();
      dialog.append(caption,sheet,close);this.shadowRoot.querySelector('.studio').append(dialog);return;
    }
    const original=e.getCelPixels(),w=e.width,h=e.height;
    if(act==='pixelstats'){
      const s=spriteStatistics(original,w,h);
      this.notify(`Píxeles: ${s.visible} visibles · ${s.colors}${s.colorsOverLimit?'+':''} colores · ${s.partial} semitransparentes`);
      alert(`Capa actual: ${this.getLayerName(e.activeLayer)}\nDimensión: ${w} × ${h}\nPíxeles visibles: ${s.visible}\nTransparentes: ${s.transparent}\nSemitransparentes: ${s.partial}\nColores diferentes: ${s.colors}${s.colorsOverLimit?'+':''}\nContenido: ${s.bounds?s.bounds.join(', '):'vacío'}`);return;
    }
    if(this.locked.has(e.activeLayer)){this.notify('Desbloqueá la capa para editarla');return;}
    let result;
    if(act==='offsettile'){
      const raw=prompt('Desplazar X,Y con envoltura (ej. 8,-4):','8,0');if(raw===null)return;
      const match=raw.trim().match(/^(-?\d+)\s*[,; ]\s*(-?\d+)$/);
      if(!match){this.notify('Ingresá X,Y en píxeles enteros');return;}
      result=offsetTile(original,w,h,Number(match[1]),Number(match[2]));
    }else if(act==='alphathreshold'){
      const raw=prompt('Umbral de alfa (0-255):','128');if(raw===null)return;
      const threshold=Number(raw);if(!Number.isInteger(threshold)||threshold<0||threshold>255){this.notify('Umbral fuera de rango');return;}
      result=alphaThreshold(original,w,h,threshold);
    }else if(act==='cleanalpha')result=clearTransparentRGB(original,w,h);
    else if(act==='isolated'){
      if(!confirm('Eliminar píxeles aislados (sin vecinos ortogonales) en la capa actual? Podés deshacer.'))return;
      result=eraseIsolated(original,w,h);
    }else if(act==='inneroutline'){
      const hex=prompt('Color del contorno interior (#RRGGBB):',this.bgColor);if(hex===null)return;
      if(!/^#[0-9a-f]{6}$/i.test(hex)){this.notify('Color hex inválido');return;}
      result=innerOutline(original,w,h,hex);
    }
    if(result){
      if(this.selection||this.selectionMask){for(let y=0;y<h;y++)for(let x=0;x<w;x++)if(!this.isSelected(x,y)){
        const n=(y*w+x)*4;result.set(original.subarray(n,n+4),n);
      }}
      e.setCelPixels(result);this.changed();this.notify('Operación aplicada a la capa · Ctrl+Z para deshacer');
    }
  }
  /** Mathematical pixel-art tools; operate on the selected cel and preserve RGBA/undo. */
  async pixelColorAction(action){
    if(this.locked.has(this.engine.activeLayer)){this.notify('La capa está bloqueada');return;}
    const countRaw=prompt(action==='posterize'?'Niveles por canal (2–32):':'Cantidad de colores (2–64):',action==='posterize'?'4':'16');
    if(countRaw===null)return;
    const count=Number(countRaw),min=2,max=action==='posterize'?32:64;
    if(!Number.isInteger(count)||count<min||count>max){this.notify(`Ingresá un entero entre ${min} y ${max}`);return;}
    const engine=this.engine,original=engine.getCelPixels(),region=this.selection;
    let pixels,colors=null;
    if(action==='posterize'){const rust=!region&&!this.selectionMask?await loadKernels():null;pixels=rust?rust.posterize(original,count):posterizeRGBA(original,engine.width,engine.height,count,{region});}
    else if(action==='extractpalette'){
      colors=paletteFromPixels(engine.render(),engine.width,engine.height,count,{region});
      if(!colors.length){this.notify('No hay píxeles con color');return;}
      this.setExtractedPalette(colors);this.notify('Paleta extraída · '+colors.length+' colores');this.changed();return;
    }else{
      const result=reducePalette(original,engine.width,engine.height,count,{region,dither:action==='dither'});
      pixels=result.pixels;colors=result.palette;
      if(action==='quantize'&&!region&&!this.selectionMask&&colors.length){const rust=await loadKernels();if(rust)pixels=rust.quantize(original,colors);}
    }
    if(this.selectionMask)for(let i=0;i<pixels.length;i+=4)if(!this.selectionMask[i/4])pixels.set(original.subarray(i,i+4),i);
    engine.setCelPixels(pixels);
    if(colors?.length)this.setExtractedPalette(colors);
    this.changed();this.notify(action==='dither'?'Tramado aplicado':action==='quantize'?'Paleta reducida':'Posterización aplicada');
  }
  setExtractedPalette(colors){
    this.projectMeta.palette=colors.map(c=>[...c,255]);
    PALETTE.splice(0,PALETTE.length,...colors.map(c=>'#'+c.map(v=>v.toString(16).padStart(2,'0')).join('')));
    this.refreshColors();
  }
  async trimTransparent(){
    const project=this.getProject(),bounds=alphaContentBounds(project.frames,project.width,project.height);
    if(!bounds){this.notify('El documento no contiene píxeles visibles');return;}
    if(bounds[0]===0&&bounds[1]===0&&bounds[2]===project.width-1&&bounds[3]===project.height-1){this.notify('El lienzo ya está ajustado al contenido');return;}
    const cropped=croppedProject(project,...bounds),layer=this.engine.activeLayer,frame=this.engine.activeFrame;
    await this.applyProject(cropped);this.engine.selectLayer(Math.min(layer,this.engine.layerCount-1));this.engine.selectFrame(Math.min(frame,this.engine.frameCount-1));
    this.changed();this.notify(`Límites ajustados: ${cropped.width} × ${cropped.height}`);
  }
  // Public embedding API: no browser dialogs; safe for third-party hosts.
  async resizeDocument(width,height,{scale=false,anchor='center'}={}){
    const e=this.engine;if(!Number.isInteger(width)||!Number.isInteger(height)||width<1||height<1||width>512||height>512)throw Error('Dimensiones fuera de rango (1-512)');
    const doc=resizedProject(this.getProject(),width,height,{scale,anchor}),layer=e.activeLayer,frame=e.activeFrame,name=this.docName;
    await this.applyProject(doc);this.engine.selectLayer(layer);this.engine.selectFrame(frame);this.docName=name;this.changed();
  }
  applyFilter(kind,options={}){
    const e=this.engine;if(this.locked.has(e.activeLayer))throw Error('Capa bloqueada');
    const original=e.getCelPixels(),result=filterImage(original,e.width,e.height,kind,{...options,region:options.region??this.selection});
    if(this.selectionMask)for(let i=0;i<result.length;i+=4)if(!this.selectionMask[i/4])result.set(original.subarray(i,i+4),i);
    e.setCelPixels(result);this.changed();
    return result;
  }
  setLayerOpacity(layer,value){const e=this.engine;if(e.kind!=='js')throw Error('Opacidad requiere motor JS');if(!Number.isInteger(layer)||layer<0||layer>=e.layerCount||!Number.isFinite(value))throw Error('Capa/opacidad incorrecta');const opacity=Math.max(0,Math.min(255,Math.round(value)));e.transaction(()=>e.layers[layer].opacity=opacity);this.layerMeta[layer]={...this.layerMeta[layer],opacity};this.changed();}
  setLayerBlend(layer,blend){const e=this.engine;if(e.kind!=='js')throw Error('Fusión requiere motor JS');if(!Number.isInteger(layer)||layer<0||layer>=e.layerCount||!Number.isInteger(blend))throw Error('Capa/modo de fusión incorrecto');e.transaction(()=>e.layers[layer].blend=blend);this.layerMeta[layer]={...this.layerMeta[layer],blend};this.changed();}
  getCelLink(frame=this.engine.activeFrame,layer=this.engine.activeLayer){return this.engine.getCelLink?.(frame,layer)??null;}
  linkCel(frame,layer,sourceFrame){
    if(!this.engine.linkCel)throw Error('Los cels vinculados requieren el motor JS en esta versión');
    this.engine.linkCel(frame,layer,sourceFrame);this.changed();
  }
  unlinkCel(frame=this.engine.activeFrame,layer=this.engine.activeLayer){
    if(!this.engine.unlinkCel)throw Error('Desvincular cels requiere el motor JS');
    this.engine.unlinkCel(frame,layer);this.changed();
  }
  addLinkedFrame(){
    if(!this.engine.addLinkedFrame)throw Error('El fotograma vinculado requiere el motor JS');
    const after=this.engine.activeFrame;this.engine.addLinkedFrame();this.projectMeta.tags=tagsAfterFrameInsert(this.projectMeta.tags,after);this.changed();
  }
  getAnimationTags(){return this.projectMeta.tags.map(t=>({...t}));}
  setAnimationTags(tags){if(!Array.isArray(tags)||tags.some(t=>!Number.isInteger(t.from)||!Number.isInteger(t.to)||t.from<0||t.to>=this.engine.frameCount||t.to<t.from))throw Error('Etiquetas inválidas');this.projectMeta.tags=tags.map(t=>({...t}));this.changed();}
  editLayerOpacity(){if(this.engine.kind!=='js'){this.notify('Esta opción requiere motor JS en esta versión');return;}const e=this.engine,i=e.activeLayer;const v=prompt('Opacidad de capa (0-255)',String(e.layers[i].opacity??255));if(v===null)return;const opacity=Math.max(0,Math.min(255,Math.round(Number(v))));if(!Number.isFinite(opacity))return;e.transaction(()=>e.layers[i].opacity=opacity);this.layerMeta[i]={...this.layerMeta[i],opacity};this.changed();}
  editLayerBlend(){if(this.engine.kind!=='js'){this.notify('Esta opción requiere motor JS en esta versión');return;}const e=this.engine,i=e.activeLayer;const modes={normal:0,multiplicar:1,pantalla:2,superponer:3,oscurecer:4,aclarar:5,diferencia:10,exclusión:11,sumar:16,restar:17,dividir:18};const v=prompt('Modo de fusión: '+Object.keys(modes).join(', '),'normal');if(!v)return;const blend=modes[v.toLowerCase().trim()];if(blend===undefined){this.notify('Modo de fusión inválido');return;}e.transaction(()=>e.layers[i].blend=blend);this.layerMeta[i]={...this.layerMeta[i],blend};this.changed();}
  addAnimationTag(){const e=this.engine,name=prompt('Nombre de la etiqueta:','Animación');if(!name?.trim())return;const end=prompt('Último fotograma (1 a '+e.frameCount+'): ',String(e.frameCount));if(end===null)return;const to=Math.round(Number(end))-1;if(!Number.isInteger(to)||to<e.activeFrame||to>=e.frameCount){this.notify('Fotograma final inválido');return;}this.projectMeta.tags.push({name:name.trim(),from:e.activeFrame,to,direction:0,repeat:0,color:[237,178,77]});this.selectedTag=this.projectMeta.tags.length-1;this.changed();}
  selectAnimationTag(){const tags=this.projectMeta.tags;if(!tags.length){this.notify('No hay etiquetas');return;}const v=prompt('Etiqueta a reproducir (nombre o número), 0 = toda la animación',tags[this.selectedTag??0]?.name||'0');if(v===null)return;let i=/^\d+$/.test(v)?Number(v)-1:tags.findIndex(t=>t.name===v);if(v==='0')i=-1;if(i>=tags.length||i<-1){this.notify('Etiqueta inválida');return;}this.selectedTag=i>=0?i:null;this.changed();}
  deleteAnimationTag(){const i=this.selectedTag??0;if(!this.projectMeta.tags.length)return;const tag=this.projectMeta.tags[i];if(!confirm('Eliminar etiqueta '+tag.name+'?'))return;this.projectMeta.tags.splice(i,1);this.selectedTag=null;this.changed();}
  async transformDocument(operation){const current=this.getProject(),layer=this.engine.activeLayer,frame=this.engine.activeFrame,name=this.docName;await this.applyProject(transformedProject(current,operation));this.engine.selectFrame(frame);this.engine.selectLayer(layer);this.docName=name;this.refresh();this.changed();}
  async resizeDialog(scale){const old=this.engine,prompted=prompt(scale?'Escalar sprite, sin interpolación (ancho x alto):':'Cambiar tamaño del lienzo (ancho x alto):',`${old.width}x${old.height}`);if(!prompted)return;const m=prompted.match(/^(\d+)\s*[x×, ]\s*(\d+)$/i);if(!m||+m[1]<1||+m[2]<1||+m[1]>512||+m[2]>512){this.notify('Ingresá dimensiones de 1 a 512 píxeles');return;}await this.resizeDocument(+m[1],+m[2],{scale,anchor:'center'});}
  async cropSelection(){if(!this.selection){this.notify('Primero seleccioná una zona');return;}const name=this.docName,frame=this.engine.activeFrame,layer=this.engine.activeLayer;const doc=croppedProject(this.getProject(),...this.selection);await this.applyProject(doc);this.engine.selectFrame(frame);this.engine.selectLayer(layer);this.docName=name;this.changed();}
  async filterDialog(type){if(this.locked.has(this.engine.activeLayer)){this.notify('La capa está bloqueada');return;}const labels={brightness:'Brillo (-255 a +255)',contrast:'Contraste (-254 a +254)',hue:'Girar matiz (grados)',threshold:'Umbral (0 a 255)',blur:'Radio de desenfoque (1 a 3)'};let amount=type==='threshold'?128:type==='blur'?1:30;if(labels[type]){const raw=prompt(labels[type]+':',String(amount));if(raw===null)return;amount=Number(raw);if(!Number.isFinite(amount)){this.notify('Valor incorrecto');return;}}this.applyFilter(type,{amount,color:[...this.bgColor.matchAll(/[0-9a-f]{2}/gi)].map(x=>parseInt(x[0],16)).concat(255)});}
  async replaceDialog(){const from=prompt('Color de origen (hex):',this.color);if(!from)return;const to=prompt('Color de reemplazo (hex):',this.bgColor);if(!to)return;if(!/^#[0-9a-f]{6}$/i.test(from)||!/^#[0-9a-f]{6}$/i.test(to)){this.notify('Usá colores #RRGGBB');return;}const parse=c=>[...c.slice(1).matchAll(/.{2}/g)].map(m=>parseInt(m[0],16)).concat(255);const e=this.engine,p=e.getCelPixels(),r=replaceColor(p,parse(from),parse(to),{region:this.selection,width:e.width});if(this.selectionMask)for(let i=0;i<p.length;i+=4)if(!this.selectionMask[i/4])r.pixels.set(p.subarray(i,i+4),i);e.setCelPixels(r.pixels);this.changed();this.notify(`${r.count} píxeles reemplazados`);}
  renameLayer(i){const n=prompt('Nombre de la capa:',this.getLayerName(i));if(n?.trim()){if(this.engine.renameLayer)this.engine.renameLayer(i,n.trim());else this.setLayerName(i,n.trim());this.changed();}}
  copySelection(cut=false){const e=this.engine,cel=e.getCelPixels(e.activeFrame,e.activeLayer),r=this.selection||[0,0,e.width-1,e.height-1];const [x0,y0,x1,y1]=r,w=x1-x0+1,h=y1-y0+1,p=new Uint8ClampedArray(w*h*4);
    for(let y=0;y<h;y++)for(let x=0;x<w;x++)if(x+x0>=0&&y+y0>=0&&x+x0<e.width&&y+y0<e.height&&this.isSelected(x+x0,y+y0))p.set(cel.subarray(((y+y0)*e.width+x+x0)*4,((y+y0)*e.width+x+x0+1)*4),(y*w+x)*4);
    this.clipboard={w,h,p};if(cut)this.eraseSelection();else this.notify('Píxeles copiados');
  }
  eraseSelection(){if(this.locked.has(this.engine.activeLayer))return;const e=this.engine,r=this.selection||[0,0,e.width-1,e.height-1];e.begin();for(let y=Math.max(0,r[1]);y<=Math.min(e.height-1,r[3]);y++)for(let x=Math.max(0,r[0]);x<=Math.min(e.width-1,r[2]);x++)if(this.isSelected(x,y))e.pixel(x,y,0);e.end();this.changed();}
  pasteSelection(){if(!this.clipboard||this.locked.has(this.engine.activeLayer))return;const e=this.engine,{w,h,p}=this.clipboard,sx=this.selection?.[0]||0,sy=this.selection?.[1]||0;e.begin();for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;if(p[i+3])e.pixel(sx+x,sy+y,(p[i+3]<<24|p[i+2]<<16|p[i+1]<<8|p[i])>>>0);}e.end();this.selection=[sx,sy,Math.min(e.width-1,sx+w-1),Math.min(e.height-1,sy+h-1)];this.selectionMask=null;this.changed();}
  async newDocument(w=32,h=32){this.fitMode=true;this.stopPlay();this.engine?.dispose?.();this.engine=await createEngine(w,h);this.locked.clear();this.selection=null;this.selectionMask=null;this.projectMeta={tags:[],slices:[],palette:null};this.selectedTag=null;this.layerMeta=[];this.dirty=false;this.hideHover();this.docName='Sprite-1';this.updateTab();this.refresh();requestAnimationFrame(()=>{if(this.isConnected)this.fitCanvas();});}
  updateTab(){this.shadowRoot.querySelector('.document-tab').innerHTML=`${esc(this.docName)}.aseprite <span class="mod-marker">●</span>`;}
  async openFile(file){const ext=file.name.toLowerCase();if(ext.endsWith('.gpl')||ext.endsWith('.pal')){this.importPalette(await file.text());return;}if(ext.endsWith('.ase')||ext.endsWith('.aseprite'))await this.openASE(file);else if(ext.endsWith('.json'))await this.openProject(file);else await this.openPNG(file);this.docName=file.name.replace(/\.(aseprite|ase|png|jpe?g|bmp|webp|json)$/i,'');this.dirty=false;this.updateTab();}
  getActivePalette(){return this.projectMeta.palette||PALETTE.map(hex=>[...hex.slice(1).matchAll(/.{2}/g)].map(m=>parseInt(m[0],16)).concat(255));}
  importPalette(text){const colors=parsePalette(text);this.projectMeta.palette=colors.map(c=>[...c]);this.projectMeta.paletteName='imported';this.$('palette-profile').value='default';PALETTE.splice(0,PALETTE.length,...colors.map(rgbToHex));this.refreshColors();this.notify(`Paleta importada: ${colors.length} colores`);}
  async openPNG(file){const bitmap=await createImageBitmap(file);const w=bitmap.width,h=bitmap.height;if(w>512||h>512){bitmap.close();throw new Error('El tamaño máximo actual es 512×512');}await this.newDocument(w,h);const c=document.createElement('canvas');c.width=w;c.height=h;const cx=c.getContext('2d',{willReadFrequently:true});cx.drawImage(bitmap,0,0);bitmap.close();this.engine.setCelPixels(cx.getImageData(0,0,w,h).data);this.changed();}
  async openASE(file){const content=await parseAseprite(await file.arrayBuffer());await this.applyProject(content);this.notify('Aseprite importado: '+content.frames.length+' fotogramas, '+content.layers.length+' capas');}
  async applyProject(doc){if(!doc||!Number.isInteger(doc.width)||!Number.isInteger(doc.height)||doc.width<1||doc.width>512||doc.height<1||doc.height>512||!Array.isArray(doc.layers)||!doc.layers.length||doc.layers.length>128||!Array.isArray(doc.frames)||!doc.frames.length||doc.frames.length>512)throw new Error('Proyecto inválido o demasiado grande');
    await this.newDocument(doc.width,doc.height);const e=this.engine;
    for(let i=1;i<doc.layers.length;i++)e.addLayer();
    this.projectMeta={tags:(doc.tags||[]).map(t=>({...t})),slices:(doc.slices||[]).map(t=>({...t})),palette:doc.palette?.map(c=>[...c])||null};
    if(this.projectMeta.palette?.length)PALETTE.splice(0,PALETTE.length,...this.projectMeta.palette.slice(0,64).map(rgbToHex));
    this.layerMeta=doc.layers.map(l=>({...l}));this.locked=new Set(doc.layers.flatMap((l,i)=>l.locked?[i]:[]));
    for(let i=0;i<doc.layers.length;i++){this.setLayerName(i,doc.layers[i].name||`Capa ${i+1}`);if(doc.layers[i].visible===false)e.toggleLayer(i);if(e.kind==='js')Object.assign(e.layers[i],{opacity:doc.layers[i].opacity??255,blend:doc.layers[i].blend??0,kind:doc.layers[i].kind??0,childLevel:doc.layers[i].childLevel??0,locked:!!doc.layers[i].locked});}
    for(let i=1;i<doc.frames.length;i++)e.addFrame();
    for(let f=0;f<doc.frames.length;f++){e.selectFrame(f);e.duration=doc.frames[f].duration||120;for(let l=0;l<doc.layers.length;l++){e.selectLayer(l);const data=doc.frames[f].cels[l];if(!data)continue;const pixels=data instanceof Uint8ClampedArray?data:new Uint8ClampedArray(data);if(pixels.length!==doc.width*doc.height*4)throw new Error('Cel inválido');e.setCelPixels(pixels);}}
    // Restore links after all raster data has been loaded, including transitive links.
    for(let f=0;f<doc.frames.length;f++)for(let l=0;l<doc.layers.length;l++){
      const target=doc.frames[f].links?.[l];
      if(target!==null&&target!==undefined){if(!e.linkCel)throw Error('El motor cargado no admite cels enlazados');e.linkCel(f,l,target);}
    }
    if(e.kind==='js'){e.history.length=0;e.future.length=0;}
    e.selectFrame(0);e.selectLayer(doc.layers.length-1);this.changed();
  }
  getProject(){const e=this.engine;return {width:e.width,height:e.height,layers:e.layers.map((l,i)=>({...this.layerMeta[i],...l,locked:this.locked.has(i)})),tags:this.projectMeta.tags.map(t=>({...t})),slices:this.projectMeta.slices.map(t=>({...t})),palette:this.projectMeta.palette?.map(c=>[...c])||undefined,frames:range(e.frameCount).map(f=>({duration:(()=>{const old=e.activeFrame;e.selectFrame(f);const duration=e.duration;e.selectFrame(old);return duration;})(),cels:range(e.layerCount).map(l=>e.getCelPixels(f,l)),links:range(e.layerCount).map(l=>e.getCelLink?.(f,l)??null)}))};}
  async openProject(file){const obj=JSON.parse(await file.text());if(obj.format!=='vs-pixel-studio/1')throw new Error('Archivo de proyecto VS inválido');await this.applyProject(obj);}
  async exportProject(){const d=this.getProject();d.frames.forEach(f=>f.cels=f.cels.map(c=>Array.from(c)));d.format='vs-pixel-studio/1';dl(new Blob([JSON.stringify(d)],{type:'application/json'}),`${this.docName}.vspixel.json`);}
  async exportAseprite(){try{const out=await encodeAsepriteCompressed(this.getProject());dl(new Blob([out],{type:'application/octet-stream'}),`${this.docName}.aseprite`);}catch(err){this.notify(err.message);}}
  async toPNGBlob(){const e=this.engine;return pngBlob(e.render(),e.width,e.height);}
  async loadFromURL(url){const response=await fetch(url);if(!response.ok)throw new Error(`No se pudo cargar ${url}: ${response.status}`);const body=await response.blob(),name=new URL(url,location.href).pathname.split('/').pop();return this.openFile(new File([body],name));}
  async exportPNG(){dl(await this.toPNGBlob(),`${this.docName}.png`);}
  async exportSpriteSheet(){const e=this.engine,w=e.width,h=e.height,count=e.frameCount;if(w*count>16384){this.notify('Spritesheet demasiado grande');return;}const out=new Uint8ClampedArray(w*count*h*4);for(let f=0;f<count;f++){const p=e.render(f);for(let y=0;y<h;y++)out.set(p.subarray(y*w*4,(y+1)*w*4),(y*w*count+f*w)*4);}dl(await pngBlob(out,w*count,h),`${this.docName}-sheet.png`);}
  startPlay(){
    if(this.engine.frameCount<2)return;
    const btn=this.$('playbtn');btn.textContent='■';
    const tag=this.projectMeta.tags[this.selectedTag];
    const cursor=new AnimationCursor(tag?.from??0,tag?.to??(this.engine.frameCount-1),tag?.direction??0,tag?.repeat??0);
    this.engine.selectFrame(cursor.current);this.refresh();
    const next=()=>{
      const frame=cursor.next();
      if(frame===null){this.stopPlay();this.refresh();return;}
      this.engine.selectFrame(frame);this.refresh();
      this.playing=setTimeout(next,this.engine.duration);
    };
    this.playing=setTimeout(next,this.engine.duration);
  }
  stopPlay(){if(this.playing){clearTimeout(this.playing);this.playing=null;}if(this.$('playbtn'))this.$('playbtn').textContent='▶';}
  getPixels(){return this.engine?.render();}
}
if(!customElements.get('vs-pixel-studio'))customElements.define('vs-pixel-studio',VSPixelStudio);
