// GIMP GPL and JASC-PAL palette interchange, independently implemented.
const rgb=v=>[Number(v[0]),Number(v[1]),Number(v[2])];
export const rgbToHex = ([r,g,b]) => '#'+[r,g,b].map(x=>Math.max(0,Math.min(255,Math.round(x))).toString(16).padStart(2,'0')).join('');
export function parsePalette(text) {
  const lines=String(text).replace(/\r/g,'').split('\n').map(s=>s.trim()).filter(Boolean);
  const first=lines[0];if(!['GIMP Palette','JASC-PAL'].includes(first))throw Error('Solo paletas GIMP .gpl o JASC .pal');
  const colors=[];
  const entries=first==='JASC-PAL'?lines.slice(3):lines.slice(1).filter(s=>!s.startsWith('#')&&!/^(Name|Columns)\s*:/i.test(s));
  for(const line of entries){const m=line.match(/^(\d{1,3})\s+(\d{1,3})\s+(\d{1,3})(?:\s+.*)?$/);if(!m)continue;const c=m.slice(1,4).map(Number);if(c.some(n=>n>255))throw Error('Componente RGB fuera de rango');colors.push([...c,255]);if(colors.length>256)throw Error('Máximo 256 colores');}
  if(!colors.length)throw Error('No se encontraron colores');
  return colors;
}
export function encodeGPL(colors,name='VS Pixel Studio'){
  const lines=['GIMP Palette','Name: '+name,'Columns: 8','# Exportado por VS Pixel Studio'];
  for(const [r,g,b] of colors)lines.push(`${String(r).padStart(3)} ${String(g).padStart(3)} ${String(b).padStart(3)} Untitled`);
  return lines.join('\n')+'\n';
}
