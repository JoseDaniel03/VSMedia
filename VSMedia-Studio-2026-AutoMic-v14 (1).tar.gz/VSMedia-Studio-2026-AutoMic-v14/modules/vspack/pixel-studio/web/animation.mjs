// Independent Aseprite-style frame-tag playback sequencer.
// 0 forward, 1 reverse, 2 ping-pong, 3 reverse ping-pong.
export function animationSequence(first,last,direction=0){
  if(!Number.isInteger(first)||!Number.isInteger(last)||first<0||last<first||![0,1,2,3].includes(direction))throw new RangeError('Etiqueta de animación inválida');
  const f=Array.from({length:last-first+1},(_,i)=>first+i),r=[...f].reverse();
  if(direction===0)return f;
  if(direction===1)return r;
  if(direction===2)return f.length<=2?[...f,...r.slice(1,-1)]:[...f,...r.slice(1,-1)];
  return [...r,...f.slice(1,-1)];
}
export class AnimationCursor {
  constructor(first,last,direction=0,repeat=0){
    if(!Number.isInteger(repeat)||repeat<0||repeat>65535)throw new RangeError('Repeticiones inválidas');
    this.sequence=animationSequence(first,last,direction);
    this.repeat=repeat;
    this.index=0;
    this.cycles=0;
  }
  get current(){return this.sequence[this.index];}
  // null indicates the last complete cycle finished, 0 repeats means infinite.
  next(){
    if(this.index<this.sequence.length-1){this.index++;return this.current;}
    this.cycles++;
    if(this.repeat!==0&&this.cycles>=this.repeat)return null;
    this.index=0;return this.current;
  }
}

// Keep animation tag ranges consistent when frames are inserted or removed.
export function tagsAfterFrameInsert(tags,after){
  return tags.map(t=>{
    if(t.from>after)return {...t,from:t.from+1,to:t.to+1};
    if(t.to>=after)return {...t,to:t.to+1};
    return {...t};
  });
}
export function tagsAfterFrameDelete(tags,at){
  return tags.map(t=>{
    const from=t.from-(at<t.from?1:0),to=t.to-(at<=t.to?1:0);
    return {...t,from,to};
  }).filter(t=>t.from<=t.to);
}
