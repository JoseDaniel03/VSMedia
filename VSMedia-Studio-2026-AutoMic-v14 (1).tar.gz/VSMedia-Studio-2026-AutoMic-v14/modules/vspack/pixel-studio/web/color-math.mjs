/* VS Pixel Studio: independent deterministic color maths; no dependencies.
 * Pixel-art operations preserve source alpha (including partial transparency).
 */
const byte=v=>Math.max(0,Math.min(255,Math.round(v)));
const inside=(x,y,r)=>!r||(x>=r[0]&&x<=r[2]&&y>=r[1]&&y<=r[3]);
const perceptual=(a,b)=>{const dr=a[0]-b[0],dg=a[1]-b[1],db=a[2]-b[2];return 3*dr*dr+4*dg*dg+2*db*db;};
function check(p,w,h){if(!(p instanceof Uint8Array||p instanceof Uint8ClampedArray)||!Number.isInteger(w)||!Number.isInteger(h)||w<1||h<1||p.length!==w*h*4)throw Error('Tamaño RGBA inválido');}
export function paletteFromPixels(data,w,h,colors=16,{region=null,iterations=7}={}){
  check(data,w,h);colors=Math.max(2,Math.min(64,Math.round(colors)));
  // Bucket histogram: bounded 32768 entries even for photos or large textures.
  const histogram=new Map();
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){
    if(!inside(x,y,region))continue;
    const i=(y*w+x)*4,alpha=data[i+3];if(alpha===0)continue;
    const key=((data[i]>>3)<<10)|((data[i+1]>>3)<<5)|(data[i+2]>>3);
    let entry=histogram.get(key);if(!entry){entry={sum:[0,0,0],weight:0};histogram.set(key,entry);}
    entry.sum[0]+=data[i]*alpha;entry.sum[1]+=data[i+1]*alpha;entry.sum[2]+=data[i+2]*alpha;entry.weight+=alpha;
  }
  if(!histogram.size)return [];
  const bins=[...histogram.values()].map(e=>({c:e.sum.map(x=>x/e.weight),weight:e.weight}));
  bins.sort((a,b)=>b.weight-a.weight);
  const k=Math.min(colors,bins.length),centers=[bins[0].c.slice()];
  // Weighted farthest-point initialization with cached nearest centroid.
  // O(k * bins), instead of the quadratic O(k² * bins) search.
  const nearest=new Float64Array(bins.length).fill(Infinity);
  while(centers.length<k){
    const latest=centers[centers.length-1];let candidate=bins[0].c,score=-1;
    for(let i=0;i<bins.length;i++){
      const sample=bins[i];nearest[i]=Math.min(nearest[i],perceptual(sample.c,latest));
      const weighted=nearest[i]*Math.sqrt(sample.weight);
      if(weighted>score){score=weighted;candidate=sample.c;}
    }
    centers.push(candidate.slice());
  }
  for(let it=0;it<iterations;it++){
    const sums=Array.from({length:k},()=>[0,0,0,0]);
    for(const b of bins){let chosen=0,best=Infinity;for(let j=0;j<k;j++){const d=perceptual(b.c,centers[j]);if(d<best){chosen=j;best=d;}}const s=sums[chosen];s[0]+=b.c[0]*b.weight;s[1]+=b.c[1]*b.weight;s[2]+=b.c[2]*b.weight;s[3]+=b.weight;}
    for(let j=0;j<k;j++)if(sums[j][3])centers[j]=sums[j].slice(0,3).map(x=>x/sums[j][3]);
  }
  // Collapse duplicate centroids after rounding; Aseprite palette accepts RGBA.
  const unique=new Set();return centers.map(c=>c.map(byte)).filter(c=>{const key=c.join(',');if(unique.has(key))return false;unique.add(key);return true;});
}
export function quantizeRGBA(data,w,h,palette,{dither=false,region=null}={}){
  check(data,w,h);if(!Array.isArray(palette)||!palette.length)throw Error('Paleta vacía');
  const out=new Uint8ClampedArray(data),color=palette.map(p=>p.slice(0,3).map(byte));
  const near=(r,g,b)=>{let selected=0,dist=Infinity;const v=[r,g,b];for(let c=0;c<color.length;c++){const d=perceptual(v,color[c]);if(d<dist){dist=d;selected=c;}}return color[selected];};
  // Floyd–Steinberg error diffusion, independent RGB, no alpha bleed or wrap at line edges.
  const error=dither?new Float32Array(w*h*3):null;
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){
    if(!inside(x,y,region))continue;
    const pixel=y*w+x,i=pixel*4;if(data[i+3]===0)continue;
    const base=pixel*3,r=byte(data[i]+(error?.[base]||0)),g=byte(data[i+1]+(error?.[base+1]||0)),b=byte(data[i+2]+(error?.[base+2]||0));
    const chosen=near(r,g,b);out.set(chosen,i);
    if(!dither)continue;
    const dif=[r-chosen[0],g-chosen[1],b-chosen[2]];
    const spread=(xx,yy,factor)=>{if(xx<0||yy<0||xx>=w||yy>=h||!inside(xx,yy,region)||data[(yy*w+xx)*4+3]===0)return;const dest=(yy*w+xx)*3;for(let c=0;c<3;c++)error[dest+c]+=dif[c]*factor;};
    spread(x+1,y,7/16);spread(x-1,y+1,3/16);spread(x,y+1,5/16);spread(x+1,y+1,1/16);
  }
  return out;
}
export function reducePalette(data,w,h,count=16,opts={}){
  const palette=paletteFromPixels(data,w,h,count,opts);
  return {palette,pixels:palette.length?quantizeRGBA(data,w,h,palette,opts):new Uint8ClampedArray(data)};
}
export function posterizeRGBA(data,w,h,levels=4,{region=null}={}){
  check(data,w,h);levels=Math.max(2,Math.min(32,Math.round(levels)));
  const out=new Uint8ClampedArray(data),factor=255/(levels-1);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){
    if(!inside(x,y,region))continue;const i=(y*w+x)*4;
    if(!data[i+3])continue;
    for(let c=0;c<3;c++)out[i+c]=byte(Math.round(data[i+c]/factor)*factor);
  }
  return out;
}
export function alphaContentBounds(frames,width,height){
  let left=width,top=height,right=-1,bottom=-1;
  for(const frame of frames)for(const pixels of frame.cels){
    if(pixels?.length!==width*height*4)throw Error('Cel de tamaño inesperado');
    for(let y=0;y<height;y++)for(let x=0;x<width;x++)if(pixels[(y*width+x)*4+3]){
      if(x<left)left=x;if(x>right)right=x;if(y<top)top=y;if(y>bottom)bottom=y;
    }
  }
  return right<0?null:[left,top,right,bottom];
}
