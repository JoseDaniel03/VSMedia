// Independently written ASE/ASEPRITE RGBA parser/writer using the documented file format.
// Only RGBA raster layer/cel data is supported; tilemaps, tags, palette profiles,
// reference layers, complex groups and advanced blend modes are still partial.
const enc = new TextEncoder();
const dec = new TextDecoder();
const read16 = (v,p) => v.getUint16(p,true);
const read32 = (v,p) => v.getUint32(p,true);
const int16 = (v,p) => v.getInt16(p,true);
const bytes = (...chunks) => { const total = chunks.reduce((n,a)=>n+a.length,0), out=new Uint8Array(total); let at=0; for(const a of chunks){out.set(a,at);at+=a.length;} return out; };
const view = a => new DataView(a.buffer,a.byteOffset,a.byteLength);
const str = a => { const b=enc.encode(a), out=new Uint8Array(2+b.length);view(out).setUint16(0,b.length,true);out.set(b,2);return out; };
const chunk = (type,body) => { const b=new Uint8Array(6+body.length),v=view(b);v.setUint32(0,b.length,true);v.setUint16(4,type,true);b.set(body,6);return b; };
async function uncompress(raw) {
  if(typeof DecompressionStream==='undefined') throw new Error('El navegador no admite descompresión zlib');
  const s=new Blob([raw]).stream().pipeThrough(new DecompressionStream('deflate'));
  return new Uint8Array(await new Response(s).arrayBuffer());
}
export async function parseAseprite(buffer){
  const a = new Uint8Array(buffer),v=view(a);
  if(a.length<128||read16(v,4)!==0xa5e0) throw new Error('Archivo Aseprite inválido');
  const count=read16(v,6),w=read16(v,8),h=read16(v,10),depth=read16(v,12);
  if(![8,16,32].includes(depth))throw new Error('Profundidad de color Aseprite no reconocida');
  if(!w||!h||w>512||h>512||count>512)throw new Error('Dimensiones o cantidad de fotogramas no admitidas');
  const layers=[],frames=[],tags=[],slices=[];let off=128;
  const palette=Array.from({length:256},(_,i)=>[i,i,i,255]);let modernPalette=false,hasPalette=depth===8;
  const transparentIndex=a[28];
  for(let fi=0;fi<count;fi++){
    if(off+16>a.length||read16(v,off+4)!==0xf1fa)throw new Error('Encabezado de fotograma inválido');
    const length=read32(v,off),end=off+length,oldCount=read16(v,off+6);
    const nChunks=oldCount===0xffff?read32(v,off+12):oldCount;
    if(length<16||end>a.length||nChunks>100000)throw new Error('Fotograma dañado');
    const duration=read16(v,off+8)||100,frame={duration,cels:[]};let cp=off+16;
    for(let ci=0;ci<nChunks;ci++){
      if(cp+6>end)throw new Error('Chunk incompleto');
      const len=read32(v,cp),type=read16(v,cp+4),d=cp+6;
      if(len<6||cp+len>end)throw new Error('Chunk inválido');
      if(type===0x2019 && d+20<=cp+len){modernPalette=true;hasPalette=true;
        const size=read32(v,d),first=read32(v,d+4),last=read32(v,d+8);
        if(size<=65536&&last-first<65536){let at=d+20;
          for(let pi=first;pi<=last && at+6<=cp+len;pi++){
            const flags=read16(v,at);at+=2;
            const color=[a[at],a[at+1],a[at+2],a[at+3]];at+=4;
            if(pi<256)palette[pi]=color;
            if(flags&1){if(at+2>cp+len)break;at+=2+read16(v,at);}
          }
        }
      }
      if(type===0x0004 || type===0x0011){hasPalette=true;
        let pi=0,at=d;const np=read16(v,at);at+=2;
        for(let packet=0;packet<np&&at+2<=cp+len;packet++){
          pi+=a[at++];const num=a[at++]||256;
          for(let k=0;k<num&&at+3<=cp+len;k++,pi++){
            const m=type===0x0011?255/63:1;
            const rgb=[Math.min(255,a[at++]*m),Math.min(255,a[at++]*m),Math.min(255,a[at++]*m),255];
            if(pi<256 && !modernPalette)palette[pi]=rgb;
          }
        }
      }
      if(type===0x2004){
        const flags=read16(v,d),kind=read16(v,d+2),blend=read16(v,d+10),op=a[d+12];
        const nameLen=read16(v,d+16),name=dec.decode(a.subarray(d+18,d+18+nameLen));
        layers.push({name:name||`Layer ${layers.length+1}`,visible:!!(flags&1),editable:!!(flags&2),kind,blend,opacity:op,childLevel:read16(v,d+4)});
      }
      if(type===0x2018 && d+10<=cp+len){
        const n=read16(v,d);let at=d+10;
        for(let ti=0;ti<n&&at+19<=cp+len;ti++){
          const from=read16(v,at),to=read16(v,at+2),direction=a[at+4],repeat=read16(v,at+5),color=[a[at+13],a[at+14],a[at+15]];
          at+=17;const nameLength=read16(v,at);at+=2;
          if(at+nameLength>cp+len)throw new Error('Etiqueta de animación corrupta');
          tags.push({from,to,direction,repeat,color,name:dec.decode(a.subarray(at,at+nameLength))});at+=nameLength;
        }
      }
      if(type===0x2022 && d+14<=cp+len){
        const n=read32(v,d),flags=read32(v,d+4);let at=d+12;
        const nameLength=read16(v,at);at+=2;
        if(at+nameLength>cp+len)throw new Error('Slice con nombre inválido');
        const name=dec.decode(a.subarray(at,at+nameLength));at+=nameLength;
        const keys=[];
        for(let ki=0;ki<n&&at+20<=cp+len;ki++){
          const key={frame:read32(v,at),x:v.getInt32(at+4,true),y:v.getInt32(at+8,true),width:read32(v,at+12),height:read32(v,at+16)};at+=20;
          if(flags&1){if(at+16>cp+len)break;key.center={x:v.getInt32(at,true),y:v.getInt32(at+4,true),width:read32(v,at+8),height:read32(v,at+12)};at+=16;}
          if(flags&2){if(at+8>cp+len)break;key.pivot={x:v.getInt32(at,true),y:v.getInt32(at+4,true)};at+=8;}
          keys.push(key);
        }
        slices.push({name,flags,keys});
      }
      if(type===0x2005){
        const layer=read16(v,d),x=int16(v,d+2),y=int16(v,d+4),typeCel=read16(v,d+7);
        if(typeCel===1){frame.cels.push({layer,link:read16(v,d+16)});}
        else if(typeCel===0||typeCel===2){
          const cw=read16(v,d+16),ch=read16(v,d+18);
          if(cw*ch>512*512)throw new Error('Cel demasiado grande');
          const compressed=a.subarray(d+20,cp+len),pixels=typeCel===2?await uncompress(compressed):new Uint8Array(compressed);
          const bpp=depth/8;
          if(pixels.length!==cw*ch*bpp)throw new Error('Tamaño de cel inválido');
          frame.cels.push({layer,x,y,cw,ch,pixels,depth});
        }
      }
      cp+=len;
    }
    frame.palette=palette.map(c=>[...c]);
    frames.push(frame);off=end;
  }
  if(!layers.length)layers.push({name:'Layer 1',visible:true,kind:0,blend:0,opacity:255});
  const normalized=frames.map((f,idx)=>{
    const links=Array.from({length:layers.length},()=>null);
    const cels=Array.from({length:layers.length},()=>new Uint8ClampedArray(w*h*4));
    for(const c of f.cels){if(c.layer>=layers.length)continue;
      if(c.pixels){
        const dest=new Uint8ClampedArray(w*h*4),{cw,ch,x,y,depth,pixels}=c;
        for(let ry=0;ry<ch;ry++)for(let rx=0;rx<cw;rx++){
          const dx=x+rx,dy=y+ry;if(dx<0||dy<0||dx>=w||dy>=h)continue;
          const source=(ry*cw+rx)*(depth/8),target=(dy*w+dx)*4;
          if(depth===32)dest.set(pixels.subarray(source,source+4),target);
          else if(depth===16){const lum=pixels[source],alpha=pixels[source+1];dest.set([lum,lum,lum,alpha],target);}
          else {const index=pixels[source],rgb=f.palette[index]||[0,0,0,255];dest.set(index===transparentIndex?[rgb[0],rgb[1],rgb[2],0]:rgb,target);}
        }
        cels[c.layer]=dest;
      }
      else if(c.link<idx){cels[c.layer]=new Uint8ClampedArray(frames[c.link]?.resolved?.[c.layer]||cels[c.layer]);links[c.layer]=c.link;}
    }
    f.resolved=cels;
    return {duration:f.duration,cels,links};
  });
  return {width:w,height:h,layers,frames:normalized,palette:hasPalette?palette.map(c=>[...c]):undefined,tags,slices};
}
export function encodeAseprite({width:w,height:h,layers,frames,palette=[],tags=[],slices=[]}){
  if(!w||!h||w>65535||h>65535||frames.length>65535)throw new Error('Dimensiones Aseprite inválidas');
  const chunkLayers=layers.map(l=>{
    const b=new Uint8Array(16);const v=view(b);v.setUint16(0,(l.visible?1:0)|(l.editable===false?0:2),true);v.setUint16(2,l.kind??0,true);v.setUint16(4,l.childLevel??0,true);v.setUint16(10,l.blend??0,true);b[12]=l.opacity??255;
    return chunk(0x2004,bytes(b,str(l.name||'Layer')));
  });
  const metaChunks=[];
  if(Array.isArray(palette)&&palette.length){
    const size=Math.min(256,palette.length),head=new Uint8Array(20),hv=view(head);hv.setUint32(0,size,true);hv.setUint32(4,0,true);hv.setUint32(8,size-1,true);
    const entries=palette.slice(0,size).map(c=>bytes(new Uint8Array(2),new Uint8Array([c[0]??0,c[1]??0,c[2]??0,c[3]??255])));
    metaChunks.push(chunk(0x2019,bytes(head,...entries)));
  }
  if(tags.length){
    const b=new Uint8Array(10);view(b).setUint16(0,tags.length,true);
    const entries=tags.map(tag=>{const item=new Uint8Array(17),v=view(item);v.setUint16(0,tag.from,true);v.setUint16(2,tag.to,true);item[4]=tag.direction??0;v.setUint16(5,tag.repeat??0,true);item.set(tag.color??[0,0,0],13);return bytes(item,str(tag.name??''));});
    metaChunks.push(chunk(0x2018,bytes(b,...entries)));
  }
  for(const slice of slices){
    const flags=slice.flags??0,head=new Uint8Array(12),v=view(head);v.setUint32(0,slice.keys.length,true);v.setUint32(4,flags,true);
    const keys=slice.keys.map(k=>{const b=new Uint8Array(20+((flags&1)?16:0)+((flags&2)?8:0)),q=view(b);q.setUint32(0,k.frame,true);q.setInt32(4,k.x,true);q.setInt32(8,k.y,true);q.setUint32(12,k.width,true);q.setUint32(16,k.height,true);let at=20;if(flags&1){q.setInt32(at,k.center?.x??0,true);q.setInt32(at+4,k.center?.y??0,true);q.setUint32(at+8,k.center?.width??0,true);q.setUint32(at+12,k.center?.height??0,true);at+=16;}if(flags&2){q.setInt32(at,k.pivot?.x??0,true);q.setInt32(at+4,k.pivot?.y??0,true);}return b;});
    metaChunks.push(chunk(0x2022,bytes(head,str(slice.name??''),...keys)));
  }
  const encodedFrames=frames.map((f,i)=>{
    const cels=f.cels.flatMap((cel,layer)=>{
      const target=f.links?.[layer];
      if(target!==undefined&&target!==null){
        if(!Number.isInteger(target)||target<0||target>=i)throw new Error(`Cel enlazado inválido: frame ${i}, layer ${layer}`);
        const b=new Uint8Array(18),v=view(b);v.setUint16(0,layer,true);b[6]=255;v.setUint16(7,1,true);v.setUint16(16,target,true);
        return [chunk(0x2005,b)];
      }
      if(cel.length!==w*h*4)throw new Error('RGBA del cel inválido');
      // Native .aseprite stores a sparse cel with (x,y) offsets and its actual
      // dimensions. Keep all nonzero RGBA bytes, including hidden RGB under alpha 0.
      let minX=w,minY=h,maxX=-1,maxY=-1;
      for(let y=0;y<h;y++)for(let x=0;x<w;x++){
        const at=(y*w+x)*4;
        if(cel[at]||cel[at+1]||cel[at+2]||cel[at+3]){
          if(x<minX)minX=x;if(y<minY)minY=y;
          if(x>maxX)maxX=x;if(y>maxY)maxY=y;
        }
      }
      if(maxX<0)return []; // Empty cel: absence of chunk means empty pixels.
      const cw=maxX-minX+1,ch=maxY-minY+1,body=new Uint8Array(cw*ch*4);
      for(let yy=0;yy<ch;yy++){
        const from=((minY+yy)*w+minX)*4;
        body.set(cel.subarray(from,from+cw*4),yy*cw*4);
      }
      const b=new Uint8Array(20),v=view(b);
      v.setUint16(0,layer,true);v.setInt16(2,minX,true);v.setInt16(4,minY,true);
      b[6]=255;v.setUint16(7,0,true);v.setUint16(16,cw,true);v.setUint16(18,ch,true);
      return [chunk(0x2005,bytes(b,body))];
    });
    const all=i===0?[...chunkLayers,...metaChunks,...cels]:cels,body=bytes(...all);
    const header=new Uint8Array(16),hv=view(header);hv.setUint32(0,16+body.length,true);hv.setUint16(4,0xf1fa,true);hv.setUint16(6,Math.min(0xfffe,all.length),true);hv.setUint16(8,Math.max(1,Math.min(65535,f.duration||100)),true);hv.setUint32(12,all.length,true);
    return bytes(header,body);
  });
  const header=new Uint8Array(128),hv=view(header),content=bytes(...encodedFrames);
  hv.setUint32(0,128+content.length,true);hv.setUint16(4,0xa5e0,true);hv.setUint16(6,frames.length,true);hv.setUint16(8,w,true);hv.setUint16(10,h,true);hv.setUint16(12,32,true);hv.setUint32(14,1,true);hv.setUint16(20,100,true);header[28]=0;hv.setUint16(32,0,true);header[34]=1;header[35]=1;hv.setUint16(36,w,true);hv.setUint16(38,h,true);
  return bytes(header,content);
}

// Recompress raw raster cels with zlib/deflate, as used by Aseprite's native writer.
// Leaves unknown metadata chunks byte-for-byte intact. Falls back to the valid raw
// encoder on platforms without CompressionStream.
export async function encodeAsepriteCompressed(doc) {
  const source=encodeAseprite(doc);
  if(typeof CompressionStream==='undefined')return source;
  const v=view(source),frames=[];
  let off=128;
  for(let frameNo=0;frameNo<doc.frames.length;frameNo++){
    const oldSize=read32(v,off),end=off+oldSize,head=new Uint8Array(source.subarray(off,off+16)),chunks=[];
    let at=off+16;
    while(at<end){
      const size=read32(v,at),type=read16(v,at+4),raw=source.subarray(at,at+size);
      if(type===0x2005&&size>=26&&read16(v,at+6+7)===0){
        const celHeader=new Uint8Array(raw.subarray(6,26));
        view(celHeader).setUint16(7,2,true);
        const compressedStream=new Blob([raw.subarray(26)]).stream().pipeThrough(new CompressionStream('deflate'));
        const compressed=new Uint8Array(await new Response(compressedStream).arrayBuffer());
        chunks.push(chunk(0x2005,bytes(celHeader,compressed)));
      }else chunks.push(new Uint8Array(raw));
      at+=size;
    }
    const body=bytes(...chunks),fh=view(head);fh.setUint32(0,head.length+body.length,true);
    frames.push(bytes(head,body));off=end;
  }
  const header=new Uint8Array(source.subarray(0,128)),content=bytes(...frames);view(header).setUint32(0,128+content.length,true);
  return bytes(header,content);
}
