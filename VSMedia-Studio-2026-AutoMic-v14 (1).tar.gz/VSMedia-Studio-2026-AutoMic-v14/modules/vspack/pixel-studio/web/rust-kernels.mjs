/* Optional WASM acceleration. No runtime setup, no network dependencies.
   The JS fallback remains authoritative if the binary is not packaged. */
let pending;
export async function loadKernels(){
  if(!pending)pending=(async()=>{
    try{
      const url=new URL('./vsmedia-kernels.wasm',import.meta.url);
      const resp=await fetch(url);
      if(!resp.ok)return null;
      const {instance}=await WebAssembly.instantiate(await resp.arrayBuffer(),{});
      const e=instance.exports;
      if(!e.memory||!e.vm_alloc||!e.vm_free||!e.vm_posterize||!e.vm_quantize)return null;
      const inout=(data,fn,more=[])=>{
        const ptr=e.vm_alloc(data.byteLength);
        if(!ptr)throw Error('Memoria WASM insuficiente');
        try{
          new Uint8Array(e.memory.buffer,ptr,data.byteLength).set(data);
          fn(ptr,data.byteLength,...more);
          return new Uint8ClampedArray(new Uint8Array(e.memory.buffer,ptr,data.byteLength));
        }finally{e.vm_free(ptr,data.byteLength);}
      };
      return Object.freeze({kind:'Rust/WASM',posterize:(p,levels)=>inout(p,e.vm_posterize,[levels]),
        quantize:(p,palette)=>{
          const rgb=Uint8Array.from(palette.flatMap(c=>c.slice(0,3))),cp=e.vm_alloc(rgb.length);
          if(!cp)throw Error('Memoria WASM insuficiente');
          try{new Uint8Array(e.memory.buffer,cp,rgb.length).set(rgb);return inout(p,e.vm_quantize,[cp,palette.length]);}
          finally{e.vm_free(cp,rgb.length);}
        }});
    }catch{return null;}
  })();
  return pending;
}
