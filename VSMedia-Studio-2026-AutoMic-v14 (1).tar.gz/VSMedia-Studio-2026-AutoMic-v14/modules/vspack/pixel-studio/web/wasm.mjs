import {PixelEngine} from './fallback.mjs';
const WASM_URL = new URL('./pixel-engine.wasm', import.meta.url);
export async function createEngine(w=32,h=32){
  try{
    const r=await fetch(WASM_URL);
    if(!r.ok)throw Error(`WASM no compilado: ${r.status}`);
    const {instance}=await WebAssembly.instantiate(await r.arrayBuffer(),{});
    // The document engine must support pixel readback, reorder and linked cels.
    // Until the wasm document ABI has these operations, use the complete JS engine.
    // Rust color/math kernels are still loaded independently via rust-kernels.mjs.
    if(!['vp_get_cel_ptr','vp_move_layer','vp_duplicate_layer','vp_get_cel_link','vp_link_cel','vp_unlink_cel'].every(key=>typeof instance.exports[key]==='function') || typeof RustEngine.prototype.moveLayer!=='function' || typeof RustEngine.prototype.duplicateLayer!=='function')return new PixelEngine(w,h);
    const e=new RustEngine(instance.exports,w,h);
    if(!e.p)throw Error('No se pudo crear el documento');
    return e;
  }catch(_err){return new PixelEngine(w,h);}
}
export class RustEngine {
  constructor(exports,w,h){this.wasm=exports;this.p=exports.vp_create(w,h);this.kind='wasm';this.layerNames=['Capa 1'];}
  get width(){return this.wasm.vp_width(this.p);}
  get height(){return this.wasm.vp_height(this.p);}
  get layerCount(){return this.wasm.vp_layer_count(this.p);}
  get frameCount(){return this.wasm.vp_frame_count(this.p);}
  get activeLayer(){return this.wasm.vp_active_layer(this.p);}
  get activeFrame(){return this.wasm.vp_active_frame(this.p);}
  get layers(){return Array.from({length:this.layerCount},(_,i)=>({name:this.layerNames[i]||`Capa ${i+1}`,visible:!!this.wasm.vp_visible(this.p,i)}));}
  get duration(){return this.wasm.vp_duration(this.p);}
  set duration(v){this.wasm.vp_set_duration(this.p,v);}
  begin(){this.wasm.vp_begin(this.p);}
  end(){this.wasm.vp_end(this.p);}
  transaction(fn){this.begin();try{fn();}finally{this.end();}}
  pixel(x,y,c){this.wasm.vp_pixel(this.p,x,y,c>>>0);}
  line(a,b,c,d,col){this.wasm.vp_line(this.p,a,b,c,d,col>>>0);}
  rect(a,b,c,d,col){this.wasm.vp_rect(this.p,a,b,c,d,col>>>0);}
  fill(x,y,c){this.wasm.vp_fill(this.p,x,y,c>>>0);}
  selectLayer(i){this.wasm.vp_select_layer(this.p,i);}
  selectFrame(i){this.wasm.vp_select_frame(this.p,i);}
  addLayer(){this.wasm.vp_add_layer(this.p);this.layerNames.push(`Capa ${this.layerNames.length+1}`);}
  addFrame(){this.wasm.vp_add_frame(this.p);}
  deleteFrame(i){if(this.wasm.vp_delete_frame)this.wasm.vp_delete_frame(this.p,i);}
  getCelPixels(frame=this.activeFrame,layer=this.activeLayer){
    if(!this.wasm.vp_get_cel_ptr)throw new Error('Recompilá el motor Rust para leer capas individuales');
    const ptr=this.wasm.vp_get_cel_ptr(this.p,frame,layer);
    if(!ptr)throw new Error('Cel no encontrado');
    return new Uint8ClampedArray(new Uint8Array(this.wasm.memory.buffer,ptr,this.width*this.height*4));
  }
  toggleLayer(i){this.wasm.vp_toggle_layer(this.p,i);}
  deleteLayer(i){this.wasm.vp_delete_layer(this.p,i);this.layerNames.splice(i,1);}
  undo(){return !!this.wasm.vp_undo(this.p);}
  redo(){return !!this.wasm.vp_redo(this.p);}
  render(frame=this.activeFrame){const old=this.activeFrame;if(frame!==old)this.selectFrame(frame);const ptr=this.wasm.vp_render(this.p),len=this.width*this.height*4;const out=new Uint8ClampedArray(new Uint8Array(this.wasm.memory.buffer,ptr,len));if(frame!==old)this.selectFrame(old);return out;}
  setCelPixels(data){const len=this.width*this.height*4;if(data.length!==len)throw Error('Tamaño RGBA inválido');const ptr=this.wasm.vp_staging_ptr(this.p);new Uint8Array(this.wasm.memory.buffer,ptr,len).set(data);this.wasm.vp_commit_pixels(this.p);}
  dispose(){if(this.p){this.wasm.vp_free(this.p);this.p=0;}}
}
