# VSPack → VS Model Studio v0.2 (fuente original)

## Reemplazo
Se eliminó el visor geométrico inventado de VSPack y se instaló el Web Component real `vs-model-studio/embed/component.js` del ZIP compartido por el usuario. El editor aparece dentro del gestor Modelos, con su navegación general alrededor. Se reutiliza el protocolo de la fuente `vs-model-studio/v1` con validación de origen para abrir y exportar `.bbmodel`.

## Estado verdadero
**Esta fuente no contiene `dist/bundle.js`.** No hay build de Blockbench listo para uso inmediato. La web VSPack abre sin compilar nada, Pixel Studio sigue disponible, pero Model Studio muestra un aviso de dependencia ausente hasta disponer de una distribución web compilada de esa misma fuente. No se utiliza un clon como respaldo.

El código del editor original se conserva en `vs-model-studio/`; su licencia GPL-3.0-or-later está en `vs-model-studio/LICENSE.MD`. No se modifican plugins ni repositorios. El paquete no incluye ficheros de tipografía que se encuentran en el ZIP fuente facilitado por el usuario.

## Flujo conectado (cuando esté el bundle)
Gestores → Modelos → Seleccionar `.bbmodel` → Abrir VS Model Studio → edición original → Guardar en pack. Los bytes del JSON exportado se guardan por IndexedDB usando el contrato existente de VSPack. El botón Volver regresa al gestor y avisa de cambios pendientes cuando el componente los comunica.

El editor original usa un DOM original dentro del documento principal en el Web Component dentro de la misma pantalla; **no abre otra pestaña**. No es un port completo a Rust.
