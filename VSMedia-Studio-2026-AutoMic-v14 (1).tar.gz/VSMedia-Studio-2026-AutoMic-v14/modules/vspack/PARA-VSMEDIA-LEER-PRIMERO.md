# VSPack Foundry 2.0 — Entrega para integrar en VSMedia

## Qué contiene

Web estática autónoma de **VSPack**, más VS Pixel Studio integrado y VS Model Studio integrado. Mantiene la interfaz de grafito cálido y dorado mate, sin demos ni backend; **no** contiene VSAudio, VSMix ni VSRadio, porque estos pertenecen a la web principal de VSMedia.

## Cómo incorporarlo

1. Copiar **toda la carpeta** de esta entrega a `public/modules/vspack/` (o directorio estático equivalente). **No separar** `assets/`, `pixel-studio/` ni `model-studio/`.
2. Desde el Home de VSMedia, abrir `/modules/vspack/index.html?embed=1&view=library` en un `iframe` integrado del mismo origen. La página VSPack oculta su marca y barra superior; deja únicamente su navegación interna de gestores y la zona de trabajo.
3. El `iframe` debe tener un área de altura completa (por ejemplo `height:calc(100dvh - 56px)`), y debe permitirse descargar ZIP y acceder a IndexedDB. No usar `sandbox` restrictivo que bloquee scripts, mismo origen o descargas.
4. Para una integración sin `iframe`, también es posible adaptar directamente `assets/app.js` al contenedor de VSMedia, pero será necesario modularizar sus dependencias DOM y CSS; **ese montaje directo aún no forma parte de esta entrega**.

### Ejemplo de montaje (mismo origen)

```html
<iframe id="vspack" title="Gestor VSPack" src="/modules/vspack/index.html?embed=1&view=managers&manager=textures" style="display:block;width:100%;height:calc(100dvh - 56px);border:0" allow="clipboard-read; clipboard-write"></iframe>
```

### Enviar comandos desde VSMedia

Los mensajes solo se admiten si VSMedia y VSPack están en **el mismo origen** (`protocolo + host + puerto` iguales). Un VSMedia servido en `127.0.0.1:3060` y un VSPack en `127.0.0.1:3061` son orígenes diferentes y no comparten IndexedDB.

```js
const frame = document.getElementById('vspack');
const origin = window.location.origin;
frame.contentWindow.postMessage({
  source: 'vsmedia', type: 'NAVIGATE', requestId: 'abrir-texturas',
  view: 'managers', manager: 'textures'
}, origin);
window.addEventListener('message', (event) => {
  if (event.origin !== origin || event.source !== frame.contentWindow) return;
  if (event.data?.source === 'vspack') console.log(event.data);
});
```

### Protocolo `vspack-host-v1`

Comandos soportados:
- `GET_STATE` sin argumentos: metadatos de la biblioteca, sin bytes privados.
- `NAVIGATE` con `view` (`library`, `managers`, `editor`, `composer`, `publisher`) y `manager` opcional (`packs`, `files`, `textures`, `models`, `items`, `interfaces`, `diagnostics`).
- `SELECT_PACK` con `packId` de un pack existente.
- `OPEN_ASSET` con `packId`, `path` y `editor` opcional (`auto`, `pixel`, `model`, `text`).

Respuestas: `{source:'vspack', type:'RESPONSE', requestId, result, error}`; notificaciones `{source:'vspack',type:'ready'|'change',schema,version,view,manager,activePackId,packs,selectedAssetId}`.

Cuando están en el mismo origen, también existe `iframe.contentWindow.VSPackHost` con `version`, `snapshot()`, `navigate()`, `selectPack()`, `openAsset()`.

## Funciones reales incorporadas

- Biblioteca y explorador: packs, ZIP, carpetas, filtros, archivos y metadatos locales.
- VS Pixel Studio: herramientas de edición de sprites, capas, timeline, archivos compatibles, guardado al pack.
- VS Model Studio: edición geométrica de cubos, JSON y `.bbmodel`, UV/atlas limitado y guardado al pack.
- Editor contextual de GUI/HUD y vistas previas, compositor por prioridades, validador local y exportador ZIP.
- Almacenamiento **IndexedDB** `vspack-local-v1`: no cambia el esquema y no lo borra en esta entrega.

## Limitaciones reales que VSMedia debe conocer

- El código de la interfaz principal y buena parte de los editores utiliza JavaScript; Rust está incluido como **código fuente experimental**, no como WASM de producción.
- El visor local de modelos es geométrico; no equivale al renderer original de Blockbench. El proyecto de Model Studio aportado no traía su ejecutable web completo. Si se incorpora legalmente a `model-studio/vendor/blockbench/`, seguir `docs/INTEGRACION-VS-MODEL-STUDIO-v1.9.md`.
- No hay integración con servidor Minecraft, plugins, nube ni publicación remota. **Solo descarga ZIP local.**
- El gestor de audio no aparece: VSPack conserva los audios presentes en ZIP, sin editarlos. VSAudio/VSRadio son módulos de VSMedia.
- Un `iframe` del mismo origen sigue siendo un componente integrado visualmente dentro de la web de VSMedia, pero no comparte el DOM de VSMedia; convertirlo en componente JavaScript nativo requeriría una segunda refactorización.

## Comandos de prueba

```sh
./start.sh
node --check assets/app.js
node --check assets/model-bridge.mjs
node test-viewport.mjs
node test-compositor.mjs
(cd pixel-studio && npm test)
(cd model-studio && npm test)
```

La web se sirve por HTTP local (no con `file://`). No ejecutar en sitios públicos sin definir autenticación, políticas de archivos y límites; actualmente todo es local y la biblioteca pertenece al navegador.


### Blockbench 5.2.2 (v2.1)

Se añadió conexión para la web original Blockbench 5.2.2 en **Gestores → Modelos**. Su compilación requiere una instalación local de las fuentes del ZIP original suministrado por el usuario; consultar [`INTEGRACION-BLOCKBENCH-v2.1.md`](INTEGRACION-BLOCKBENCH-v2.1.md). VSMedia no debe reemplazar `model-studio/vendor/blockbench/` ni copiarlo fuera del mismo origen; el puente requiere que el iframe comparta origen con VSPack.
